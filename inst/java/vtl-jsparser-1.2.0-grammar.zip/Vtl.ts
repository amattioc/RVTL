// Generated from it/bancaditalia/oss/vtl/grammar/Vtl.g4 by ANTLR 4.13.1
// noinspection ES6UnusedImports,JSUnusedGlobalSymbols,JSUnusedLocalSymbols

import {
	ATN,
	ATNDeserializer, DecisionState, DFA, FailedPredicateException,
	RecognitionException, NoViableAltException, BailErrorStrategy,
	Parser, ParserATNSimulator,
	RuleContext, ParserRuleContext, PredictionMode, PredictionContextCache,
	TerminalNode, RuleNode,
	Token, TokenStream,
	Interval, IntervalSet
} from 'antlr4';
import VtlVisitor from "./VtlVisitor.js";

// for running tests with parameters, TODO: discuss strategy for typed parameters in CI
// eslint-disable-next-line no-unused-vars
type int = number;

export default class Vtl extends Parser {
	public static readonly LPAREN = 1;
	public static readonly RPAREN = 2;
	public static readonly QLPAREN = 3;
	public static readonly QRPAREN = 4;
	public static readonly GLPAREN = 5;
	public static readonly GRPAREN = 6;
	public static readonly EQ = 7;
	public static readonly LT = 8;
	public static readonly MT = 9;
	public static readonly ME = 10;
	public static readonly NEQ = 11;
	public static readonly LE = 12;
	public static readonly PLUS = 13;
	public static readonly MINUS = 14;
	public static readonly MUL = 15;
	public static readonly DIV = 16;
	public static readonly COMMA = 17;
	public static readonly POINTER = 18;
	public static readonly ASSIGN = 19;
	public static readonly MEMBERSHIP = 20;
	public static readonly COLON = 21;
	public static readonly EVAL = 22;
	public static readonly IF = 23;
	public static readonly THEN = 24;
	public static readonly ELSE = 25;
	public static readonly USING = 26;
	public static readonly WITH = 27;
	public static readonly CURRENT_DATE = 28;
	public static readonly ON = 29;
	public static readonly DROP = 30;
	public static readonly KEEP = 31;
	public static readonly CALC = 32;
	public static readonly ATTRCALC = 33;
	public static readonly RENAME = 34;
	public static readonly AS = 35;
	public static readonly AND = 36;
	public static readonly OR = 37;
	public static readonly XOR = 38;
	public static readonly NOT = 39;
	public static readonly BETWEEN = 40;
	public static readonly IN = 41;
	public static readonly NOT_IN = 42;
	public static readonly NULL_CONSTANT = 43;
	public static readonly ISNULL = 44;
	public static readonly EX = 45;
	public static readonly UNION = 46;
	public static readonly DIFF = 47;
	public static readonly SYMDIFF = 48;
	public static readonly INTERSECT = 49;
	public static readonly KEYS = 50;
	public static readonly INTYEAR = 51;
	public static readonly INTMONTH = 52;
	public static readonly INTDAY = 53;
	public static readonly CHECK = 54;
	public static readonly EXISTS_IN = 55;
	public static readonly TO = 56;
	public static readonly RETURN = 57;
	public static readonly IMBALANCE = 58;
	public static readonly ERRORCODE = 59;
	public static readonly ALL = 60;
	public static readonly AGGREGATE = 61;
	public static readonly ERRORLEVEL = 62;
	public static readonly ORDER = 63;
	public static readonly BY = 64;
	public static readonly RANK = 65;
	public static readonly ASC = 66;
	public static readonly DESC = 67;
	public static readonly MIN = 68;
	public static readonly MAX = 69;
	public static readonly FIRST = 70;
	public static readonly LAST = 71;
	public static readonly INDEXOF = 72;
	public static readonly ABS = 73;
	public static readonly KEY = 74;
	public static readonly LN = 75;
	public static readonly LOG = 76;
	public static readonly TRUNC = 77;
	public static readonly ROUND = 78;
	public static readonly POWER = 79;
	public static readonly MOD = 80;
	public static readonly LEN = 81;
	public static readonly CONCAT = 82;
	public static readonly TRIM = 83;
	public static readonly UCASE = 84;
	public static readonly LCASE = 85;
	public static readonly SUBSTR = 86;
	public static readonly SUM = 87;
	public static readonly AVG = 88;
	public static readonly MEDIAN = 89;
	public static readonly COUNT = 90;
	public static readonly DIMENSION = 91;
	public static readonly MEASURE = 92;
	public static readonly ATTRIBUTE = 93;
	public static readonly FILTER = 94;
	public static readonly MERGE = 95;
	public static readonly EXP = 96;
	public static readonly ROLE = 97;
	public static readonly VIRAL = 98;
	public static readonly CHARSET_MATCH = 99;
	public static readonly TYPE = 100;
	public static readonly NVL = 101;
	public static readonly HIERARCHY = 102;
	public static readonly OPTIONAL = 103;
	public static readonly INVALID = 104;
	public static readonly VALUE_DOMAIN = 105;
	public static readonly VARIABLE = 106;
	public static readonly DATA = 107;
	public static readonly STRUCTURE = 108;
	public static readonly DATASET = 109;
	public static readonly OPERATOR = 110;
	public static readonly DEFINE = 111;
	public static readonly PUT_SYMBOL = 112;
	public static readonly DATAPOINT = 113;
	public static readonly HIERARCHICAL = 114;
	public static readonly RULESET = 115;
	public static readonly RULE = 116;
	public static readonly END = 117;
	public static readonly ALTER_DATASET = 118;
	public static readonly LTRIM = 119;
	public static readonly RTRIM = 120;
	public static readonly INSTR = 121;
	public static readonly REPLACE = 122;
	public static readonly CEIL = 123;
	public static readonly FLOOR = 124;
	public static readonly SQRT = 125;
	public static readonly ANY = 126;
	public static readonly SETDIFF = 127;
	public static readonly STDDEV_POP = 128;
	public static readonly STDDEV_SAMP = 129;
	public static readonly VAR_POP = 130;
	public static readonly VAR_SAMP = 131;
	public static readonly GROUP = 132;
	public static readonly EXCEPT = 133;
	public static readonly HAVING = 134;
	public static readonly FIRST_VALUE = 135;
	public static readonly LAST_VALUE = 136;
	public static readonly LAG = 137;
	public static readonly LEAD = 138;
	public static readonly RATIO_TO_REPORT = 139;
	public static readonly OVER = 140;
	public static readonly PRECEDING = 141;
	public static readonly FOLLOWING = 142;
	public static readonly UNBOUNDED = 143;
	public static readonly PARTITION = 144;
	public static readonly ROWS = 145;
	public static readonly RANGE = 146;
	public static readonly CURRENT = 147;
	public static readonly VALID = 148;
	public static readonly FILL_TIME_SERIES = 149;
	public static readonly FLOW_TO_STOCK = 150;
	public static readonly STOCK_TO_FLOW = 151;
	public static readonly TIMESHIFT = 152;
	public static readonly MEASURES = 153;
	public static readonly NO_MEASURES = 154;
	public static readonly CONDITION = 155;
	public static readonly BOOLEAN = 156;
	public static readonly DATE = 157;
	public static readonly TIME_PERIOD = 158;
	public static readonly NUMBER = 159;
	public static readonly STRING = 160;
	public static readonly TIME = 161;
	public static readonly INTEGER = 162;
	public static readonly FLOAT = 163;
	public static readonly LIST = 164;
	public static readonly RECORD = 165;
	public static readonly RESTRICT = 166;
	public static readonly YYYY = 167;
	public static readonly MM = 168;
	public static readonly DD = 169;
	public static readonly MAX_LENGTH = 170;
	public static readonly REGEXP = 171;
	public static readonly IS = 172;
	public static readonly WHEN = 173;
	public static readonly FROM = 174;
	public static readonly AGGREGATES = 175;
	public static readonly POINTS = 176;
	public static readonly POINT = 177;
	public static readonly TOTAL = 178;
	public static readonly PARTIAL = 179;
	public static readonly ALWAYS = 180;
	public static readonly INNER_JOIN = 181;
	public static readonly LEFT_JOIN = 182;
	public static readonly CROSS_JOIN = 183;
	public static readonly FULL_JOIN = 184;
	public static readonly MAPS_FROM = 185;
	public static readonly MAPS_TO = 186;
	public static readonly MAP_TO = 187;
	public static readonly MAP_FROM = 188;
	public static readonly RETURNS = 189;
	public static readonly PIVOT = 190;
	public static readonly CUSTOMPIVOT = 191;
	public static readonly UNPIVOT = 192;
	public static readonly SUBSPACE = 193;
	public static readonly APPLY = 194;
	public static readonly CONDITIONED = 195;
	public static readonly PERIOD_INDICATOR = 196;
	public static readonly SINGLE = 197;
	public static readonly DURATION = 198;
	public static readonly TIME_AGG = 199;
	public static readonly UNIT = 200;
	public static readonly VALUE = 201;
	public static readonly VALUEDOMAINS = 202;
	public static readonly VARIABLES = 203;
	public static readonly INPUT = 204;
	public static readonly OUTPUT = 205;
	public static readonly CAST = 206;
	public static readonly RULE_PRIORITY = 207;
	public static readonly DATASET_PRIORITY = 208;
	public static readonly DEFAULT = 209;
	public static readonly CHECK_DATAPOINT = 210;
	public static readonly CHECK_HIERARCHY = 211;
	public static readonly COMPUTED = 212;
	public static readonly NON_NULL = 213;
	public static readonly NON_ZERO = 214;
	public static readonly PARTIAL_NULL = 215;
	public static readonly PARTIAL_ZERO = 216;
	public static readonly ALWAYS_NULL = 217;
	public static readonly ALWAYS_ZERO = 218;
	public static readonly COMPONENTS = 219;
	public static readonly ALL_MEASURES = 220;
	public static readonly SCALAR = 221;
	public static readonly COMPONENT = 222;
	public static readonly DATAPOINT_ON_VD = 223;
	public static readonly DATAPOINT_ON_VAR = 224;
	public static readonly HIERARCHICAL_ON_VD = 225;
	public static readonly HIERARCHICAL_ON_VAR = 226;
	public static readonly SET = 227;
	public static readonly LANGUAGE = 228;
	public static readonly INTEGER_CONSTANT = 229;
	public static readonly NUMBER_CONSTANT = 230;
	public static readonly BOOLEAN_CONSTANT = 231;
	public static readonly STRING_CONSTANT = 232;
	public static readonly TIME_UNIT = 233;
	public static readonly IDENTIFIER = 234;
	public static readonly WS = 235;
	public static readonly EOL = 236;
	public static readonly ML_COMMENT = 237;
	public static readonly SL_COMMENT = 238;
	public static readonly EOF = Token.EOF;
	public static readonly RULE_start = 0;
	public static readonly RULE_statement = 1;
	public static readonly RULE_expr = 2;
	public static readonly RULE_exprComponent = 3;
	public static readonly RULE_functionsComponents = 4;
	public static readonly RULE_functions = 5;
	public static readonly RULE_datasetClause = 6;
	public static readonly RULE_renameClause = 7;
	public static readonly RULE_aggrClause = 8;
	public static readonly RULE_filterClause = 9;
	public static readonly RULE_calcClause = 10;
	public static readonly RULE_keepOrDropClause = 11;
	public static readonly RULE_pivotOrUnpivotClause = 12;
	public static readonly RULE_subspaceClause = 13;
	public static readonly RULE_joinOperators = 14;
	public static readonly RULE_defOperators = 15;
	public static readonly RULE_genericOperators = 16;
	public static readonly RULE_genericOperatorsComponent = 17;
	public static readonly RULE_parameterComponent = 18;
	public static readonly RULE_parameter = 19;
	public static readonly RULE_stringOperators = 20;
	public static readonly RULE_stringOperatorsComponent = 21;
	public static readonly RULE_numericOperators = 22;
	public static readonly RULE_numericOperatorsComponent = 23;
	public static readonly RULE_comparisonOperators = 24;
	public static readonly RULE_comparisonOperatorsComponent = 25;
	public static readonly RULE_timeOperators = 26;
	public static readonly RULE_timeOperatorsComponent = 27;
	public static readonly RULE_setOperators = 28;
	public static readonly RULE_hierarchyOperators = 29;
	public static readonly RULE_validationOperators = 30;
	public static readonly RULE_conditionalOperators = 31;
	public static readonly RULE_conditionalOperatorsComponent = 32;
	public static readonly RULE_aggrOperators = 33;
	public static readonly RULE_aggrOperatorsGrouping = 34;
	public static readonly RULE_anFunction = 35;
	public static readonly RULE_anFunctionComponent = 36;
	public static readonly RULE_renameClauseItem = 37;
	public static readonly RULE_aggregateClause = 38;
	public static readonly RULE_aggrFunctionClause = 39;
	public static readonly RULE_calcClauseItem = 40;
	public static readonly RULE_subspaceClauseItem = 41;
	public static readonly RULE_joinClauseWithoutUsing = 42;
	public static readonly RULE_joinClause = 43;
	public static readonly RULE_joinClauseItem = 44;
	public static readonly RULE_joinBody = 45;
	public static readonly RULE_joinApplyClause = 46;
	public static readonly RULE_partitionByClause = 47;
	public static readonly RULE_orderByClause = 48;
	public static readonly RULE_orderByItem = 49;
	public static readonly RULE_windowingClause = 50;
	public static readonly RULE_signedInteger = 51;
	public static readonly RULE_limitClauseItem = 52;
	public static readonly RULE_groupingClause = 53;
	public static readonly RULE_havingClause = 54;
	public static readonly RULE_parameterItem = 55;
	public static readonly RULE_outputParameterType = 56;
	public static readonly RULE_outputParameterTypeComponent = 57;
	public static readonly RULE_inputParameterType = 58;
	public static readonly RULE_rulesetType = 59;
	public static readonly RULE_scalarType = 60;
	public static readonly RULE_componentType = 61;
	public static readonly RULE_datasetType = 62;
	public static readonly RULE_scalarSetType = 63;
	public static readonly RULE_dpRuleset = 64;
	public static readonly RULE_hrRuleset = 65;
	public static readonly RULE_valueDomainName = 66;
	public static readonly RULE_rulesetID = 67;
	public static readonly RULE_rulesetSignature = 68;
	public static readonly RULE_signature = 69;
	public static readonly RULE_ruleClauseDatapoint = 70;
	public static readonly RULE_ruleItemDatapoint = 71;
	public static readonly RULE_ruleClauseHierarchical = 72;
	public static readonly RULE_ruleItemHierarchical = 73;
	public static readonly RULE_hierRuleSignature = 74;
	public static readonly RULE_valueDomainSignature = 75;
	public static readonly RULE_codeItemRelation = 76;
	public static readonly RULE_codeItemRelationClause = 77;
	public static readonly RULE_valueDomainValue = 78;
	public static readonly RULE_scalarTypeConstraint = 79;
	public static readonly RULE_compConstraint = 80;
	public static readonly RULE_multModifier = 81;
	public static readonly RULE_validationOutput = 82;
	public static readonly RULE_validationMode = 83;
	public static readonly RULE_conditionClause = 84;
	public static readonly RULE_inputMode = 85;
	public static readonly RULE_imbalanceExpr = 86;
	public static readonly RULE_inputModeHierarchy = 87;
	public static readonly RULE_outputModeHierarchy = 88;
	public static readonly RULE_alias = 89;
	public static readonly RULE_varID = 90;
	public static readonly RULE_simpleComponentId = 91;
	public static readonly RULE_componentID = 92;
	public static readonly RULE_inexpr = 93;
	public static readonly RULE_erCode = 94;
	public static readonly RULE_erLevel = 95;
	public static readonly RULE_comparisonOperand = 96;
	public static readonly RULE_optionalExpr = 97;
	public static readonly RULE_optionalExprComponent = 98;
	public static readonly RULE_componentRole = 99;
	public static readonly RULE_viralAttribute = 100;
	public static readonly RULE_valueDomainID = 101;
	public static readonly RULE_operatorID = 102;
	public static readonly RULE_routineName = 103;
	public static readonly RULE_constant = 104;
	public static readonly RULE_basicScalarType = 105;
	public static readonly RULE_retainType = 106;
	public static readonly literalNames: (string | null)[] = [ null, "'('", 
                                                            "')'", "'['", 
                                                            "']'", "'{'", 
                                                            "'}'", "'='", 
                                                            "'<'", "'>'", 
                                                            "'>='", "'<>'", 
                                                            "'<='", "'+'", 
                                                            "'-'", "'*'", 
                                                            "'/'", "','", 
                                                            "'->'", "':='", 
                                                            "'#'", "':'", 
                                                            "'eval'", "'if'", 
                                                            "'then'", "'else'", 
                                                            "'using'", "'with'", 
                                                            "'current_date'", 
                                                            "'on'", "'drop'", 
                                                            "'keep'", "'calc'", 
                                                            "'attrcalc'", 
                                                            "'rename'", 
                                                            "'as'", "'and'", 
                                                            "'or'", "'xor'", 
                                                            "'not'", "'between'", 
                                                            "'in'", "'not_in'", 
                                                            "'null'", "'isnull'", 
                                                            "'ex'", "'union'", 
                                                            "'diff'", "'symdiff'", 
                                                            "'intersect'", 
                                                            "'keys'", "'intyear'", 
                                                            "'intmonth'", 
                                                            "'intday'", 
                                                            "'check'", "'exists_in'", 
                                                            "'to'", "'return'", 
                                                            "'imbalance'", 
                                                            "'errorcode'", 
                                                            "'all'", "'aggr'", 
                                                            "'errorlevel'", 
                                                            "'order'", "'by'", 
                                                            "'rank'", "'asc'", 
                                                            "'desc'", "'min'", 
                                                            "'max'", "'first'", 
                                                            "'last'", "'indexof'", 
                                                            "'abs'", "'key'", 
                                                            "'ln'", "'log'", 
                                                            "'trunc'", "'round'", 
                                                            "'power'", "'mod'", 
                                                            "'length'", 
                                                            "'||'", "'trim'", 
                                                            "'upper'", "'lower'", 
                                                            "'substr'", 
                                                            "'sum'", "'avg'", 
                                                            "'median'", 
                                                            "'count'", "'identifier'", 
                                                            "'measure'", 
                                                            "'attribute'", 
                                                            "'filter'", 
                                                            "'merge'", "'exp'", 
                                                            "'componentRole'", 
                                                            "'viral'", "'match_characters'", 
                                                            "'type'", "'nvl'", 
                                                            "'hierarchy'", 
                                                            "'_'", "'invalid'", 
                                                            "'valuedomain'", 
                                                            "'variable'", 
                                                            "'data'", "'structure'", 
                                                            "'dataset'", 
                                                            "'operator'", 
                                                            "'define'", 
                                                            "'<-'", "'datapoint'", 
                                                            "'hierarchical'", 
                                                            "'ruleset'", 
                                                            "'rule'", "'end'", 
                                                            "'alterDataset'", 
                                                            "'ltrim'", "'rtrim'", 
                                                            "'instr'", "'replace'", 
                                                            "'ceil'", "'floor'", 
                                                            "'sqrt'", "'any'", 
                                                            "'setdiff'", 
                                                            "'stddev_pop'", 
                                                            "'stddev_samp'", 
                                                            "'var_pop'", 
                                                            "'var_samp'", 
                                                            "'group'", "'except'", 
                                                            "'having'", 
                                                            "'first_value'", 
                                                            "'last_value'", 
                                                            "'lag'", "'lead'", 
                                                            "'ratio_to_report'", 
                                                            "'over'", "'preceding'", 
                                                            "'following'", 
                                                            "'unbounded'", 
                                                            "'partition'", 
                                                            "'rows'", "'range'", 
                                                            "'current'", 
                                                            "'valid'", "'fill_time_series'", 
                                                            "'flow_to_stock'", 
                                                            "'stock_to_flow'", 
                                                            "'timeshift'", 
                                                            "'measures'", 
                                                            "'no_measures'", 
                                                            "'condition'", 
                                                            "'boolean'", 
                                                            "'date'", "'time_period'", 
                                                            "'number'", 
                                                            "'string'", 
                                                            "'time'", "'integer'", 
                                                            "'float'", "'list'", 
                                                            "'record'", 
                                                            "'restrict'", 
                                                            "'yyyy'", "'mm'", 
                                                            "'dd'", "'maxLength'", 
                                                            "'regexp'", 
                                                            "'is'", "'when'", 
                                                            "'from'", "'aggregates'", 
                                                            "'points'", 
                                                            "'point'", "'total'", 
                                                            "'partial'", 
                                                            "'always'", 
                                                            "'inner_join'", 
                                                            "'left_join'", 
                                                            "'cross_join'", 
                                                            "'full_join'", 
                                                            "'maps_from'", 
                                                            "'maps_to'", 
                                                            "'map_to'", 
                                                            "'map_from'", 
                                                            "'returns'", 
                                                            "'pivot'", "'customPivot'", 
                                                            "'unpivot'", 
                                                            "'sub'", "'apply'", 
                                                            "'conditioned'", 
                                                            "'period_indicator'", 
                                                            "'single'", 
                                                            "'duration'", 
                                                            "'time_agg'", 
                                                            "'unit'", "'Value'", 
                                                            "'valuedomains'", 
                                                            "'variables'", 
                                                            "'input'", "'output'", 
                                                            "'cast'", "'rule_priority'", 
                                                            "'dataset_priority'", 
                                                            "'default'", 
                                                            "'check_datapoint'", 
                                                            "'check_hierarchy'", 
                                                            "'computed'", 
                                                            "'non_null'", 
                                                            "'non_zero'", 
                                                            "'partial_null'", 
                                                            "'partial_zero'", 
                                                            "'always_null'", 
                                                            "'always_zero'", 
                                                            "'components'", 
                                                            "'all_measures'", 
                                                            "'scalar'", 
                                                            "'component'", 
                                                            "'datapoint_on_valuedomains'", 
                                                            "'datapoint_on_variables'", 
                                                            "'hierarchical_on_valuedomains'", 
                                                            "'hierarchical_on_variables'", 
                                                            "'set'", "'language'", 
                                                            null, null, 
                                                            null, null, 
                                                            null, null, 
                                                            null, "';'" ];
	public static readonly symbolicNames: (string | null)[] = [ null, "LPAREN", 
                                                             "RPAREN", "QLPAREN", 
                                                             "QRPAREN", 
                                                             "GLPAREN", 
                                                             "GRPAREN", 
                                                             "EQ", "LT", 
                                                             "MT", "ME", 
                                                             "NEQ", "LE", 
                                                             "PLUS", "MINUS", 
                                                             "MUL", "DIV", 
                                                             "COMMA", "POINTER", 
                                                             "ASSIGN", "MEMBERSHIP", 
                                                             "COLON", "EVAL", 
                                                             "IF", "THEN", 
                                                             "ELSE", "USING", 
                                                             "WITH", "CURRENT_DATE", 
                                                             "ON", "DROP", 
                                                             "KEEP", "CALC", 
                                                             "ATTRCALC", 
                                                             "RENAME", "AS", 
                                                             "AND", "OR", 
                                                             "XOR", "NOT", 
                                                             "BETWEEN", 
                                                             "IN", "NOT_IN", 
                                                             "NULL_CONSTANT", 
                                                             "ISNULL", "EX", 
                                                             "UNION", "DIFF", 
                                                             "SYMDIFF", 
                                                             "INTERSECT", 
                                                             "KEYS", "INTYEAR", 
                                                             "INTMONTH", 
                                                             "INTDAY", "CHECK", 
                                                             "EXISTS_IN", 
                                                             "TO", "RETURN", 
                                                             "IMBALANCE", 
                                                             "ERRORCODE", 
                                                             "ALL", "AGGREGATE", 
                                                             "ERRORLEVEL", 
                                                             "ORDER", "BY", 
                                                             "RANK", "ASC", 
                                                             "DESC", "MIN", 
                                                             "MAX", "FIRST", 
                                                             "LAST", "INDEXOF", 
                                                             "ABS", "KEY", 
                                                             "LN", "LOG", 
                                                             "TRUNC", "ROUND", 
                                                             "POWER", "MOD", 
                                                             "LEN", "CONCAT", 
                                                             "TRIM", "UCASE", 
                                                             "LCASE", "SUBSTR", 
                                                             "SUM", "AVG", 
                                                             "MEDIAN", "COUNT", 
                                                             "DIMENSION", 
                                                             "MEASURE", 
                                                             "ATTRIBUTE", 
                                                             "FILTER", "MERGE", 
                                                             "EXP", "ROLE", 
                                                             "VIRAL", "CHARSET_MATCH", 
                                                             "TYPE", "NVL", 
                                                             "HIERARCHY", 
                                                             "OPTIONAL", 
                                                             "INVALID", 
                                                             "VALUE_DOMAIN", 
                                                             "VARIABLE", 
                                                             "DATA", "STRUCTURE", 
                                                             "DATASET", 
                                                             "OPERATOR", 
                                                             "DEFINE", "PUT_SYMBOL", 
                                                             "DATAPOINT", 
                                                             "HIERARCHICAL", 
                                                             "RULESET", 
                                                             "RULE", "END", 
                                                             "ALTER_DATASET", 
                                                             "LTRIM", "RTRIM", 
                                                             "INSTR", "REPLACE", 
                                                             "CEIL", "FLOOR", 
                                                             "SQRT", "ANY", 
                                                             "SETDIFF", 
                                                             "STDDEV_POP", 
                                                             "STDDEV_SAMP", 
                                                             "VAR_POP", 
                                                             "VAR_SAMP", 
                                                             "GROUP", "EXCEPT", 
                                                             "HAVING", "FIRST_VALUE", 
                                                             "LAST_VALUE", 
                                                             "LAG", "LEAD", 
                                                             "RATIO_TO_REPORT", 
                                                             "OVER", "PRECEDING", 
                                                             "FOLLOWING", 
                                                             "UNBOUNDED", 
                                                             "PARTITION", 
                                                             "ROWS", "RANGE", 
                                                             "CURRENT", 
                                                             "VALID", "FILL_TIME_SERIES", 
                                                             "FLOW_TO_STOCK", 
                                                             "STOCK_TO_FLOW", 
                                                             "TIMESHIFT", 
                                                             "MEASURES", 
                                                             "NO_MEASURES", 
                                                             "CONDITION", 
                                                             "BOOLEAN", 
                                                             "DATE", "TIME_PERIOD", 
                                                             "NUMBER", "STRING", 
                                                             "TIME", "INTEGER", 
                                                             "FLOAT", "LIST", 
                                                             "RECORD", "RESTRICT", 
                                                             "YYYY", "MM", 
                                                             "DD", "MAX_LENGTH", 
                                                             "REGEXP", "IS", 
                                                             "WHEN", "FROM", 
                                                             "AGGREGATES", 
                                                             "POINTS", "POINT", 
                                                             "TOTAL", "PARTIAL", 
                                                             "ALWAYS", "INNER_JOIN", 
                                                             "LEFT_JOIN", 
                                                             "CROSS_JOIN", 
                                                             "FULL_JOIN", 
                                                             "MAPS_FROM", 
                                                             "MAPS_TO", 
                                                             "MAP_TO", "MAP_FROM", 
                                                             "RETURNS", 
                                                             "PIVOT", "CUSTOMPIVOT", 
                                                             "UNPIVOT", 
                                                             "SUBSPACE", 
                                                             "APPLY", "CONDITIONED", 
                                                             "PERIOD_INDICATOR", 
                                                             "SINGLE", "DURATION", 
                                                             "TIME_AGG", 
                                                             "UNIT", "VALUE", 
                                                             "VALUEDOMAINS", 
                                                             "VARIABLES", 
                                                             "INPUT", "OUTPUT", 
                                                             "CAST", "RULE_PRIORITY", 
                                                             "DATASET_PRIORITY", 
                                                             "DEFAULT", 
                                                             "CHECK_DATAPOINT", 
                                                             "CHECK_HIERARCHY", 
                                                             "COMPUTED", 
                                                             "NON_NULL", 
                                                             "NON_ZERO", 
                                                             "PARTIAL_NULL", 
                                                             "PARTIAL_ZERO", 
                                                             "ALWAYS_NULL", 
                                                             "ALWAYS_ZERO", 
                                                             "COMPONENTS", 
                                                             "ALL_MEASURES", 
                                                             "SCALAR", "COMPONENT", 
                                                             "DATAPOINT_ON_VD", 
                                                             "DATAPOINT_ON_VAR", 
                                                             "HIERARCHICAL_ON_VD", 
                                                             "HIERARCHICAL_ON_VAR", 
                                                             "SET", "LANGUAGE", 
                                                             "INTEGER_CONSTANT", 
                                                             "NUMBER_CONSTANT", 
                                                             "BOOLEAN_CONSTANT", 
                                                             "STRING_CONSTANT", 
                                                             "TIME_UNIT", 
                                                             "IDENTIFIER", 
                                                             "WS", "EOL", 
                                                             "ML_COMMENT", 
                                                             "SL_COMMENT" ];
	// tslint:disable:no-trailing-whitespace
	public static readonly ruleNames: string[] = [
		"start", "statement", "expr", "exprComponent", "functionsComponents", 
		"functions", "datasetClause", "renameClause", "aggrClause", "filterClause", 
		"calcClause", "keepOrDropClause", "pivotOrUnpivotClause", "subspaceClause", 
		"joinOperators", "defOperators", "genericOperators", "genericOperatorsComponent", 
		"parameterComponent", "parameter", "stringOperators", "stringOperatorsComponent", 
		"numericOperators", "numericOperatorsComponent", "comparisonOperators", 
		"comparisonOperatorsComponent", "timeOperators", "timeOperatorsComponent", 
		"setOperators", "hierarchyOperators", "validationOperators", "conditionalOperators", 
		"conditionalOperatorsComponent", "aggrOperators", "aggrOperatorsGrouping", 
		"anFunction", "anFunctionComponent", "renameClauseItem", "aggregateClause", 
		"aggrFunctionClause", "calcClauseItem", "subspaceClauseItem", "joinClauseWithoutUsing", 
		"joinClause", "joinClauseItem", "joinBody", "joinApplyClause", "partitionByClause", 
		"orderByClause", "orderByItem", "windowingClause", "signedInteger", "limitClauseItem", 
		"groupingClause", "havingClause", "parameterItem", "outputParameterType", 
		"outputParameterTypeComponent", "inputParameterType", "rulesetType", "scalarType", 
		"componentType", "datasetType", "scalarSetType", "dpRuleset", "hrRuleset", 
		"valueDomainName", "rulesetID", "rulesetSignature", "signature", "ruleClauseDatapoint", 
		"ruleItemDatapoint", "ruleClauseHierarchical", "ruleItemHierarchical", 
		"hierRuleSignature", "valueDomainSignature", "codeItemRelation", "codeItemRelationClause", 
		"valueDomainValue", "scalarTypeConstraint", "compConstraint", "multModifier", 
		"validationOutput", "validationMode", "conditionClause", "inputMode", 
		"imbalanceExpr", "inputModeHierarchy", "outputModeHierarchy", "alias", 
		"varID", "simpleComponentId", "componentID", "inexpr", "erCode", "erLevel", 
		"comparisonOperand", "optionalExpr", "optionalExprComponent", "componentRole", 
		"viralAttribute", "valueDomainID", "operatorID", "routineName", "constant", 
		"basicScalarType", "retainType",
	];
	public get grammarFileName(): string { return "Vtl.g4"; }
	public get literalNames(): (string | null)[] { return Vtl.literalNames; }
	public get symbolicNames(): (string | null)[] { return Vtl.symbolicNames; }
	public get ruleNames(): string[] { return Vtl.ruleNames; }
	public get serializedATN(): number[] { return Vtl._serializedATN; }

	protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException {
		return new FailedPredicateException(this, predicate, message);
	}

	constructor(input: TokenStream) {
		super(input);
		this._interp = new ParserATNSimulator(this, Vtl._ATN, Vtl.DecisionsToDFA, new PredictionContextCache());
	}
	// @RuleVersion(0)
	public start(): StartContext {
		let localctx: StartContext = new StartContext(this, this._ctx, this.state);
		this.enterRule(localctx, 0, Vtl.RULE_start);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 219;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===111 || _la===234) {
				{
				{
				this.state = 214;
				this.statement();
				this.state = 215;
				this.match(Vtl.EOL);
				}
				}
				this.state = 221;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 222;
			this.match(Vtl.EOF);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public statement(): StatementContext {
		let localctx: StatementContext = new StatementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 2, Vtl.RULE_statement);
		try {
			this.state = 233;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 1, this._ctx) ) {
			case 1:
				localctx = new TemporaryAssignmentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 224;
				this.varID();
				this.state = 225;
				this.match(Vtl.ASSIGN);
				this.state = 226;
				this.expr(0);
				}
				break;
			case 2:
				localctx = new PersistAssignmentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 228;
				this.varID();
				this.state = 229;
				this.match(Vtl.PUT_SYMBOL);
				this.state = 230;
				this.expr(0);
				}
				break;
			case 3:
				localctx = new DefineExpressionContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 232;
				this.defOperators();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}

	public expr(): ExprContext;
	public expr(_p: number): ExprContext;
	// @RuleVersion(0)
	public expr(_p?: number): ExprContext {
		if (_p === undefined) {
			_p = 0;
		}

		let _parentctx: ParserRuleContext = this._ctx;
		let _parentState: number = this.state;
		let localctx: ExprContext = new ExprContext(this, this._ctx, _parentState);
		let _prevctx: ExprContext = localctx;
		let _startState: number = 4;
		this.enterRecursionRule(localctx, 4, Vtl.RULE_expr, _p);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 252;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 2, this._ctx) ) {
			case 1:
				{
				localctx = new ParenthesisExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;

				this.state = 236;
				this.match(Vtl.LPAREN);
				this.state = 237;
				this.expr(0);
				this.state = 238;
				this.match(Vtl.RPAREN);
				}
				break;
			case 2:
				{
				localctx = new FunctionsExpressionContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 240;
				this.functions();
				}
				break;
			case 3:
				{
				localctx = new UnaryExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 241;
				(localctx as UnaryExprContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 13)) & ~0x1F) === 0 && ((1 << (_la - 13)) & 67108867) !== 0))) {
				    (localctx as UnaryExprContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 242;
				(localctx as UnaryExprContext)._right = this.expr(10);
				}
				break;
			case 4:
				{
				localctx = new IfExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 243;
				this.match(Vtl.IF);
				this.state = 244;
				(localctx as IfExprContext)._conditionalExpr = this.expr(0);
				this.state = 245;
				this.match(Vtl.THEN);
				this.state = 246;
				(localctx as IfExprContext)._thenExpr = this.expr(0);
				this.state = 247;
				this.match(Vtl.ELSE);
				this.state = 248;
				(localctx as IfExprContext)._elseExpr = this.expr(3);
				}
				break;
			case 5:
				{
				localctx = new ConstantExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 250;
				this.constant();
				}
				break;
			case 6:
				{
				localctx = new VarIdExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 251;
				this.varID();
				}
				break;
			}
			this._ctx.stop = this._input.LT(-1);
			this.state = 283;
			this._errHandler.sync(this);
			_alt = this._interp.adaptivePredict(this._input, 4, this._ctx);
			while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
				if (_alt === 1) {
					if (this._parseListeners != null) {
						this.triggerExitRuleEvent();
					}
					_prevctx = localctx;
					{
					this.state = 281;
					this._errHandler.sync(this);
					switch ( this._interp.adaptivePredict(this._input, 3, this._ctx) ) {
					case 1:
						{
						localctx = new ArithmeticExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 254;
						if (!(this.precpred(this._ctx, 9))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 9)");
						}
						this.state = 255;
						(localctx as ArithmeticExprContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===15 || _la===16)) {
						    (localctx as ArithmeticExprContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 256;
						(localctx as ArithmeticExprContext)._right = this.expr(10);
						}
						break;
					case 2:
						{
						localctx = new ArithmeticExprOrConcatContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprOrConcatContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 257;
						if (!(this.precpred(this._ctx, 8))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 8)");
						}
						this.state = 258;
						(localctx as ArithmeticExprOrConcatContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===13 || _la===14 || _la===82)) {
						    (localctx as ArithmeticExprOrConcatContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 259;
						(localctx as ArithmeticExprOrConcatContext)._right = this.expr(9);
						}
						break;
					case 3:
						{
						localctx = new ComparisonExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ComparisonExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 260;
						if (!(this.precpred(this._ctx, 7))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 7)");
						}
						this.state = 261;
						(localctx as ComparisonExprContext)._op = this.comparisonOperand();
						this.state = 262;
						(localctx as ComparisonExprContext)._right = this.expr(8);
						}
						break;
					case 4:
						{
						localctx = new BooleanExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as BooleanExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 264;
						if (!(this.precpred(this._ctx, 5))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 5)");
						}
						this.state = 265;
						(localctx as BooleanExprContext)._op = this.match(Vtl.AND);
						this.state = 266;
						(localctx as BooleanExprContext)._right = this.expr(6);
						}
						break;
					case 5:
						{
						localctx = new BooleanExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as BooleanExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 267;
						if (!(this.precpred(this._ctx, 4))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 4)");
						}
						this.state = 268;
						(localctx as BooleanExprContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===37 || _la===38)) {
						    (localctx as BooleanExprContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 269;
						(localctx as BooleanExprContext)._right = this.expr(5);
						}
						break;
					case 6:
						{
						localctx = new ClauseExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ClauseExprContext)._dataset = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 270;
						if (!(this.precpred(this._ctx, 12))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 12)");
						}
						this.state = 271;
						this.match(Vtl.QLPAREN);
						this.state = 272;
						(localctx as ClauseExprContext)._clause = this.datasetClause();
						this.state = 273;
						this.match(Vtl.QRPAREN);
						}
						break;
					case 7:
						{
						localctx = new MembershipExprContext(this, new ExprContext(this, _parentctx, _parentState));
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 275;
						if (!(this.precpred(this._ctx, 11))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 11)");
						}
						this.state = 276;
						this.match(Vtl.MEMBERSHIP);
						this.state = 277;
						this.simpleComponentId();
						}
						break;
					case 8:
						{
						localctx = new InNotInExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as InNotInExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_expr);
						this.state = 278;
						if (!(this.precpred(this._ctx, 6))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 6)");
						}
						this.state = 279;
						(localctx as InNotInExprContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===41 || _la===42)) {
						    (localctx as InNotInExprContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 280;
						(localctx as InNotInExprContext)._right = this.inexpr();
						}
						break;
					}
					}
				}
				this.state = 285;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 4, this._ctx);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.unrollRecursionContexts(_parentctx);
		}
		return localctx;
	}

	public exprComponent(): ExprComponentContext;
	public exprComponent(_p: number): ExprComponentContext;
	// @RuleVersion(0)
	public exprComponent(_p?: number): ExprComponentContext {
		if (_p === undefined) {
			_p = 0;
		}

		let _parentctx: ParserRuleContext = this._ctx;
		let _parentState: number = this.state;
		let localctx: ExprComponentContext = new ExprComponentContext(this, this._ctx, _parentState);
		let _prevctx: ExprComponentContext = localctx;
		let _startState: number = 6;
		this.enterRecursionRule(localctx, 6, Vtl.RULE_exprComponent, _p);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 303;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 5, this._ctx) ) {
			case 1:
				{
				localctx = new ParenthesisExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;

				this.state = 287;
				this.match(Vtl.LPAREN);
				this.state = 288;
				this.exprComponent(0);
				this.state = 289;
				this.match(Vtl.RPAREN);
				}
				break;
			case 2:
				{
				localctx = new FunctionsExpressionCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 291;
				this.functionsComponents();
				}
				break;
			case 3:
				{
				localctx = new UnaryExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 292;
				(localctx as UnaryExprCompContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 13)) & ~0x1F) === 0 && ((1 << (_la - 13)) & 67108867) !== 0))) {
				    (localctx as UnaryExprCompContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 293;
				(localctx as UnaryExprCompContext)._right = this.exprComponent(10);
				}
				break;
			case 4:
				{
				localctx = new IfExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 294;
				this.match(Vtl.IF);
				this.state = 295;
				(localctx as IfExprCompContext)._conditionalExpr = this.exprComponent(0);
				this.state = 296;
				this.match(Vtl.THEN);
				this.state = 297;
				(localctx as IfExprCompContext)._thenExpr = this.exprComponent(0);
				this.state = 298;
				this.match(Vtl.ELSE);
				this.state = 299;
				(localctx as IfExprCompContext)._elseExpr = this.exprComponent(3);
				}
				break;
			case 5:
				{
				localctx = new ConstantExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 301;
				this.constant();
				}
				break;
			case 6:
				{
				localctx = new CompIdContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 302;
				this.componentID();
				}
				break;
			}
			this._ctx.stop = this._input.LT(-1);
			this.state = 326;
			this._errHandler.sync(this);
			_alt = this._interp.adaptivePredict(this._input, 7, this._ctx);
			while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
				if (_alt === 1) {
					if (this._parseListeners != null) {
						this.triggerExitRuleEvent();
					}
					_prevctx = localctx;
					{
					this.state = 324;
					this._errHandler.sync(this);
					switch ( this._interp.adaptivePredict(this._input, 6, this._ctx) ) {
					case 1:
						{
						localctx = new ArithmeticExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_exprComponent);
						this.state = 305;
						if (!(this.precpred(this._ctx, 9))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 9)");
						}
						this.state = 306;
						(localctx as ArithmeticExprCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===15 || _la===16)) {
						    (localctx as ArithmeticExprCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 307;
						(localctx as ArithmeticExprCompContext)._right = this.exprComponent(10);
						}
						break;
					case 2:
						{
						localctx = new ArithmeticExprOrConcatCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprOrConcatCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_exprComponent);
						this.state = 308;
						if (!(this.precpred(this._ctx, 8))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 8)");
						}
						this.state = 309;
						(localctx as ArithmeticExprOrConcatCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===13 || _la===14 || _la===82)) {
						    (localctx as ArithmeticExprOrConcatCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 310;
						(localctx as ArithmeticExprOrConcatCompContext)._right = this.exprComponent(9);
						}
						break;
					case 3:
						{
						localctx = new ComparisonExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as ComparisonExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_exprComponent);
						this.state = 311;
						if (!(this.precpred(this._ctx, 7))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 7)");
						}
						this.state = 312;
						this.comparisonOperand();
						this.state = 313;
						(localctx as ComparisonExprCompContext)._right = this.exprComponent(8);
						}
						break;
					case 4:
						{
						localctx = new BooleanExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as BooleanExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_exprComponent);
						this.state = 315;
						if (!(this.precpred(this._ctx, 5))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 5)");
						}
						this.state = 316;
						(localctx as BooleanExprCompContext)._op = this.match(Vtl.AND);
						this.state = 317;
						(localctx as BooleanExprCompContext)._right = this.exprComponent(6);
						}
						break;
					case 5:
						{
						localctx = new BooleanExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as BooleanExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_exprComponent);
						this.state = 318;
						if (!(this.precpred(this._ctx, 4))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 4)");
						}
						this.state = 319;
						(localctx as BooleanExprCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===37 || _la===38)) {
						    (localctx as BooleanExprCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 320;
						(localctx as BooleanExprCompContext)._right = this.exprComponent(5);
						}
						break;
					case 6:
						{
						localctx = new InNotInExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as InNotInExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, Vtl.RULE_exprComponent);
						this.state = 321;
						if (!(this.precpred(this._ctx, 6))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 6)");
						}
						this.state = 322;
						(localctx as InNotInExprCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===41 || _la===42)) {
						    (localctx as InNotInExprCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 323;
						(localctx as InNotInExprCompContext)._right = this.inexpr();
						}
						break;
					}
					}
				}
				this.state = 328;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 7, this._ctx);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.unrollRecursionContexts(_parentctx);
		}
		return localctx;
	}
	// @RuleVersion(0)
	public functionsComponents(): FunctionsComponentsContext {
		let localctx: FunctionsComponentsContext = new FunctionsComponentsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 8, Vtl.RULE_functionsComponents);
		try {
			this.state = 337;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 8, this._ctx) ) {
			case 1:
				localctx = new GenericFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 329;
				this.genericOperatorsComponent();
				}
				break;
			case 2:
				localctx = new StringFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 330;
				this.stringOperatorsComponent();
				}
				break;
			case 3:
				localctx = new NumericFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 331;
				this.numericOperatorsComponent();
				}
				break;
			case 4:
				localctx = new ComparisonFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 332;
				this.comparisonOperatorsComponent();
				}
				break;
			case 5:
				localctx = new TimeFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 333;
				this.timeOperatorsComponent();
				}
				break;
			case 6:
				localctx = new ConditionalFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 334;
				this.conditionalOperatorsComponent();
				}
				break;
			case 7:
				localctx = new AggregateFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 335;
				this.aggrOperators();
				}
				break;
			case 8:
				localctx = new AnalyticFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 336;
				this.anFunctionComponent();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public functions(): FunctionsContext {
		let localctx: FunctionsContext = new FunctionsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 10, Vtl.RULE_functions);
		try {
			this.state = 351;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 9, this._ctx) ) {
			case 1:
				localctx = new JoinFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 339;
				this.joinOperators();
				}
				break;
			case 2:
				localctx = new GenericFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 340;
				this.genericOperators();
				}
				break;
			case 3:
				localctx = new StringFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 341;
				this.stringOperators();
				}
				break;
			case 4:
				localctx = new NumericFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 342;
				this.numericOperators();
				}
				break;
			case 5:
				localctx = new ComparisonFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 343;
				this.comparisonOperators();
				}
				break;
			case 6:
				localctx = new TimeFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 344;
				this.timeOperators();
				}
				break;
			case 7:
				localctx = new SetFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 345;
				this.setOperators();
				}
				break;
			case 8:
				localctx = new HierarchyFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 346;
				this.hierarchyOperators();
				}
				break;
			case 9:
				localctx = new ValidationFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 9);
				{
				this.state = 347;
				this.validationOperators();
				}
				break;
			case 10:
				localctx = new ConditionalFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 10);
				{
				this.state = 348;
				this.conditionalOperators();
				}
				break;
			case 11:
				localctx = new AggregateFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 11);
				{
				this.state = 349;
				this.aggrOperatorsGrouping();
				}
				break;
			case 12:
				localctx = new AnalyticFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 12);
				{
				this.state = 350;
				this.anFunction();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public datasetClause(): DatasetClauseContext {
		let localctx: DatasetClauseContext = new DatasetClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 12, Vtl.RULE_datasetClause);
		try {
			this.state = 360;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 34:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 353;
				this.renameClause();
				}
				break;
			case 61:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 354;
				this.aggrClause();
				}
				break;
			case 94:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 355;
				this.filterClause();
				}
				break;
			case 32:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 356;
				this.calcClause();
				}
				break;
			case 30:
			case 31:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 357;
				this.keepOrDropClause();
				}
				break;
			case 190:
			case 192:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 358;
				this.pivotOrUnpivotClause();
				}
				break;
			case 193:
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 359;
				this.subspaceClause();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public renameClause(): RenameClauseContext {
		let localctx: RenameClauseContext = new RenameClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 14, Vtl.RULE_renameClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 362;
			this.match(Vtl.RENAME);
			this.state = 363;
			this.renameClauseItem();
			this.state = 368;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 364;
				this.match(Vtl.COMMA);
				this.state = 365;
				this.renameClauseItem();
				}
				}
				this.state = 370;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrClause(): AggrClauseContext {
		let localctx: AggrClauseContext = new AggrClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 16, Vtl.RULE_aggrClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 371;
			this.match(Vtl.AGGREGATE);
			this.state = 372;
			this.aggregateClause();
			this.state = 377;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===132) {
				{
				this.state = 373;
				this.groupingClause();
				this.state = 375;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===134) {
					{
					this.state = 374;
					this.havingClause();
					}
				}

				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public filterClause(): FilterClauseContext {
		let localctx: FilterClauseContext = new FilterClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 18, Vtl.RULE_filterClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 379;
			this.match(Vtl.FILTER);
			this.state = 380;
			this.exprComponent(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public calcClause(): CalcClauseContext {
		let localctx: CalcClauseContext = new CalcClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 20, Vtl.RULE_calcClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 382;
			this.match(Vtl.CALC);
			this.state = 383;
			this.calcClauseItem();
			this.state = 388;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 384;
				this.match(Vtl.COMMA);
				this.state = 385;
				this.calcClauseItem();
				}
				}
				this.state = 390;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public keepOrDropClause(): KeepOrDropClauseContext {
		let localctx: KeepOrDropClauseContext = new KeepOrDropClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 22, Vtl.RULE_keepOrDropClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 391;
			localctx._op = this._input.LT(1);
			_la = this._input.LA(1);
			if(!(_la===30 || _la===31)) {
			    localctx._op = this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 392;
			this.componentID();
			this.state = 397;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 393;
				this.match(Vtl.COMMA);
				this.state = 394;
				this.componentID();
				}
				}
				this.state = 399;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public pivotOrUnpivotClause(): PivotOrUnpivotClauseContext {
		let localctx: PivotOrUnpivotClauseContext = new PivotOrUnpivotClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 24, Vtl.RULE_pivotOrUnpivotClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 400;
			localctx._op = this._input.LT(1);
			_la = this._input.LA(1);
			if(!(_la===190 || _la===192)) {
			    localctx._op = this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 401;
			localctx._id_ = this.componentID();
			this.state = 402;
			this.match(Vtl.COMMA);
			this.state = 403;
			localctx._mea = this.componentID();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public subspaceClause(): SubspaceClauseContext {
		let localctx: SubspaceClauseContext = new SubspaceClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 26, Vtl.RULE_subspaceClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 405;
			this.match(Vtl.SUBSPACE);
			this.state = 406;
			this.subspaceClauseItem();
			this.state = 411;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 407;
				this.match(Vtl.COMMA);
				this.state = 408;
				this.subspaceClauseItem();
				}
				}
				this.state = 413;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinOperators(): JoinOperatorsContext {
		let localctx: JoinOperatorsContext = new JoinOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 28, Vtl.RULE_joinOperators);
		let _la: number;
		try {
			this.state = 426;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 181:
			case 182:
				localctx = new JoinExprContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 414;
				(localctx as JoinExprContext)._joinKeyword = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===181 || _la===182)) {
				    (localctx as JoinExprContext)._joinKeyword = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 415;
				this.match(Vtl.LPAREN);
				this.state = 416;
				this.joinClause();
				this.state = 417;
				this.joinBody();
				this.state = 418;
				this.match(Vtl.RPAREN);
				}
				break;
			case 183:
			case 184:
				localctx = new JoinExprContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 420;
				(localctx as JoinExprContext)._joinKeyword = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===183 || _la===184)) {
				    (localctx as JoinExprContext)._joinKeyword = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 421;
				this.match(Vtl.LPAREN);
				this.state = 422;
				this.joinClauseWithoutUsing();
				this.state = 423;
				this.joinBody();
				this.state = 424;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public defOperators(): DefOperatorsContext {
		let localctx: DefOperatorsContext = new DefOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 30, Vtl.RULE_defOperators);
		let _la: number;
		try {
			this.state = 478;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 21, this._ctx) ) {
			case 1:
				localctx = new DefOperatorContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 428;
				this.match(Vtl.DEFINE);
				this.state = 429;
				this.match(Vtl.OPERATOR);
				this.state = 430;
				this.operatorID();
				this.state = 431;
				this.match(Vtl.LPAREN);
				this.state = 440;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===234) {
					{
					this.state = 432;
					this.parameterItem();
					this.state = 437;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 433;
						this.match(Vtl.COMMA);
						this.state = 434;
						this.parameterItem();
						}
						}
						this.state = 439;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 442;
				this.match(Vtl.RPAREN);
				this.state = 445;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===189) {
					{
					this.state = 443;
					this.match(Vtl.RETURNS);
					this.state = 444;
					this.outputParameterType();
					}
				}

				this.state = 447;
				this.match(Vtl.IS);
				{
				this.state = 448;
				this.expr(0);
				}
				this.state = 449;
				this.match(Vtl.END);
				this.state = 450;
				this.match(Vtl.OPERATOR);
				}
				break;
			case 2:
				localctx = new DefDatapointRulesetContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 452;
				this.match(Vtl.DEFINE);
				this.state = 453;
				this.match(Vtl.DATAPOINT);
				this.state = 454;
				this.match(Vtl.RULESET);
				this.state = 455;
				this.rulesetID();
				this.state = 456;
				this.match(Vtl.LPAREN);
				this.state = 457;
				this.rulesetSignature();
				this.state = 458;
				this.match(Vtl.RPAREN);
				this.state = 459;
				this.match(Vtl.IS);
				this.state = 460;
				this.ruleClauseDatapoint();
				this.state = 461;
				this.match(Vtl.END);
				this.state = 462;
				this.match(Vtl.DATAPOINT);
				this.state = 463;
				this.match(Vtl.RULESET);
				}
				break;
			case 3:
				localctx = new DefHierarchicalContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 465;
				this.match(Vtl.DEFINE);
				this.state = 466;
				this.match(Vtl.HIERARCHICAL);
				this.state = 467;
				this.match(Vtl.RULESET);
				this.state = 468;
				this.rulesetID();
				this.state = 469;
				this.match(Vtl.LPAREN);
				this.state = 470;
				this.hierRuleSignature();
				this.state = 471;
				this.match(Vtl.RPAREN);
				this.state = 472;
				this.match(Vtl.IS);
				this.state = 473;
				this.ruleClauseHierarchical();
				this.state = 474;
				this.match(Vtl.END);
				this.state = 475;
				this.match(Vtl.HIERARCHICAL);
				this.state = 476;
				this.match(Vtl.RULESET);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public genericOperators(): GenericOperatorsContext {
		let localctx: GenericOperatorsContext = new GenericOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 32, Vtl.RULE_genericOperators);
		let _la: number;
		try {
			this.state = 537;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 234:
				localctx = new CallDatasetContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 480;
				this.operatorID();
				this.state = 481;
				this.match(Vtl.LPAREN);
				this.state = 490;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===43 || _la===103 || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 47) !== 0)) {
					{
					this.state = 482;
					this.parameter();
					this.state = 487;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 483;
						this.match(Vtl.COMMA);
						this.state = 484;
						this.parameter();
						}
						}
						this.state = 489;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 492;
				this.match(Vtl.RPAREN);
				}
				break;
			case 22:
				localctx = new EvalAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 494;
				this.match(Vtl.EVAL);
				this.state = 495;
				this.match(Vtl.LPAREN);
				this.state = 496;
				this.routineName();
				this.state = 497;
				this.match(Vtl.LPAREN);
				this.state = 500;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 234:
					{
					this.state = 498;
					this.varID();
					}
					break;
				case 43:
				case 229:
				case 230:
				case 231:
				case 232:
					{
					this.state = 499;
					this.constant();
					}
					break;
				case 2:
				case 17:
					break;
				default:
					break;
				}
				this.state = 509;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 502;
					this.match(Vtl.COMMA);
					this.state = 505;
					this._errHandler.sync(this);
					switch (this._input.LA(1)) {
					case 234:
						{
						this.state = 503;
						this.varID();
						}
						break;
					case 43:
					case 229:
					case 230:
					case 231:
					case 232:
						{
						this.state = 504;
						this.constant();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					this.state = 511;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 512;
				this.match(Vtl.RPAREN);
				this.state = 515;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===228) {
					{
					this.state = 513;
					this.match(Vtl.LANGUAGE);
					this.state = 514;
					this.match(Vtl.STRING_CONSTANT);
					}
				}

				this.state = 519;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===189) {
					{
					this.state = 517;
					this.match(Vtl.RETURNS);
					this.state = 518;
					this.datasetType();
					}
				}

				this.state = 521;
				this.match(Vtl.RPAREN);
				}
				break;
			case 206:
				localctx = new CastExprDatasetContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 523;
				this.match(Vtl.CAST);
				this.state = 524;
				this.match(Vtl.LPAREN);
				this.state = 525;
				this.expr(0);
				this.state = 526;
				this.match(Vtl.COMMA);
				this.state = 529;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 156:
				case 157:
				case 158:
				case 159:
				case 160:
				case 161:
				case 162:
				case 198:
				case 221:
					{
					this.state = 527;
					this.basicScalarType();
					}
					break;
				case 234:
					{
					this.state = 528;
					this.valueDomainName();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				this.state = 533;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 531;
					this.match(Vtl.COMMA);
					this.state = 532;
					this.match(Vtl.STRING_CONSTANT);
					}
				}

				this.state = 535;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public genericOperatorsComponent(): GenericOperatorsComponentContext {
		let localctx: GenericOperatorsComponentContext = new GenericOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 34, Vtl.RULE_genericOperatorsComponent);
		let _la: number;
		try {
			this.state = 596;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 234:
				localctx = new CallComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 539;
				this.operatorID();
				this.state = 540;
				this.match(Vtl.LPAREN);
				this.state = 549;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===43 || _la===103 || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 47) !== 0)) {
					{
					this.state = 541;
					this.parameterComponent();
					this.state = 546;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 542;
						this.match(Vtl.COMMA);
						this.state = 543;
						this.parameterComponent();
						}
						}
						this.state = 548;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 551;
				this.match(Vtl.RPAREN);
				}
				break;
			case 206:
				localctx = new CastExprComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 553;
				this.match(Vtl.CAST);
				this.state = 554;
				this.match(Vtl.LPAREN);
				this.state = 555;
				this.exprComponent(0);
				this.state = 556;
				this.match(Vtl.COMMA);
				this.state = 559;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 156:
				case 157:
				case 158:
				case 159:
				case 160:
				case 161:
				case 162:
				case 198:
				case 221:
					{
					this.state = 557;
					this.basicScalarType();
					}
					break;
				case 234:
					{
					this.state = 558;
					this.valueDomainName();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				this.state = 563;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 561;
					this.match(Vtl.COMMA);
					this.state = 562;
					this.match(Vtl.STRING_CONSTANT);
					}
				}

				this.state = 565;
				this.match(Vtl.RPAREN);
				}
				break;
			case 22:
				localctx = new EvalAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 567;
				this.match(Vtl.EVAL);
				this.state = 568;
				this.match(Vtl.LPAREN);
				this.state = 569;
				this.routineName();
				this.state = 570;
				this.match(Vtl.LPAREN);
				this.state = 573;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 234:
					{
					this.state = 571;
					this.componentID();
					}
					break;
				case 43:
				case 229:
				case 230:
				case 231:
				case 232:
					{
					this.state = 572;
					this.constant();
					}
					break;
				case 2:
				case 17:
					break;
				default:
					break;
				}
				this.state = 582;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 575;
					this.match(Vtl.COMMA);
					this.state = 578;
					this._errHandler.sync(this);
					switch (this._input.LA(1)) {
					case 234:
						{
						this.state = 576;
						this.componentID();
						}
						break;
					case 43:
					case 229:
					case 230:
					case 231:
					case 232:
						{
						this.state = 577;
						this.constant();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					this.state = 584;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 585;
				this.match(Vtl.RPAREN);
				this.state = 588;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===228) {
					{
					this.state = 586;
					this.match(Vtl.LANGUAGE);
					this.state = 587;
					this.match(Vtl.STRING_CONSTANT);
					}
				}

				this.state = 592;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===189) {
					{
					this.state = 590;
					this.match(Vtl.RETURNS);
					this.state = 591;
					this.outputParameterTypeComponent();
					}
				}

				this.state = 594;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public parameterComponent(): ParameterComponentContext {
		let localctx: ParameterComponentContext = new ParameterComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 36, Vtl.RULE_parameterComponent);
		try {
			this.state = 601;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 598;
				this.componentID();
				}
				break;
			case 43:
			case 229:
			case 230:
			case 231:
			case 232:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 599;
				this.constant();
				}
				break;
			case 103:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 600;
				this.match(Vtl.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public parameter(): ParameterContext {
		let localctx: ParameterContext = new ParameterContext(this, this._ctx, this.state);
		this.enterRule(localctx, 38, Vtl.RULE_parameter);
		try {
			this.state = 606;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 603;
				this.varID();
				}
				break;
			case 43:
			case 229:
			case 230:
			case 231:
			case 232:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 604;
				this.constant();
				}
				break;
			case 103:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 605;
				this.match(Vtl.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public stringOperators(): StringOperatorsContext {
		let localctx: StringOperatorsContext = new StringOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 40, Vtl.RULE_stringOperators);
		let _la: number;
		try {
			this.state = 656;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 81:
			case 83:
			case 84:
			case 85:
			case 119:
			case 120:
				localctx = new UnaryStringFunctionContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 608;
				(localctx as UnaryStringFunctionContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 81)) & ~0x1F) === 0 && ((1 << (_la - 81)) & 29) !== 0) || _la===119 || _la===120)) {
				    (localctx as UnaryStringFunctionContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 609;
				this.match(Vtl.LPAREN);
				this.state = 610;
				this.expr(0);
				this.state = 611;
				this.match(Vtl.RPAREN);
				}
				break;
			case 86:
				localctx = new SubstrAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 613;
				this.match(Vtl.SUBSTR);
				this.state = 614;
				this.match(Vtl.LPAREN);
				this.state = 615;
				this.expr(0);
				this.state = 626;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 45, this._ctx) ) {
				case 1:
					{
					this.state = 622;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						{
						this.state = 616;
						this.match(Vtl.COMMA);
						this.state = 617;
						(localctx as SubstrAtomContext)._startParameter = this.optionalExpr();
						}
						{
						this.state = 619;
						this.match(Vtl.COMMA);
						this.state = 620;
						(localctx as SubstrAtomContext)._endParameter = this.optionalExpr();
						}
						}
					}

					}
					break;
				case 2:
					{
					this.state = 624;
					this.match(Vtl.COMMA);
					this.state = 625;
					(localctx as SubstrAtomContext)._startParameter = this.optionalExpr();
					}
					break;
				}
				this.state = 628;
				this.match(Vtl.RPAREN);
				}
				break;
			case 122:
				localctx = new ReplaceAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 630;
				this.match(Vtl.REPLACE);
				this.state = 631;
				this.match(Vtl.LPAREN);
				this.state = 632;
				this.expr(0);
				this.state = 633;
				this.match(Vtl.COMMA);
				this.state = 634;
				(localctx as ReplaceAtomContext)._param = this.expr(0);
				this.state = 637;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 635;
					this.match(Vtl.COMMA);
					this.state = 636;
					this.optionalExpr();
					}
				}

				this.state = 639;
				this.match(Vtl.RPAREN);
				}
				break;
			case 121:
				localctx = new InstrAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 641;
				this.match(Vtl.INSTR);
				this.state = 642;
				this.match(Vtl.LPAREN);
				this.state = 643;
				this.expr(0);
				this.state = 644;
				this.match(Vtl.COMMA);
				this.state = 645;
				(localctx as InstrAtomContext)._pattern = this.expr(0);
				this.state = 648;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 47, this._ctx) ) {
				case 1:
					{
					this.state = 646;
					this.match(Vtl.COMMA);
					this.state = 647;
					(localctx as InstrAtomContext)._startParameter = this.optionalExpr();
					}
					break;
				}
				this.state = 652;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 650;
					this.match(Vtl.COMMA);
					this.state = 651;
					(localctx as InstrAtomContext)._occurrenceParameter = this.optionalExpr();
					}
				}

				this.state = 654;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public stringOperatorsComponent(): StringOperatorsComponentContext {
		let localctx: StringOperatorsComponentContext = new StringOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 42, Vtl.RULE_stringOperatorsComponent);
		let _la: number;
		try {
			this.state = 706;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 81:
			case 83:
			case 84:
			case 85:
			case 119:
			case 120:
				localctx = new UnaryStringFunctionComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 658;
				(localctx as UnaryStringFunctionComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 81)) & ~0x1F) === 0 && ((1 << (_la - 81)) & 29) !== 0) || _la===119 || _la===120)) {
				    (localctx as UnaryStringFunctionComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 659;
				this.match(Vtl.LPAREN);
				this.state = 660;
				this.exprComponent(0);
				this.state = 661;
				this.match(Vtl.RPAREN);
				}
				break;
			case 86:
				localctx = new SubstrAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 663;
				this.match(Vtl.SUBSTR);
				this.state = 664;
				this.match(Vtl.LPAREN);
				this.state = 665;
				this.exprComponent(0);
				this.state = 676;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 51, this._ctx) ) {
				case 1:
					{
					this.state = 672;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						{
						this.state = 666;
						this.match(Vtl.COMMA);
						this.state = 667;
						(localctx as SubstrAtomComponentContext)._startParameter = this.optionalExprComponent();
						}
						{
						this.state = 669;
						this.match(Vtl.COMMA);
						this.state = 670;
						(localctx as SubstrAtomComponentContext)._endParameter = this.optionalExprComponent();
						}
						}
					}

					}
					break;
				case 2:
					{
					this.state = 674;
					this.match(Vtl.COMMA);
					this.state = 675;
					(localctx as SubstrAtomComponentContext)._startParameter = this.optionalExprComponent();
					}
					break;
				}
				this.state = 678;
				this.match(Vtl.RPAREN);
				}
				break;
			case 122:
				localctx = new ReplaceAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 680;
				this.match(Vtl.REPLACE);
				this.state = 681;
				this.match(Vtl.LPAREN);
				this.state = 682;
				this.exprComponent(0);
				this.state = 683;
				this.match(Vtl.COMMA);
				this.state = 684;
				(localctx as ReplaceAtomComponentContext)._param = this.exprComponent(0);
				this.state = 687;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 685;
					this.match(Vtl.COMMA);
					this.state = 686;
					this.optionalExprComponent();
					}
				}

				this.state = 689;
				this.match(Vtl.RPAREN);
				}
				break;
			case 121:
				localctx = new InstrAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 691;
				this.match(Vtl.INSTR);
				this.state = 692;
				this.match(Vtl.LPAREN);
				this.state = 693;
				this.exprComponent(0);
				this.state = 694;
				this.match(Vtl.COMMA);
				this.state = 695;
				(localctx as InstrAtomComponentContext)._pattern = this.exprComponent(0);
				this.state = 698;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 53, this._ctx) ) {
				case 1:
					{
					this.state = 696;
					this.match(Vtl.COMMA);
					this.state = 697;
					(localctx as InstrAtomComponentContext)._startParameter = this.optionalExprComponent();
					}
					break;
				}
				this.state = 702;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 700;
					this.match(Vtl.COMMA);
					this.state = 701;
					(localctx as InstrAtomComponentContext)._occurrenceParameter = this.optionalExprComponent();
					}
				}

				this.state = 704;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public numericOperators(): NumericOperatorsContext {
		let localctx: NumericOperatorsContext = new NumericOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 44, Vtl.RULE_numericOperators);
		let _la: number;
		try {
			this.state = 729;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 73:
			case 75:
			case 96:
			case 123:
			case 124:
			case 125:
				localctx = new UnaryNumericContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 708;
				(localctx as UnaryNumericContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 73)) & ~0x1F) === 0 && ((1 << (_la - 73)) & 8388613) !== 0) || ((((_la - 123)) & ~0x1F) === 0 && ((1 << (_la - 123)) & 7) !== 0))) {
				    (localctx as UnaryNumericContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 709;
				this.match(Vtl.LPAREN);
				this.state = 710;
				this.expr(0);
				this.state = 711;
				this.match(Vtl.RPAREN);
				}
				break;
			case 77:
			case 78:
				localctx = new UnaryWithOptionalNumericContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 713;
				(localctx as UnaryWithOptionalNumericContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===77 || _la===78)) {
				    (localctx as UnaryWithOptionalNumericContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 714;
				this.match(Vtl.LPAREN);
				this.state = 715;
				this.expr(0);
				this.state = 718;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 716;
					this.match(Vtl.COMMA);
					this.state = 717;
					this.optionalExpr();
					}
				}

				this.state = 720;
				this.match(Vtl.RPAREN);
				}
				break;
			case 76:
			case 79:
			case 80:
				localctx = new BinaryNumericContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 722;
				(localctx as BinaryNumericContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 76)) & ~0x1F) === 0 && ((1 << (_la - 76)) & 25) !== 0))) {
				    (localctx as BinaryNumericContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 723;
				this.match(Vtl.LPAREN);
				this.state = 724;
				(localctx as BinaryNumericContext)._left = this.expr(0);
				this.state = 725;
				this.match(Vtl.COMMA);
				this.state = 726;
				(localctx as BinaryNumericContext)._right = this.expr(0);
				this.state = 727;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public numericOperatorsComponent(): NumericOperatorsComponentContext {
		let localctx: NumericOperatorsComponentContext = new NumericOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 46, Vtl.RULE_numericOperatorsComponent);
		let _la: number;
		try {
			this.state = 752;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 73:
			case 75:
			case 96:
			case 123:
			case 124:
			case 125:
				localctx = new UnaryNumericComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 731;
				(localctx as UnaryNumericComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 73)) & ~0x1F) === 0 && ((1 << (_la - 73)) & 8388613) !== 0) || ((((_la - 123)) & ~0x1F) === 0 && ((1 << (_la - 123)) & 7) !== 0))) {
				    (localctx as UnaryNumericComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 732;
				this.match(Vtl.LPAREN);
				this.state = 733;
				this.exprComponent(0);
				this.state = 734;
				this.match(Vtl.RPAREN);
				}
				break;
			case 77:
			case 78:
				localctx = new UnaryWithOptionalNumericComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 736;
				(localctx as UnaryWithOptionalNumericComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===77 || _la===78)) {
				    (localctx as UnaryWithOptionalNumericComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 737;
				this.match(Vtl.LPAREN);
				this.state = 738;
				this.exprComponent(0);
				this.state = 741;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 739;
					this.match(Vtl.COMMA);
					this.state = 740;
					this.optionalExprComponent();
					}
				}

				this.state = 743;
				this.match(Vtl.RPAREN);
				}
				break;
			case 76:
			case 79:
			case 80:
				localctx = new BinaryNumericComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 745;
				(localctx as BinaryNumericComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 76)) & ~0x1F) === 0 && ((1 << (_la - 76)) & 25) !== 0))) {
				    (localctx as BinaryNumericComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 746;
				this.match(Vtl.LPAREN);
				this.state = 747;
				(localctx as BinaryNumericComponentContext)._left = this.exprComponent(0);
				this.state = 748;
				this.match(Vtl.COMMA);
				this.state = 749;
				(localctx as BinaryNumericComponentContext)._right = this.exprComponent(0);
				this.state = 750;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public comparisonOperators(): ComparisonOperatorsContext {
		let localctx: ComparisonOperatorsContext = new ComparisonOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 48, Vtl.RULE_comparisonOperators);
		let _la: number;
		try {
			this.state = 786;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 40:
				localctx = new BetweenAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 754;
				this.match(Vtl.BETWEEN);
				this.state = 755;
				this.match(Vtl.LPAREN);
				this.state = 756;
				(localctx as BetweenAtomContext)._op = this.expr(0);
				this.state = 757;
				this.match(Vtl.COMMA);
				this.state = 758;
				(localctx as BetweenAtomContext)._from_ = this.expr(0);
				this.state = 759;
				this.match(Vtl.COMMA);
				this.state = 760;
				(localctx as BetweenAtomContext)._to_ = this.expr(0);
				this.state = 761;
				this.match(Vtl.RPAREN);
				}
				break;
			case 99:
				localctx = new CharsetMatchAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 763;
				this.match(Vtl.CHARSET_MATCH);
				this.state = 764;
				this.match(Vtl.LPAREN);
				this.state = 765;
				(localctx as CharsetMatchAtomContext)._op = this.expr(0);
				this.state = 766;
				this.match(Vtl.COMMA);
				this.state = 767;
				(localctx as CharsetMatchAtomContext)._pattern = this.expr(0);
				this.state = 768;
				this.match(Vtl.RPAREN);
				}
				break;
			case 44:
				localctx = new IsNullAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 770;
				this.match(Vtl.ISNULL);
				this.state = 771;
				this.match(Vtl.LPAREN);
				this.state = 772;
				this.expr(0);
				this.state = 773;
				this.match(Vtl.RPAREN);
				}
				break;
			case 55:
				localctx = new ExistInAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 775;
				this.match(Vtl.EXISTS_IN);
				this.state = 776;
				this.match(Vtl.LPAREN);
				this.state = 777;
				(localctx as ExistInAtomContext)._left = this.expr(0);
				this.state = 778;
				this.match(Vtl.COMMA);
				this.state = 779;
				(localctx as ExistInAtomContext)._right = this.expr(0);
				this.state = 782;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 780;
					this.match(Vtl.COMMA);
					this.state = 781;
					this.retainType();
					}
				}

				this.state = 784;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public comparisonOperatorsComponent(): ComparisonOperatorsComponentContext {
		let localctx: ComparisonOperatorsComponentContext = new ComparisonOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 50, Vtl.RULE_comparisonOperatorsComponent);
		try {
			this.state = 809;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 40:
				localctx = new BetweenAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 788;
				this.match(Vtl.BETWEEN);
				this.state = 789;
				this.match(Vtl.LPAREN);
				this.state = 790;
				(localctx as BetweenAtomComponentContext)._op = this.exprComponent(0);
				this.state = 791;
				this.match(Vtl.COMMA);
				this.state = 792;
				(localctx as BetweenAtomComponentContext)._from_ = this.exprComponent(0);
				this.state = 793;
				this.match(Vtl.COMMA);
				this.state = 794;
				(localctx as BetweenAtomComponentContext)._to_ = this.exprComponent(0);
				this.state = 795;
				this.match(Vtl.RPAREN);
				}
				break;
			case 99:
				localctx = new CharsetMatchAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 797;
				this.match(Vtl.CHARSET_MATCH);
				this.state = 798;
				this.match(Vtl.LPAREN);
				this.state = 799;
				(localctx as CharsetMatchAtomComponentContext)._op = this.exprComponent(0);
				this.state = 800;
				this.match(Vtl.COMMA);
				this.state = 801;
				(localctx as CharsetMatchAtomComponentContext)._pattern = this.exprComponent(0);
				this.state = 802;
				this.match(Vtl.RPAREN);
				}
				break;
			case 44:
				localctx = new IsNullAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 804;
				this.match(Vtl.ISNULL);
				this.state = 805;
				this.match(Vtl.LPAREN);
				this.state = 806;
				this.exprComponent(0);
				this.state = 807;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public timeOperators(): TimeOperatorsContext {
		let localctx: TimeOperatorsContext = new TimeOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 52, Vtl.RULE_timeOperators);
		let _la: number;
		try {
			this.state = 857;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 196:
				localctx = new PeriodAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 811;
				this.match(Vtl.PERIOD_INDICATOR);
				this.state = 812;
				this.match(Vtl.LPAREN);
				this.state = 814;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 281042946) !== 0) || ((((_la - 39)) & ~0x1F) === 0 && ((1 << (_la - 39)) & 1610712755) !== 0) || ((((_la - 73)) & ~0x1F) === 0 && ((1 << (_la - 73)) & 881065469) !== 0) || ((((_la - 119)) & ~0x1F) === 0 && ((1 << (_la - 119)) & 3223265151) !== 0) || ((((_la - 151)) & ~0x1F) === 0 && ((1 << (_la - 151)) & 3221225475) !== 0) || ((((_la - 183)) & ~0x1F) === 0 && ((1 << (_la - 183)) & 411115523) !== 0) || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 47) !== 0)) {
					{
					this.state = 813;
					this.expr(0);
					}
				}

				this.state = 816;
				this.match(Vtl.RPAREN);
				}
				break;
			case 149:
				localctx = new FillTimeAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 817;
				this.match(Vtl.FILL_TIME_SERIES);
				this.state = 818;
				this.match(Vtl.LPAREN);
				this.state = 819;
				this.expr(0);
				this.state = 822;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 820;
					this.match(Vtl.COMMA);
					this.state = 821;
					(localctx as FillTimeAtomContext)._op = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===60 || _la===197)) {
					    (localctx as FillTimeAtomContext)._op = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 824;
				this.match(Vtl.RPAREN);
				}
				break;
			case 150:
			case 151:
				localctx = new FlowAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 826;
				(localctx as FlowAtomContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===150 || _la===151)) {
				    (localctx as FlowAtomContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 827;
				this.match(Vtl.LPAREN);
				this.state = 828;
				this.expr(0);
				this.state = 829;
				this.match(Vtl.RPAREN);
				}
				break;
			case 152:
				localctx = new TimeShiftAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 831;
				this.match(Vtl.TIMESHIFT);
				this.state = 832;
				this.match(Vtl.LPAREN);
				this.state = 833;
				this.expr(0);
				this.state = 834;
				this.match(Vtl.COMMA);
				this.state = 835;
				this.signedInteger();
				this.state = 836;
				this.match(Vtl.RPAREN);
				}
				break;
			case 199:
				localctx = new TimeAggAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 838;
				this.match(Vtl.TIME_AGG);
				this.state = 839;
				this.match(Vtl.LPAREN);
				this.state = 840;
				(localctx as TimeAggAtomContext)._periodIndTo = this.match(Vtl.TIME_UNIT);
				this.state = 843;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 65, this._ctx) ) {
				case 1:
					{
					this.state = 841;
					this.match(Vtl.COMMA);
					this.state = 842;
					(localctx as TimeAggAtomContext)._periodIndFrom = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===103 || _la===233)) {
					    (localctx as TimeAggAtomContext)._periodIndFrom = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
					break;
				}
				this.state = 847;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 66, this._ctx) ) {
				case 1:
					{
					this.state = 845;
					this.match(Vtl.COMMA);
					this.state = 846;
					(localctx as TimeAggAtomContext)._op = this.optionalExpr();
					}
					break;
				}
				this.state = 851;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 849;
					this.match(Vtl.COMMA);
					this.state = 850;
					(localctx as TimeAggAtomContext)._delim = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===70 || _la===71)) {
					    (localctx as TimeAggAtomContext)._delim = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 853;
				this.match(Vtl.RPAREN);
				}
				break;
			case 28:
				localctx = new CurrentDateAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 854;
				this.match(Vtl.CURRENT_DATE);
				this.state = 855;
				this.match(Vtl.LPAREN);
				this.state = 856;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public timeOperatorsComponent(): TimeOperatorsComponentContext {
		let localctx: TimeOperatorsComponentContext = new TimeOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 54, Vtl.RULE_timeOperatorsComponent);
		let _la: number;
		try {
			this.state = 905;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 196:
				localctx = new PeriodAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 859;
				this.match(Vtl.PERIOD_INDICATOR);
				this.state = 860;
				this.match(Vtl.LPAREN);
				this.state = 862;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 281042946) !== 0) || ((((_la - 39)) & ~0x1F) === 0 && ((1 << (_la - 39)) & 1677721651) !== 0) || ((((_la - 73)) & ~0x1F) === 0 && ((1 << (_la - 73)) & 344194557) !== 0) || ((((_la - 119)) & ~0x1F) === 0 && ((1 << (_la - 119)) & 3223264895) !== 0) || _la===151 || _la===152 || ((((_la - 196)) & ~0x1F) === 0 && ((1 << (_la - 196)) & 1033) !== 0) || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 47) !== 0)) {
					{
					this.state = 861;
					this.exprComponent(0);
					}
				}

				this.state = 864;
				this.match(Vtl.RPAREN);
				}
				break;
			case 149:
				localctx = new FillTimeAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 865;
				this.match(Vtl.FILL_TIME_SERIES);
				this.state = 866;
				this.match(Vtl.LPAREN);
				this.state = 867;
				this.exprComponent(0);
				this.state = 870;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 868;
					this.match(Vtl.COMMA);
					this.state = 869;
					_la = this._input.LA(1);
					if(!(_la===60 || _la===197)) {
					this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 872;
				this.match(Vtl.RPAREN);
				}
				break;
			case 150:
			case 151:
				localctx = new FlowAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 874;
				(localctx as FlowAtomComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===150 || _la===151)) {
				    (localctx as FlowAtomComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 875;
				this.match(Vtl.LPAREN);
				this.state = 876;
				this.exprComponent(0);
				this.state = 877;
				this.match(Vtl.RPAREN);
				}
				break;
			case 152:
				localctx = new TimeShiftAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 879;
				this.match(Vtl.TIMESHIFT);
				this.state = 880;
				this.match(Vtl.LPAREN);
				this.state = 881;
				this.exprComponent(0);
				this.state = 882;
				this.match(Vtl.COMMA);
				this.state = 883;
				this.signedInteger();
				this.state = 884;
				this.match(Vtl.RPAREN);
				}
				break;
			case 199:
				localctx = new TimeAggAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 886;
				this.match(Vtl.TIME_AGG);
				this.state = 887;
				this.match(Vtl.LPAREN);
				this.state = 888;
				(localctx as TimeAggAtomComponentContext)._periodIndTo = this.match(Vtl.TIME_UNIT);
				this.state = 891;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 71, this._ctx) ) {
				case 1:
					{
					this.state = 889;
					this.match(Vtl.COMMA);
					this.state = 890;
					(localctx as TimeAggAtomComponentContext)._periodIndFrom = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===103 || _la===233)) {
					    (localctx as TimeAggAtomComponentContext)._periodIndFrom = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
					break;
				}
				this.state = 895;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 72, this._ctx) ) {
				case 1:
					{
					this.state = 893;
					this.match(Vtl.COMMA);
					this.state = 894;
					(localctx as TimeAggAtomComponentContext)._op = this.optionalExprComponent();
					}
					break;
				}
				this.state = 899;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 897;
					this.match(Vtl.COMMA);
					this.state = 898;
					(localctx as TimeAggAtomComponentContext)._delim = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===70 || _la===71)) {
					    (localctx as TimeAggAtomComponentContext)._delim = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 901;
				this.match(Vtl.RPAREN);
				}
				break;
			case 28:
				localctx = new CurrentDateAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 902;
				this.match(Vtl.CURRENT_DATE);
				this.state = 903;
				this.match(Vtl.LPAREN);
				this.state = 904;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public setOperators(): SetOperatorsContext {
		let localctx: SetOperatorsContext = new SetOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 56, Vtl.RULE_setOperators);
		let _la: number;
		try {
			this.state = 936;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 46:
				localctx = new UnionAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 907;
				this.match(Vtl.UNION);
				this.state = 908;
				this.match(Vtl.LPAREN);
				this.state = 909;
				(localctx as UnionAtomContext)._left = this.expr(0);
				this.state = 912;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				do {
					{
					{
					this.state = 910;
					this.match(Vtl.COMMA);
					this.state = 911;
					this.expr(0);
					}
					}
					this.state = 914;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				} while (_la===17);
				this.state = 916;
				this.match(Vtl.RPAREN);
				}
				break;
			case 49:
				localctx = new IntersectAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 918;
				this.match(Vtl.INTERSECT);
				this.state = 919;
				this.match(Vtl.LPAREN);
				this.state = 920;
				(localctx as IntersectAtomContext)._left = this.expr(0);
				this.state = 923;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				do {
					{
					{
					this.state = 921;
					this.match(Vtl.COMMA);
					this.state = 922;
					this.expr(0);
					}
					}
					this.state = 925;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				} while (_la===17);
				this.state = 927;
				this.match(Vtl.RPAREN);
				}
				break;
			case 48:
			case 127:
				localctx = new SetOrSYmDiffAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 929;
				(localctx as SetOrSYmDiffAtomContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===48 || _la===127)) {
				    (localctx as SetOrSYmDiffAtomContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 930;
				this.match(Vtl.LPAREN);
				this.state = 931;
				(localctx as SetOrSYmDiffAtomContext)._left = this.expr(0);
				this.state = 932;
				this.match(Vtl.COMMA);
				this.state = 933;
				(localctx as SetOrSYmDiffAtomContext)._right = this.expr(0);
				this.state = 934;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public hierarchyOperators(): HierarchyOperatorsContext {
		let localctx: HierarchyOperatorsContext = new HierarchyOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 58, Vtl.RULE_hierarchyOperators);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 938;
			this.match(Vtl.HIERARCHY);
			this.state = 939;
			this.match(Vtl.LPAREN);
			this.state = 940;
			localctx._op = this.expr(0);
			this.state = 941;
			this.match(Vtl.COMMA);
			this.state = 942;
			localctx._hrName = this.match(Vtl.IDENTIFIER);
			this.state = 944;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===155) {
				{
				this.state = 943;
				this.conditionClause();
				}
			}

			this.state = 948;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 79, this._ctx) ) {
			case 1:
				{
				this.state = 946;
				this.match(Vtl.RULE);
				this.state = 947;
				localctx._ruleComponent = this.componentID();
				}
				break;
			}
			this.state = 951;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (((((_la - 213)) & ~0x1F) === 0 && ((1 << (_la - 213)) & 63) !== 0)) {
				{
				this.state = 950;
				this.validationMode();
				}
			}

			this.state = 954;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===109 || _la===116 || _la===207) {
				{
				this.state = 953;
				this.inputModeHierarchy();
				}
			}

			this.state = 957;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===60 || _la===212) {
				{
				this.state = 956;
				this.outputModeHierarchy();
				}
			}

			this.state = 959;
			this.match(Vtl.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public validationOperators(): ValidationOperatorsContext {
		let localctx: ValidationOperatorsContext = new ValidationOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 60, Vtl.RULE_validationOperators);
		let _la: number;
		try {
			this.state = 1022;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 210:
				localctx = new ValidateDPrulesetContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 961;
				this.match(Vtl.CHECK_DATAPOINT);
				this.state = 962;
				this.match(Vtl.LPAREN);
				this.state = 963;
				(localctx as ValidateDPrulesetContext)._op = this.expr(0);
				this.state = 964;
				this.match(Vtl.COMMA);
				this.state = 965;
				(localctx as ValidateDPrulesetContext)._dpName = this.match(Vtl.IDENTIFIER);
				this.state = 975;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===219) {
					{
					this.state = 966;
					this.match(Vtl.COMPONENTS);
					this.state = 967;
					this.componentID();
					this.state = 972;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 968;
						this.match(Vtl.COMMA);
						this.state = 969;
						this.componentID();
						}
						}
						this.state = 974;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 978;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===60 || _la===104 || _la===220) {
					{
					this.state = 977;
					this.validationOutput();
					}
				}

				this.state = 980;
				this.match(Vtl.RPAREN);
				}
				break;
			case 211:
				localctx = new ValidateHRrulesetContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 982;
				this.match(Vtl.CHECK_HIERARCHY);
				this.state = 983;
				this.match(Vtl.LPAREN);
				this.state = 984;
				(localctx as ValidateHRrulesetContext)._op = this.expr(0);
				this.state = 985;
				this.match(Vtl.COMMA);
				this.state = 986;
				(localctx as ValidateHRrulesetContext)._hrName = this.match(Vtl.IDENTIFIER);
				this.state = 988;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===155) {
					{
					this.state = 987;
					this.conditionClause();
					}
				}

				this.state = 992;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===116) {
					{
					this.state = 990;
					this.match(Vtl.RULE);
					this.state = 991;
					this.componentID();
					}
				}

				this.state = 995;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (((((_la - 213)) & ~0x1F) === 0 && ((1 << (_la - 213)) & 63) !== 0)) {
					{
					this.state = 994;
					this.validationMode();
					}
				}

				this.state = 998;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===109 || _la===208) {
					{
					this.state = 997;
					this.inputMode();
					}
				}

				this.state = 1001;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===60 || _la===104 || _la===220) {
					{
					this.state = 1000;
					this.validationOutput();
					}
				}

				this.state = 1003;
				this.match(Vtl.RPAREN);
				}
				break;
			case 54:
				localctx = new ValidationSimpleContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1005;
				this.match(Vtl.CHECK);
				this.state = 1006;
				this.match(Vtl.LPAREN);
				this.state = 1007;
				(localctx as ValidationSimpleContext)._op = this.expr(0);
				this.state = 1009;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===59) {
					{
					this.state = 1008;
					(localctx as ValidationSimpleContext)._codeErr = this.erCode();
					}
				}

				this.state = 1012;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===62) {
					{
					this.state = 1011;
					(localctx as ValidationSimpleContext)._levelCode = this.erLevel();
					}
				}

				this.state = 1015;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===58) {
					{
					this.state = 1014;
					this.imbalanceExpr();
					}
				}

				this.state = 1018;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===60 || _la===104) {
					{
					this.state = 1017;
					(localctx as ValidationSimpleContext)._output = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===60 || _la===104)) {
					    (localctx as ValidationSimpleContext)._output = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 1020;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public conditionalOperators(): ConditionalOperatorsContext {
		let localctx: ConditionalOperatorsContext = new ConditionalOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 62, Vtl.RULE_conditionalOperators);
		try {
			localctx = new NvlAtomContext(this, localctx);
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1024;
			this.match(Vtl.NVL);
			this.state = 1025;
			this.match(Vtl.LPAREN);
			this.state = 1026;
			(localctx as NvlAtomContext)._left = this.expr(0);
			this.state = 1027;
			this.match(Vtl.COMMA);
			this.state = 1028;
			(localctx as NvlAtomContext)._right = this.expr(0);
			this.state = 1029;
			this.match(Vtl.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public conditionalOperatorsComponent(): ConditionalOperatorsComponentContext {
		let localctx: ConditionalOperatorsComponentContext = new ConditionalOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 64, Vtl.RULE_conditionalOperatorsComponent);
		try {
			localctx = new NvlAtomComponentContext(this, localctx);
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1031;
			this.match(Vtl.NVL);
			this.state = 1032;
			this.match(Vtl.LPAREN);
			this.state = 1033;
			(localctx as NvlAtomComponentContext)._left = this.exprComponent(0);
			this.state = 1034;
			this.match(Vtl.COMMA);
			this.state = 1035;
			(localctx as NvlAtomComponentContext)._right = this.exprComponent(0);
			this.state = 1036;
			this.match(Vtl.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrOperators(): AggrOperatorsContext {
		let localctx: AggrOperatorsContext = new AggrOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 66, Vtl.RULE_aggrOperators);
		let _la: number;
		try {
			this.state = 1046;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 96, this._ctx) ) {
			case 1:
				localctx = new AggrCompContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1038;
				(localctx as AggrCompContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 68)) & ~0x1F) === 0 && ((1 << (_la - 68)) & 7864323) !== 0) || ((((_la - 128)) & ~0x1F) === 0 && ((1 << (_la - 128)) & 15) !== 0))) {
				    (localctx as AggrCompContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1039;
				this.match(Vtl.LPAREN);
				this.state = 1040;
				this.exprComponent(0);
				this.state = 1041;
				this.match(Vtl.RPAREN);
				}
				break;
			case 2:
				localctx = new CountAggrCompContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1043;
				this.match(Vtl.COUNT);
				this.state = 1044;
				this.match(Vtl.LPAREN);
				this.state = 1045;
				this.match(Vtl.RPAREN);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrOperatorsGrouping(): AggrOperatorsGroupingContext {
		let localctx: AggrOperatorsGroupingContext = new AggrOperatorsGroupingContext(this, this._ctx, this.state);
		this.enterRule(localctx, 68, Vtl.RULE_aggrOperatorsGrouping);
		let _la: number;
		try {
			localctx = new AggrDatasetContext(this, localctx);
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1048;
			(localctx as AggrDatasetContext)._op = this._input.LT(1);
			_la = this._input.LA(1);
			if(!(((((_la - 68)) & ~0x1F) === 0 && ((1 << (_la - 68)) & 7864323) !== 0) || ((((_la - 128)) & ~0x1F) === 0 && ((1 << (_la - 128)) & 15) !== 0))) {
			    (localctx as AggrDatasetContext)._op = this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 1049;
			this.match(Vtl.LPAREN);
			this.state = 1050;
			this.expr(0);
			this.state = 1055;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===132) {
				{
				this.state = 1051;
				this.groupingClause();
				this.state = 1053;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===134) {
					{
					this.state = 1052;
					this.havingClause();
					}
				}

				}
			}

			this.state = 1057;
			this.match(Vtl.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public anFunction(): AnFunctionContext {
		let localctx: AnFunctionContext = new AnFunctionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 70, Vtl.RULE_anFunction);
		let _la: number;
		try {
			this.state = 1105;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 68:
			case 69:
			case 87:
			case 88:
			case 89:
			case 90:
			case 128:
			case 129:
			case 130:
			case 131:
			case 135:
			case 136:
				localctx = new AnSimpleFunctionContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1059;
				(localctx as AnSimpleFunctionContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 68)) & ~0x1F) === 0 && ((1 << (_la - 68)) & 7864323) !== 0) || ((((_la - 128)) & ~0x1F) === 0 && ((1 << (_la - 128)) & 399) !== 0))) {
				    (localctx as AnSimpleFunctionContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1060;
				this.match(Vtl.LPAREN);
				this.state = 1061;
				this.expr(0);
				this.state = 1062;
				this.match(Vtl.OVER);
				this.state = 1063;
				this.match(Vtl.LPAREN);
				{
				this.state = 1065;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===144) {
					{
					this.state = 1064;
					(localctx as AnSimpleFunctionContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1068;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===63) {
					{
					this.state = 1067;
					(localctx as AnSimpleFunctionContext)._orderBy = this.orderByClause();
					}
				}

				this.state = 1071;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===107 || _la===146) {
					{
					this.state = 1070;
					(localctx as AnSimpleFunctionContext)._windowing = this.windowingClause();
					}
				}

				}
				this.state = 1073;
				this.match(Vtl.RPAREN);
				this.state = 1074;
				this.match(Vtl.RPAREN);
				}
				break;
			case 137:
			case 138:
				localctx = new LagOrLeadAnContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1076;
				(localctx as LagOrLeadAnContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===137 || _la===138)) {
				    (localctx as LagOrLeadAnContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1077;
				this.match(Vtl.LPAREN);
				this.state = 1078;
				this.expr(0);
				this.state = 1084;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 1079;
					this.match(Vtl.COMMA);
					this.state = 1080;
					(localctx as LagOrLeadAnContext)._offet = this.signedInteger();
					this.state = 1082;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===43 || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 15) !== 0)) {
						{
						this.state = 1081;
						(localctx as LagOrLeadAnContext)._defaultValue = this.constant();
						}
					}

					}
				}

				this.state = 1086;
				this.match(Vtl.OVER);
				this.state = 1087;
				this.match(Vtl.LPAREN);
				{
				this.state = 1089;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===144) {
					{
					this.state = 1088;
					(localctx as LagOrLeadAnContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1091;
				(localctx as LagOrLeadAnContext)._orderBy = this.orderByClause();
				}
				this.state = 1093;
				this.match(Vtl.RPAREN);
				this.state = 1094;
				this.match(Vtl.RPAREN);
				}
				break;
			case 139:
				localctx = new RatioToReportAnContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1096;
				(localctx as RatioToReportAnContext)._op = this.match(Vtl.RATIO_TO_REPORT);
				this.state = 1097;
				this.match(Vtl.LPAREN);
				this.state = 1098;
				this.expr(0);
				this.state = 1099;
				this.match(Vtl.OVER);
				this.state = 1100;
				this.match(Vtl.LPAREN);
				{
				this.state = 1101;
				(localctx as RatioToReportAnContext)._partition = this.partitionByClause();
				}
				this.state = 1102;
				this.match(Vtl.RPAREN);
				this.state = 1103;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public anFunctionComponent(): AnFunctionComponentContext {
		let localctx: AnFunctionComponentContext = new AnFunctionComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 72, Vtl.RULE_anFunctionComponent);
		let _la: number;
		try {
			this.state = 1165;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 68:
			case 69:
			case 87:
			case 88:
			case 89:
			case 90:
			case 128:
			case 129:
			case 130:
			case 131:
			case 135:
			case 136:
				localctx = new AnSimpleFunctionComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1107;
				(localctx as AnSimpleFunctionComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 68)) & ~0x1F) === 0 && ((1 << (_la - 68)) & 7864323) !== 0) || ((((_la - 128)) & ~0x1F) === 0 && ((1 << (_la - 128)) & 399) !== 0))) {
				    (localctx as AnSimpleFunctionComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1108;
				this.match(Vtl.LPAREN);
				this.state = 1109;
				this.exprComponent(0);
				this.state = 1110;
				this.match(Vtl.OVER);
				this.state = 1111;
				this.match(Vtl.LPAREN);
				{
				this.state = 1113;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===144) {
					{
					this.state = 1112;
					(localctx as AnSimpleFunctionComponentContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1116;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===63) {
					{
					this.state = 1115;
					(localctx as AnSimpleFunctionComponentContext)._orderBy = this.orderByClause();
					}
				}

				this.state = 1119;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===107 || _la===146) {
					{
					this.state = 1118;
					(localctx as AnSimpleFunctionComponentContext)._windowing = this.windowingClause();
					}
				}

				}
				this.state = 1121;
				this.match(Vtl.RPAREN);
				this.state = 1122;
				this.match(Vtl.RPAREN);
				}
				break;
			case 137:
			case 138:
				localctx = new LagOrLeadAnComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1124;
				(localctx as LagOrLeadAnComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===137 || _la===138)) {
				    (localctx as LagOrLeadAnComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1125;
				this.match(Vtl.LPAREN);
				this.state = 1126;
				this.exprComponent(0);
				this.state = 1132;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 1127;
					this.match(Vtl.COMMA);
					this.state = 1128;
					(localctx as LagOrLeadAnComponentContext)._offet = this.signedInteger();
					this.state = 1130;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===43 || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 15) !== 0)) {
						{
						this.state = 1129;
						(localctx as LagOrLeadAnComponentContext)._defaultValue = this.constant();
						}
					}

					}
				}

				this.state = 1134;
				this.match(Vtl.OVER);
				this.state = 1135;
				this.match(Vtl.LPAREN);
				{
				this.state = 1137;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===144) {
					{
					this.state = 1136;
					(localctx as LagOrLeadAnComponentContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1139;
				(localctx as LagOrLeadAnComponentContext)._orderBy = this.orderByClause();
				}
				this.state = 1141;
				this.match(Vtl.RPAREN);
				this.state = 1142;
				this.match(Vtl.RPAREN);
				}
				break;
			case 65:
				localctx = new RankAnComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1144;
				(localctx as RankAnComponentContext)._op = this.match(Vtl.RANK);
				this.state = 1145;
				this.match(Vtl.LPAREN);
				this.state = 1146;
				this.match(Vtl.OVER);
				this.state = 1147;
				this.match(Vtl.LPAREN);
				{
				this.state = 1149;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===144) {
					{
					this.state = 1148;
					(localctx as RankAnComponentContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1151;
				(localctx as RankAnComponentContext)._orderBy = this.orderByClause();
				}
				this.state = 1153;
				this.match(Vtl.RPAREN);
				this.state = 1154;
				this.match(Vtl.RPAREN);
				}
				break;
			case 139:
				localctx = new RatioToReportAnComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1156;
				(localctx as RatioToReportAnComponentContext)._op = this.match(Vtl.RATIO_TO_REPORT);
				this.state = 1157;
				this.match(Vtl.LPAREN);
				this.state = 1158;
				this.exprComponent(0);
				this.state = 1159;
				this.match(Vtl.OVER);
				this.state = 1160;
				this.match(Vtl.LPAREN);
				{
				this.state = 1161;
				(localctx as RatioToReportAnComponentContext)._partition = this.partitionByClause();
				}
				this.state = 1162;
				this.match(Vtl.RPAREN);
				this.state = 1163;
				this.match(Vtl.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public renameClauseItem(): RenameClauseItemContext {
		let localctx: RenameClauseItemContext = new RenameClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 74, Vtl.RULE_renameClauseItem);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1167;
			localctx._fromName = this.componentID();
			this.state = 1168;
			this.match(Vtl.TO);
			this.state = 1169;
			localctx._toName = this.componentID();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggregateClause(): AggregateClauseContext {
		let localctx: AggregateClauseContext = new AggregateClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 76, Vtl.RULE_aggregateClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1171;
			this.aggrFunctionClause();
			this.state = 1176;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1172;
				this.match(Vtl.COMMA);
				this.state = 1173;
				this.aggrFunctionClause();
				}
				}
				this.state = 1178;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrFunctionClause(): AggrFunctionClauseContext {
		let localctx: AggrFunctionClauseContext = new AggrFunctionClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 78, Vtl.RULE_aggrFunctionClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1180;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (((((_la - 91)) & ~0x1F) === 0 && ((1 << (_la - 91)) & 135) !== 0) || _la===222) {
				{
				this.state = 1179;
				this.componentRole();
				}
			}

			this.state = 1182;
			this.componentID();
			this.state = 1183;
			this.match(Vtl.ASSIGN);
			this.state = 1184;
			this.aggrOperators();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public calcClauseItem(): CalcClauseItemContext {
		let localctx: CalcClauseItemContext = new CalcClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 80, Vtl.RULE_calcClauseItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1187;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (((((_la - 91)) & ~0x1F) === 0 && ((1 << (_la - 91)) & 135) !== 0) || _la===222) {
				{
				this.state = 1186;
				this.componentRole();
				}
			}

			this.state = 1189;
			this.componentID();
			this.state = 1190;
			this.match(Vtl.ASSIGN);
			this.state = 1191;
			this.exprComponent(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public subspaceClauseItem(): SubspaceClauseItemContext {
		let localctx: SubspaceClauseItemContext = new SubspaceClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 82, Vtl.RULE_subspaceClauseItem);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1193;
			this.componentID();
			this.state = 1194;
			this.match(Vtl.EQ);
			this.state = 1195;
			this.constant();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinClauseWithoutUsing(): JoinClauseWithoutUsingContext {
		let localctx: JoinClauseWithoutUsingContext = new JoinClauseWithoutUsingContext(this, this._ctx, this.state);
		this.enterRule(localctx, 84, Vtl.RULE_joinClauseWithoutUsing);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1197;
			this.joinClauseItem();
			this.state = 1202;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1198;
				this.match(Vtl.COMMA);
				this.state = 1199;
				this.joinClauseItem();
				}
				}
				this.state = 1204;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinClause(): JoinClauseContext {
		let localctx: JoinClauseContext = new JoinClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 86, Vtl.RULE_joinClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1205;
			this.joinClauseItem();
			this.state = 1210;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1206;
				this.match(Vtl.COMMA);
				this.state = 1207;
				this.joinClauseItem();
				}
				}
				this.state = 1212;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 1222;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===26) {
				{
				this.state = 1213;
				this.match(Vtl.USING);
				this.state = 1214;
				this.componentID();
				this.state = 1219;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1215;
					this.match(Vtl.COMMA);
					this.state = 1216;
					this.componentID();
					}
					}
					this.state = 1221;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinClauseItem(): JoinClauseItemContext {
		let localctx: JoinClauseItemContext = new JoinClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 88, Vtl.RULE_joinClauseItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1224;
			this.expr(0);
			this.state = 1227;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===35) {
				{
				this.state = 1225;
				this.match(Vtl.AS);
				this.state = 1226;
				this.alias();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinBody(): JoinBodyContext {
		let localctx: JoinBodyContext = new JoinBodyContext(this, this._ctx, this.state);
		this.enterRule(localctx, 90, Vtl.RULE_joinBody);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1230;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===94) {
				{
				this.state = 1229;
				this.filterClause();
				}
			}

			this.state = 1235;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 32:
				{
				this.state = 1232;
				this.calcClause();
				}
				break;
			case 194:
				{
				this.state = 1233;
				this.joinApplyClause();
				}
				break;
			case 61:
				{
				this.state = 1234;
				this.aggrClause();
				}
				break;
			case 2:
			case 30:
			case 31:
			case 34:
				break;
			default:
				break;
			}
			this.state = 1238;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===30 || _la===31) {
				{
				this.state = 1237;
				this.keepOrDropClause();
				}
			}

			this.state = 1241;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===34) {
				{
				this.state = 1240;
				this.renameClause();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinApplyClause(): JoinApplyClauseContext {
		let localctx: JoinApplyClauseContext = new JoinApplyClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 92, Vtl.RULE_joinApplyClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1243;
			this.match(Vtl.APPLY);
			this.state = 1244;
			this.expr(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public partitionByClause(): PartitionByClauseContext {
		let localctx: PartitionByClauseContext = new PartitionByClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 94, Vtl.RULE_partitionByClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1246;
			this.match(Vtl.PARTITION);
			this.state = 1247;
			this.match(Vtl.BY);
			this.state = 1248;
			this.componentID();
			this.state = 1253;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1249;
				this.match(Vtl.COMMA);
				this.state = 1250;
				this.componentID();
				}
				}
				this.state = 1255;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public orderByClause(): OrderByClauseContext {
		let localctx: OrderByClauseContext = new OrderByClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 96, Vtl.RULE_orderByClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1256;
			this.match(Vtl.ORDER);
			this.state = 1257;
			this.match(Vtl.BY);
			this.state = 1258;
			this.orderByItem();
			this.state = 1263;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1259;
				this.match(Vtl.COMMA);
				this.state = 1260;
				this.orderByItem();
				}
				}
				this.state = 1265;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public orderByItem(): OrderByItemContext {
		let localctx: OrderByItemContext = new OrderByItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 98, Vtl.RULE_orderByItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1266;
			this.componentID();
			this.state = 1268;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===66 || _la===67) {
				{
				this.state = 1267;
				_la = this._input.LA(1);
				if(!(_la===66 || _la===67)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public windowingClause(): WindowingClauseContext {
		let localctx: WindowingClauseContext = new WindowingClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 100, Vtl.RULE_windowingClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1273;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 107:
				{
				{
				this.state = 1270;
				this.match(Vtl.DATA);
				this.state = 1271;
				this.match(Vtl.POINTS);
				}
				}
				break;
			case 146:
				{
				this.state = 1272;
				this.match(Vtl.RANGE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			this.state = 1275;
			this.match(Vtl.BETWEEN);
			this.state = 1276;
			localctx._from_ = this.limitClauseItem();
			this.state = 1277;
			this.match(Vtl.AND);
			this.state = 1278;
			localctx._to_ = this.limitClauseItem();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public signedInteger(): SignedIntegerContext {
		let localctx: SignedIntegerContext = new SignedIntegerContext(this, this._ctx, this.state);
		this.enterRule(localctx, 102, Vtl.RULE_signedInteger);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1280;
			this.match(Vtl.INTEGER_CONSTANT);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public limitClauseItem(): LimitClauseItemContext {
		let localctx: LimitClauseItemContext = new LimitClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 104, Vtl.RULE_limitClauseItem);
		try {
			this.state = 1293;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 130, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1282;
				this.match(Vtl.INTEGER_CONSTANT);
				this.state = 1283;
				localctx._dir = this.match(Vtl.PRECEDING);
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1284;
				this.match(Vtl.INTEGER_CONSTANT);
				this.state = 1285;
				localctx._dir = this.match(Vtl.FOLLOWING);
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1286;
				this.match(Vtl.CURRENT);
				this.state = 1287;
				this.match(Vtl.DATA);
				this.state = 1288;
				this.match(Vtl.POINT);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1289;
				this.match(Vtl.UNBOUNDED);
				this.state = 1290;
				localctx._dir = this.match(Vtl.PRECEDING);
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1291;
				this.match(Vtl.UNBOUNDED);
				this.state = 1292;
				localctx._dir = this.match(Vtl.FOLLOWING);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public groupingClause(): GroupingClauseContext {
		let localctx: GroupingClauseContext = new GroupingClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 106, Vtl.RULE_groupingClause);
		let _la: number;
		try {
			this.state = 1324;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 135, this._ctx) ) {
			case 1:
				localctx = new GroupByOrExceptContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1295;
				this.match(Vtl.GROUP);
				this.state = 1296;
				(localctx as GroupByOrExceptContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===64 || _la===133)) {
				    (localctx as GroupByOrExceptContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1297;
				this.componentID();
				this.state = 1302;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1298;
					this.match(Vtl.COMMA);
					this.state = 1299;
					this.componentID();
					}
					}
					this.state = 1304;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1313;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===199) {
					{
					this.state = 1305;
					this.match(Vtl.TIME_AGG);
					this.state = 1306;
					this.match(Vtl.LPAREN);
					this.state = 1307;
					this.match(Vtl.TIME_UNIT);
					this.state = 1310;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						this.state = 1308;
						this.match(Vtl.COMMA);
						this.state = 1309;
						(localctx as GroupByOrExceptContext)._delim = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===70 || _la===71)) {
						    (localctx as GroupByOrExceptContext)._delim = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						}
					}

					this.state = 1312;
					this.match(Vtl.RPAREN);
					}
				}

				}
				break;
			case 2:
				localctx = new GroupAllContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1315;
				this.match(Vtl.GROUP);
				this.state = 1316;
				this.match(Vtl.ALL);
				this.state = 1317;
				this.exprComponent(0);
				this.state = 1322;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===199) {
					{
					this.state = 1318;
					this.match(Vtl.TIME_AGG);
					this.state = 1319;
					this.match(Vtl.LPAREN);
					this.state = 1320;
					this.match(Vtl.TIME_UNIT);
					this.state = 1321;
					this.match(Vtl.RPAREN);
					}
				}

				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public havingClause(): HavingClauseContext {
		let localctx: HavingClauseContext = new HavingClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 108, Vtl.RULE_havingClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1326;
			this.match(Vtl.HAVING);
			this.state = 1327;
			this.exprComponent(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public parameterItem(): ParameterItemContext {
		let localctx: ParameterItemContext = new ParameterItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 110, Vtl.RULE_parameterItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1329;
			this.varID();
			this.state = 1330;
			this.inputParameterType();
			this.state = 1333;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===209) {
				{
				this.state = 1331;
				this.match(Vtl.DEFAULT);
				this.state = 1332;
				this.constant();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public outputParameterType(): OutputParameterTypeContext {
		let localctx: OutputParameterTypeContext = new OutputParameterTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 112, Vtl.RULE_outputParameterType);
		try {
			this.state = 1338;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 156:
			case 157:
			case 158:
			case 159:
			case 160:
			case 161:
			case 162:
			case 198:
			case 221:
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1335;
				this.scalarType();
				}
				break;
			case 109:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1336;
				this.datasetType();
				}
				break;
			case 91:
			case 92:
			case 93:
			case 98:
			case 222:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1337;
				this.componentType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public outputParameterTypeComponent(): OutputParameterTypeComponentContext {
		let localctx: OutputParameterTypeComponentContext = new OutputParameterTypeComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 114, Vtl.RULE_outputParameterTypeComponent);
		try {
			this.state = 1342;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 91:
			case 92:
			case 93:
			case 98:
			case 222:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1340;
				this.componentType();
				}
				break;
			case 156:
			case 157:
			case 158:
			case 159:
			case 160:
			case 161:
			case 162:
			case 198:
			case 221:
			case 234:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1341;
				this.scalarType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inputParameterType(): InputParameterTypeContext {
		let localctx: InputParameterTypeContext = new InputParameterTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 116, Vtl.RULE_inputParameterType);
		try {
			this.state = 1349;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 156:
			case 157:
			case 158:
			case 159:
			case 160:
			case 161:
			case 162:
			case 198:
			case 221:
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1344;
				this.scalarType();
				}
				break;
			case 109:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1345;
				this.datasetType();
				}
				break;
			case 227:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1346;
				this.scalarSetType();
				}
				break;
			case 113:
			case 114:
			case 115:
			case 223:
			case 224:
			case 225:
			case 226:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1347;
				this.rulesetType();
				}
				break;
			case 91:
			case 92:
			case 93:
			case 98:
			case 222:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1348;
				this.componentType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public rulesetType(): RulesetTypeContext {
		let localctx: RulesetTypeContext = new RulesetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 118, Vtl.RULE_rulesetType);
		try {
			this.state = 1354;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 115:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1351;
				this.match(Vtl.RULESET);
				}
				break;
			case 113:
			case 223:
			case 224:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1352;
				this.dpRuleset();
				}
				break;
			case 114:
			case 225:
			case 226:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1353;
				this.hrRuleset();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarType(): ScalarTypeContext {
		let localctx: ScalarTypeContext = new ScalarTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 120, Vtl.RULE_scalarType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1358;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 156:
			case 157:
			case 158:
			case 159:
			case 160:
			case 161:
			case 162:
			case 198:
			case 221:
				{
				this.state = 1356;
				this.basicScalarType();
				}
				break;
			case 234:
				{
				this.state = 1357;
				this.valueDomainName();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			this.state = 1361;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===3 || _la===5) {
				{
				this.state = 1360;
				this.scalarTypeConstraint();
				}
			}

			this.state = 1367;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===39 || _la===43) {
				{
				this.state = 1364;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===39) {
					{
					this.state = 1363;
					this.match(Vtl.NOT);
					}
				}

				this.state = 1366;
				this.match(Vtl.NULL_CONSTANT);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public componentType(): ComponentTypeContext {
		let localctx: ComponentTypeContext = new ComponentTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 122, Vtl.RULE_componentType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1369;
			this.componentRole();
			this.state = 1374;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===8) {
				{
				this.state = 1370;
				this.match(Vtl.LT);
				this.state = 1371;
				this.scalarType();
				this.state = 1372;
				this.match(Vtl.MT);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public datasetType(): DatasetTypeContext {
		let localctx: DatasetTypeContext = new DatasetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 124, Vtl.RULE_datasetType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1376;
			this.match(Vtl.DATASET);
			this.state = 1388;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===5) {
				{
				this.state = 1377;
				this.match(Vtl.GLPAREN);
				this.state = 1378;
				this.compConstraint();
				this.state = 1383;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1379;
					this.match(Vtl.COMMA);
					this.state = 1380;
					this.compConstraint();
					}
					}
					this.state = 1385;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1386;
				this.match(Vtl.GRPAREN);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarSetType(): ScalarSetTypeContext {
		let localctx: ScalarSetTypeContext = new ScalarSetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 126, Vtl.RULE_scalarSetType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1390;
			this.match(Vtl.SET);
			this.state = 1395;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===8) {
				{
				this.state = 1391;
				this.match(Vtl.LT);
				this.state = 1392;
				this.scalarType();
				this.state = 1393;
				this.match(Vtl.MT);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public dpRuleset(): DpRulesetContext {
		let localctx: DpRulesetContext = new DpRulesetContext(this, this._ctx, this.state);
		this.enterRule(localctx, 128, Vtl.RULE_dpRuleset);
		let _la: number;
		try {
			this.state = 1426;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 113:
				localctx = new DataPointContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1397;
				this.match(Vtl.DATAPOINT);
				}
				break;
			case 223:
				localctx = new DataPointVdContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1398;
				this.match(Vtl.DATAPOINT_ON_VD);
				this.state = 1410;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1399;
					this.match(Vtl.GLPAREN);
					this.state = 1400;
					this.valueDomainName();
					this.state = 1405;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===15) {
						{
						{
						this.state = 1401;
						this.match(Vtl.MUL);
						this.state = 1402;
						this.valueDomainName();
						}
						}
						this.state = 1407;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 1408;
					this.match(Vtl.GRPAREN);
					}
				}

				}
				break;
			case 224:
				localctx = new DataPointVarContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1412;
				this.match(Vtl.DATAPOINT_ON_VAR);
				this.state = 1424;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1413;
					this.match(Vtl.GLPAREN);
					this.state = 1414;
					this.varID();
					this.state = 1419;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===15) {
						{
						{
						this.state = 1415;
						this.match(Vtl.MUL);
						this.state = 1416;
						this.varID();
						}
						}
						this.state = 1421;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 1422;
					this.match(Vtl.GRPAREN);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public hrRuleset(): HrRulesetContext {
		let localctx: HrRulesetContext = new HrRulesetContext(this, this._ctx, this.state);
		this.enterRule(localctx, 130, Vtl.RULE_hrRuleset);
		let _la: number;
		try {
			this.state = 1468;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 114:
				localctx = new HrRulesetTypeContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1428;
				this.match(Vtl.HIERARCHICAL);
				}
				break;
			case 225:
				localctx = new HrRulesetVdTypeContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1429;
				this.match(Vtl.HIERARCHICAL_ON_VD);
				this.state = 1446;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1430;
					this.match(Vtl.GLPAREN);
					this.state = 1431;
					(localctx as HrRulesetVdTypeContext)._vdName = this.match(Vtl.IDENTIFIER);
					this.state = 1443;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===1) {
						{
						this.state = 1432;
						this.match(Vtl.LPAREN);
						this.state = 1433;
						this.valueDomainName();
						this.state = 1438;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
						while (_la===15) {
							{
							{
							this.state = 1434;
							this.match(Vtl.MUL);
							this.state = 1435;
							this.valueDomainName();
							}
							}
							this.state = 1440;
							this._errHandler.sync(this);
							_la = this._input.LA(1);
						}
						this.state = 1441;
						this.match(Vtl.RPAREN);
						}
					}

					this.state = 1445;
					this.match(Vtl.GRPAREN);
					}
				}

				}
				break;
			case 226:
				localctx = new HrRulesetVarTypeContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1448;
				this.match(Vtl.HIERARCHICAL_ON_VAR);
				this.state = 1466;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1449;
					this.match(Vtl.GLPAREN);
					this.state = 1450;
					(localctx as HrRulesetVarTypeContext)._varName = this.varID();
					this.state = 1462;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===1) {
						{
						this.state = 1451;
						this.match(Vtl.LPAREN);
						this.state = 1452;
						this.varID();
						this.state = 1457;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
						while (_la===15) {
							{
							{
							this.state = 1453;
							this.match(Vtl.MUL);
							this.state = 1454;
							this.varID();
							}
							}
							this.state = 1459;
							this._errHandler.sync(this);
							_la = this._input.LA(1);
						}
						this.state = 1460;
						this.match(Vtl.RPAREN);
						}
					}

					this.state = 1464;
					this.match(Vtl.GRPAREN);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainName(): ValueDomainNameContext {
		let localctx: ValueDomainNameContext = new ValueDomainNameContext(this, this._ctx, this.state);
		this.enterRule(localctx, 132, Vtl.RULE_valueDomainName);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1470;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public rulesetID(): RulesetIDContext {
		let localctx: RulesetIDContext = new RulesetIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 134, Vtl.RULE_rulesetID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1472;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public rulesetSignature(): RulesetSignatureContext {
		let localctx: RulesetSignatureContext = new RulesetSignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 136, Vtl.RULE_rulesetSignature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1474;
			_la = this._input.LA(1);
			if(!(_la===105 || _la===106)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 1475;
			this.signature();
			this.state = 1480;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1476;
				this.match(Vtl.COMMA);
				this.state = 1477;
				this.signature();
				}
				}
				this.state = 1482;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public signature(): SignatureContext {
		let localctx: SignatureContext = new SignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 138, Vtl.RULE_signature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1483;
			this.varID();
			this.state = 1486;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===35) {
				{
				this.state = 1484;
				this.match(Vtl.AS);
				this.state = 1485;
				this.alias();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleClauseDatapoint(): RuleClauseDatapointContext {
		let localctx: RuleClauseDatapointContext = new RuleClauseDatapointContext(this, this._ctx, this.state);
		this.enterRule(localctx, 140, Vtl.RULE_ruleClauseDatapoint);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1488;
			this.ruleItemDatapoint();
			this.state = 1493;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===236) {
				{
				{
				this.state = 1489;
				this.match(Vtl.EOL);
				this.state = 1490;
				this.ruleItemDatapoint();
				}
				}
				this.state = 1495;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleItemDatapoint(): RuleItemDatapointContext {
		let localctx: RuleItemDatapointContext = new RuleItemDatapointContext(this, this._ctx, this.state);
		this.enterRule(localctx, 142, Vtl.RULE_ruleItemDatapoint);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1498;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 164, this._ctx) ) {
			case 1:
				{
				this.state = 1496;
				localctx._ruleName = this.match(Vtl.IDENTIFIER);
				this.state = 1497;
				this.match(Vtl.COLON);
				}
				break;
			}
			this.state = 1504;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===173) {
				{
				this.state = 1500;
				this.match(Vtl.WHEN);
				this.state = 1501;
				localctx._antecedentContiditon = this.exprComponent(0);
				this.state = 1502;
				this.match(Vtl.THEN);
				}
			}

			this.state = 1506;
			localctx._consequentCondition = this.exprComponent(0);
			this.state = 1508;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===59) {
				{
				this.state = 1507;
				this.erCode();
				}
			}

			this.state = 1511;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===62) {
				{
				this.state = 1510;
				this.erLevel();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleClauseHierarchical(): RuleClauseHierarchicalContext {
		let localctx: RuleClauseHierarchicalContext = new RuleClauseHierarchicalContext(this, this._ctx, this.state);
		this.enterRule(localctx, 144, Vtl.RULE_ruleClauseHierarchical);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1513;
			this.ruleItemHierarchical();
			this.state = 1518;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===236) {
				{
				{
				this.state = 1514;
				this.match(Vtl.EOL);
				this.state = 1515;
				this.ruleItemHierarchical();
				}
				}
				this.state = 1520;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleItemHierarchical(): RuleItemHierarchicalContext {
		let localctx: RuleItemHierarchicalContext = new RuleItemHierarchicalContext(this, this._ctx, this.state);
		this.enterRule(localctx, 146, Vtl.RULE_ruleItemHierarchical);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1523;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 169, this._ctx) ) {
			case 1:
				{
				this.state = 1521;
				localctx._ruleName = this.match(Vtl.IDENTIFIER);
				this.state = 1522;
				this.match(Vtl.COLON);
				}
				break;
			}
			this.state = 1525;
			this.codeItemRelation();
			this.state = 1527;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===59) {
				{
				this.state = 1526;
				this.erCode();
				}
			}

			this.state = 1530;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===62) {
				{
				this.state = 1529;
				this.erLevel();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public hierRuleSignature(): HierRuleSignatureContext {
		let localctx: HierRuleSignatureContext = new HierRuleSignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 148, Vtl.RULE_hierRuleSignature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1532;
			_la = this._input.LA(1);
			if(!(_la===105 || _la===106)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 1535;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===155) {
				{
				this.state = 1533;
				this.match(Vtl.CONDITION);
				this.state = 1534;
				this.valueDomainSignature();
				}
			}

			this.state = 1537;
			this.match(Vtl.RULE);
			this.state = 1538;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainSignature(): ValueDomainSignatureContext {
		let localctx: ValueDomainSignatureContext = new ValueDomainSignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 150, Vtl.RULE_valueDomainSignature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1540;
			this.signature();
			this.state = 1545;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1541;
				this.match(Vtl.COMMA);
				this.state = 1542;
				this.signature();
				}
				}
				this.state = 1547;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public codeItemRelation(): CodeItemRelationContext {
		let localctx: CodeItemRelationContext = new CodeItemRelationContext(this, this._ctx, this.state);
		this.enterRule(localctx, 152, Vtl.RULE_codeItemRelation);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1552;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===173) {
				{
				this.state = 1548;
				this.match(Vtl.WHEN);
				this.state = 1549;
				this.exprComponent(0);
				this.state = 1550;
				this.match(Vtl.THEN);
				}
			}

			this.state = 1554;
			localctx._codeItemRef = this.valueDomainValue();
			this.state = 1556;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 8064) !== 0)) {
				{
				this.state = 1555;
				this.comparisonOperand();
				}
			}

			this.state = 1558;
			this.codeItemRelationClause();
			this.state = 1562;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===13 || _la===14 || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 35) !== 0)) {
				{
				{
				this.state = 1559;
				this.codeItemRelationClause();
				}
				}
				this.state = 1564;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public codeItemRelationClause(): CodeItemRelationClauseContext {
		let localctx: CodeItemRelationClauseContext = new CodeItemRelationClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 154, Vtl.RULE_codeItemRelationClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1566;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===13 || _la===14) {
				{
				this.state = 1565;
				localctx._opAdd = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===13 || _la===14)) {
				    localctx._opAdd = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			this.state = 1568;
			localctx._rightCodeItem = this.valueDomainValue();
			this.state = 1573;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===3) {
				{
				this.state = 1569;
				this.match(Vtl.QLPAREN);
				this.state = 1570;
				localctx._rightCondition = this.exprComponent(0);
				this.state = 1571;
				this.match(Vtl.QRPAREN);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainValue(): ValueDomainValueContext {
		let localctx: ValueDomainValueContext = new ValueDomainValueContext(this, this._ctx, this.state);
		this.enterRule(localctx, 156, Vtl.RULE_valueDomainValue);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1575;
			_la = this._input.LA(1);
			if(!(((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 35) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarTypeConstraint(): ScalarTypeConstraintContext {
		let localctx: ScalarTypeConstraintContext = new ScalarTypeConstraintContext(this, this._ctx, this.state);
		this.enterRule(localctx, 158, Vtl.RULE_scalarTypeConstraint);
		let _la: number;
		try {
			this.state = 1592;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 3:
				localctx = new ConditionConstraintContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1577;
				this.match(Vtl.QLPAREN);
				this.state = 1578;
				this.exprComponent(0);
				this.state = 1579;
				this.match(Vtl.QRPAREN);
				}
				break;
			case 5:
				localctx = new RangeConstraintContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1581;
				this.match(Vtl.GLPAREN);
				this.state = 1582;
				this.constant();
				this.state = 1587;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1583;
					this.match(Vtl.COMMA);
					this.state = 1584;
					this.constant();
					}
					}
					this.state = 1589;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1590;
				this.match(Vtl.GRPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public compConstraint(): CompConstraintContext {
		let localctx: CompConstraintContext = new CompConstraintContext(this, this._ctx, this.state);
		this.enterRule(localctx, 160, Vtl.RULE_compConstraint);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1594;
			this.componentType();
			this.state = 1597;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 234:
				{
				this.state = 1595;
				this.componentID();
				}
				break;
			case 103:
				{
				this.state = 1596;
				this.multModifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public multModifier(): MultModifierContext {
		let localctx: MultModifierContext = new MultModifierContext(this, this._ctx, this.state);
		this.enterRule(localctx, 162, Vtl.RULE_multModifier);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1599;
			this.match(Vtl.OPTIONAL);
			this.state = 1601;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===13 || _la===15) {
				{
				this.state = 1600;
				_la = this._input.LA(1);
				if(!(_la===13 || _la===15)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public validationOutput(): ValidationOutputContext {
		let localctx: ValidationOutputContext = new ValidationOutputContext(this, this._ctx, this.state);
		this.enterRule(localctx, 164, Vtl.RULE_validationOutput);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1603;
			_la = this._input.LA(1);
			if(!(_la===60 || _la===104 || _la===220)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public validationMode(): ValidationModeContext {
		let localctx: ValidationModeContext = new ValidationModeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 166, Vtl.RULE_validationMode);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1605;
			_la = this._input.LA(1);
			if(!(((((_la - 213)) & ~0x1F) === 0 && ((1 << (_la - 213)) & 63) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public conditionClause(): ConditionClauseContext {
		let localctx: ConditionClauseContext = new ConditionClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 168, Vtl.RULE_conditionClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1607;
			this.match(Vtl.CONDITION);
			this.state = 1608;
			this.componentID();
			this.state = 1613;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1609;
				this.match(Vtl.COMMA);
				this.state = 1610;
				this.componentID();
				}
				}
				this.state = 1615;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inputMode(): InputModeContext {
		let localctx: InputModeContext = new InputModeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 170, Vtl.RULE_inputMode);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1616;
			_la = this._input.LA(1);
			if(!(_la===109 || _la===208)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public imbalanceExpr(): ImbalanceExprContext {
		let localctx: ImbalanceExprContext = new ImbalanceExprContext(this, this._ctx, this.state);
		this.enterRule(localctx, 172, Vtl.RULE_imbalanceExpr);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1618;
			this.match(Vtl.IMBALANCE);
			this.state = 1619;
			this.expr(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inputModeHierarchy(): InputModeHierarchyContext {
		let localctx: InputModeHierarchyContext = new InputModeHierarchyContext(this, this._ctx, this.state);
		this.enterRule(localctx, 174, Vtl.RULE_inputModeHierarchy);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1621;
			_la = this._input.LA(1);
			if(!(_la===109 || _la===116 || _la===207)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public outputModeHierarchy(): OutputModeHierarchyContext {
		let localctx: OutputModeHierarchyContext = new OutputModeHierarchyContext(this, this._ctx, this.state);
		this.enterRule(localctx, 176, Vtl.RULE_outputModeHierarchy);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1623;
			_la = this._input.LA(1);
			if(!(_la===60 || _la===212)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public alias(): AliasContext {
		let localctx: AliasContext = new AliasContext(this, this._ctx, this.state);
		this.enterRule(localctx, 178, Vtl.RULE_alias);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1625;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public varID(): VarIDContext {
		let localctx: VarIDContext = new VarIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 180, Vtl.RULE_varID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1627;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public simpleComponentId(): SimpleComponentIdContext {
		let localctx: SimpleComponentIdContext = new SimpleComponentIdContext(this, this._ctx, this.state);
		this.enterRule(localctx, 182, Vtl.RULE_simpleComponentId);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1629;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public componentID(): ComponentIDContext {
		let localctx: ComponentIDContext = new ComponentIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 184, Vtl.RULE_componentID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1631;
			this.match(Vtl.IDENTIFIER);
			this.state = 1634;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 184, this._ctx) ) {
			case 1:
				{
				this.state = 1632;
				this.match(Vtl.MEMBERSHIP);
				this.state = 1633;
				this.match(Vtl.IDENTIFIER);
				}
				break;
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inexpr(): InexprContext {
		let localctx: InexprContext = new InexprContext(this, this._ctx, this.state);
		this.enterRule(localctx, 186, Vtl.RULE_inexpr);
		let _la: number;
		try {
			this.state = 1648;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 5:
				localctx = new SetExprContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1636;
				this.match(Vtl.GLPAREN);
				this.state = 1637;
				this.constant();
				this.state = 1642;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1638;
					this.match(Vtl.COMMA);
					this.state = 1639;
					this.constant();
					}
					}
					this.state = 1644;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1645;
				this.match(Vtl.GRPAREN);
				}
				break;
			case 234:
				localctx = new ValueDomainExprContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1647;
				this.valueDomainID();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public erCode(): ErCodeContext {
		let localctx: ErCodeContext = new ErCodeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 188, Vtl.RULE_erCode);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1650;
			this.match(Vtl.ERRORCODE);
			this.state = 1651;
			this.constant();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public erLevel(): ErLevelContext {
		let localctx: ErLevelContext = new ErLevelContext(this, this._ctx, this.state);
		this.enterRule(localctx, 190, Vtl.RULE_erLevel);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1653;
			this.match(Vtl.ERRORLEVEL);
			this.state = 1654;
			this.constant();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public comparisonOperand(): ComparisonOperandContext {
		let localctx: ComparisonOperandContext = new ComparisonOperandContext(this, this._ctx, this.state);
		this.enterRule(localctx, 192, Vtl.RULE_comparisonOperand);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1656;
			_la = this._input.LA(1);
			if(!((((_la) & ~0x1F) === 0 && ((1 << _la) & 8064) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public optionalExpr(): OptionalExprContext {
		let localctx: OptionalExprContext = new OptionalExprContext(this, this._ctx, this.state);
		this.enterRule(localctx, 194, Vtl.RULE_optionalExpr);
		try {
			this.state = 1660;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 13:
			case 14:
			case 22:
			case 23:
			case 28:
			case 39:
			case 40:
			case 43:
			case 44:
			case 46:
			case 48:
			case 49:
			case 54:
			case 55:
			case 68:
			case 69:
			case 73:
			case 75:
			case 76:
			case 77:
			case 78:
			case 79:
			case 80:
			case 81:
			case 83:
			case 84:
			case 85:
			case 86:
			case 87:
			case 88:
			case 89:
			case 90:
			case 96:
			case 99:
			case 101:
			case 102:
			case 119:
			case 120:
			case 121:
			case 122:
			case 123:
			case 124:
			case 125:
			case 127:
			case 128:
			case 129:
			case 130:
			case 131:
			case 135:
			case 136:
			case 137:
			case 138:
			case 139:
			case 149:
			case 150:
			case 151:
			case 152:
			case 181:
			case 182:
			case 183:
			case 184:
			case 196:
			case 199:
			case 206:
			case 210:
			case 211:
			case 229:
			case 230:
			case 231:
			case 232:
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1658;
				this.expr(0);
				}
				break;
			case 103:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1659;
				this.match(Vtl.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public optionalExprComponent(): OptionalExprComponentContext {
		let localctx: OptionalExprComponentContext = new OptionalExprComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 196, Vtl.RULE_optionalExprComponent);
		try {
			this.state = 1664;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 13:
			case 14:
			case 22:
			case 23:
			case 28:
			case 39:
			case 40:
			case 43:
			case 44:
			case 65:
			case 68:
			case 69:
			case 73:
			case 75:
			case 76:
			case 77:
			case 78:
			case 79:
			case 80:
			case 81:
			case 83:
			case 84:
			case 85:
			case 86:
			case 87:
			case 88:
			case 89:
			case 90:
			case 96:
			case 99:
			case 101:
			case 119:
			case 120:
			case 121:
			case 122:
			case 123:
			case 124:
			case 125:
			case 128:
			case 129:
			case 130:
			case 131:
			case 135:
			case 136:
			case 137:
			case 138:
			case 139:
			case 149:
			case 150:
			case 151:
			case 152:
			case 196:
			case 199:
			case 206:
			case 229:
			case 230:
			case 231:
			case 232:
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1662;
				this.exprComponent(0);
				}
				break;
			case 103:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1663;
				this.match(Vtl.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public componentRole(): ComponentRoleContext {
		let localctx: ComponentRoleContext = new ComponentRoleContext(this, this._ctx, this.state);
		this.enterRule(localctx, 198, Vtl.RULE_componentRole);
		try {
			this.state = 1671;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 92:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1666;
				this.match(Vtl.MEASURE);
				}
				break;
			case 222:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1667;
				this.match(Vtl.COMPONENT);
				}
				break;
			case 91:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1668;
				this.match(Vtl.DIMENSION);
				}
				break;
			case 93:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1669;
				this.match(Vtl.ATTRIBUTE);
				}
				break;
			case 98:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1670;
				this.viralAttribute();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public viralAttribute(): ViralAttributeContext {
		let localctx: ViralAttributeContext = new ViralAttributeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 200, Vtl.RULE_viralAttribute);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1673;
			this.match(Vtl.VIRAL);
			this.state = 1674;
			this.match(Vtl.ATTRIBUTE);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainID(): ValueDomainIDContext {
		let localctx: ValueDomainIDContext = new ValueDomainIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 202, Vtl.RULE_valueDomainID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1676;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public operatorID(): OperatorIDContext {
		let localctx: OperatorIDContext = new OperatorIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 204, Vtl.RULE_operatorID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1678;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public routineName(): RoutineNameContext {
		let localctx: RoutineNameContext = new RoutineNameContext(this, this._ctx, this.state);
		this.enterRule(localctx, 206, Vtl.RULE_routineName);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1680;
			this.match(Vtl.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public constant(): ConstantContext {
		let localctx: ConstantContext = new ConstantContext(this, this._ctx, this.state);
		this.enterRule(localctx, 208, Vtl.RULE_constant);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1682;
			_la = this._input.LA(1);
			if(!(_la===43 || ((((_la - 229)) & ~0x1F) === 0 && ((1 << (_la - 229)) & 15) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public basicScalarType(): BasicScalarTypeContext {
		let localctx: BasicScalarTypeContext = new BasicScalarTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 210, Vtl.RULE_basicScalarType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1684;
			_la = this._input.LA(1);
			if(!(((((_la - 156)) & ~0x1F) === 0 && ((1 << (_la - 156)) & 127) !== 0) || _la===198 || _la===221)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public retainType(): RetainTypeContext {
		let localctx: RetainTypeContext = new RetainTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 212, Vtl.RULE_retainType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1686;
			_la = this._input.LA(1);
			if(!(_la===60 || _la===231)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}

	public sempred(localctx: RuleContext, ruleIndex: number, predIndex: number): boolean {
		switch (ruleIndex) {
		case 2:
			return this.expr_sempred(localctx as ExprContext, predIndex);
		case 3:
			return this.exprComponent_sempred(localctx as ExprComponentContext, predIndex);
		}
		return true;
	}
	private expr_sempred(localctx: ExprContext, predIndex: number): boolean {
		switch (predIndex) {
		case 0:
			return this.precpred(this._ctx, 9);
		case 1:
			return this.precpred(this._ctx, 8);
		case 2:
			return this.precpred(this._ctx, 7);
		case 3:
			return this.precpred(this._ctx, 5);
		case 4:
			return this.precpred(this._ctx, 4);
		case 5:
			return this.precpred(this._ctx, 12);
		case 6:
			return this.precpred(this._ctx, 11);
		case 7:
			return this.precpred(this._ctx, 6);
		}
		return true;
	}
	private exprComponent_sempred(localctx: ExprComponentContext, predIndex: number): boolean {
		switch (predIndex) {
		case 8:
			return this.precpred(this._ctx, 9);
		case 9:
			return this.precpred(this._ctx, 8);
		case 10:
			return this.precpred(this._ctx, 7);
		case 11:
			return this.precpred(this._ctx, 5);
		case 12:
			return this.precpred(this._ctx, 4);
		case 13:
			return this.precpred(this._ctx, 6);
		}
		return true;
	}

	public static readonly _serializedATN: number[] = [4,1,238,1689,2,0,7,0,
	2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,
	2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,7,14,2,15,7,15,2,16,7,16,2,
	17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,
	7,24,2,25,7,25,2,26,7,26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,
	31,2,32,7,32,2,33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,
	2,39,7,39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
	46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,52,2,53,
	7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,59,7,59,2,60,7,
	60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,2,65,7,65,2,66,7,66,2,67,7,67,
	2,68,7,68,2,69,7,69,2,70,7,70,2,71,7,71,2,72,7,72,2,73,7,73,2,74,7,74,2,
	75,7,75,2,76,7,76,2,77,7,77,2,78,7,78,2,79,7,79,2,80,7,80,2,81,7,81,2,82,
	7,82,2,83,7,83,2,84,7,84,2,85,7,85,2,86,7,86,2,87,7,87,2,88,7,88,2,89,7,
	89,2,90,7,90,2,91,7,91,2,92,7,92,2,93,7,93,2,94,7,94,2,95,7,95,2,96,7,96,
	2,97,7,97,2,98,7,98,2,99,7,99,2,100,7,100,2,101,7,101,2,102,7,102,2,103,
	7,103,2,104,7,104,2,105,7,105,2,106,7,106,1,0,1,0,1,0,5,0,218,8,0,10,0,
	12,0,221,9,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,234,8,1,1,
	2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,253,
	8,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
	1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,5,2,282,8,2,10,2,12,2,285,9,2,1,
	3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,304,
	8,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,
	1,3,1,3,5,3,325,8,3,10,3,12,3,328,9,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,
	4,338,8,4,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,352,8,5,1,
	6,1,6,1,6,1,6,1,6,1,6,1,6,3,6,361,8,6,1,7,1,7,1,7,1,7,5,7,367,8,7,10,7,
	12,7,370,9,7,1,8,1,8,1,8,1,8,3,8,376,8,8,3,8,378,8,8,1,9,1,9,1,9,1,10,1,
	10,1,10,1,10,5,10,387,8,10,10,10,12,10,390,9,10,1,11,1,11,1,11,1,11,5,11,
	396,8,11,10,11,12,11,399,9,11,1,12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,
	13,5,13,410,8,13,10,13,12,13,413,9,13,1,14,1,14,1,14,1,14,1,14,1,14,1,14,
	1,14,1,14,1,14,1,14,1,14,3,14,427,8,14,1,15,1,15,1,15,1,15,1,15,1,15,1,
	15,5,15,436,8,15,10,15,12,15,439,9,15,3,15,441,8,15,1,15,1,15,1,15,3,15,
	446,8,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,
	15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,
	1,15,1,15,1,15,1,15,3,15,479,8,15,1,16,1,16,1,16,1,16,1,16,5,16,486,8,16,
	10,16,12,16,489,9,16,3,16,491,8,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,
	16,3,16,501,8,16,1,16,1,16,1,16,3,16,506,8,16,5,16,508,8,16,10,16,12,16,
	511,9,16,1,16,1,16,1,16,3,16,516,8,16,1,16,1,16,3,16,520,8,16,1,16,1,16,
	1,16,1,16,1,16,1,16,1,16,1,16,3,16,530,8,16,1,16,1,16,3,16,534,8,16,1,16,
	1,16,3,16,538,8,16,1,17,1,17,1,17,1,17,1,17,5,17,545,8,17,10,17,12,17,548,
	9,17,3,17,550,8,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,3,17,560,8,17,
	1,17,1,17,3,17,564,8,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,3,17,574,
	8,17,1,17,1,17,1,17,3,17,579,8,17,5,17,581,8,17,10,17,12,17,584,9,17,1,
	17,1,17,1,17,3,17,589,8,17,1,17,1,17,3,17,593,8,17,1,17,1,17,3,17,597,8,
	17,1,18,1,18,1,18,3,18,602,8,18,1,19,1,19,1,19,3,19,607,8,19,1,20,1,20,
	1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,3,20,623,8,
	20,1,20,1,20,3,20,627,8,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,
	3,20,638,8,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,3,20,649,8,20,
	1,20,1,20,3,20,653,8,20,1,20,1,20,3,20,657,8,20,1,21,1,21,1,21,1,21,1,21,
	1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,673,8,21,1,21,1,21,3,
	21,677,8,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,688,8,21,
	1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,699,8,21,1,21,1,21,3,
	21,703,8,21,1,21,1,21,3,21,707,8,21,1,22,1,22,1,22,1,22,1,22,1,22,1,22,
	1,22,1,22,1,22,3,22,719,8,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,
	22,3,22,730,8,22,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,3,23,
	742,8,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,3,23,753,8,23,1,24,
	1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,
	24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,783,
	8,24,1,24,1,24,3,24,787,8,24,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,
	25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,810,
	8,25,1,26,1,26,1,26,3,26,815,8,26,1,26,1,26,1,26,1,26,1,26,1,26,3,26,823,
	8,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,
	26,1,26,1,26,1,26,1,26,1,26,3,26,844,8,26,1,26,1,26,3,26,848,8,26,1,26,
	1,26,3,26,852,8,26,1,26,1,26,1,26,1,26,3,26,858,8,26,1,27,1,27,1,27,3,27,
	863,8,27,1,27,1,27,1,27,1,27,1,27,1,27,3,27,871,8,27,1,27,1,27,1,27,1,27,
	1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,
	27,3,27,892,8,27,1,27,1,27,3,27,896,8,27,1,27,1,27,3,27,900,8,27,1,27,1,
	27,1,27,1,27,3,27,906,8,27,1,28,1,28,1,28,1,28,1,28,4,28,913,8,28,11,28,
	12,28,914,1,28,1,28,1,28,1,28,1,28,1,28,1,28,4,28,924,8,28,11,28,12,28,
	925,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,937,8,28,1,29,1,29,
	1,29,1,29,1,29,1,29,3,29,945,8,29,1,29,1,29,3,29,949,8,29,1,29,3,29,952,
	8,29,1,29,3,29,955,8,29,1,29,3,29,958,8,29,1,29,1,29,1,30,1,30,1,30,1,30,
	1,30,1,30,1,30,1,30,1,30,5,30,971,8,30,10,30,12,30,974,9,30,3,30,976,8,
	30,1,30,3,30,979,8,30,1,30,1,30,1,30,1,30,1,30,1,30,1,30,1,30,3,30,989,
	8,30,1,30,1,30,3,30,993,8,30,1,30,3,30,996,8,30,1,30,3,30,999,8,30,1,30,
	3,30,1002,8,30,1,30,1,30,1,30,1,30,1,30,1,30,3,30,1010,8,30,1,30,3,30,1013,
	8,30,1,30,3,30,1016,8,30,1,30,3,30,1019,8,30,1,30,1,30,3,30,1023,8,30,1,
	31,1,31,1,31,1,31,1,31,1,31,1,31,1,32,1,32,1,32,1,32,1,32,1,32,1,32,1,33,
	1,33,1,33,1,33,1,33,1,33,1,33,1,33,3,33,1047,8,33,1,34,1,34,1,34,1,34,1,
	34,3,34,1054,8,34,3,34,1056,8,34,1,34,1,34,1,35,1,35,1,35,1,35,1,35,1,35,
	3,35,1066,8,35,1,35,3,35,1069,8,35,1,35,3,35,1072,8,35,1,35,1,35,1,35,1,
	35,1,35,1,35,1,35,1,35,1,35,3,35,1083,8,35,3,35,1085,8,35,1,35,1,35,1,35,
	3,35,1090,8,35,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,35,1,
	35,1,35,1,35,3,35,1106,8,35,1,36,1,36,1,36,1,36,1,36,1,36,3,36,1114,8,36,
	1,36,3,36,1117,8,36,1,36,3,36,1120,8,36,1,36,1,36,1,36,1,36,1,36,1,36,1,
	36,1,36,1,36,3,36,1131,8,36,3,36,1133,8,36,1,36,1,36,1,36,3,36,1138,8,36,
	1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,3,36,1150,8,36,1,36,1,
	36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,3,36,1166,
	8,36,1,37,1,37,1,37,1,37,1,38,1,38,1,38,5,38,1175,8,38,10,38,12,38,1178,
	9,38,1,39,3,39,1181,8,39,1,39,1,39,1,39,1,39,1,40,3,40,1188,8,40,1,40,1,
	40,1,40,1,40,1,41,1,41,1,41,1,41,1,42,1,42,1,42,5,42,1201,8,42,10,42,12,
	42,1204,9,42,1,43,1,43,1,43,5,43,1209,8,43,10,43,12,43,1212,9,43,1,43,1,
	43,1,43,1,43,5,43,1218,8,43,10,43,12,43,1221,9,43,3,43,1223,8,43,1,44,1,
	44,1,44,3,44,1228,8,44,1,45,3,45,1231,8,45,1,45,1,45,1,45,3,45,1236,8,45,
	1,45,3,45,1239,8,45,1,45,3,45,1242,8,45,1,46,1,46,1,46,1,47,1,47,1,47,1,
	47,1,47,5,47,1252,8,47,10,47,12,47,1255,9,47,1,48,1,48,1,48,1,48,1,48,5,
	48,1262,8,48,10,48,12,48,1265,9,48,1,49,1,49,3,49,1269,8,49,1,50,1,50,1,
	50,3,50,1274,8,50,1,50,1,50,1,50,1,50,1,50,1,51,1,51,1,52,1,52,1,52,1,52,
	1,52,1,52,1,52,1,52,1,52,1,52,1,52,3,52,1294,8,52,1,53,1,53,1,53,1,53,1,
	53,5,53,1301,8,53,10,53,12,53,1304,9,53,1,53,1,53,1,53,1,53,1,53,3,53,1311,
	8,53,1,53,3,53,1314,8,53,1,53,1,53,1,53,1,53,1,53,1,53,1,53,3,53,1323,8,
	53,3,53,1325,8,53,1,54,1,54,1,54,1,55,1,55,1,55,1,55,3,55,1334,8,55,1,56,
	1,56,1,56,3,56,1339,8,56,1,57,1,57,3,57,1343,8,57,1,58,1,58,1,58,1,58,1,
	58,3,58,1350,8,58,1,59,1,59,1,59,3,59,1355,8,59,1,60,1,60,3,60,1359,8,60,
	1,60,3,60,1362,8,60,1,60,3,60,1365,8,60,1,60,3,60,1368,8,60,1,61,1,61,1,
	61,1,61,1,61,3,61,1375,8,61,1,62,1,62,1,62,1,62,1,62,5,62,1382,8,62,10,
	62,12,62,1385,9,62,1,62,1,62,3,62,1389,8,62,1,63,1,63,1,63,1,63,1,63,3,
	63,1396,8,63,1,64,1,64,1,64,1,64,1,64,1,64,5,64,1404,8,64,10,64,12,64,1407,
	9,64,1,64,1,64,3,64,1411,8,64,1,64,1,64,1,64,1,64,1,64,5,64,1418,8,64,10,
	64,12,64,1421,9,64,1,64,1,64,3,64,1425,8,64,3,64,1427,8,64,1,65,1,65,1,
	65,1,65,1,65,1,65,1,65,1,65,5,65,1437,8,65,10,65,12,65,1440,9,65,1,65,1,
	65,3,65,1444,8,65,1,65,3,65,1447,8,65,1,65,1,65,1,65,1,65,1,65,1,65,1,65,
	5,65,1456,8,65,10,65,12,65,1459,9,65,1,65,1,65,3,65,1463,8,65,1,65,1,65,
	3,65,1467,8,65,3,65,1469,8,65,1,66,1,66,1,67,1,67,1,68,1,68,1,68,1,68,5,
	68,1479,8,68,10,68,12,68,1482,9,68,1,69,1,69,1,69,3,69,1487,8,69,1,70,1,
	70,1,70,5,70,1492,8,70,10,70,12,70,1495,9,70,1,71,1,71,3,71,1499,8,71,1,
	71,1,71,1,71,1,71,3,71,1505,8,71,1,71,1,71,3,71,1509,8,71,1,71,3,71,1512,
	8,71,1,72,1,72,1,72,5,72,1517,8,72,10,72,12,72,1520,9,72,1,73,1,73,3,73,
	1524,8,73,1,73,1,73,3,73,1528,8,73,1,73,3,73,1531,8,73,1,74,1,74,1,74,3,
	74,1536,8,74,1,74,1,74,1,74,1,75,1,75,1,75,5,75,1544,8,75,10,75,12,75,1547,
	9,75,1,76,1,76,1,76,1,76,3,76,1553,8,76,1,76,1,76,3,76,1557,8,76,1,76,1,
	76,5,76,1561,8,76,10,76,12,76,1564,9,76,1,77,3,77,1567,8,77,1,77,1,77,1,
	77,1,77,1,77,3,77,1574,8,77,1,78,1,78,1,79,1,79,1,79,1,79,1,79,1,79,1,79,
	1,79,5,79,1586,8,79,10,79,12,79,1589,9,79,1,79,1,79,3,79,1593,8,79,1,80,
	1,80,1,80,3,80,1598,8,80,1,81,1,81,3,81,1602,8,81,1,82,1,82,1,83,1,83,1,
	84,1,84,1,84,1,84,5,84,1612,8,84,10,84,12,84,1615,9,84,1,85,1,85,1,86,1,
	86,1,86,1,87,1,87,1,88,1,88,1,89,1,89,1,90,1,90,1,91,1,91,1,92,1,92,1,92,
	3,92,1635,8,92,1,93,1,93,1,93,1,93,5,93,1641,8,93,10,93,12,93,1644,9,93,
	1,93,1,93,1,93,3,93,1649,8,93,1,94,1,94,1,94,1,95,1,95,1,95,1,96,1,96,1,
	97,1,97,3,97,1661,8,97,1,98,1,98,3,98,1665,8,98,1,99,1,99,1,99,1,99,1,99,
	3,99,1672,8,99,1,100,1,100,1,100,1,101,1,101,1,102,1,102,1,103,1,103,1,
	104,1,104,1,105,1,105,1,106,1,106,1,106,0,2,4,6,107,0,2,4,6,8,10,12,14,
	16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,
	64,66,68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,
	110,112,114,116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,
	146,148,150,152,154,156,158,160,162,164,166,168,170,172,174,176,178,180,
	182,184,186,188,190,192,194,196,198,200,202,204,206,208,210,212,0,37,2,
	0,13,14,39,39,1,0,15,16,2,0,13,14,82,82,1,0,37,38,1,0,41,42,1,0,30,31,2,
	0,190,190,192,192,1,0,181,182,1,0,183,184,3,0,81,81,83,85,119,120,4,0,73,
	73,75,75,96,96,123,125,1,0,77,78,2,0,76,76,79,80,2,0,60,60,197,197,1,0,
	150,151,2,0,103,103,233,233,1,0,70,71,2,0,48,48,127,127,2,0,60,60,104,104,
	3,0,68,69,87,90,128,131,4,0,68,69,87,90,128,131,135,136,1,0,137,138,1,0,
	66,67,2,0,64,64,133,133,1,0,105,106,1,0,13,14,2,0,229,230,234,234,2,0,13,
	13,15,15,3,0,60,60,104,104,220,220,1,0,213,218,2,0,109,109,208,208,3,0,
	109,109,116,116,207,207,2,0,60,60,212,212,1,0,7,12,2,0,43,43,229,232,3,
	0,156,162,198,198,221,221,2,0,60,60,231,231,1855,0,219,1,0,0,0,2,233,1,
	0,0,0,4,252,1,0,0,0,6,303,1,0,0,0,8,337,1,0,0,0,10,351,1,0,0,0,12,360,1,
	0,0,0,14,362,1,0,0,0,16,371,1,0,0,0,18,379,1,0,0,0,20,382,1,0,0,0,22,391,
	1,0,0,0,24,400,1,0,0,0,26,405,1,0,0,0,28,426,1,0,0,0,30,478,1,0,0,0,32,
	537,1,0,0,0,34,596,1,0,0,0,36,601,1,0,0,0,38,606,1,0,0,0,40,656,1,0,0,0,
	42,706,1,0,0,0,44,729,1,0,0,0,46,752,1,0,0,0,48,786,1,0,0,0,50,809,1,0,
	0,0,52,857,1,0,0,0,54,905,1,0,0,0,56,936,1,0,0,0,58,938,1,0,0,0,60,1022,
	1,0,0,0,62,1024,1,0,0,0,64,1031,1,0,0,0,66,1046,1,0,0,0,68,1048,1,0,0,0,
	70,1105,1,0,0,0,72,1165,1,0,0,0,74,1167,1,0,0,0,76,1171,1,0,0,0,78,1180,
	1,0,0,0,80,1187,1,0,0,0,82,1193,1,0,0,0,84,1197,1,0,0,0,86,1205,1,0,0,0,
	88,1224,1,0,0,0,90,1230,1,0,0,0,92,1243,1,0,0,0,94,1246,1,0,0,0,96,1256,
	1,0,0,0,98,1266,1,0,0,0,100,1273,1,0,0,0,102,1280,1,0,0,0,104,1293,1,0,
	0,0,106,1324,1,0,0,0,108,1326,1,0,0,0,110,1329,1,0,0,0,112,1338,1,0,0,0,
	114,1342,1,0,0,0,116,1349,1,0,0,0,118,1354,1,0,0,0,120,1358,1,0,0,0,122,
	1369,1,0,0,0,124,1376,1,0,0,0,126,1390,1,0,0,0,128,1426,1,0,0,0,130,1468,
	1,0,0,0,132,1470,1,0,0,0,134,1472,1,0,0,0,136,1474,1,0,0,0,138,1483,1,0,
	0,0,140,1488,1,0,0,0,142,1498,1,0,0,0,144,1513,1,0,0,0,146,1523,1,0,0,0,
	148,1532,1,0,0,0,150,1540,1,0,0,0,152,1552,1,0,0,0,154,1566,1,0,0,0,156,
	1575,1,0,0,0,158,1592,1,0,0,0,160,1594,1,0,0,0,162,1599,1,0,0,0,164,1603,
	1,0,0,0,166,1605,1,0,0,0,168,1607,1,0,0,0,170,1616,1,0,0,0,172,1618,1,0,
	0,0,174,1621,1,0,0,0,176,1623,1,0,0,0,178,1625,1,0,0,0,180,1627,1,0,0,0,
	182,1629,1,0,0,0,184,1631,1,0,0,0,186,1648,1,0,0,0,188,1650,1,0,0,0,190,
	1653,1,0,0,0,192,1656,1,0,0,0,194,1660,1,0,0,0,196,1664,1,0,0,0,198,1671,
	1,0,0,0,200,1673,1,0,0,0,202,1676,1,0,0,0,204,1678,1,0,0,0,206,1680,1,0,
	0,0,208,1682,1,0,0,0,210,1684,1,0,0,0,212,1686,1,0,0,0,214,215,3,2,1,0,
	215,216,5,236,0,0,216,218,1,0,0,0,217,214,1,0,0,0,218,221,1,0,0,0,219,217,
	1,0,0,0,219,220,1,0,0,0,220,222,1,0,0,0,221,219,1,0,0,0,222,223,5,0,0,1,
	223,1,1,0,0,0,224,225,3,180,90,0,225,226,5,19,0,0,226,227,3,4,2,0,227,234,
	1,0,0,0,228,229,3,180,90,0,229,230,5,112,0,0,230,231,3,4,2,0,231,234,1,
	0,0,0,232,234,3,30,15,0,233,224,1,0,0,0,233,228,1,0,0,0,233,232,1,0,0,0,
	234,3,1,0,0,0,235,236,6,2,-1,0,236,237,5,1,0,0,237,238,3,4,2,0,238,239,
	5,2,0,0,239,253,1,0,0,0,240,253,3,10,5,0,241,242,7,0,0,0,242,253,3,4,2,
	10,243,244,5,23,0,0,244,245,3,4,2,0,245,246,5,24,0,0,246,247,3,4,2,0,247,
	248,5,25,0,0,248,249,3,4,2,3,249,253,1,0,0,0,250,253,3,208,104,0,251,253,
	3,180,90,0,252,235,1,0,0,0,252,240,1,0,0,0,252,241,1,0,0,0,252,243,1,0,
	0,0,252,250,1,0,0,0,252,251,1,0,0,0,253,283,1,0,0,0,254,255,10,9,0,0,255,
	256,7,1,0,0,256,282,3,4,2,10,257,258,10,8,0,0,258,259,7,2,0,0,259,282,3,
	4,2,9,260,261,10,7,0,0,261,262,3,192,96,0,262,263,3,4,2,8,263,282,1,0,0,
	0,264,265,10,5,0,0,265,266,5,36,0,0,266,282,3,4,2,6,267,268,10,4,0,0,268,
	269,7,3,0,0,269,282,3,4,2,5,270,271,10,12,0,0,271,272,5,3,0,0,272,273,3,
	12,6,0,273,274,5,4,0,0,274,282,1,0,0,0,275,276,10,11,0,0,276,277,5,20,0,
	0,277,282,3,182,91,0,278,279,10,6,0,0,279,280,7,4,0,0,280,282,3,186,93,
	0,281,254,1,0,0,0,281,257,1,0,0,0,281,260,1,0,0,0,281,264,1,0,0,0,281,267,
	1,0,0,0,281,270,1,0,0,0,281,275,1,0,0,0,281,278,1,0,0,0,282,285,1,0,0,0,
	283,281,1,0,0,0,283,284,1,0,0,0,284,5,1,0,0,0,285,283,1,0,0,0,286,287,6,
	3,-1,0,287,288,5,1,0,0,288,289,3,6,3,0,289,290,5,2,0,0,290,304,1,0,0,0,
	291,304,3,8,4,0,292,293,7,0,0,0,293,304,3,6,3,10,294,295,5,23,0,0,295,296,
	3,6,3,0,296,297,5,24,0,0,297,298,3,6,3,0,298,299,5,25,0,0,299,300,3,6,3,
	3,300,304,1,0,0,0,301,304,3,208,104,0,302,304,3,184,92,0,303,286,1,0,0,
	0,303,291,1,0,0,0,303,292,1,0,0,0,303,294,1,0,0,0,303,301,1,0,0,0,303,302,
	1,0,0,0,304,326,1,0,0,0,305,306,10,9,0,0,306,307,7,1,0,0,307,325,3,6,3,
	10,308,309,10,8,0,0,309,310,7,2,0,0,310,325,3,6,3,9,311,312,10,7,0,0,312,
	313,3,192,96,0,313,314,3,6,3,8,314,325,1,0,0,0,315,316,10,5,0,0,316,317,
	5,36,0,0,317,325,3,6,3,6,318,319,10,4,0,0,319,320,7,3,0,0,320,325,3,6,3,
	5,321,322,10,6,0,0,322,323,7,4,0,0,323,325,3,186,93,0,324,305,1,0,0,0,324,
	308,1,0,0,0,324,311,1,0,0,0,324,315,1,0,0,0,324,318,1,0,0,0,324,321,1,0,
	0,0,325,328,1,0,0,0,326,324,1,0,0,0,326,327,1,0,0,0,327,7,1,0,0,0,328,326,
	1,0,0,0,329,338,3,34,17,0,330,338,3,42,21,0,331,338,3,46,23,0,332,338,3,
	50,25,0,333,338,3,54,27,0,334,338,3,64,32,0,335,338,3,66,33,0,336,338,3,
	72,36,0,337,329,1,0,0,0,337,330,1,0,0,0,337,331,1,0,0,0,337,332,1,0,0,0,
	337,333,1,0,0,0,337,334,1,0,0,0,337,335,1,0,0,0,337,336,1,0,0,0,338,9,1,
	0,0,0,339,352,3,28,14,0,340,352,3,32,16,0,341,352,3,40,20,0,342,352,3,44,
	22,0,343,352,3,48,24,0,344,352,3,52,26,0,345,352,3,56,28,0,346,352,3,58,
	29,0,347,352,3,60,30,0,348,352,3,62,31,0,349,352,3,68,34,0,350,352,3,70,
	35,0,351,339,1,0,0,0,351,340,1,0,0,0,351,341,1,0,0,0,351,342,1,0,0,0,351,
	343,1,0,0,0,351,344,1,0,0,0,351,345,1,0,0,0,351,346,1,0,0,0,351,347,1,0,
	0,0,351,348,1,0,0,0,351,349,1,0,0,0,351,350,1,0,0,0,352,11,1,0,0,0,353,
	361,3,14,7,0,354,361,3,16,8,0,355,361,3,18,9,0,356,361,3,20,10,0,357,361,
	3,22,11,0,358,361,3,24,12,0,359,361,3,26,13,0,360,353,1,0,0,0,360,354,1,
	0,0,0,360,355,1,0,0,0,360,356,1,0,0,0,360,357,1,0,0,0,360,358,1,0,0,0,360,
	359,1,0,0,0,361,13,1,0,0,0,362,363,5,34,0,0,363,368,3,74,37,0,364,365,5,
	17,0,0,365,367,3,74,37,0,366,364,1,0,0,0,367,370,1,0,0,0,368,366,1,0,0,
	0,368,369,1,0,0,0,369,15,1,0,0,0,370,368,1,0,0,0,371,372,5,61,0,0,372,377,
	3,76,38,0,373,375,3,106,53,0,374,376,3,108,54,0,375,374,1,0,0,0,375,376,
	1,0,0,0,376,378,1,0,0,0,377,373,1,0,0,0,377,378,1,0,0,0,378,17,1,0,0,0,
	379,380,5,94,0,0,380,381,3,6,3,0,381,19,1,0,0,0,382,383,5,32,0,0,383,388,
	3,80,40,0,384,385,5,17,0,0,385,387,3,80,40,0,386,384,1,0,0,0,387,390,1,
	0,0,0,388,386,1,0,0,0,388,389,1,0,0,0,389,21,1,0,0,0,390,388,1,0,0,0,391,
	392,7,5,0,0,392,397,3,184,92,0,393,394,5,17,0,0,394,396,3,184,92,0,395,
	393,1,0,0,0,396,399,1,0,0,0,397,395,1,0,0,0,397,398,1,0,0,0,398,23,1,0,
	0,0,399,397,1,0,0,0,400,401,7,6,0,0,401,402,3,184,92,0,402,403,5,17,0,0,
	403,404,3,184,92,0,404,25,1,0,0,0,405,406,5,193,0,0,406,411,3,82,41,0,407,
	408,5,17,0,0,408,410,3,82,41,0,409,407,1,0,0,0,410,413,1,0,0,0,411,409,
	1,0,0,0,411,412,1,0,0,0,412,27,1,0,0,0,413,411,1,0,0,0,414,415,7,7,0,0,
	415,416,5,1,0,0,416,417,3,86,43,0,417,418,3,90,45,0,418,419,5,2,0,0,419,
	427,1,0,0,0,420,421,7,8,0,0,421,422,5,1,0,0,422,423,3,84,42,0,423,424,3,
	90,45,0,424,425,5,2,0,0,425,427,1,0,0,0,426,414,1,0,0,0,426,420,1,0,0,0,
	427,29,1,0,0,0,428,429,5,111,0,0,429,430,5,110,0,0,430,431,3,204,102,0,
	431,440,5,1,0,0,432,437,3,110,55,0,433,434,5,17,0,0,434,436,3,110,55,0,
	435,433,1,0,0,0,436,439,1,0,0,0,437,435,1,0,0,0,437,438,1,0,0,0,438,441,
	1,0,0,0,439,437,1,0,0,0,440,432,1,0,0,0,440,441,1,0,0,0,441,442,1,0,0,0,
	442,445,5,2,0,0,443,444,5,189,0,0,444,446,3,112,56,0,445,443,1,0,0,0,445,
	446,1,0,0,0,446,447,1,0,0,0,447,448,5,172,0,0,448,449,3,4,2,0,449,450,5,
	117,0,0,450,451,5,110,0,0,451,479,1,0,0,0,452,453,5,111,0,0,453,454,5,113,
	0,0,454,455,5,115,0,0,455,456,3,134,67,0,456,457,5,1,0,0,457,458,3,136,
	68,0,458,459,5,2,0,0,459,460,5,172,0,0,460,461,3,140,70,0,461,462,5,117,
	0,0,462,463,5,113,0,0,463,464,5,115,0,0,464,479,1,0,0,0,465,466,5,111,0,
	0,466,467,5,114,0,0,467,468,5,115,0,0,468,469,3,134,67,0,469,470,5,1,0,
	0,470,471,3,148,74,0,471,472,5,2,0,0,472,473,5,172,0,0,473,474,3,144,72,
	0,474,475,5,117,0,0,475,476,5,114,0,0,476,477,5,115,0,0,477,479,1,0,0,0,
	478,428,1,0,0,0,478,452,1,0,0,0,478,465,1,0,0,0,479,31,1,0,0,0,480,481,
	3,204,102,0,481,490,5,1,0,0,482,487,3,38,19,0,483,484,5,17,0,0,484,486,
	3,38,19,0,485,483,1,0,0,0,486,489,1,0,0,0,487,485,1,0,0,0,487,488,1,0,0,
	0,488,491,1,0,0,0,489,487,1,0,0,0,490,482,1,0,0,0,490,491,1,0,0,0,491,492,
	1,0,0,0,492,493,5,2,0,0,493,538,1,0,0,0,494,495,5,22,0,0,495,496,5,1,0,
	0,496,497,3,206,103,0,497,500,5,1,0,0,498,501,3,180,90,0,499,501,3,208,
	104,0,500,498,1,0,0,0,500,499,1,0,0,0,500,501,1,0,0,0,501,509,1,0,0,0,502,
	505,5,17,0,0,503,506,3,180,90,0,504,506,3,208,104,0,505,503,1,0,0,0,505,
	504,1,0,0,0,506,508,1,0,0,0,507,502,1,0,0,0,508,511,1,0,0,0,509,507,1,0,
	0,0,509,510,1,0,0,0,510,512,1,0,0,0,511,509,1,0,0,0,512,515,5,2,0,0,513,
	514,5,228,0,0,514,516,5,232,0,0,515,513,1,0,0,0,515,516,1,0,0,0,516,519,
	1,0,0,0,517,518,5,189,0,0,518,520,3,124,62,0,519,517,1,0,0,0,519,520,1,
	0,0,0,520,521,1,0,0,0,521,522,5,2,0,0,522,538,1,0,0,0,523,524,5,206,0,0,
	524,525,5,1,0,0,525,526,3,4,2,0,526,529,5,17,0,0,527,530,3,210,105,0,528,
	530,3,132,66,0,529,527,1,0,0,0,529,528,1,0,0,0,530,533,1,0,0,0,531,532,
	5,17,0,0,532,534,5,232,0,0,533,531,1,0,0,0,533,534,1,0,0,0,534,535,1,0,
	0,0,535,536,5,2,0,0,536,538,1,0,0,0,537,480,1,0,0,0,537,494,1,0,0,0,537,
	523,1,0,0,0,538,33,1,0,0,0,539,540,3,204,102,0,540,549,5,1,0,0,541,546,
	3,36,18,0,542,543,5,17,0,0,543,545,3,36,18,0,544,542,1,0,0,0,545,548,1,
	0,0,0,546,544,1,0,0,0,546,547,1,0,0,0,547,550,1,0,0,0,548,546,1,0,0,0,549,
	541,1,0,0,0,549,550,1,0,0,0,550,551,1,0,0,0,551,552,5,2,0,0,552,597,1,0,
	0,0,553,554,5,206,0,0,554,555,5,1,0,0,555,556,3,6,3,0,556,559,5,17,0,0,
	557,560,3,210,105,0,558,560,3,132,66,0,559,557,1,0,0,0,559,558,1,0,0,0,
	560,563,1,0,0,0,561,562,5,17,0,0,562,564,5,232,0,0,563,561,1,0,0,0,563,
	564,1,0,0,0,564,565,1,0,0,0,565,566,5,2,0,0,566,597,1,0,0,0,567,568,5,22,
	0,0,568,569,5,1,0,0,569,570,3,206,103,0,570,573,5,1,0,0,571,574,3,184,92,
	0,572,574,3,208,104,0,573,571,1,0,0,0,573,572,1,0,0,0,573,574,1,0,0,0,574,
	582,1,0,0,0,575,578,5,17,0,0,576,579,3,184,92,0,577,579,3,208,104,0,578,
	576,1,0,0,0,578,577,1,0,0,0,579,581,1,0,0,0,580,575,1,0,0,0,581,584,1,0,
	0,0,582,580,1,0,0,0,582,583,1,0,0,0,583,585,1,0,0,0,584,582,1,0,0,0,585,
	588,5,2,0,0,586,587,5,228,0,0,587,589,5,232,0,0,588,586,1,0,0,0,588,589,
	1,0,0,0,589,592,1,0,0,0,590,591,5,189,0,0,591,593,3,114,57,0,592,590,1,
	0,0,0,592,593,1,0,0,0,593,594,1,0,0,0,594,595,5,2,0,0,595,597,1,0,0,0,596,
	539,1,0,0,0,596,553,1,0,0,0,596,567,1,0,0,0,597,35,1,0,0,0,598,602,3,184,
	92,0,599,602,3,208,104,0,600,602,5,103,0,0,601,598,1,0,0,0,601,599,1,0,
	0,0,601,600,1,0,0,0,602,37,1,0,0,0,603,607,3,180,90,0,604,607,3,208,104,
	0,605,607,5,103,0,0,606,603,1,0,0,0,606,604,1,0,0,0,606,605,1,0,0,0,607,
	39,1,0,0,0,608,609,7,9,0,0,609,610,5,1,0,0,610,611,3,4,2,0,611,612,5,2,
	0,0,612,657,1,0,0,0,613,614,5,86,0,0,614,615,5,1,0,0,615,626,3,4,2,0,616,
	617,5,17,0,0,617,618,3,194,97,0,618,619,1,0,0,0,619,620,5,17,0,0,620,621,
	3,194,97,0,621,623,1,0,0,0,622,616,1,0,0,0,622,623,1,0,0,0,623,627,1,0,
	0,0,624,625,5,17,0,0,625,627,3,194,97,0,626,622,1,0,0,0,626,624,1,0,0,0,
	627,628,1,0,0,0,628,629,5,2,0,0,629,657,1,0,0,0,630,631,5,122,0,0,631,632,
	5,1,0,0,632,633,3,4,2,0,633,634,5,17,0,0,634,637,3,4,2,0,635,636,5,17,0,
	0,636,638,3,194,97,0,637,635,1,0,0,0,637,638,1,0,0,0,638,639,1,0,0,0,639,
	640,5,2,0,0,640,657,1,0,0,0,641,642,5,121,0,0,642,643,5,1,0,0,643,644,3,
	4,2,0,644,645,5,17,0,0,645,648,3,4,2,0,646,647,5,17,0,0,647,649,3,194,97,
	0,648,646,1,0,0,0,648,649,1,0,0,0,649,652,1,0,0,0,650,651,5,17,0,0,651,
	653,3,194,97,0,652,650,1,0,0,0,652,653,1,0,0,0,653,654,1,0,0,0,654,655,
	5,2,0,0,655,657,1,0,0,0,656,608,1,0,0,0,656,613,1,0,0,0,656,630,1,0,0,0,
	656,641,1,0,0,0,657,41,1,0,0,0,658,659,7,9,0,0,659,660,5,1,0,0,660,661,
	3,6,3,0,661,662,5,2,0,0,662,707,1,0,0,0,663,664,5,86,0,0,664,665,5,1,0,
	0,665,676,3,6,3,0,666,667,5,17,0,0,667,668,3,196,98,0,668,669,1,0,0,0,669,
	670,5,17,0,0,670,671,3,196,98,0,671,673,1,0,0,0,672,666,1,0,0,0,672,673,
	1,0,0,0,673,677,1,0,0,0,674,675,5,17,0,0,675,677,3,196,98,0,676,672,1,0,
	0,0,676,674,1,0,0,0,677,678,1,0,0,0,678,679,5,2,0,0,679,707,1,0,0,0,680,
	681,5,122,0,0,681,682,5,1,0,0,682,683,3,6,3,0,683,684,5,17,0,0,684,687,
	3,6,3,0,685,686,5,17,0,0,686,688,3,196,98,0,687,685,1,0,0,0,687,688,1,0,
	0,0,688,689,1,0,0,0,689,690,5,2,0,0,690,707,1,0,0,0,691,692,5,121,0,0,692,
	693,5,1,0,0,693,694,3,6,3,0,694,695,5,17,0,0,695,698,3,6,3,0,696,697,5,
	17,0,0,697,699,3,196,98,0,698,696,1,0,0,0,698,699,1,0,0,0,699,702,1,0,0,
	0,700,701,5,17,0,0,701,703,3,196,98,0,702,700,1,0,0,0,702,703,1,0,0,0,703,
	704,1,0,0,0,704,705,5,2,0,0,705,707,1,0,0,0,706,658,1,0,0,0,706,663,1,0,
	0,0,706,680,1,0,0,0,706,691,1,0,0,0,707,43,1,0,0,0,708,709,7,10,0,0,709,
	710,5,1,0,0,710,711,3,4,2,0,711,712,5,2,0,0,712,730,1,0,0,0,713,714,7,11,
	0,0,714,715,5,1,0,0,715,718,3,4,2,0,716,717,5,17,0,0,717,719,3,194,97,0,
	718,716,1,0,0,0,718,719,1,0,0,0,719,720,1,0,0,0,720,721,5,2,0,0,721,730,
	1,0,0,0,722,723,7,12,0,0,723,724,5,1,0,0,724,725,3,4,2,0,725,726,5,17,0,
	0,726,727,3,4,2,0,727,728,5,2,0,0,728,730,1,0,0,0,729,708,1,0,0,0,729,713,
	1,0,0,0,729,722,1,0,0,0,730,45,1,0,0,0,731,732,7,10,0,0,732,733,5,1,0,0,
	733,734,3,6,3,0,734,735,5,2,0,0,735,753,1,0,0,0,736,737,7,11,0,0,737,738,
	5,1,0,0,738,741,3,6,3,0,739,740,5,17,0,0,740,742,3,196,98,0,741,739,1,0,
	0,0,741,742,1,0,0,0,742,743,1,0,0,0,743,744,5,2,0,0,744,753,1,0,0,0,745,
	746,7,12,0,0,746,747,5,1,0,0,747,748,3,6,3,0,748,749,5,17,0,0,749,750,3,
	6,3,0,750,751,5,2,0,0,751,753,1,0,0,0,752,731,1,0,0,0,752,736,1,0,0,0,752,
	745,1,0,0,0,753,47,1,0,0,0,754,755,5,40,0,0,755,756,5,1,0,0,756,757,3,4,
	2,0,757,758,5,17,0,0,758,759,3,4,2,0,759,760,5,17,0,0,760,761,3,4,2,0,761,
	762,5,2,0,0,762,787,1,0,0,0,763,764,5,99,0,0,764,765,5,1,0,0,765,766,3,
	4,2,0,766,767,5,17,0,0,767,768,3,4,2,0,768,769,5,2,0,0,769,787,1,0,0,0,
	770,771,5,44,0,0,771,772,5,1,0,0,772,773,3,4,2,0,773,774,5,2,0,0,774,787,
	1,0,0,0,775,776,5,55,0,0,776,777,5,1,0,0,777,778,3,4,2,0,778,779,5,17,0,
	0,779,782,3,4,2,0,780,781,5,17,0,0,781,783,3,212,106,0,782,780,1,0,0,0,
	782,783,1,0,0,0,783,784,1,0,0,0,784,785,5,2,0,0,785,787,1,0,0,0,786,754,
	1,0,0,0,786,763,1,0,0,0,786,770,1,0,0,0,786,775,1,0,0,0,787,49,1,0,0,0,
	788,789,5,40,0,0,789,790,5,1,0,0,790,791,3,6,3,0,791,792,5,17,0,0,792,793,
	3,6,3,0,793,794,5,17,0,0,794,795,3,6,3,0,795,796,5,2,0,0,796,810,1,0,0,
	0,797,798,5,99,0,0,798,799,5,1,0,0,799,800,3,6,3,0,800,801,5,17,0,0,801,
	802,3,6,3,0,802,803,5,2,0,0,803,810,1,0,0,0,804,805,5,44,0,0,805,806,5,
	1,0,0,806,807,3,6,3,0,807,808,5,2,0,0,808,810,1,0,0,0,809,788,1,0,0,0,809,
	797,1,0,0,0,809,804,1,0,0,0,810,51,1,0,0,0,811,812,5,196,0,0,812,814,5,
	1,0,0,813,815,3,4,2,0,814,813,1,0,0,0,814,815,1,0,0,0,815,816,1,0,0,0,816,
	858,5,2,0,0,817,818,5,149,0,0,818,819,5,1,0,0,819,822,3,4,2,0,820,821,5,
	17,0,0,821,823,7,13,0,0,822,820,1,0,0,0,822,823,1,0,0,0,823,824,1,0,0,0,
	824,825,5,2,0,0,825,858,1,0,0,0,826,827,7,14,0,0,827,828,5,1,0,0,828,829,
	3,4,2,0,829,830,5,2,0,0,830,858,1,0,0,0,831,832,5,152,0,0,832,833,5,1,0,
	0,833,834,3,4,2,0,834,835,5,17,0,0,835,836,3,102,51,0,836,837,5,2,0,0,837,
	858,1,0,0,0,838,839,5,199,0,0,839,840,5,1,0,0,840,843,5,233,0,0,841,842,
	5,17,0,0,842,844,7,15,0,0,843,841,1,0,0,0,843,844,1,0,0,0,844,847,1,0,0,
	0,845,846,5,17,0,0,846,848,3,194,97,0,847,845,1,0,0,0,847,848,1,0,0,0,848,
	851,1,0,0,0,849,850,5,17,0,0,850,852,7,16,0,0,851,849,1,0,0,0,851,852,1,
	0,0,0,852,853,1,0,0,0,853,858,5,2,0,0,854,855,5,28,0,0,855,856,5,1,0,0,
	856,858,5,2,0,0,857,811,1,0,0,0,857,817,1,0,0,0,857,826,1,0,0,0,857,831,
	1,0,0,0,857,838,1,0,0,0,857,854,1,0,0,0,858,53,1,0,0,0,859,860,5,196,0,
	0,860,862,5,1,0,0,861,863,3,6,3,0,862,861,1,0,0,0,862,863,1,0,0,0,863,864,
	1,0,0,0,864,906,5,2,0,0,865,866,5,149,0,0,866,867,5,1,0,0,867,870,3,6,3,
	0,868,869,5,17,0,0,869,871,7,13,0,0,870,868,1,0,0,0,870,871,1,0,0,0,871,
	872,1,0,0,0,872,873,5,2,0,0,873,906,1,0,0,0,874,875,7,14,0,0,875,876,5,
	1,0,0,876,877,3,6,3,0,877,878,5,2,0,0,878,906,1,0,0,0,879,880,5,152,0,0,
	880,881,5,1,0,0,881,882,3,6,3,0,882,883,5,17,0,0,883,884,3,102,51,0,884,
	885,5,2,0,0,885,906,1,0,0,0,886,887,5,199,0,0,887,888,5,1,0,0,888,891,5,
	233,0,0,889,890,5,17,0,0,890,892,7,15,0,0,891,889,1,0,0,0,891,892,1,0,0,
	0,892,895,1,0,0,0,893,894,5,17,0,0,894,896,3,196,98,0,895,893,1,0,0,0,895,
	896,1,0,0,0,896,899,1,0,0,0,897,898,5,17,0,0,898,900,7,16,0,0,899,897,1,
	0,0,0,899,900,1,0,0,0,900,901,1,0,0,0,901,906,5,2,0,0,902,903,5,28,0,0,
	903,904,5,1,0,0,904,906,5,2,0,0,905,859,1,0,0,0,905,865,1,0,0,0,905,874,
	1,0,0,0,905,879,1,0,0,0,905,886,1,0,0,0,905,902,1,0,0,0,906,55,1,0,0,0,
	907,908,5,46,0,0,908,909,5,1,0,0,909,912,3,4,2,0,910,911,5,17,0,0,911,913,
	3,4,2,0,912,910,1,0,0,0,913,914,1,0,0,0,914,912,1,0,0,0,914,915,1,0,0,0,
	915,916,1,0,0,0,916,917,5,2,0,0,917,937,1,0,0,0,918,919,5,49,0,0,919,920,
	5,1,0,0,920,923,3,4,2,0,921,922,5,17,0,0,922,924,3,4,2,0,923,921,1,0,0,
	0,924,925,1,0,0,0,925,923,1,0,0,0,925,926,1,0,0,0,926,927,1,0,0,0,927,928,
	5,2,0,0,928,937,1,0,0,0,929,930,7,17,0,0,930,931,5,1,0,0,931,932,3,4,2,
	0,932,933,5,17,0,0,933,934,3,4,2,0,934,935,5,2,0,0,935,937,1,0,0,0,936,
	907,1,0,0,0,936,918,1,0,0,0,936,929,1,0,0,0,937,57,1,0,0,0,938,939,5,102,
	0,0,939,940,5,1,0,0,940,941,3,4,2,0,941,942,5,17,0,0,942,944,5,234,0,0,
	943,945,3,168,84,0,944,943,1,0,0,0,944,945,1,0,0,0,945,948,1,0,0,0,946,
	947,5,116,0,0,947,949,3,184,92,0,948,946,1,0,0,0,948,949,1,0,0,0,949,951,
	1,0,0,0,950,952,3,166,83,0,951,950,1,0,0,0,951,952,1,0,0,0,952,954,1,0,
	0,0,953,955,3,174,87,0,954,953,1,0,0,0,954,955,1,0,0,0,955,957,1,0,0,0,
	956,958,3,176,88,0,957,956,1,0,0,0,957,958,1,0,0,0,958,959,1,0,0,0,959,
	960,5,2,0,0,960,59,1,0,0,0,961,962,5,210,0,0,962,963,5,1,0,0,963,964,3,
	4,2,0,964,965,5,17,0,0,965,975,5,234,0,0,966,967,5,219,0,0,967,972,3,184,
	92,0,968,969,5,17,0,0,969,971,3,184,92,0,970,968,1,0,0,0,971,974,1,0,0,
	0,972,970,1,0,0,0,972,973,1,0,0,0,973,976,1,0,0,0,974,972,1,0,0,0,975,966,
	1,0,0,0,975,976,1,0,0,0,976,978,1,0,0,0,977,979,3,164,82,0,978,977,1,0,
	0,0,978,979,1,0,0,0,979,980,1,0,0,0,980,981,5,2,0,0,981,1023,1,0,0,0,982,
	983,5,211,0,0,983,984,5,1,0,0,984,985,3,4,2,0,985,986,5,17,0,0,986,988,
	5,234,0,0,987,989,3,168,84,0,988,987,1,0,0,0,988,989,1,0,0,0,989,992,1,
	0,0,0,990,991,5,116,0,0,991,993,3,184,92,0,992,990,1,0,0,0,992,993,1,0,
	0,0,993,995,1,0,0,0,994,996,3,166,83,0,995,994,1,0,0,0,995,996,1,0,0,0,
	996,998,1,0,0,0,997,999,3,170,85,0,998,997,1,0,0,0,998,999,1,0,0,0,999,
	1001,1,0,0,0,1000,1002,3,164,82,0,1001,1000,1,0,0,0,1001,1002,1,0,0,0,1002,
	1003,1,0,0,0,1003,1004,5,2,0,0,1004,1023,1,0,0,0,1005,1006,5,54,0,0,1006,
	1007,5,1,0,0,1007,1009,3,4,2,0,1008,1010,3,188,94,0,1009,1008,1,0,0,0,1009,
	1010,1,0,0,0,1010,1012,1,0,0,0,1011,1013,3,190,95,0,1012,1011,1,0,0,0,1012,
	1013,1,0,0,0,1013,1015,1,0,0,0,1014,1016,3,172,86,0,1015,1014,1,0,0,0,1015,
	1016,1,0,0,0,1016,1018,1,0,0,0,1017,1019,7,18,0,0,1018,1017,1,0,0,0,1018,
	1019,1,0,0,0,1019,1020,1,0,0,0,1020,1021,5,2,0,0,1021,1023,1,0,0,0,1022,
	961,1,0,0,0,1022,982,1,0,0,0,1022,1005,1,0,0,0,1023,61,1,0,0,0,1024,1025,
	5,101,0,0,1025,1026,5,1,0,0,1026,1027,3,4,2,0,1027,1028,5,17,0,0,1028,1029,
	3,4,2,0,1029,1030,5,2,0,0,1030,63,1,0,0,0,1031,1032,5,101,0,0,1032,1033,
	5,1,0,0,1033,1034,3,6,3,0,1034,1035,5,17,0,0,1035,1036,3,6,3,0,1036,1037,
	5,2,0,0,1037,65,1,0,0,0,1038,1039,7,19,0,0,1039,1040,5,1,0,0,1040,1041,
	3,6,3,0,1041,1042,5,2,0,0,1042,1047,1,0,0,0,1043,1044,5,90,0,0,1044,1045,
	5,1,0,0,1045,1047,5,2,0,0,1046,1038,1,0,0,0,1046,1043,1,0,0,0,1047,67,1,
	0,0,0,1048,1049,7,19,0,0,1049,1050,5,1,0,0,1050,1055,3,4,2,0,1051,1053,
	3,106,53,0,1052,1054,3,108,54,0,1053,1052,1,0,0,0,1053,1054,1,0,0,0,1054,
	1056,1,0,0,0,1055,1051,1,0,0,0,1055,1056,1,0,0,0,1056,1057,1,0,0,0,1057,
	1058,5,2,0,0,1058,69,1,0,0,0,1059,1060,7,20,0,0,1060,1061,5,1,0,0,1061,
	1062,3,4,2,0,1062,1063,5,140,0,0,1063,1065,5,1,0,0,1064,1066,3,94,47,0,
	1065,1064,1,0,0,0,1065,1066,1,0,0,0,1066,1068,1,0,0,0,1067,1069,3,96,48,
	0,1068,1067,1,0,0,0,1068,1069,1,0,0,0,1069,1071,1,0,0,0,1070,1072,3,100,
	50,0,1071,1070,1,0,0,0,1071,1072,1,0,0,0,1072,1073,1,0,0,0,1073,1074,5,
	2,0,0,1074,1075,5,2,0,0,1075,1106,1,0,0,0,1076,1077,7,21,0,0,1077,1078,
	5,1,0,0,1078,1084,3,4,2,0,1079,1080,5,17,0,0,1080,1082,3,102,51,0,1081,
	1083,3,208,104,0,1082,1081,1,0,0,0,1082,1083,1,0,0,0,1083,1085,1,0,0,0,
	1084,1079,1,0,0,0,1084,1085,1,0,0,0,1085,1086,1,0,0,0,1086,1087,5,140,0,
	0,1087,1089,5,1,0,0,1088,1090,3,94,47,0,1089,1088,1,0,0,0,1089,1090,1,0,
	0,0,1090,1091,1,0,0,0,1091,1092,3,96,48,0,1092,1093,1,0,0,0,1093,1094,5,
	2,0,0,1094,1095,5,2,0,0,1095,1106,1,0,0,0,1096,1097,5,139,0,0,1097,1098,
	5,1,0,0,1098,1099,3,4,2,0,1099,1100,5,140,0,0,1100,1101,5,1,0,0,1101,1102,
	3,94,47,0,1102,1103,5,2,0,0,1103,1104,5,2,0,0,1104,1106,1,0,0,0,1105,1059,
	1,0,0,0,1105,1076,1,0,0,0,1105,1096,1,0,0,0,1106,71,1,0,0,0,1107,1108,7,
	20,0,0,1108,1109,5,1,0,0,1109,1110,3,6,3,0,1110,1111,5,140,0,0,1111,1113,
	5,1,0,0,1112,1114,3,94,47,0,1113,1112,1,0,0,0,1113,1114,1,0,0,0,1114,1116,
	1,0,0,0,1115,1117,3,96,48,0,1116,1115,1,0,0,0,1116,1117,1,0,0,0,1117,1119,
	1,0,0,0,1118,1120,3,100,50,0,1119,1118,1,0,0,0,1119,1120,1,0,0,0,1120,1121,
	1,0,0,0,1121,1122,5,2,0,0,1122,1123,5,2,0,0,1123,1166,1,0,0,0,1124,1125,
	7,21,0,0,1125,1126,5,1,0,0,1126,1132,3,6,3,0,1127,1128,5,17,0,0,1128,1130,
	3,102,51,0,1129,1131,3,208,104,0,1130,1129,1,0,0,0,1130,1131,1,0,0,0,1131,
	1133,1,0,0,0,1132,1127,1,0,0,0,1132,1133,1,0,0,0,1133,1134,1,0,0,0,1134,
	1135,5,140,0,0,1135,1137,5,1,0,0,1136,1138,3,94,47,0,1137,1136,1,0,0,0,
	1137,1138,1,0,0,0,1138,1139,1,0,0,0,1139,1140,3,96,48,0,1140,1141,1,0,0,
	0,1141,1142,5,2,0,0,1142,1143,5,2,0,0,1143,1166,1,0,0,0,1144,1145,5,65,
	0,0,1145,1146,5,1,0,0,1146,1147,5,140,0,0,1147,1149,5,1,0,0,1148,1150,3,
	94,47,0,1149,1148,1,0,0,0,1149,1150,1,0,0,0,1150,1151,1,0,0,0,1151,1152,
	3,96,48,0,1152,1153,1,0,0,0,1153,1154,5,2,0,0,1154,1155,5,2,0,0,1155,1166,
	1,0,0,0,1156,1157,5,139,0,0,1157,1158,5,1,0,0,1158,1159,3,6,3,0,1159,1160,
	5,140,0,0,1160,1161,5,1,0,0,1161,1162,3,94,47,0,1162,1163,5,2,0,0,1163,
	1164,5,2,0,0,1164,1166,1,0,0,0,1165,1107,1,0,0,0,1165,1124,1,0,0,0,1165,
	1144,1,0,0,0,1165,1156,1,0,0,0,1166,73,1,0,0,0,1167,1168,3,184,92,0,1168,
	1169,5,56,0,0,1169,1170,3,184,92,0,1170,75,1,0,0,0,1171,1176,3,78,39,0,
	1172,1173,5,17,0,0,1173,1175,3,78,39,0,1174,1172,1,0,0,0,1175,1178,1,0,
	0,0,1176,1174,1,0,0,0,1176,1177,1,0,0,0,1177,77,1,0,0,0,1178,1176,1,0,0,
	0,1179,1181,3,198,99,0,1180,1179,1,0,0,0,1180,1181,1,0,0,0,1181,1182,1,
	0,0,0,1182,1183,3,184,92,0,1183,1184,5,19,0,0,1184,1185,3,66,33,0,1185,
	79,1,0,0,0,1186,1188,3,198,99,0,1187,1186,1,0,0,0,1187,1188,1,0,0,0,1188,
	1189,1,0,0,0,1189,1190,3,184,92,0,1190,1191,5,19,0,0,1191,1192,3,6,3,0,
	1192,81,1,0,0,0,1193,1194,3,184,92,0,1194,1195,5,7,0,0,1195,1196,3,208,
	104,0,1196,83,1,0,0,0,1197,1202,3,88,44,0,1198,1199,5,17,0,0,1199,1201,
	3,88,44,0,1200,1198,1,0,0,0,1201,1204,1,0,0,0,1202,1200,1,0,0,0,1202,1203,
	1,0,0,0,1203,85,1,0,0,0,1204,1202,1,0,0,0,1205,1210,3,88,44,0,1206,1207,
	5,17,0,0,1207,1209,3,88,44,0,1208,1206,1,0,0,0,1209,1212,1,0,0,0,1210,1208,
	1,0,0,0,1210,1211,1,0,0,0,1211,1222,1,0,0,0,1212,1210,1,0,0,0,1213,1214,
	5,26,0,0,1214,1219,3,184,92,0,1215,1216,5,17,0,0,1216,1218,3,184,92,0,1217,
	1215,1,0,0,0,1218,1221,1,0,0,0,1219,1217,1,0,0,0,1219,1220,1,0,0,0,1220,
	1223,1,0,0,0,1221,1219,1,0,0,0,1222,1213,1,0,0,0,1222,1223,1,0,0,0,1223,
	87,1,0,0,0,1224,1227,3,4,2,0,1225,1226,5,35,0,0,1226,1228,3,178,89,0,1227,
	1225,1,0,0,0,1227,1228,1,0,0,0,1228,89,1,0,0,0,1229,1231,3,18,9,0,1230,
	1229,1,0,0,0,1230,1231,1,0,0,0,1231,1235,1,0,0,0,1232,1236,3,20,10,0,1233,
	1236,3,92,46,0,1234,1236,3,16,8,0,1235,1232,1,0,0,0,1235,1233,1,0,0,0,1235,
	1234,1,0,0,0,1235,1236,1,0,0,0,1236,1238,1,0,0,0,1237,1239,3,22,11,0,1238,
	1237,1,0,0,0,1238,1239,1,0,0,0,1239,1241,1,0,0,0,1240,1242,3,14,7,0,1241,
	1240,1,0,0,0,1241,1242,1,0,0,0,1242,91,1,0,0,0,1243,1244,5,194,0,0,1244,
	1245,3,4,2,0,1245,93,1,0,0,0,1246,1247,5,144,0,0,1247,1248,5,64,0,0,1248,
	1253,3,184,92,0,1249,1250,5,17,0,0,1250,1252,3,184,92,0,1251,1249,1,0,0,
	0,1252,1255,1,0,0,0,1253,1251,1,0,0,0,1253,1254,1,0,0,0,1254,95,1,0,0,0,
	1255,1253,1,0,0,0,1256,1257,5,63,0,0,1257,1258,5,64,0,0,1258,1263,3,98,
	49,0,1259,1260,5,17,0,0,1260,1262,3,98,49,0,1261,1259,1,0,0,0,1262,1265,
	1,0,0,0,1263,1261,1,0,0,0,1263,1264,1,0,0,0,1264,97,1,0,0,0,1265,1263,1,
	0,0,0,1266,1268,3,184,92,0,1267,1269,7,22,0,0,1268,1267,1,0,0,0,1268,1269,
	1,0,0,0,1269,99,1,0,0,0,1270,1271,5,107,0,0,1271,1274,5,176,0,0,1272,1274,
	5,146,0,0,1273,1270,1,0,0,0,1273,1272,1,0,0,0,1274,1275,1,0,0,0,1275,1276,
	5,40,0,0,1276,1277,3,104,52,0,1277,1278,5,36,0,0,1278,1279,3,104,52,0,1279,
	101,1,0,0,0,1280,1281,5,229,0,0,1281,103,1,0,0,0,1282,1283,5,229,0,0,1283,
	1294,5,141,0,0,1284,1285,5,229,0,0,1285,1294,5,142,0,0,1286,1287,5,147,
	0,0,1287,1288,5,107,0,0,1288,1294,5,177,0,0,1289,1290,5,143,0,0,1290,1294,
	5,141,0,0,1291,1292,5,143,0,0,1292,1294,5,142,0,0,1293,1282,1,0,0,0,1293,
	1284,1,0,0,0,1293,1286,1,0,0,0,1293,1289,1,0,0,0,1293,1291,1,0,0,0,1294,
	105,1,0,0,0,1295,1296,5,132,0,0,1296,1297,7,23,0,0,1297,1302,3,184,92,0,
	1298,1299,5,17,0,0,1299,1301,3,184,92,0,1300,1298,1,0,0,0,1301,1304,1,0,
	0,0,1302,1300,1,0,0,0,1302,1303,1,0,0,0,1303,1313,1,0,0,0,1304,1302,1,0,
	0,0,1305,1306,5,199,0,0,1306,1307,5,1,0,0,1307,1310,5,233,0,0,1308,1309,
	5,17,0,0,1309,1311,7,16,0,0,1310,1308,1,0,0,0,1310,1311,1,0,0,0,1311,1312,
	1,0,0,0,1312,1314,5,2,0,0,1313,1305,1,0,0,0,1313,1314,1,0,0,0,1314,1325,
	1,0,0,0,1315,1316,5,132,0,0,1316,1317,5,60,0,0,1317,1322,3,6,3,0,1318,1319,
	5,199,0,0,1319,1320,5,1,0,0,1320,1321,5,233,0,0,1321,1323,5,2,0,0,1322,
	1318,1,0,0,0,1322,1323,1,0,0,0,1323,1325,1,0,0,0,1324,1295,1,0,0,0,1324,
	1315,1,0,0,0,1325,107,1,0,0,0,1326,1327,5,134,0,0,1327,1328,3,6,3,0,1328,
	109,1,0,0,0,1329,1330,3,180,90,0,1330,1333,3,116,58,0,1331,1332,5,209,0,
	0,1332,1334,3,208,104,0,1333,1331,1,0,0,0,1333,1334,1,0,0,0,1334,111,1,
	0,0,0,1335,1339,3,120,60,0,1336,1339,3,124,62,0,1337,1339,3,122,61,0,1338,
	1335,1,0,0,0,1338,1336,1,0,0,0,1338,1337,1,0,0,0,1339,113,1,0,0,0,1340,
	1343,3,122,61,0,1341,1343,3,120,60,0,1342,1340,1,0,0,0,1342,1341,1,0,0,
	0,1343,115,1,0,0,0,1344,1350,3,120,60,0,1345,1350,3,124,62,0,1346,1350,
	3,126,63,0,1347,1350,3,118,59,0,1348,1350,3,122,61,0,1349,1344,1,0,0,0,
	1349,1345,1,0,0,0,1349,1346,1,0,0,0,1349,1347,1,0,0,0,1349,1348,1,0,0,0,
	1350,117,1,0,0,0,1351,1355,5,115,0,0,1352,1355,3,128,64,0,1353,1355,3,130,
	65,0,1354,1351,1,0,0,0,1354,1352,1,0,0,0,1354,1353,1,0,0,0,1355,119,1,0,
	0,0,1356,1359,3,210,105,0,1357,1359,3,132,66,0,1358,1356,1,0,0,0,1358,1357,
	1,0,0,0,1359,1361,1,0,0,0,1360,1362,3,158,79,0,1361,1360,1,0,0,0,1361,1362,
	1,0,0,0,1362,1367,1,0,0,0,1363,1365,5,39,0,0,1364,1363,1,0,0,0,1364,1365,
	1,0,0,0,1365,1366,1,0,0,0,1366,1368,5,43,0,0,1367,1364,1,0,0,0,1367,1368,
	1,0,0,0,1368,121,1,0,0,0,1369,1374,3,198,99,0,1370,1371,5,8,0,0,1371,1372,
	3,120,60,0,1372,1373,5,9,0,0,1373,1375,1,0,0,0,1374,1370,1,0,0,0,1374,1375,
	1,0,0,0,1375,123,1,0,0,0,1376,1388,5,109,0,0,1377,1378,5,5,0,0,1378,1383,
	3,160,80,0,1379,1380,5,17,0,0,1380,1382,3,160,80,0,1381,1379,1,0,0,0,1382,
	1385,1,0,0,0,1383,1381,1,0,0,0,1383,1384,1,0,0,0,1384,1386,1,0,0,0,1385,
	1383,1,0,0,0,1386,1387,5,6,0,0,1387,1389,1,0,0,0,1388,1377,1,0,0,0,1388,
	1389,1,0,0,0,1389,125,1,0,0,0,1390,1395,5,227,0,0,1391,1392,5,8,0,0,1392,
	1393,3,120,60,0,1393,1394,5,9,0,0,1394,1396,1,0,0,0,1395,1391,1,0,0,0,1395,
	1396,1,0,0,0,1396,127,1,0,0,0,1397,1427,5,113,0,0,1398,1410,5,223,0,0,1399,
	1400,5,5,0,0,1400,1405,3,132,66,0,1401,1402,5,15,0,0,1402,1404,3,132,66,
	0,1403,1401,1,0,0,0,1404,1407,1,0,0,0,1405,1403,1,0,0,0,1405,1406,1,0,0,
	0,1406,1408,1,0,0,0,1407,1405,1,0,0,0,1408,1409,5,6,0,0,1409,1411,1,0,0,
	0,1410,1399,1,0,0,0,1410,1411,1,0,0,0,1411,1427,1,0,0,0,1412,1424,5,224,
	0,0,1413,1414,5,5,0,0,1414,1419,3,180,90,0,1415,1416,5,15,0,0,1416,1418,
	3,180,90,0,1417,1415,1,0,0,0,1418,1421,1,0,0,0,1419,1417,1,0,0,0,1419,1420,
	1,0,0,0,1420,1422,1,0,0,0,1421,1419,1,0,0,0,1422,1423,5,6,0,0,1423,1425,
	1,0,0,0,1424,1413,1,0,0,0,1424,1425,1,0,0,0,1425,1427,1,0,0,0,1426,1397,
	1,0,0,0,1426,1398,1,0,0,0,1426,1412,1,0,0,0,1427,129,1,0,0,0,1428,1469,
	5,114,0,0,1429,1446,5,225,0,0,1430,1431,5,5,0,0,1431,1443,5,234,0,0,1432,
	1433,5,1,0,0,1433,1438,3,132,66,0,1434,1435,5,15,0,0,1435,1437,3,132,66,
	0,1436,1434,1,0,0,0,1437,1440,1,0,0,0,1438,1436,1,0,0,0,1438,1439,1,0,0,
	0,1439,1441,1,0,0,0,1440,1438,1,0,0,0,1441,1442,5,2,0,0,1442,1444,1,0,0,
	0,1443,1432,1,0,0,0,1443,1444,1,0,0,0,1444,1445,1,0,0,0,1445,1447,5,6,0,
	0,1446,1430,1,0,0,0,1446,1447,1,0,0,0,1447,1469,1,0,0,0,1448,1466,5,226,
	0,0,1449,1450,5,5,0,0,1450,1462,3,180,90,0,1451,1452,5,1,0,0,1452,1457,
	3,180,90,0,1453,1454,5,15,0,0,1454,1456,3,180,90,0,1455,1453,1,0,0,0,1456,
	1459,1,0,0,0,1457,1455,1,0,0,0,1457,1458,1,0,0,0,1458,1460,1,0,0,0,1459,
	1457,1,0,0,0,1460,1461,5,2,0,0,1461,1463,1,0,0,0,1462,1451,1,0,0,0,1462,
	1463,1,0,0,0,1463,1464,1,0,0,0,1464,1465,5,6,0,0,1465,1467,1,0,0,0,1466,
	1449,1,0,0,0,1466,1467,1,0,0,0,1467,1469,1,0,0,0,1468,1428,1,0,0,0,1468,
	1429,1,0,0,0,1468,1448,1,0,0,0,1469,131,1,0,0,0,1470,1471,5,234,0,0,1471,
	133,1,0,0,0,1472,1473,5,234,0,0,1473,135,1,0,0,0,1474,1475,7,24,0,0,1475,
	1480,3,138,69,0,1476,1477,5,17,0,0,1477,1479,3,138,69,0,1478,1476,1,0,0,
	0,1479,1482,1,0,0,0,1480,1478,1,0,0,0,1480,1481,1,0,0,0,1481,137,1,0,0,
	0,1482,1480,1,0,0,0,1483,1486,3,180,90,0,1484,1485,5,35,0,0,1485,1487,3,
	178,89,0,1486,1484,1,0,0,0,1486,1487,1,0,0,0,1487,139,1,0,0,0,1488,1493,
	3,142,71,0,1489,1490,5,236,0,0,1490,1492,3,142,71,0,1491,1489,1,0,0,0,1492,
	1495,1,0,0,0,1493,1491,1,0,0,0,1493,1494,1,0,0,0,1494,141,1,0,0,0,1495,
	1493,1,0,0,0,1496,1497,5,234,0,0,1497,1499,5,21,0,0,1498,1496,1,0,0,0,1498,
	1499,1,0,0,0,1499,1504,1,0,0,0,1500,1501,5,173,0,0,1501,1502,3,6,3,0,1502,
	1503,5,24,0,0,1503,1505,1,0,0,0,1504,1500,1,0,0,0,1504,1505,1,0,0,0,1505,
	1506,1,0,0,0,1506,1508,3,6,3,0,1507,1509,3,188,94,0,1508,1507,1,0,0,0,1508,
	1509,1,0,0,0,1509,1511,1,0,0,0,1510,1512,3,190,95,0,1511,1510,1,0,0,0,1511,
	1512,1,0,0,0,1512,143,1,0,0,0,1513,1518,3,146,73,0,1514,1515,5,236,0,0,
	1515,1517,3,146,73,0,1516,1514,1,0,0,0,1517,1520,1,0,0,0,1518,1516,1,0,
	0,0,1518,1519,1,0,0,0,1519,145,1,0,0,0,1520,1518,1,0,0,0,1521,1522,5,234,
	0,0,1522,1524,5,21,0,0,1523,1521,1,0,0,0,1523,1524,1,0,0,0,1524,1525,1,
	0,0,0,1525,1527,3,152,76,0,1526,1528,3,188,94,0,1527,1526,1,0,0,0,1527,
	1528,1,0,0,0,1528,1530,1,0,0,0,1529,1531,3,190,95,0,1530,1529,1,0,0,0,1530,
	1531,1,0,0,0,1531,147,1,0,0,0,1532,1535,7,24,0,0,1533,1534,5,155,0,0,1534,
	1536,3,150,75,0,1535,1533,1,0,0,0,1535,1536,1,0,0,0,1536,1537,1,0,0,0,1537,
	1538,5,116,0,0,1538,1539,5,234,0,0,1539,149,1,0,0,0,1540,1545,3,138,69,
	0,1541,1542,5,17,0,0,1542,1544,3,138,69,0,1543,1541,1,0,0,0,1544,1547,1,
	0,0,0,1545,1543,1,0,0,0,1545,1546,1,0,0,0,1546,151,1,0,0,0,1547,1545,1,
	0,0,0,1548,1549,5,173,0,0,1549,1550,3,6,3,0,1550,1551,5,24,0,0,1551,1553,
	1,0,0,0,1552,1548,1,0,0,0,1552,1553,1,0,0,0,1553,1554,1,0,0,0,1554,1556,
	3,156,78,0,1555,1557,3,192,96,0,1556,1555,1,0,0,0,1556,1557,1,0,0,0,1557,
	1558,1,0,0,0,1558,1562,3,154,77,0,1559,1561,3,154,77,0,1560,1559,1,0,0,
	0,1561,1564,1,0,0,0,1562,1560,1,0,0,0,1562,1563,1,0,0,0,1563,153,1,0,0,
	0,1564,1562,1,0,0,0,1565,1567,7,25,0,0,1566,1565,1,0,0,0,1566,1567,1,0,
	0,0,1567,1568,1,0,0,0,1568,1573,3,156,78,0,1569,1570,5,3,0,0,1570,1571,
	3,6,3,0,1571,1572,5,4,0,0,1572,1574,1,0,0,0,1573,1569,1,0,0,0,1573,1574,
	1,0,0,0,1574,155,1,0,0,0,1575,1576,7,26,0,0,1576,157,1,0,0,0,1577,1578,
	5,3,0,0,1578,1579,3,6,3,0,1579,1580,5,4,0,0,1580,1593,1,0,0,0,1581,1582,
	5,5,0,0,1582,1587,3,208,104,0,1583,1584,5,17,0,0,1584,1586,3,208,104,0,
	1585,1583,1,0,0,0,1586,1589,1,0,0,0,1587,1585,1,0,0,0,1587,1588,1,0,0,0,
	1588,1590,1,0,0,0,1589,1587,1,0,0,0,1590,1591,5,6,0,0,1591,1593,1,0,0,0,
	1592,1577,1,0,0,0,1592,1581,1,0,0,0,1593,159,1,0,0,0,1594,1597,3,122,61,
	0,1595,1598,3,184,92,0,1596,1598,3,162,81,0,1597,1595,1,0,0,0,1597,1596,
	1,0,0,0,1598,161,1,0,0,0,1599,1601,5,103,0,0,1600,1602,7,27,0,0,1601,1600,
	1,0,0,0,1601,1602,1,0,0,0,1602,163,1,0,0,0,1603,1604,7,28,0,0,1604,165,
	1,0,0,0,1605,1606,7,29,0,0,1606,167,1,0,0,0,1607,1608,5,155,0,0,1608,1613,
	3,184,92,0,1609,1610,5,17,0,0,1610,1612,3,184,92,0,1611,1609,1,0,0,0,1612,
	1615,1,0,0,0,1613,1611,1,0,0,0,1613,1614,1,0,0,0,1614,169,1,0,0,0,1615,
	1613,1,0,0,0,1616,1617,7,30,0,0,1617,171,1,0,0,0,1618,1619,5,58,0,0,1619,
	1620,3,4,2,0,1620,173,1,0,0,0,1621,1622,7,31,0,0,1622,175,1,0,0,0,1623,
	1624,7,32,0,0,1624,177,1,0,0,0,1625,1626,5,234,0,0,1626,179,1,0,0,0,1627,
	1628,5,234,0,0,1628,181,1,0,0,0,1629,1630,5,234,0,0,1630,183,1,0,0,0,1631,
	1634,5,234,0,0,1632,1633,5,20,0,0,1633,1635,5,234,0,0,1634,1632,1,0,0,0,
	1634,1635,1,0,0,0,1635,185,1,0,0,0,1636,1637,5,5,0,0,1637,1642,3,208,104,
	0,1638,1639,5,17,0,0,1639,1641,3,208,104,0,1640,1638,1,0,0,0,1641,1644,
	1,0,0,0,1642,1640,1,0,0,0,1642,1643,1,0,0,0,1643,1645,1,0,0,0,1644,1642,
	1,0,0,0,1645,1646,5,6,0,0,1646,1649,1,0,0,0,1647,1649,3,202,101,0,1648,
	1636,1,0,0,0,1648,1647,1,0,0,0,1649,187,1,0,0,0,1650,1651,5,59,0,0,1651,
	1652,3,208,104,0,1652,189,1,0,0,0,1653,1654,5,62,0,0,1654,1655,3,208,104,
	0,1655,191,1,0,0,0,1656,1657,7,33,0,0,1657,193,1,0,0,0,1658,1661,3,4,2,
	0,1659,1661,5,103,0,0,1660,1658,1,0,0,0,1660,1659,1,0,0,0,1661,195,1,0,
	0,0,1662,1665,3,6,3,0,1663,1665,5,103,0,0,1664,1662,1,0,0,0,1664,1663,1,
	0,0,0,1665,197,1,0,0,0,1666,1672,5,92,0,0,1667,1672,5,222,0,0,1668,1672,
	5,91,0,0,1669,1672,5,93,0,0,1670,1672,3,200,100,0,1671,1666,1,0,0,0,1671,
	1667,1,0,0,0,1671,1668,1,0,0,0,1671,1669,1,0,0,0,1671,1670,1,0,0,0,1672,
	199,1,0,0,0,1673,1674,5,98,0,0,1674,1675,5,93,0,0,1675,201,1,0,0,0,1676,
	1677,5,234,0,0,1677,203,1,0,0,0,1678,1679,5,234,0,0,1679,205,1,0,0,0,1680,
	1681,5,234,0,0,1681,207,1,0,0,0,1682,1683,7,34,0,0,1683,209,1,0,0,0,1684,
	1685,7,35,0,0,1685,211,1,0,0,0,1686,1687,7,36,0,0,1687,213,1,0,0,0,190,
	219,233,252,281,283,303,324,326,337,351,360,368,375,377,388,397,411,426,
	437,440,445,478,487,490,500,505,509,515,519,529,533,537,546,549,559,563,
	573,578,582,588,592,596,601,606,622,626,637,648,652,656,672,676,687,698,
	702,706,718,729,741,752,782,786,809,814,822,843,847,851,857,862,870,891,
	895,899,905,914,925,936,944,948,951,954,957,972,975,978,988,992,995,998,
	1001,1009,1012,1015,1018,1022,1046,1053,1055,1065,1068,1071,1082,1084,1089,
	1105,1113,1116,1119,1130,1132,1137,1149,1165,1176,1180,1187,1202,1210,1219,
	1222,1227,1230,1235,1238,1241,1253,1263,1268,1273,1293,1302,1310,1313,1322,
	1324,1333,1338,1342,1349,1354,1358,1361,1364,1367,1374,1383,1388,1395,1405,
	1410,1419,1424,1426,1438,1443,1446,1457,1462,1466,1468,1480,1486,1493,1498,
	1504,1508,1511,1518,1523,1527,1530,1535,1545,1552,1556,1562,1566,1573,1587,
	1592,1597,1601,1613,1634,1642,1648,1660,1664,1671];

	private static __ATN: ATN;
	public static get _ATN(): ATN {
		if (!Vtl.__ATN) {
			Vtl.__ATN = new ATNDeserializer().deserialize(Vtl._serializedATN);
		}

		return Vtl.__ATN;
	}


	static DecisionsToDFA = Vtl._ATN.decisionToState.map( (ds: DecisionState, index: number) => new DFA(ds, index) );

}

export class StartContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public EOF(): TerminalNode {
		return this.getToken(Vtl.EOF, 0);
	}
	public statement_list(): StatementContext[] {
		return this.getTypedRuleContexts(StatementContext) as StatementContext[];
	}
	public statement(i: number): StatementContext {
		return this.getTypedRuleContext(StatementContext, i) as StatementContext;
	}
	public EOL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.EOL);
	}
	public EOL(i: number): TerminalNode {
		return this.getToken(Vtl.EOL, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_start;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitStart) {
			return visitor.visitStart(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StatementContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_statement;
	}
	public copyFrom(ctx: StatementContext): void {
		super.copyFrom(ctx);
	}
}
export class DefineExpressionContext extends StatementContext {
	constructor(parser: Vtl, ctx: StatementContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public defOperators(): DefOperatorsContext {
		return this.getTypedRuleContext(DefOperatorsContext, 0) as DefOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDefineExpression) {
			return visitor.visitDefineExpression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TemporaryAssignmentContext extends StatementContext {
	constructor(parser: Vtl, ctx: StatementContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public ASSIGN(): TerminalNode {
		return this.getToken(Vtl.ASSIGN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTemporaryAssignment) {
			return visitor.visitTemporaryAssignment(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class PersistAssignmentContext extends StatementContext {
	constructor(parser: Vtl, ctx: StatementContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public PUT_SYMBOL(): TerminalNode {
		return this.getToken(Vtl.PUT_SYMBOL, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitPersistAssignment) {
			return visitor.visitPersistAssignment(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ExprContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_expr;
	}
	public copyFrom(ctx: ExprContext): void {
		super.copyFrom(ctx);
	}
}
export class VarIdExprContext extends ExprContext {
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitVarIdExpr) {
			return visitor.visitVarIdExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class MembershipExprContext extends ExprContext {
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public MEMBERSHIP(): TerminalNode {
		return this.getToken(Vtl.MEMBERSHIP, 0);
	}
	public simpleComponentId(): SimpleComponentIdContext {
		return this.getTypedRuleContext(SimpleComponentIdContext, 0) as SimpleComponentIdContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitMembershipExpr) {
			return visitor.visitMembershipExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class InNotInExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: InexprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public inexpr(): InexprContext {
		return this.getTypedRuleContext(InexprContext, 0) as InexprContext;
	}
	public IN(): TerminalNode {
		return this.getToken(Vtl.IN, 0);
	}
	public NOT_IN(): TerminalNode {
		return this.getToken(Vtl.NOT_IN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInNotInExpr) {
			return visitor.visitInNotInExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BooleanExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public AND(): TerminalNode {
		return this.getToken(Vtl.AND, 0);
	}
	public OR(): TerminalNode {
		return this.getToken(Vtl.OR, 0);
	}
	public XOR(): TerminalNode {
		return this.getToken(Vtl.XOR, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBooleanExpr) {
			return visitor.visitBooleanExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: ComparisonOperandContext;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public comparisonOperand(): ComparisonOperandContext {
		return this.getTypedRuleContext(ComparisonOperandContext, 0) as ComparisonOperandContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComparisonExpr) {
			return visitor.visitComparisonExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryExprContext extends ExprContext {
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(Vtl.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(Vtl.MINUS, 0);
	}
	public NOT(): TerminalNode {
		return this.getToken(Vtl.NOT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryExpr) {
			return visitor.visitUnaryExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FunctionsExpressionContext extends ExprContext {
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public functions(): FunctionsContext {
		return this.getTypedRuleContext(FunctionsContext, 0) as FunctionsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFunctionsExpression) {
			return visitor.visitFunctionsExpression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IfExprContext extends ExprContext {
	public _conditionalExpr!: ExprContext;
	public _thenExpr!: ExprContext;
	public _elseExpr!: ExprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public IF(): TerminalNode {
		return this.getToken(Vtl.IF, 0);
	}
	public THEN(): TerminalNode {
		return this.getToken(Vtl.THEN, 0);
	}
	public ELSE(): TerminalNode {
		return this.getToken(Vtl.ELSE, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitIfExpr) {
			return visitor.visitIfExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ClauseExprContext extends ExprContext {
	public _dataset!: ExprContext;
	public _clause!: DatasetClauseContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public QLPAREN(): TerminalNode {
		return this.getToken(Vtl.QLPAREN, 0);
	}
	public QRPAREN(): TerminalNode {
		return this.getToken(Vtl.QRPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public datasetClause(): DatasetClauseContext {
		return this.getTypedRuleContext(DatasetClauseContext, 0) as DatasetClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitClauseExpr) {
			return visitor.visitClauseExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ArithmeticExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public MUL(): TerminalNode {
		return this.getToken(Vtl.MUL, 0);
	}
	public DIV(): TerminalNode {
		return this.getToken(Vtl.DIV, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitArithmeticExpr) {
			return visitor.visitArithmeticExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ParenthesisExprContext extends ExprContext {
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitParenthesisExpr) {
			return visitor.visitParenthesisExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConstantExprContext extends ExprContext {
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConstantExpr) {
			return visitor.visitConstantExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ArithmeticExprOrConcatContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(Vtl.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(Vtl.MINUS, 0);
	}
	public CONCAT(): TerminalNode {
		return this.getToken(Vtl.CONCAT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitArithmeticExprOrConcat) {
			return visitor.visitArithmeticExprOrConcat(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ExprComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_exprComponent;
	}
	public copyFrom(ctx: ExprComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class ArithmeticExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public MUL(): TerminalNode {
		return this.getToken(Vtl.MUL, 0);
	}
	public DIV(): TerminalNode {
		return this.getToken(Vtl.DIV, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitArithmeticExprComp) {
			return visitor.visitArithmeticExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IfExprCompContext extends ExprComponentContext {
	public _conditionalExpr!: ExprComponentContext;
	public _thenExpr!: ExprComponentContext;
	public _elseExpr!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public IF(): TerminalNode {
		return this.getToken(Vtl.IF, 0);
	}
	public THEN(): TerminalNode {
		return this.getToken(Vtl.THEN, 0);
	}
	public ELSE(): TerminalNode {
		return this.getToken(Vtl.ELSE, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitIfExprComp) {
			return visitor.visitIfExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public comparisonOperand(): ComparisonOperandContext {
		return this.getTypedRuleContext(ComparisonOperandContext, 0) as ComparisonOperandContext;
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComparisonExprComp) {
			return visitor.visitComparisonExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FunctionsExpressionCompContext extends ExprComponentContext {
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public functionsComponents(): FunctionsComponentsContext {
		return this.getTypedRuleContext(FunctionsComponentsContext, 0) as FunctionsComponentsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFunctionsExpressionComp) {
			return visitor.visitFunctionsExpressionComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CompIdContext extends ExprComponentContext {
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCompId) {
			return visitor.visitCompId(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConstantExprCompContext extends ExprComponentContext {
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConstantExprComp) {
			return visitor.visitConstantExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ArithmeticExprOrConcatCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(Vtl.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(Vtl.MINUS, 0);
	}
	public CONCAT(): TerminalNode {
		return this.getToken(Vtl.CONCAT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitArithmeticExprOrConcatComp) {
			return visitor.visitArithmeticExprOrConcatComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ParenthesisExprCompContext extends ExprComponentContext {
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitParenthesisExprComp) {
			return visitor.visitParenthesisExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class InNotInExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: InexprContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public inexpr(): InexprContext {
		return this.getTypedRuleContext(InexprContext, 0) as InexprContext;
	}
	public IN(): TerminalNode {
		return this.getToken(Vtl.IN, 0);
	}
	public NOT_IN(): TerminalNode {
		return this.getToken(Vtl.NOT_IN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInNotInExprComp) {
			return visitor.visitInNotInExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryExprCompContext extends ExprComponentContext {
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(Vtl.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(Vtl.MINUS, 0);
	}
	public NOT(): TerminalNode {
		return this.getToken(Vtl.NOT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryExprComp) {
			return visitor.visitUnaryExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BooleanExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public AND(): TerminalNode {
		return this.getToken(Vtl.AND, 0);
	}
	public OR(): TerminalNode {
		return this.getToken(Vtl.OR, 0);
	}
	public XOR(): TerminalNode {
		return this.getToken(Vtl.XOR, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBooleanExprComp) {
			return visitor.visitBooleanExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class FunctionsComponentsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_functionsComponents;
	}
	public copyFrom(ctx: FunctionsComponentsContext): void {
		super.copyFrom(ctx);
	}
}
export class NumericFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public numericOperatorsComponent(): NumericOperatorsComponentContext {
		return this.getTypedRuleContext(NumericOperatorsComponentContext, 0) as NumericOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitNumericFunctionsComponents) {
			return visitor.visitNumericFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class StringFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public stringOperatorsComponent(): StringOperatorsComponentContext {
		return this.getTypedRuleContext(StringOperatorsComponentContext, 0) as StringOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitStringFunctionsComponents) {
			return visitor.visitStringFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public comparisonOperatorsComponent(): ComparisonOperatorsComponentContext {
		return this.getTypedRuleContext(ComparisonOperatorsComponentContext, 0) as ComparisonOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComparisonFunctionsComponents) {
			return visitor.visitComparisonFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public timeOperatorsComponent(): TimeOperatorsComponentContext {
		return this.getTypedRuleContext(TimeOperatorsComponentContext, 0) as TimeOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTimeFunctionsComponents) {
			return visitor.visitTimeFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class GenericFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public genericOperatorsComponent(): GenericOperatorsComponentContext {
		return this.getTypedRuleContext(GenericOperatorsComponentContext, 0) as GenericOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitGenericFunctionsComponents) {
			return visitor.visitGenericFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AnalyticFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public anFunctionComponent(): AnFunctionComponentContext {
		return this.getTypedRuleContext(AnFunctionComponentContext, 0) as AnFunctionComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAnalyticFunctionsComponents) {
			return visitor.visitAnalyticFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConditionalFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public conditionalOperatorsComponent(): ConditionalOperatorsComponentContext {
		return this.getTypedRuleContext(ConditionalOperatorsComponentContext, 0) as ConditionalOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConditionalFunctionsComponents) {
			return visitor.visitConditionalFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AggregateFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: Vtl, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public aggrOperators(): AggrOperatorsContext {
		return this.getTypedRuleContext(AggrOperatorsContext, 0) as AggrOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggregateFunctionsComponents) {
			return visitor.visitAggregateFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class FunctionsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_functions;
	}
	public copyFrom(ctx: FunctionsContext): void {
		super.copyFrom(ctx);
	}
}
export class HierarchyFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public hierarchyOperators(): HierarchyOperatorsContext {
		return this.getTypedRuleContext(HierarchyOperatorsContext, 0) as HierarchyOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHierarchyFunctions) {
			return visitor.visitHierarchyFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class StringFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public stringOperators(): StringOperatorsContext {
		return this.getTypedRuleContext(StringOperatorsContext, 0) as StringOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitStringFunctions) {
			return visitor.visitStringFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValidationFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public validationOperators(): ValidationOperatorsContext {
		return this.getTypedRuleContext(ValidationOperatorsContext, 0) as ValidationOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValidationFunctions) {
			return visitor.visitValidationFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class GenericFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public genericOperators(): GenericOperatorsContext {
		return this.getTypedRuleContext(GenericOperatorsContext, 0) as GenericOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitGenericFunctions) {
			return visitor.visitGenericFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConditionalFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public conditionalOperators(): ConditionalOperatorsContext {
		return this.getTypedRuleContext(ConditionalOperatorsContext, 0) as ConditionalOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConditionalFunctions) {
			return visitor.visitConditionalFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AggregateFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public aggrOperatorsGrouping(): AggrOperatorsGroupingContext {
		return this.getTypedRuleContext(AggrOperatorsGroupingContext, 0) as AggrOperatorsGroupingContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggregateFunctions) {
			return visitor.visitAggregateFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class JoinFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public joinOperators(): JoinOperatorsContext {
		return this.getTypedRuleContext(JoinOperatorsContext, 0) as JoinOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinFunctions) {
			return visitor.visitJoinFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public comparisonOperators(): ComparisonOperatorsContext {
		return this.getTypedRuleContext(ComparisonOperatorsContext, 0) as ComparisonOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComparisonFunctions) {
			return visitor.visitComparisonFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class NumericFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public numericOperators(): NumericOperatorsContext {
		return this.getTypedRuleContext(NumericOperatorsContext, 0) as NumericOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitNumericFunctions) {
			return visitor.visitNumericFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public timeOperators(): TimeOperatorsContext {
		return this.getTypedRuleContext(TimeOperatorsContext, 0) as TimeOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTimeFunctions) {
			return visitor.visitTimeFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SetFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public setOperators(): SetOperatorsContext {
		return this.getTypedRuleContext(SetOperatorsContext, 0) as SetOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSetFunctions) {
			return visitor.visitSetFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AnalyticFunctionsContext extends FunctionsContext {
	constructor(parser: Vtl, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public anFunction(): AnFunctionContext {
		return this.getTypedRuleContext(AnFunctionContext, 0) as AnFunctionContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAnalyticFunctions) {
			return visitor.visitAnalyticFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DatasetClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public renameClause(): RenameClauseContext {
		return this.getTypedRuleContext(RenameClauseContext, 0) as RenameClauseContext;
	}
	public aggrClause(): AggrClauseContext {
		return this.getTypedRuleContext(AggrClauseContext, 0) as AggrClauseContext;
	}
	public filterClause(): FilterClauseContext {
		return this.getTypedRuleContext(FilterClauseContext, 0) as FilterClauseContext;
	}
	public calcClause(): CalcClauseContext {
		return this.getTypedRuleContext(CalcClauseContext, 0) as CalcClauseContext;
	}
	public keepOrDropClause(): KeepOrDropClauseContext {
		return this.getTypedRuleContext(KeepOrDropClauseContext, 0) as KeepOrDropClauseContext;
	}
	public pivotOrUnpivotClause(): PivotOrUnpivotClauseContext {
		return this.getTypedRuleContext(PivotOrUnpivotClauseContext, 0) as PivotOrUnpivotClauseContext;
	}
	public subspaceClause(): SubspaceClauseContext {
		return this.getTypedRuleContext(SubspaceClauseContext, 0) as SubspaceClauseContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_datasetClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDatasetClause) {
			return visitor.visitDatasetClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RenameClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RENAME(): TerminalNode {
		return this.getToken(Vtl.RENAME, 0);
	}
	public renameClauseItem_list(): RenameClauseItemContext[] {
		return this.getTypedRuleContexts(RenameClauseItemContext) as RenameClauseItemContext[];
	}
	public renameClauseItem(i: number): RenameClauseItemContext {
		return this.getTypedRuleContext(RenameClauseItemContext, i) as RenameClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_renameClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRenameClause) {
			return visitor.visitRenameClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public AGGREGATE(): TerminalNode {
		return this.getToken(Vtl.AGGREGATE, 0);
	}
	public aggregateClause(): AggregateClauseContext {
		return this.getTypedRuleContext(AggregateClauseContext, 0) as AggregateClauseContext;
	}
	public groupingClause(): GroupingClauseContext {
		return this.getTypedRuleContext(GroupingClauseContext, 0) as GroupingClauseContext;
	}
	public havingClause(): HavingClauseContext {
		return this.getTypedRuleContext(HavingClauseContext, 0) as HavingClauseContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_aggrClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggrClause) {
			return visitor.visitAggrClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class FilterClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public FILTER(): TerminalNode {
		return this.getToken(Vtl.FILTER, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_filterClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFilterClause) {
			return visitor.visitFilterClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CalcClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public CALC(): TerminalNode {
		return this.getToken(Vtl.CALC, 0);
	}
	public calcClauseItem_list(): CalcClauseItemContext[] {
		return this.getTypedRuleContexts(CalcClauseItemContext) as CalcClauseItemContext[];
	}
	public calcClauseItem(i: number): CalcClauseItemContext {
		return this.getTypedRuleContext(CalcClauseItemContext, i) as CalcClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_calcClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCalcClause) {
			return visitor.visitCalcClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class KeepOrDropClauseContext extends ParserRuleContext {
	public _op!: Token;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public KEEP(): TerminalNode {
		return this.getToken(Vtl.KEEP, 0);
	}
	public DROP(): TerminalNode {
		return this.getToken(Vtl.DROP, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_keepOrDropClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitKeepOrDropClause) {
			return visitor.visitKeepOrDropClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class PivotOrUnpivotClauseContext extends ParserRuleContext {
	public _op!: Token;
	public _id_!: ComponentIDContext;
	public _mea!: ComponentIDContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public PIVOT(): TerminalNode {
		return this.getToken(Vtl.PIVOT, 0);
	}
	public UNPIVOT(): TerminalNode {
		return this.getToken(Vtl.UNPIVOT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_pivotOrUnpivotClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitPivotOrUnpivotClause) {
			return visitor.visitPivotOrUnpivotClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SubspaceClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public SUBSPACE(): TerminalNode {
		return this.getToken(Vtl.SUBSPACE, 0);
	}
	public subspaceClauseItem_list(): SubspaceClauseItemContext[] {
		return this.getTypedRuleContexts(SubspaceClauseItemContext) as SubspaceClauseItemContext[];
	}
	public subspaceClauseItem(i: number): SubspaceClauseItemContext {
		return this.getTypedRuleContext(SubspaceClauseItemContext, i) as SubspaceClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_subspaceClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSubspaceClause) {
			return visitor.visitSubspaceClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_joinOperators;
	}
	public copyFrom(ctx: JoinOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class JoinExprContext extends JoinOperatorsContext {
	public _joinKeyword!: Token;
	constructor(parser: Vtl, ctx: JoinOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public joinClause(): JoinClauseContext {
		return this.getTypedRuleContext(JoinClauseContext, 0) as JoinClauseContext;
	}
	public joinBody(): JoinBodyContext {
		return this.getTypedRuleContext(JoinBodyContext, 0) as JoinBodyContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public INNER_JOIN(): TerminalNode {
		return this.getToken(Vtl.INNER_JOIN, 0);
	}
	public LEFT_JOIN(): TerminalNode {
		return this.getToken(Vtl.LEFT_JOIN, 0);
	}
	public joinClauseWithoutUsing(): JoinClauseWithoutUsingContext {
		return this.getTypedRuleContext(JoinClauseWithoutUsingContext, 0) as JoinClauseWithoutUsingContext;
	}
	public FULL_JOIN(): TerminalNode {
		return this.getToken(Vtl.FULL_JOIN, 0);
	}
	public CROSS_JOIN(): TerminalNode {
		return this.getToken(Vtl.CROSS_JOIN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinExpr) {
			return visitor.visitJoinExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DefOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_defOperators;
	}
	public copyFrom(ctx: DefOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class DefOperatorContext extends DefOperatorsContext {
	constructor(parser: Vtl, ctx: DefOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DEFINE(): TerminalNode {
		return this.getToken(Vtl.DEFINE, 0);
	}
	public OPERATOR_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.OPERATOR);
	}
	public OPERATOR(i: number): TerminalNode {
		return this.getToken(Vtl.OPERATOR, i);
	}
	public operatorID(): OperatorIDContext {
		return this.getTypedRuleContext(OperatorIDContext, 0) as OperatorIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public IS(): TerminalNode {
		return this.getToken(Vtl.IS, 0);
	}
	public END(): TerminalNode {
		return this.getToken(Vtl.END, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public parameterItem_list(): ParameterItemContext[] {
		return this.getTypedRuleContexts(ParameterItemContext) as ParameterItemContext[];
	}
	public parameterItem(i: number): ParameterItemContext {
		return this.getTypedRuleContext(ParameterItemContext, i) as ParameterItemContext;
	}
	public RETURNS(): TerminalNode {
		return this.getToken(Vtl.RETURNS, 0);
	}
	public outputParameterType(): OutputParameterTypeContext {
		return this.getTypedRuleContext(OutputParameterTypeContext, 0) as OutputParameterTypeContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDefOperator) {
			return visitor.visitDefOperator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DefHierarchicalContext extends DefOperatorsContext {
	constructor(parser: Vtl, ctx: DefOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DEFINE(): TerminalNode {
		return this.getToken(Vtl.DEFINE, 0);
	}
	public HIERARCHICAL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.HIERARCHICAL);
	}
	public HIERARCHICAL(i: number): TerminalNode {
		return this.getToken(Vtl.HIERARCHICAL, i);
	}
	public RULESET_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RULESET);
	}
	public RULESET(i: number): TerminalNode {
		return this.getToken(Vtl.RULESET, i);
	}
	public rulesetID(): RulesetIDContext {
		return this.getTypedRuleContext(RulesetIDContext, 0) as RulesetIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public hierRuleSignature(): HierRuleSignatureContext {
		return this.getTypedRuleContext(HierRuleSignatureContext, 0) as HierRuleSignatureContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public IS(): TerminalNode {
		return this.getToken(Vtl.IS, 0);
	}
	public ruleClauseHierarchical(): RuleClauseHierarchicalContext {
		return this.getTypedRuleContext(RuleClauseHierarchicalContext, 0) as RuleClauseHierarchicalContext;
	}
	public END(): TerminalNode {
		return this.getToken(Vtl.END, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDefHierarchical) {
			return visitor.visitDefHierarchical(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DefDatapointRulesetContext extends DefOperatorsContext {
	constructor(parser: Vtl, ctx: DefOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DEFINE(): TerminalNode {
		return this.getToken(Vtl.DEFINE, 0);
	}
	public DATAPOINT_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.DATAPOINT);
	}
	public DATAPOINT(i: number): TerminalNode {
		return this.getToken(Vtl.DATAPOINT, i);
	}
	public RULESET_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RULESET);
	}
	public RULESET(i: number): TerminalNode {
		return this.getToken(Vtl.RULESET, i);
	}
	public rulesetID(): RulesetIDContext {
		return this.getTypedRuleContext(RulesetIDContext, 0) as RulesetIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public rulesetSignature(): RulesetSignatureContext {
		return this.getTypedRuleContext(RulesetSignatureContext, 0) as RulesetSignatureContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public IS(): TerminalNode {
		return this.getToken(Vtl.IS, 0);
	}
	public ruleClauseDatapoint(): RuleClauseDatapointContext {
		return this.getTypedRuleContext(RuleClauseDatapointContext, 0) as RuleClauseDatapointContext;
	}
	public END(): TerminalNode {
		return this.getToken(Vtl.END, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDefDatapointRuleset) {
			return visitor.visitDefDatapointRuleset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GenericOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_genericOperators;
	}
	public copyFrom(ctx: GenericOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class EvalAtomContext extends GenericOperatorsContext {
	constructor(parser: Vtl, ctx: GenericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public EVAL(): TerminalNode {
		return this.getToken(Vtl.EVAL, 0);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public routineName(): RoutineNameContext {
		return this.getTypedRuleContext(RoutineNameContext, 0) as RoutineNameContext;
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public varID_list(): VarIDContext[] {
		return this.getTypedRuleContexts(VarIDContext) as VarIDContext[];
	}
	public varID(i: number): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, i) as VarIDContext;
	}
	public constant_list(): ConstantContext[] {
		return this.getTypedRuleContexts(ConstantContext) as ConstantContext[];
	}
	public constant(i: number): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, i) as ConstantContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public LANGUAGE(): TerminalNode {
		return this.getToken(Vtl.LANGUAGE, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.STRING_CONSTANT, 0);
	}
	public RETURNS(): TerminalNode {
		return this.getToken(Vtl.RETURNS, 0);
	}
	public datasetType(): DatasetTypeContext {
		return this.getTypedRuleContext(DatasetTypeContext, 0) as DatasetTypeContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitEvalAtom) {
			return visitor.visitEvalAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CastExprDatasetContext extends GenericOperatorsContext {
	constructor(parser: Vtl, ctx: GenericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CAST(): TerminalNode {
		return this.getToken(Vtl.CAST, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public valueDomainName(): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, 0) as ValueDomainNameContext;
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.STRING_CONSTANT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCastExprDataset) {
			return visitor.visitCastExprDataset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CallDatasetContext extends GenericOperatorsContext {
	constructor(parser: Vtl, ctx: GenericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public operatorID(): OperatorIDContext {
		return this.getTypedRuleContext(OperatorIDContext, 0) as OperatorIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public parameter_list(): ParameterContext[] {
		return this.getTypedRuleContexts(ParameterContext) as ParameterContext[];
	}
	public parameter(i: number): ParameterContext {
		return this.getTypedRuleContext(ParameterContext, i) as ParameterContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCallDataset) {
			return visitor.visitCallDataset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GenericOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_genericOperatorsComponent;
	}
	public copyFrom(ctx: GenericOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class EvalAtomComponentContext extends GenericOperatorsComponentContext {
	constructor(parser: Vtl, ctx: GenericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public EVAL(): TerminalNode {
		return this.getToken(Vtl.EVAL, 0);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public routineName(): RoutineNameContext {
		return this.getTypedRuleContext(RoutineNameContext, 0) as RoutineNameContext;
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public constant_list(): ConstantContext[] {
		return this.getTypedRuleContexts(ConstantContext) as ConstantContext[];
	}
	public constant(i: number): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, i) as ConstantContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public LANGUAGE(): TerminalNode {
		return this.getToken(Vtl.LANGUAGE, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.STRING_CONSTANT, 0);
	}
	public RETURNS(): TerminalNode {
		return this.getToken(Vtl.RETURNS, 0);
	}
	public outputParameterTypeComponent(): OutputParameterTypeComponentContext {
		return this.getTypedRuleContext(OutputParameterTypeComponentContext, 0) as OutputParameterTypeComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitEvalAtomComponent) {
			return visitor.visitEvalAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CastExprComponentContext extends GenericOperatorsComponentContext {
	constructor(parser: Vtl, ctx: GenericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CAST(): TerminalNode {
		return this.getToken(Vtl.CAST, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public valueDomainName(): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, 0) as ValueDomainNameContext;
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.STRING_CONSTANT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCastExprComponent) {
			return visitor.visitCastExprComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CallComponentContext extends GenericOperatorsComponentContext {
	constructor(parser: Vtl, ctx: GenericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public operatorID(): OperatorIDContext {
		return this.getTypedRuleContext(OperatorIDContext, 0) as OperatorIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public parameterComponent_list(): ParameterComponentContext[] {
		return this.getTypedRuleContexts(ParameterComponentContext) as ParameterComponentContext[];
	}
	public parameterComponent(i: number): ParameterComponentContext {
		return this.getTypedRuleContext(ParameterComponentContext, i) as ParameterComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCallComponent) {
			return visitor.visitCallComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParameterComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_parameterComponent;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitParameterComponent) {
			return visitor.visitParameterComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParameterContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_parameter;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitParameter) {
			return visitor.visitParameter(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StringOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_stringOperators;
	}
	public copyFrom(ctx: StringOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class InstrAtomContext extends StringOperatorsContext {
	public _pattern!: ExprContext;
	public _startParameter!: OptionalExprContext;
	public _occurrenceParameter!: OptionalExprContext;
	constructor(parser: Vtl, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public INSTR(): TerminalNode {
		return this.getToken(Vtl.INSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public optionalExpr_list(): OptionalExprContext[] {
		return this.getTypedRuleContexts(OptionalExprContext) as OptionalExprContext[];
	}
	public optionalExpr(i: number): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, i) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInstrAtom) {
			return visitor.visitInstrAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryStringFunctionContext extends StringOperatorsContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public TRIM(): TerminalNode {
		return this.getToken(Vtl.TRIM, 0);
	}
	public LTRIM(): TerminalNode {
		return this.getToken(Vtl.LTRIM, 0);
	}
	public RTRIM(): TerminalNode {
		return this.getToken(Vtl.RTRIM, 0);
	}
	public UCASE(): TerminalNode {
		return this.getToken(Vtl.UCASE, 0);
	}
	public LCASE(): TerminalNode {
		return this.getToken(Vtl.LCASE, 0);
	}
	public LEN(): TerminalNode {
		return this.getToken(Vtl.LEN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryStringFunction) {
			return visitor.visitUnaryStringFunction(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SubstrAtomContext extends StringOperatorsContext {
	public _startParameter!: OptionalExprContext;
	public _endParameter!: OptionalExprContext;
	constructor(parser: Vtl, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public SUBSTR(): TerminalNode {
		return this.getToken(Vtl.SUBSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public optionalExpr_list(): OptionalExprContext[] {
		return this.getTypedRuleContexts(OptionalExprContext) as OptionalExprContext[];
	}
	public optionalExpr(i: number): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, i) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSubstrAtom) {
			return visitor.visitSubstrAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ReplaceAtomContext extends StringOperatorsContext {
	public _param!: ExprContext;
	constructor(parser: Vtl, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public REPLACE(): TerminalNode {
		return this.getToken(Vtl.REPLACE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public optionalExpr(): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, 0) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitReplaceAtom) {
			return visitor.visitReplaceAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StringOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_stringOperatorsComponent;
	}
	public copyFrom(ctx: StringOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class ReplaceAtomComponentContext extends StringOperatorsComponentContext {
	public _param!: ExprComponentContext;
	constructor(parser: Vtl, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public REPLACE(): TerminalNode {
		return this.getToken(Vtl.REPLACE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public optionalExprComponent(): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, 0) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitReplaceAtomComponent) {
			return visitor.visitReplaceAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryStringFunctionComponentContext extends StringOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public TRIM(): TerminalNode {
		return this.getToken(Vtl.TRIM, 0);
	}
	public LTRIM(): TerminalNode {
		return this.getToken(Vtl.LTRIM, 0);
	}
	public RTRIM(): TerminalNode {
		return this.getToken(Vtl.RTRIM, 0);
	}
	public UCASE(): TerminalNode {
		return this.getToken(Vtl.UCASE, 0);
	}
	public LCASE(): TerminalNode {
		return this.getToken(Vtl.LCASE, 0);
	}
	public LEN(): TerminalNode {
		return this.getToken(Vtl.LEN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryStringFunctionComponent) {
			return visitor.visitUnaryStringFunctionComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SubstrAtomComponentContext extends StringOperatorsComponentContext {
	public _startParameter!: OptionalExprComponentContext;
	public _endParameter!: OptionalExprComponentContext;
	constructor(parser: Vtl, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public SUBSTR(): TerminalNode {
		return this.getToken(Vtl.SUBSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public optionalExprComponent_list(): OptionalExprComponentContext[] {
		return this.getTypedRuleContexts(OptionalExprComponentContext) as OptionalExprComponentContext[];
	}
	public optionalExprComponent(i: number): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, i) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSubstrAtomComponent) {
			return visitor.visitSubstrAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class InstrAtomComponentContext extends StringOperatorsComponentContext {
	public _pattern!: ExprComponentContext;
	public _startParameter!: OptionalExprComponentContext;
	public _occurrenceParameter!: OptionalExprComponentContext;
	constructor(parser: Vtl, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public INSTR(): TerminalNode {
		return this.getToken(Vtl.INSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public optionalExprComponent_list(): OptionalExprComponentContext[] {
		return this.getTypedRuleContexts(OptionalExprComponentContext) as OptionalExprComponentContext[];
	}
	public optionalExprComponent(i: number): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, i) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInstrAtomComponent) {
			return visitor.visitInstrAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class NumericOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_numericOperators;
	}
	public copyFrom(ctx: NumericOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class UnaryNumericContext extends NumericOperatorsContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: NumericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public CEIL(): TerminalNode {
		return this.getToken(Vtl.CEIL, 0);
	}
	public FLOOR(): TerminalNode {
		return this.getToken(Vtl.FLOOR, 0);
	}
	public ABS(): TerminalNode {
		return this.getToken(Vtl.ABS, 0);
	}
	public EXP(): TerminalNode {
		return this.getToken(Vtl.EXP, 0);
	}
	public LN(): TerminalNode {
		return this.getToken(Vtl.LN, 0);
	}
	public SQRT(): TerminalNode {
		return this.getToken(Vtl.SQRT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryNumeric) {
			return visitor.visitUnaryNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryWithOptionalNumericContext extends NumericOperatorsContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: NumericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public ROUND(): TerminalNode {
		return this.getToken(Vtl.ROUND, 0);
	}
	public TRUNC(): TerminalNode {
		return this.getToken(Vtl.TRUNC, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public optionalExpr(): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, 0) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryWithOptionalNumeric) {
			return visitor.visitUnaryWithOptionalNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BinaryNumericContext extends NumericOperatorsContext {
	public _op!: Token;
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: NumericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public MOD(): TerminalNode {
		return this.getToken(Vtl.MOD, 0);
	}
	public POWER(): TerminalNode {
		return this.getToken(Vtl.POWER, 0);
	}
	public LOG(): TerminalNode {
		return this.getToken(Vtl.LOG, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBinaryNumeric) {
			return visitor.visitBinaryNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class NumericOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_numericOperatorsComponent;
	}
	public copyFrom(ctx: NumericOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class UnaryNumericComponentContext extends NumericOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: NumericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public CEIL(): TerminalNode {
		return this.getToken(Vtl.CEIL, 0);
	}
	public FLOOR(): TerminalNode {
		return this.getToken(Vtl.FLOOR, 0);
	}
	public ABS(): TerminalNode {
		return this.getToken(Vtl.ABS, 0);
	}
	public EXP(): TerminalNode {
		return this.getToken(Vtl.EXP, 0);
	}
	public LN(): TerminalNode {
		return this.getToken(Vtl.LN, 0);
	}
	public SQRT(): TerminalNode {
		return this.getToken(Vtl.SQRT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryNumericComponent) {
			return visitor.visitUnaryNumericComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BinaryNumericComponentContext extends NumericOperatorsComponentContext {
	public _op!: Token;
	public _left!: ExprComponentContext;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: NumericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public MOD(): TerminalNode {
		return this.getToken(Vtl.MOD, 0);
	}
	public POWER(): TerminalNode {
		return this.getToken(Vtl.POWER, 0);
	}
	public LOG(): TerminalNode {
		return this.getToken(Vtl.LOG, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBinaryNumericComponent) {
			return visitor.visitBinaryNumericComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryWithOptionalNumericComponentContext extends NumericOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: NumericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public ROUND(): TerminalNode {
		return this.getToken(Vtl.ROUND, 0);
	}
	public TRUNC(): TerminalNode {
		return this.getToken(Vtl.TRUNC, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public optionalExprComponent(): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, 0) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnaryWithOptionalNumericComponent) {
			return visitor.visitUnaryWithOptionalNumericComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComparisonOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_comparisonOperators;
	}
	public copyFrom(ctx: ComparisonOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class BetweenAtomContext extends ComparisonOperatorsContext {
	public _op!: ExprContext;
	public _from_!: ExprContext;
	public _to_!: ExprContext;
	constructor(parser: Vtl, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public BETWEEN(): TerminalNode {
		return this.getToken(Vtl.BETWEEN, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBetweenAtom) {
			return visitor.visitBetweenAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CharsetMatchAtomContext extends ComparisonOperatorsContext {
	public _op!: ExprContext;
	public _pattern!: ExprContext;
	constructor(parser: Vtl, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHARSET_MATCH(): TerminalNode {
		return this.getToken(Vtl.CHARSET_MATCH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCharsetMatchAtom) {
			return visitor.visitCharsetMatchAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IsNullAtomContext extends ComparisonOperatorsContext {
	constructor(parser: Vtl, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public ISNULL(): TerminalNode {
		return this.getToken(Vtl.ISNULL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitIsNullAtom) {
			return visitor.visitIsNullAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ExistInAtomContext extends ComparisonOperatorsContext {
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public EXISTS_IN(): TerminalNode {
		return this.getToken(Vtl.EXISTS_IN, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public retainType(): RetainTypeContext {
		return this.getTypedRuleContext(RetainTypeContext, 0) as RetainTypeContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitExistInAtom) {
			return visitor.visitExistInAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComparisonOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_comparisonOperatorsComponent;
	}
	public copyFrom(ctx: ComparisonOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class IsNullAtomComponentContext extends ComparisonOperatorsComponentContext {
	constructor(parser: Vtl, ctx: ComparisonOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public ISNULL(): TerminalNode {
		return this.getToken(Vtl.ISNULL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitIsNullAtomComponent) {
			return visitor.visitIsNullAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CharsetMatchAtomComponentContext extends ComparisonOperatorsComponentContext {
	public _op!: ExprComponentContext;
	public _pattern!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ComparisonOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHARSET_MATCH(): TerminalNode {
		return this.getToken(Vtl.CHARSET_MATCH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCharsetMatchAtomComponent) {
			return visitor.visitCharsetMatchAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BetweenAtomComponentContext extends ComparisonOperatorsComponentContext {
	public _op!: ExprComponentContext;
	public _from_!: ExprComponentContext;
	public _to_!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ComparisonOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public BETWEEN(): TerminalNode {
		return this.getToken(Vtl.BETWEEN, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBetweenAtomComponent) {
			return visitor.visitBetweenAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_timeOperators;
	}
	public copyFrom(ctx: TimeOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class FlowAtomContext extends TimeOperatorsContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public FLOW_TO_STOCK(): TerminalNode {
		return this.getToken(Vtl.FLOW_TO_STOCK, 0);
	}
	public STOCK_TO_FLOW(): TerminalNode {
		return this.getToken(Vtl.STOCK_TO_FLOW, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFlowAtom) {
			return visitor.visitFlowAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeShiftAtomContext extends TimeOperatorsContext {
	constructor(parser: Vtl, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIMESHIFT(): TerminalNode {
		return this.getToken(Vtl.TIMESHIFT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTimeShiftAtom) {
			return visitor.visitTimeShiftAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeAggAtomContext extends TimeOperatorsContext {
	public _periodIndTo!: Token;
	public _periodIndFrom!: Token;
	public _op!: OptionalExprContext;
	public _delim!: Token;
	constructor(parser: Vtl, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(Vtl.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public TIME_UNIT_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.TIME_UNIT);
	}
	public TIME_UNIT(i: number): TerminalNode {
		return this.getToken(Vtl.TIME_UNIT, i);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public optionalExpr(): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, 0) as OptionalExprContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
	public FIRST(): TerminalNode {
		return this.getToken(Vtl.FIRST, 0);
	}
	public LAST(): TerminalNode {
		return this.getToken(Vtl.LAST, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTimeAggAtom) {
			return visitor.visitTimeAggAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CurrentDateAtomContext extends TimeOperatorsContext {
	constructor(parser: Vtl, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CURRENT_DATE(): TerminalNode {
		return this.getToken(Vtl.CURRENT_DATE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCurrentDateAtom) {
			return visitor.visitCurrentDateAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class PeriodAtomContext extends TimeOperatorsContext {
	constructor(parser: Vtl, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public PERIOD_INDICATOR(): TerminalNode {
		return this.getToken(Vtl.PERIOD_INDICATOR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitPeriodAtom) {
			return visitor.visitPeriodAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FillTimeAtomContext extends TimeOperatorsContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public FILL_TIME_SERIES(): TerminalNode {
		return this.getToken(Vtl.FILL_TIME_SERIES, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public SINGLE(): TerminalNode {
		return this.getToken(Vtl.SINGLE, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFillTimeAtom) {
			return visitor.visitFillTimeAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_timeOperatorsComponent;
	}
	public copyFrom(ctx: TimeOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class PeriodAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: Vtl, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public PERIOD_INDICATOR(): TerminalNode {
		return this.getToken(Vtl.PERIOD_INDICATOR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitPeriodAtomComponent) {
			return visitor.visitPeriodAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeShiftAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: Vtl, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIMESHIFT(): TerminalNode {
		return this.getToken(Vtl.TIMESHIFT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTimeShiftAtomComponent) {
			return visitor.visitTimeShiftAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeAggAtomComponentContext extends TimeOperatorsComponentContext {
	public _periodIndTo!: Token;
	public _periodIndFrom!: Token;
	public _op!: OptionalExprComponentContext;
	public _delim!: Token;
	constructor(parser: Vtl, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(Vtl.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public TIME_UNIT_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.TIME_UNIT);
	}
	public TIME_UNIT(i: number): TerminalNode {
		return this.getToken(Vtl.TIME_UNIT, i);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public optionalExprComponent(): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, 0) as OptionalExprComponentContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
	public FIRST(): TerminalNode {
		return this.getToken(Vtl.FIRST, 0);
	}
	public LAST(): TerminalNode {
		return this.getToken(Vtl.LAST, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitTimeAggAtomComponent) {
			return visitor.visitTimeAggAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CurrentDateAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: Vtl, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CURRENT_DATE(): TerminalNode {
		return this.getToken(Vtl.CURRENT_DATE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCurrentDateAtomComponent) {
			return visitor.visitCurrentDateAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FlowAtomComponentContext extends TimeOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public FLOW_TO_STOCK(): TerminalNode {
		return this.getToken(Vtl.FLOW_TO_STOCK, 0);
	}
	public STOCK_TO_FLOW(): TerminalNode {
		return this.getToken(Vtl.STOCK_TO_FLOW, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFlowAtomComponent) {
			return visitor.visitFlowAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FillTimeAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: Vtl, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public FILL_TIME_SERIES(): TerminalNode {
		return this.getToken(Vtl.FILL_TIME_SERIES, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public SINGLE(): TerminalNode {
		return this.getToken(Vtl.SINGLE, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitFillTimeAtomComponent) {
			return visitor.visitFillTimeAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SetOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_setOperators;
	}
	public copyFrom(ctx: SetOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class SetOrSYmDiffAtomContext extends SetOperatorsContext {
	public _op!: Token;
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: SetOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public SETDIFF(): TerminalNode {
		return this.getToken(Vtl.SETDIFF, 0);
	}
	public SYMDIFF(): TerminalNode {
		return this.getToken(Vtl.SYMDIFF, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSetOrSYmDiffAtom) {
			return visitor.visitSetOrSYmDiffAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IntersectAtomContext extends SetOperatorsContext {
	public _left!: ExprContext;
	constructor(parser: Vtl, ctx: SetOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public INTERSECT(): TerminalNode {
		return this.getToken(Vtl.INTERSECT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitIntersectAtom) {
			return visitor.visitIntersectAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnionAtomContext extends SetOperatorsContext {
	public _left!: ExprContext;
	constructor(parser: Vtl, ctx: SetOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public UNION(): TerminalNode {
		return this.getToken(Vtl.UNION, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitUnionAtom) {
			return visitor.visitUnionAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HierarchyOperatorsContext extends ParserRuleContext {
	public _op!: ExprContext;
	public _hrName!: Token;
	public _ruleComponent!: ComponentIDContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public HIERARCHY(): TerminalNode {
		return this.getToken(Vtl.HIERARCHY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
	public conditionClause(): ConditionClauseContext {
		return this.getTypedRuleContext(ConditionClauseContext, 0) as ConditionClauseContext;
	}
	public RULE(): TerminalNode {
		return this.getToken(Vtl.RULE, 0);
	}
	public validationMode(): ValidationModeContext {
		return this.getTypedRuleContext(ValidationModeContext, 0) as ValidationModeContext;
	}
	public inputModeHierarchy(): InputModeHierarchyContext {
		return this.getTypedRuleContext(InputModeHierarchyContext, 0) as InputModeHierarchyContext;
	}
	public outputModeHierarchy(): OutputModeHierarchyContext {
		return this.getTypedRuleContext(OutputModeHierarchyContext, 0) as OutputModeHierarchyContext;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_hierarchyOperators;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHierarchyOperators) {
			return visitor.visitHierarchyOperators(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValidationOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_validationOperators;
	}
	public copyFrom(ctx: ValidationOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class ValidateHRrulesetContext extends ValidationOperatorsContext {
	public _op!: ExprContext;
	public _hrName!: Token;
	constructor(parser: Vtl, ctx: ValidationOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHECK_HIERARCHY(): TerminalNode {
		return this.getToken(Vtl.CHECK_HIERARCHY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
	public conditionClause(): ConditionClauseContext {
		return this.getTypedRuleContext(ConditionClauseContext, 0) as ConditionClauseContext;
	}
	public RULE(): TerminalNode {
		return this.getToken(Vtl.RULE, 0);
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public validationMode(): ValidationModeContext {
		return this.getTypedRuleContext(ValidationModeContext, 0) as ValidationModeContext;
	}
	public inputMode(): InputModeContext {
		return this.getTypedRuleContext(InputModeContext, 0) as InputModeContext;
	}
	public validationOutput(): ValidationOutputContext {
		return this.getTypedRuleContext(ValidationOutputContext, 0) as ValidationOutputContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValidateHRruleset) {
			return visitor.visitValidateHRruleset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValidateDPrulesetContext extends ValidationOperatorsContext {
	public _op!: ExprContext;
	public _dpName!: Token;
	constructor(parser: Vtl, ctx: ValidationOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHECK_DATAPOINT(): TerminalNode {
		return this.getToken(Vtl.CHECK_DATAPOINT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
	public COMPONENTS(): TerminalNode {
		return this.getToken(Vtl.COMPONENTS, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public validationOutput(): ValidationOutputContext {
		return this.getTypedRuleContext(ValidationOutputContext, 0) as ValidationOutputContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValidateDPruleset) {
			return visitor.visitValidateDPruleset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValidationSimpleContext extends ValidationOperatorsContext {
	public _op!: ExprContext;
	public _codeErr!: ErCodeContext;
	public _levelCode!: ErLevelContext;
	public _output!: Token;
	constructor(parser: Vtl, ctx: ValidationOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHECK(): TerminalNode {
		return this.getToken(Vtl.CHECK, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public imbalanceExpr(): ImbalanceExprContext {
		return this.getTypedRuleContext(ImbalanceExprContext, 0) as ImbalanceExprContext;
	}
	public erCode(): ErCodeContext {
		return this.getTypedRuleContext(ErCodeContext, 0) as ErCodeContext;
	}
	public erLevel(): ErLevelContext {
		return this.getTypedRuleContext(ErLevelContext, 0) as ErLevelContext;
	}
	public INVALID(): TerminalNode {
		return this.getToken(Vtl.INVALID, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValidationSimple) {
			return visitor.visitValidationSimple(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConditionalOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_conditionalOperators;
	}
	public copyFrom(ctx: ConditionalOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class NvlAtomContext extends ConditionalOperatorsContext {
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: Vtl, ctx: ConditionalOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public NVL(): TerminalNode {
		return this.getToken(Vtl.NVL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitNvlAtom) {
			return visitor.visitNvlAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConditionalOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_conditionalOperatorsComponent;
	}
	public copyFrom(ctx: ConditionalOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class NvlAtomComponentContext extends ConditionalOperatorsComponentContext {
	public _left!: ExprComponentContext;
	public _right!: ExprComponentContext;
	constructor(parser: Vtl, ctx: ConditionalOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public NVL(): TerminalNode {
		return this.getToken(Vtl.NVL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitNvlAtomComponent) {
			return visitor.visitNvlAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrOperatorsContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_aggrOperators;
	}
	public copyFrom(ctx: AggrOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class AggrCompContext extends AggrOperatorsContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: AggrOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public SUM(): TerminalNode {
		return this.getToken(Vtl.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(Vtl.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(Vtl.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(Vtl.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(Vtl.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(Vtl.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(Vtl.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(Vtl.VAR_SAMP, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggrComp) {
			return visitor.visitAggrComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CountAggrCompContext extends AggrOperatorsContext {
	constructor(parser: Vtl, ctx: AggrOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public COUNT(): TerminalNode {
		return this.getToken(Vtl.COUNT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCountAggrComp) {
			return visitor.visitCountAggrComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrOperatorsGroupingContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_aggrOperatorsGrouping;
	}
	public copyFrom(ctx: AggrOperatorsGroupingContext): void {
		super.copyFrom(ctx);
	}
}
export class AggrDatasetContext extends AggrOperatorsGroupingContext {
	public _op!: Token;
	constructor(parser: Vtl, ctx: AggrOperatorsGroupingContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public SUM(): TerminalNode {
		return this.getToken(Vtl.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(Vtl.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(Vtl.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(Vtl.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(Vtl.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(Vtl.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(Vtl.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(Vtl.VAR_SAMP, 0);
	}
	public groupingClause(): GroupingClauseContext {
		return this.getTypedRuleContext(GroupingClauseContext, 0) as GroupingClauseContext;
	}
	public havingClause(): HavingClauseContext {
		return this.getTypedRuleContext(HavingClauseContext, 0) as HavingClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggrDataset) {
			return visitor.visitAggrDataset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AnFunctionContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_anFunction;
	}
	public copyFrom(ctx: AnFunctionContext): void {
		super.copyFrom(ctx);
	}
}
export class LagOrLeadAnContext extends AnFunctionContext {
	public _op!: Token;
	public _offet!: SignedIntegerContext;
	public _defaultValue!: ConstantContext;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public LAG(): TerminalNode {
		return this.getToken(Vtl.LAG, 0);
	}
	public LEAD(): TerminalNode {
		return this.getToken(Vtl.LEAD, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitLagOrLeadAn) {
			return visitor.visitLagOrLeadAn(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class RatioToReportAnContext extends AnFunctionContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public RATIO_TO_REPORT(): TerminalNode {
		return this.getToken(Vtl.RATIO_TO_REPORT, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRatioToReportAn) {
			return visitor.visitRatioToReportAn(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AnSimpleFunctionContext extends AnFunctionContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	public _windowing!: WindowingClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public SUM(): TerminalNode {
		return this.getToken(Vtl.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(Vtl.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(Vtl.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(Vtl.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(Vtl.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(Vtl.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(Vtl.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(Vtl.VAR_SAMP, 0);
	}
	public FIRST_VALUE(): TerminalNode {
		return this.getToken(Vtl.FIRST_VALUE, 0);
	}
	public LAST_VALUE(): TerminalNode {
		return this.getToken(Vtl.LAST_VALUE, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public windowingClause(): WindowingClauseContext {
		return this.getTypedRuleContext(WindowingClauseContext, 0) as WindowingClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAnSimpleFunction) {
			return visitor.visitAnSimpleFunction(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AnFunctionComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_anFunctionComponent;
	}
	public copyFrom(ctx: AnFunctionComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class AnSimpleFunctionComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	public _windowing!: WindowingClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public SUM(): TerminalNode {
		return this.getToken(Vtl.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(Vtl.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(Vtl.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(Vtl.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(Vtl.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(Vtl.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(Vtl.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(Vtl.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(Vtl.VAR_SAMP, 0);
	}
	public FIRST_VALUE(): TerminalNode {
		return this.getToken(Vtl.FIRST_VALUE, 0);
	}
	public LAST_VALUE(): TerminalNode {
		return this.getToken(Vtl.LAST_VALUE, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public windowingClause(): WindowingClauseContext {
		return this.getTypedRuleContext(WindowingClauseContext, 0) as WindowingClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAnSimpleFunctionComponent) {
			return visitor.visitAnSimpleFunctionComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class LagOrLeadAnComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _offet!: SignedIntegerContext;
	public _defaultValue!: ConstantContext;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public LAG(): TerminalNode {
		return this.getToken(Vtl.LAG, 0);
	}
	public LEAD(): TerminalNode {
		return this.getToken(Vtl.LEAD, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(Vtl.COMMA, 0);
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitLagOrLeadAnComponent) {
			return visitor.visitLagOrLeadAnComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class RankAnComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public RANK(): TerminalNode {
		return this.getToken(Vtl.RANK, 0);
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRankAnComponent) {
			return visitor.visitRankAnComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class RatioToReportAnComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	constructor(parser: Vtl, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.LPAREN, i);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(Vtl.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(Vtl.RPAREN, i);
	}
	public RATIO_TO_REPORT(): TerminalNode {
		return this.getToken(Vtl.RATIO_TO_REPORT, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRatioToReportAnComponent) {
			return visitor.visitRatioToReportAnComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RenameClauseItemContext extends ParserRuleContext {
	public _fromName!: ComponentIDContext;
	public _toName!: ComponentIDContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public TO(): TerminalNode {
		return this.getToken(Vtl.TO, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_renameClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRenameClauseItem) {
			return visitor.visitRenameClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggregateClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public aggrFunctionClause_list(): AggrFunctionClauseContext[] {
		return this.getTypedRuleContexts(AggrFunctionClauseContext) as AggrFunctionClauseContext[];
	}
	public aggrFunctionClause(i: number): AggrFunctionClauseContext {
		return this.getTypedRuleContext(AggrFunctionClauseContext, i) as AggrFunctionClauseContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_aggregateClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggregateClause) {
			return visitor.visitAggregateClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrFunctionClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public ASSIGN(): TerminalNode {
		return this.getToken(Vtl.ASSIGN, 0);
	}
	public aggrOperators(): AggrOperatorsContext {
		return this.getTypedRuleContext(AggrOperatorsContext, 0) as AggrOperatorsContext;
	}
	public componentRole(): ComponentRoleContext {
		return this.getTypedRuleContext(ComponentRoleContext, 0) as ComponentRoleContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_aggrFunctionClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAggrFunctionClause) {
			return visitor.visitAggrFunctionClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CalcClauseItemContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public ASSIGN(): TerminalNode {
		return this.getToken(Vtl.ASSIGN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public componentRole(): ComponentRoleContext {
		return this.getTypedRuleContext(ComponentRoleContext, 0) as ComponentRoleContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_calcClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCalcClauseItem) {
			return visitor.visitCalcClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SubspaceClauseItemContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public EQ(): TerminalNode {
		return this.getToken(Vtl.EQ, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_subspaceClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSubspaceClauseItem) {
			return visitor.visitSubspaceClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinClauseWithoutUsingContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public joinClauseItem_list(): JoinClauseItemContext[] {
		return this.getTypedRuleContexts(JoinClauseItemContext) as JoinClauseItemContext[];
	}
	public joinClauseItem(i: number): JoinClauseItemContext {
		return this.getTypedRuleContext(JoinClauseItemContext, i) as JoinClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_joinClauseWithoutUsing;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinClauseWithoutUsing) {
			return visitor.visitJoinClauseWithoutUsing(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public joinClauseItem_list(): JoinClauseItemContext[] {
		return this.getTypedRuleContexts(JoinClauseItemContext) as JoinClauseItemContext[];
	}
	public joinClauseItem(i: number): JoinClauseItemContext {
		return this.getTypedRuleContext(JoinClauseItemContext, i) as JoinClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public USING(): TerminalNode {
		return this.getToken(Vtl.USING, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_joinClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinClause) {
			return visitor.visitJoinClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinClauseItemContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public AS(): TerminalNode {
		return this.getToken(Vtl.AS, 0);
	}
	public alias(): AliasContext {
		return this.getTypedRuleContext(AliasContext, 0) as AliasContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_joinClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinClauseItem) {
			return visitor.visitJoinClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinBodyContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public filterClause(): FilterClauseContext {
		return this.getTypedRuleContext(FilterClauseContext, 0) as FilterClauseContext;
	}
	public calcClause(): CalcClauseContext {
		return this.getTypedRuleContext(CalcClauseContext, 0) as CalcClauseContext;
	}
	public joinApplyClause(): JoinApplyClauseContext {
		return this.getTypedRuleContext(JoinApplyClauseContext, 0) as JoinApplyClauseContext;
	}
	public aggrClause(): AggrClauseContext {
		return this.getTypedRuleContext(AggrClauseContext, 0) as AggrClauseContext;
	}
	public keepOrDropClause(): KeepOrDropClauseContext {
		return this.getTypedRuleContext(KeepOrDropClauseContext, 0) as KeepOrDropClauseContext;
	}
	public renameClause(): RenameClauseContext {
		return this.getTypedRuleContext(RenameClauseContext, 0) as RenameClauseContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_joinBody;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinBody) {
			return visitor.visitJoinBody(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinApplyClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public APPLY(): TerminalNode {
		return this.getToken(Vtl.APPLY, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_joinApplyClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitJoinApplyClause) {
			return visitor.visitJoinApplyClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class PartitionByClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public PARTITION(): TerminalNode {
		return this.getToken(Vtl.PARTITION, 0);
	}
	public BY(): TerminalNode {
		return this.getToken(Vtl.BY, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_partitionByClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitPartitionByClause) {
			return visitor.visitPartitionByClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OrderByClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ORDER(): TerminalNode {
		return this.getToken(Vtl.ORDER, 0);
	}
	public BY(): TerminalNode {
		return this.getToken(Vtl.BY, 0);
	}
	public orderByItem_list(): OrderByItemContext[] {
		return this.getTypedRuleContexts(OrderByItemContext) as OrderByItemContext[];
	}
	public orderByItem(i: number): OrderByItemContext {
		return this.getTypedRuleContext(OrderByItemContext, i) as OrderByItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_orderByClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOrderByClause) {
			return visitor.visitOrderByClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OrderByItemContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public ASC(): TerminalNode {
		return this.getToken(Vtl.ASC, 0);
	}
	public DESC(): TerminalNode {
		return this.getToken(Vtl.DESC, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_orderByItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOrderByItem) {
			return visitor.visitOrderByItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class WindowingClauseContext extends ParserRuleContext {
	public _from_!: LimitClauseItemContext;
	public _to_!: LimitClauseItemContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public BETWEEN(): TerminalNode {
		return this.getToken(Vtl.BETWEEN, 0);
	}
	public AND(): TerminalNode {
		return this.getToken(Vtl.AND, 0);
	}
	public limitClauseItem_list(): LimitClauseItemContext[] {
		return this.getTypedRuleContexts(LimitClauseItemContext) as LimitClauseItemContext[];
	}
	public limitClauseItem(i: number): LimitClauseItemContext {
		return this.getTypedRuleContext(LimitClauseItemContext, i) as LimitClauseItemContext;
	}
	public RANGE(): TerminalNode {
		return this.getToken(Vtl.RANGE, 0);
	}
	public DATA(): TerminalNode {
		return this.getToken(Vtl.DATA, 0);
	}
	public POINTS(): TerminalNode {
		return this.getToken(Vtl.POINTS, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_windowingClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitWindowingClause) {
			return visitor.visitWindowingClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SignedIntegerContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public INTEGER_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.INTEGER_CONSTANT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_signedInteger;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSignedInteger) {
			return visitor.visitSignedInteger(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class LimitClauseItemContext extends ParserRuleContext {
	public _dir!: Token;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public INTEGER_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.INTEGER_CONSTANT, 0);
	}
	public PRECEDING(): TerminalNode {
		return this.getToken(Vtl.PRECEDING, 0);
	}
	public FOLLOWING(): TerminalNode {
		return this.getToken(Vtl.FOLLOWING, 0);
	}
	public CURRENT(): TerminalNode {
		return this.getToken(Vtl.CURRENT, 0);
	}
	public DATA(): TerminalNode {
		return this.getToken(Vtl.DATA, 0);
	}
	public POINT(): TerminalNode {
		return this.getToken(Vtl.POINT, 0);
	}
	public UNBOUNDED(): TerminalNode {
		return this.getToken(Vtl.UNBOUNDED, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_limitClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitLimitClauseItem) {
			return visitor.visitLimitClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GroupingClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_groupingClause;
	}
	public copyFrom(ctx: GroupingClauseContext): void {
		super.copyFrom(ctx);
	}
}
export class GroupAllContext extends GroupingClauseContext {
	constructor(parser: Vtl, ctx: GroupingClauseContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GROUP(): TerminalNode {
		return this.getToken(Vtl.GROUP, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(Vtl.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public TIME_UNIT(): TerminalNode {
		return this.getToken(Vtl.TIME_UNIT, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitGroupAll) {
			return visitor.visitGroupAll(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class GroupByOrExceptContext extends GroupingClauseContext {
	public _op!: Token;
	public _delim!: Token;
	constructor(parser: Vtl, ctx: GroupingClauseContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GROUP(): TerminalNode {
		return this.getToken(Vtl.GROUP, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public BY(): TerminalNode {
		return this.getToken(Vtl.BY, 0);
	}
	public EXCEPT(): TerminalNode {
		return this.getToken(Vtl.EXCEPT, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(Vtl.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public TIME_UNIT(): TerminalNode {
		return this.getToken(Vtl.TIME_UNIT, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public FIRST(): TerminalNode {
		return this.getToken(Vtl.FIRST, 0);
	}
	public LAST(): TerminalNode {
		return this.getToken(Vtl.LAST, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitGroupByOrExcept) {
			return visitor.visitGroupByOrExcept(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HavingClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public HAVING(): TerminalNode {
		return this.getToken(Vtl.HAVING, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_havingClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHavingClause) {
			return visitor.visitHavingClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParameterItemContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public inputParameterType(): InputParameterTypeContext {
		return this.getTypedRuleContext(InputParameterTypeContext, 0) as InputParameterTypeContext;
	}
	public DEFAULT(): TerminalNode {
		return this.getToken(Vtl.DEFAULT, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_parameterItem;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitParameterItem) {
			return visitor.visitParameterItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OutputParameterTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public datasetType(): DatasetTypeContext {
		return this.getTypedRuleContext(DatasetTypeContext, 0) as DatasetTypeContext;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_outputParameterType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOutputParameterType) {
			return visitor.visitOutputParameterType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OutputParameterTypeComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_outputParameterTypeComponent;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOutputParameterTypeComponent) {
			return visitor.visitOutputParameterTypeComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InputParameterTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public datasetType(): DatasetTypeContext {
		return this.getTypedRuleContext(DatasetTypeContext, 0) as DatasetTypeContext;
	}
	public scalarSetType(): ScalarSetTypeContext {
		return this.getTypedRuleContext(ScalarSetTypeContext, 0) as ScalarSetTypeContext;
	}
	public rulesetType(): RulesetTypeContext {
		return this.getTypedRuleContext(RulesetTypeContext, 0) as RulesetTypeContext;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_inputParameterType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInputParameterType) {
			return visitor.visitInputParameterType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RulesetTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RULESET(): TerminalNode {
		return this.getToken(Vtl.RULESET, 0);
	}
	public dpRuleset(): DpRulesetContext {
		return this.getTypedRuleContext(DpRulesetContext, 0) as DpRulesetContext;
	}
	public hrRuleset(): HrRulesetContext {
		return this.getTypedRuleContext(HrRulesetContext, 0) as HrRulesetContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_rulesetType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRulesetType) {
			return visitor.visitRulesetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public valueDomainName(): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, 0) as ValueDomainNameContext;
	}
	public scalarTypeConstraint(): ScalarTypeConstraintContext {
		return this.getTypedRuleContext(ScalarTypeConstraintContext, 0) as ScalarTypeConstraintContext;
	}
	public NULL_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.NULL_CONSTANT, 0);
	}
	public NOT(): TerminalNode {
		return this.getToken(Vtl.NOT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_scalarType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitScalarType) {
			return visitor.visitScalarType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComponentTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentRole(): ComponentRoleContext {
		return this.getTypedRuleContext(ComponentRoleContext, 0) as ComponentRoleContext;
	}
	public LT(): TerminalNode {
		return this.getToken(Vtl.LT, 0);
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public MT(): TerminalNode {
		return this.getToken(Vtl.MT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_componentType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComponentType) {
			return visitor.visitComponentType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DatasetTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public DATASET(): TerminalNode {
		return this.getToken(Vtl.DATASET, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public compConstraint_list(): CompConstraintContext[] {
		return this.getTypedRuleContexts(CompConstraintContext) as CompConstraintContext[];
	}
	public compConstraint(i: number): CompConstraintContext {
		return this.getTypedRuleContext(CompConstraintContext, i) as CompConstraintContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_datasetType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDatasetType) {
			return visitor.visitDatasetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarSetTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public SET(): TerminalNode {
		return this.getToken(Vtl.SET, 0);
	}
	public LT(): TerminalNode {
		return this.getToken(Vtl.LT, 0);
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public MT(): TerminalNode {
		return this.getToken(Vtl.MT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_scalarSetType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitScalarSetType) {
			return visitor.visitScalarSetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DpRulesetContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_dpRuleset;
	}
	public copyFrom(ctx: DpRulesetContext): void {
		super.copyFrom(ctx);
	}
}
export class DataPointVdContext extends DpRulesetContext {
	constructor(parser: Vtl, ctx: DpRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATAPOINT_ON_VD(): TerminalNode {
		return this.getToken(Vtl.DATAPOINT_ON_VD, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public valueDomainName_list(): ValueDomainNameContext[] {
		return this.getTypedRuleContexts(ValueDomainNameContext) as ValueDomainNameContext[];
	}
	public valueDomainName(i: number): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, i) as ValueDomainNameContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(Vtl.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDataPointVd) {
			return visitor.visitDataPointVd(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DataPointVarContext extends DpRulesetContext {
	constructor(parser: Vtl, ctx: DpRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATAPOINT_ON_VAR(): TerminalNode {
		return this.getToken(Vtl.DATAPOINT_ON_VAR, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public varID_list(): VarIDContext[] {
		return this.getTypedRuleContexts(VarIDContext) as VarIDContext[];
	}
	public varID(i: number): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, i) as VarIDContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(Vtl.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDataPointVar) {
			return visitor.visitDataPointVar(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DataPointContext extends DpRulesetContext {
	constructor(parser: Vtl, ctx: DpRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATAPOINT(): TerminalNode {
		return this.getToken(Vtl.DATAPOINT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitDataPoint) {
			return visitor.visitDataPoint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HrRulesetContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_hrRuleset;
	}
	public copyFrom(ctx: HrRulesetContext): void {
		super.copyFrom(ctx);
	}
}
export class HrRulesetVdTypeContext extends HrRulesetContext {
	public _vdName!: Token;
	constructor(parser: Vtl, ctx: HrRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public HIERARCHICAL_ON_VD(): TerminalNode {
		return this.getToken(Vtl.HIERARCHICAL_ON_VD, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public valueDomainName_list(): ValueDomainNameContext[] {
		return this.getTypedRuleContexts(ValueDomainNameContext) as ValueDomainNameContext[];
	}
	public valueDomainName(i: number): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, i) as ValueDomainNameContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(Vtl.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHrRulesetVdType) {
			return visitor.visitHrRulesetVdType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class HrRulesetVarTypeContext extends HrRulesetContext {
	public _varName!: VarIDContext;
	constructor(parser: Vtl, ctx: HrRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public HIERARCHICAL_ON_VAR(): TerminalNode {
		return this.getToken(Vtl.HIERARCHICAL_ON_VAR, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public varID_list(): VarIDContext[] {
		return this.getTypedRuleContexts(VarIDContext) as VarIDContext[];
	}
	public varID(i: number): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, i) as VarIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(Vtl.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(Vtl.RPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(Vtl.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHrRulesetVarType) {
			return visitor.visitHrRulesetVarType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class HrRulesetTypeContext extends HrRulesetContext {
	constructor(parser: Vtl, ctx: HrRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public HIERARCHICAL(): TerminalNode {
		return this.getToken(Vtl.HIERARCHICAL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHrRulesetType) {
			return visitor.visitHrRulesetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainNameContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_valueDomainName;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValueDomainName) {
			return visitor.visitValueDomainName(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RulesetIDContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_rulesetID;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRulesetID) {
			return visitor.visitRulesetID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RulesetSignatureContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public signature_list(): SignatureContext[] {
		return this.getTypedRuleContexts(SignatureContext) as SignatureContext[];
	}
	public signature(i: number): SignatureContext {
		return this.getTypedRuleContext(SignatureContext, i) as SignatureContext;
	}
	public VALUE_DOMAIN(): TerminalNode {
		return this.getToken(Vtl.VALUE_DOMAIN, 0);
	}
	public VARIABLE(): TerminalNode {
		return this.getToken(Vtl.VARIABLE, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_rulesetSignature;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRulesetSignature) {
			return visitor.visitRulesetSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SignatureContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public AS(): TerminalNode {
		return this.getToken(Vtl.AS, 0);
	}
	public alias(): AliasContext {
		return this.getTypedRuleContext(AliasContext, 0) as AliasContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_signature;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSignature) {
			return visitor.visitSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleClauseDatapointContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ruleItemDatapoint_list(): RuleItemDatapointContext[] {
		return this.getTypedRuleContexts(RuleItemDatapointContext) as RuleItemDatapointContext[];
	}
	public ruleItemDatapoint(i: number): RuleItemDatapointContext {
		return this.getTypedRuleContext(RuleItemDatapointContext, i) as RuleItemDatapointContext;
	}
	public EOL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.EOL);
	}
	public EOL(i: number): TerminalNode {
		return this.getToken(Vtl.EOL, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_ruleClauseDatapoint;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRuleClauseDatapoint) {
			return visitor.visitRuleClauseDatapoint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleItemDatapointContext extends ParserRuleContext {
	public _ruleName!: Token;
	public _antecedentContiditon!: ExprComponentContext;
	public _consequentCondition!: ExprComponentContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public COLON(): TerminalNode {
		return this.getToken(Vtl.COLON, 0);
	}
	public WHEN(): TerminalNode {
		return this.getToken(Vtl.WHEN, 0);
	}
	public THEN(): TerminalNode {
		return this.getToken(Vtl.THEN, 0);
	}
	public erCode(): ErCodeContext {
		return this.getTypedRuleContext(ErCodeContext, 0) as ErCodeContext;
	}
	public erLevel(): ErLevelContext {
		return this.getTypedRuleContext(ErLevelContext, 0) as ErLevelContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_ruleItemDatapoint;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRuleItemDatapoint) {
			return visitor.visitRuleItemDatapoint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleClauseHierarchicalContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ruleItemHierarchical_list(): RuleItemHierarchicalContext[] {
		return this.getTypedRuleContexts(RuleItemHierarchicalContext) as RuleItemHierarchicalContext[];
	}
	public ruleItemHierarchical(i: number): RuleItemHierarchicalContext {
		return this.getTypedRuleContext(RuleItemHierarchicalContext, i) as RuleItemHierarchicalContext;
	}
	public EOL_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.EOL);
	}
	public EOL(i: number): TerminalNode {
		return this.getToken(Vtl.EOL, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_ruleClauseHierarchical;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRuleClauseHierarchical) {
			return visitor.visitRuleClauseHierarchical(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleItemHierarchicalContext extends ParserRuleContext {
	public _ruleName!: Token;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public codeItemRelation(): CodeItemRelationContext {
		return this.getTypedRuleContext(CodeItemRelationContext, 0) as CodeItemRelationContext;
	}
	public COLON(): TerminalNode {
		return this.getToken(Vtl.COLON, 0);
	}
	public erCode(): ErCodeContext {
		return this.getTypedRuleContext(ErCodeContext, 0) as ErCodeContext;
	}
	public erLevel(): ErLevelContext {
		return this.getTypedRuleContext(ErLevelContext, 0) as ErLevelContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_ruleItemHierarchical;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRuleItemHierarchical) {
			return visitor.visitRuleItemHierarchical(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HierRuleSignatureContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RULE(): TerminalNode {
		return this.getToken(Vtl.RULE, 0);
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
	public VALUE_DOMAIN(): TerminalNode {
		return this.getToken(Vtl.VALUE_DOMAIN, 0);
	}
	public VARIABLE(): TerminalNode {
		return this.getToken(Vtl.VARIABLE, 0);
	}
	public CONDITION(): TerminalNode {
		return this.getToken(Vtl.CONDITION, 0);
	}
	public valueDomainSignature(): ValueDomainSignatureContext {
		return this.getTypedRuleContext(ValueDomainSignatureContext, 0) as ValueDomainSignatureContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_hierRuleSignature;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitHierRuleSignature) {
			return visitor.visitHierRuleSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainSignatureContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public signature_list(): SignatureContext[] {
		return this.getTypedRuleContexts(SignatureContext) as SignatureContext[];
	}
	public signature(i: number): SignatureContext {
		return this.getTypedRuleContext(SignatureContext, i) as SignatureContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_valueDomainSignature;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValueDomainSignature) {
			return visitor.visitValueDomainSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CodeItemRelationContext extends ParserRuleContext {
	public _codeItemRef!: ValueDomainValueContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public codeItemRelationClause_list(): CodeItemRelationClauseContext[] {
		return this.getTypedRuleContexts(CodeItemRelationClauseContext) as CodeItemRelationClauseContext[];
	}
	public codeItemRelationClause(i: number): CodeItemRelationClauseContext {
		return this.getTypedRuleContext(CodeItemRelationClauseContext, i) as CodeItemRelationClauseContext;
	}
	public valueDomainValue(): ValueDomainValueContext {
		return this.getTypedRuleContext(ValueDomainValueContext, 0) as ValueDomainValueContext;
	}
	public WHEN(): TerminalNode {
		return this.getToken(Vtl.WHEN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public THEN(): TerminalNode {
		return this.getToken(Vtl.THEN, 0);
	}
	public comparisonOperand(): ComparisonOperandContext {
		return this.getTypedRuleContext(ComparisonOperandContext, 0) as ComparisonOperandContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_codeItemRelation;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCodeItemRelation) {
			return visitor.visitCodeItemRelation(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CodeItemRelationClauseContext extends ParserRuleContext {
	public _opAdd!: Token;
	public _rightCodeItem!: ValueDomainValueContext;
	public _rightCondition!: ExprComponentContext;
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public valueDomainValue(): ValueDomainValueContext {
		return this.getTypedRuleContext(ValueDomainValueContext, 0) as ValueDomainValueContext;
	}
	public QLPAREN(): TerminalNode {
		return this.getToken(Vtl.QLPAREN, 0);
	}
	public QRPAREN(): TerminalNode {
		return this.getToken(Vtl.QRPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(Vtl.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(Vtl.MINUS, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_codeItemRelationClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCodeItemRelationClause) {
			return visitor.visitCodeItemRelationClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainValueContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
	public INTEGER_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.INTEGER_CONSTANT, 0);
	}
	public NUMBER_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.NUMBER_CONSTANT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_valueDomainValue;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValueDomainValue) {
			return visitor.visitValueDomainValue(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarTypeConstraintContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_scalarTypeConstraint;
	}
	public copyFrom(ctx: ScalarTypeConstraintContext): void {
		super.copyFrom(ctx);
	}
}
export class RangeConstraintContext extends ScalarTypeConstraintContext {
	constructor(parser: Vtl, ctx: ScalarTypeConstraintContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public constant_list(): ConstantContext[] {
		return this.getTypedRuleContexts(ConstantContext) as ConstantContext[];
	}
	public constant(i: number): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, i) as ConstantContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRangeConstraint) {
			return visitor.visitRangeConstraint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConditionConstraintContext extends ScalarTypeConstraintContext {
	constructor(parser: Vtl, ctx: ScalarTypeConstraintContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public QLPAREN(): TerminalNode {
		return this.getToken(Vtl.QLPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public QRPAREN(): TerminalNode {
		return this.getToken(Vtl.QRPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConditionConstraint) {
			return visitor.visitConditionConstraint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CompConstraintContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public multModifier(): MultModifierContext {
		return this.getTypedRuleContext(MultModifierContext, 0) as MultModifierContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_compConstraint;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitCompConstraint) {
			return visitor.visitCompConstraint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MultModifierContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
	public PLUS(): TerminalNode {
		return this.getToken(Vtl.PLUS, 0);
	}
	public MUL(): TerminalNode {
		return this.getToken(Vtl.MUL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_multModifier;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitMultModifier) {
			return visitor.visitMultModifier(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValidationOutputContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public INVALID(): TerminalNode {
		return this.getToken(Vtl.INVALID, 0);
	}
	public ALL_MEASURES(): TerminalNode {
		return this.getToken(Vtl.ALL_MEASURES, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_validationOutput;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValidationOutput) {
			return visitor.visitValidationOutput(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValidationModeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public NON_NULL(): TerminalNode {
		return this.getToken(Vtl.NON_NULL, 0);
	}
	public NON_ZERO(): TerminalNode {
		return this.getToken(Vtl.NON_ZERO, 0);
	}
	public PARTIAL_NULL(): TerminalNode {
		return this.getToken(Vtl.PARTIAL_NULL, 0);
	}
	public PARTIAL_ZERO(): TerminalNode {
		return this.getToken(Vtl.PARTIAL_ZERO, 0);
	}
	public ALWAYS_NULL(): TerminalNode {
		return this.getToken(Vtl.ALWAYS_NULL, 0);
	}
	public ALWAYS_ZERO(): TerminalNode {
		return this.getToken(Vtl.ALWAYS_ZERO, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_validationMode;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValidationMode) {
			return visitor.visitValidationMode(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConditionClauseContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public CONDITION(): TerminalNode {
		return this.getToken(Vtl.CONDITION, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_conditionClause;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConditionClause) {
			return visitor.visitConditionClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InputModeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public DATASET(): TerminalNode {
		return this.getToken(Vtl.DATASET, 0);
	}
	public DATASET_PRIORITY(): TerminalNode {
		return this.getToken(Vtl.DATASET_PRIORITY, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_inputMode;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInputMode) {
			return visitor.visitInputMode(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ImbalanceExprContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IMBALANCE(): TerminalNode {
		return this.getToken(Vtl.IMBALANCE, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_imbalanceExpr;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitImbalanceExpr) {
			return visitor.visitImbalanceExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InputModeHierarchyContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RULE(): TerminalNode {
		return this.getToken(Vtl.RULE, 0);
	}
	public DATASET(): TerminalNode {
		return this.getToken(Vtl.DATASET, 0);
	}
	public RULE_PRIORITY(): TerminalNode {
		return this.getToken(Vtl.RULE_PRIORITY, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_inputModeHierarchy;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitInputModeHierarchy) {
			return visitor.visitInputModeHierarchy(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OutputModeHierarchyContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public COMPUTED(): TerminalNode {
		return this.getToken(Vtl.COMPUTED, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_outputModeHierarchy;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOutputModeHierarchy) {
			return visitor.visitOutputModeHierarchy(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AliasContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_alias;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitAlias) {
			return visitor.visitAlias(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class VarIDContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_varID;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitVarID) {
			return visitor.visitVarID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SimpleComponentIdContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_simpleComponentId;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSimpleComponentId) {
			return visitor.visitSimpleComponentId(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComponentIDContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.IDENTIFIER);
	}
	public IDENTIFIER(i: number): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, i);
	}
	public MEMBERSHIP(): TerminalNode {
		return this.getToken(Vtl.MEMBERSHIP, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_componentID;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComponentID) {
			return visitor.visitComponentID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InexprContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_inexpr;
	}
	public copyFrom(ctx: InexprContext): void {
		super.copyFrom(ctx);
	}
}
export class SetExprContext extends InexprContext {
	constructor(parser: Vtl, ctx: InexprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(Vtl.GLPAREN, 0);
	}
	public constant_list(): ConstantContext[] {
		return this.getTypedRuleContexts(ConstantContext) as ConstantContext[];
	}
	public constant(i: number): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, i) as ConstantContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(Vtl.GRPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(Vtl.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(Vtl.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitSetExpr) {
			return visitor.visitSetExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValueDomainExprContext extends InexprContext {
	constructor(parser: Vtl, ctx: InexprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public valueDomainID(): ValueDomainIDContext {
		return this.getTypedRuleContext(ValueDomainIDContext, 0) as ValueDomainIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValueDomainExpr) {
			return visitor.visitValueDomainExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ErCodeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ERRORCODE(): TerminalNode {
		return this.getToken(Vtl.ERRORCODE, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_erCode;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitErCode) {
			return visitor.visitErCode(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ErLevelContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ERRORLEVEL(): TerminalNode {
		return this.getToken(Vtl.ERRORLEVEL, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_erLevel;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitErLevel) {
			return visitor.visitErLevel(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComparisonOperandContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public MT(): TerminalNode {
		return this.getToken(Vtl.MT, 0);
	}
	public ME(): TerminalNode {
		return this.getToken(Vtl.ME, 0);
	}
	public LE(): TerminalNode {
		return this.getToken(Vtl.LE, 0);
	}
	public LT(): TerminalNode {
		return this.getToken(Vtl.LT, 0);
	}
	public EQ(): TerminalNode {
		return this.getToken(Vtl.EQ, 0);
	}
	public NEQ(): TerminalNode {
		return this.getToken(Vtl.NEQ, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_comparisonOperand;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComparisonOperand) {
			return visitor.visitComparisonOperand(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OptionalExprContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_optionalExpr;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOptionalExpr) {
			return visitor.visitOptionalExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OptionalExprComponentContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(Vtl.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_optionalExprComponent;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOptionalExprComponent) {
			return visitor.visitOptionalExprComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComponentRoleContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public MEASURE(): TerminalNode {
		return this.getToken(Vtl.MEASURE, 0);
	}
	public COMPONENT(): TerminalNode {
		return this.getToken(Vtl.COMPONENT, 0);
	}
	public DIMENSION(): TerminalNode {
		return this.getToken(Vtl.DIMENSION, 0);
	}
	public ATTRIBUTE(): TerminalNode {
		return this.getToken(Vtl.ATTRIBUTE, 0);
	}
	public viralAttribute(): ViralAttributeContext {
		return this.getTypedRuleContext(ViralAttributeContext, 0) as ViralAttributeContext;
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_componentRole;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitComponentRole) {
			return visitor.visitComponentRole(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ViralAttributeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public VIRAL(): TerminalNode {
		return this.getToken(Vtl.VIRAL, 0);
	}
	public ATTRIBUTE(): TerminalNode {
		return this.getToken(Vtl.ATTRIBUTE, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_viralAttribute;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitViralAttribute) {
			return visitor.visitViralAttribute(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainIDContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_valueDomainID;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitValueDomainID) {
			return visitor.visitValueDomainID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OperatorIDContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_operatorID;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitOperatorID) {
			return visitor.visitOperatorID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RoutineNameContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(Vtl.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_routineName;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRoutineName) {
			return visitor.visitRoutineName(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConstantContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public INTEGER_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.INTEGER_CONSTANT, 0);
	}
	public NUMBER_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.NUMBER_CONSTANT, 0);
	}
	public BOOLEAN_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.BOOLEAN_CONSTANT, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.STRING_CONSTANT, 0);
	}
	public NULL_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.NULL_CONSTANT, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_constant;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitConstant) {
			return visitor.visitConstant(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class BasicScalarTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public STRING(): TerminalNode {
		return this.getToken(Vtl.STRING, 0);
	}
	public INTEGER(): TerminalNode {
		return this.getToken(Vtl.INTEGER, 0);
	}
	public NUMBER(): TerminalNode {
		return this.getToken(Vtl.NUMBER, 0);
	}
	public BOOLEAN(): TerminalNode {
		return this.getToken(Vtl.BOOLEAN, 0);
	}
	public DATE(): TerminalNode {
		return this.getToken(Vtl.DATE, 0);
	}
	public TIME(): TerminalNode {
		return this.getToken(Vtl.TIME, 0);
	}
	public TIME_PERIOD(): TerminalNode {
		return this.getToken(Vtl.TIME_PERIOD, 0);
	}
	public DURATION(): TerminalNode {
		return this.getToken(Vtl.DURATION, 0);
	}
	public SCALAR(): TerminalNode {
		return this.getToken(Vtl.SCALAR, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_basicScalarType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitBasicScalarType) {
			return visitor.visitBasicScalarType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RetainTypeContext extends ParserRuleContext {
	constructor(parser?: Vtl, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public BOOLEAN_CONSTANT(): TerminalNode {
		return this.getToken(Vtl.BOOLEAN_CONSTANT, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(Vtl.ALL, 0);
	}
    public get ruleIndex(): number {
    	return Vtl.RULE_retainType;
	}
	// @Override
	public accept<Result>(visitor: VtlVisitor<Result>): Result {
		if (visitor.visitRetainType) {
			return visitor.visitRetainType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
