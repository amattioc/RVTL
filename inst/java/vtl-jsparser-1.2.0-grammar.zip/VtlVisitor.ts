// Generated from it/bancaditalia/oss/vtl/grammar/Vtl.g4 by ANTLR 4.13.1

import {ParseTreeVisitor} from 'antlr4';


import { StartContext } from "./Vtl";
import { TemporaryAssignmentContext } from "./Vtl";
import { PersistAssignmentContext } from "./Vtl";
import { DefineExpressionContext } from "./Vtl";
import { VarIdExprContext } from "./Vtl";
import { MembershipExprContext } from "./Vtl";
import { InNotInExprContext } from "./Vtl";
import { BooleanExprContext } from "./Vtl";
import { ComparisonExprContext } from "./Vtl";
import { UnaryExprContext } from "./Vtl";
import { FunctionsExpressionContext } from "./Vtl";
import { IfExprContext } from "./Vtl";
import { ClauseExprContext } from "./Vtl";
import { ArithmeticExprContext } from "./Vtl";
import { ParenthesisExprContext } from "./Vtl";
import { ConstantExprContext } from "./Vtl";
import { ArithmeticExprOrConcatContext } from "./Vtl";
import { ArithmeticExprCompContext } from "./Vtl";
import { IfExprCompContext } from "./Vtl";
import { ComparisonExprCompContext } from "./Vtl";
import { FunctionsExpressionCompContext } from "./Vtl";
import { CompIdContext } from "./Vtl";
import { ConstantExprCompContext } from "./Vtl";
import { ArithmeticExprOrConcatCompContext } from "./Vtl";
import { ParenthesisExprCompContext } from "./Vtl";
import { InNotInExprCompContext } from "./Vtl";
import { UnaryExprCompContext } from "./Vtl";
import { BooleanExprCompContext } from "./Vtl";
import { GenericFunctionsComponentsContext } from "./Vtl";
import { StringFunctionsComponentsContext } from "./Vtl";
import { NumericFunctionsComponentsContext } from "./Vtl";
import { ComparisonFunctionsComponentsContext } from "./Vtl";
import { TimeFunctionsComponentsContext } from "./Vtl";
import { ConditionalFunctionsComponentsContext } from "./Vtl";
import { AggregateFunctionsComponentsContext } from "./Vtl";
import { AnalyticFunctionsComponentsContext } from "./Vtl";
import { JoinFunctionsContext } from "./Vtl";
import { GenericFunctionsContext } from "./Vtl";
import { StringFunctionsContext } from "./Vtl";
import { NumericFunctionsContext } from "./Vtl";
import { ComparisonFunctionsContext } from "./Vtl";
import { TimeFunctionsContext } from "./Vtl";
import { SetFunctionsContext } from "./Vtl";
import { HierarchyFunctionsContext } from "./Vtl";
import { ValidationFunctionsContext } from "./Vtl";
import { ConditionalFunctionsContext } from "./Vtl";
import { AggregateFunctionsContext } from "./Vtl";
import { AnalyticFunctionsContext } from "./Vtl";
import { DatasetClauseContext } from "./Vtl";
import { RenameClauseContext } from "./Vtl";
import { AggrClauseContext } from "./Vtl";
import { FilterClauseContext } from "./Vtl";
import { CalcClauseContext } from "./Vtl";
import { KeepOrDropClauseContext } from "./Vtl";
import { PivotOrUnpivotClauseContext } from "./Vtl";
import { SubspaceClauseContext } from "./Vtl";
import { JoinExprContext } from "./Vtl";
import { DefOperatorContext } from "./Vtl";
import { DefDatapointRulesetContext } from "./Vtl";
import { DefHierarchicalContext } from "./Vtl";
import { CallDatasetContext } from "./Vtl";
import { EvalAtomContext } from "./Vtl";
import { CastExprDatasetContext } from "./Vtl";
import { CallComponentContext } from "./Vtl";
import { CastExprComponentContext } from "./Vtl";
import { EvalAtomComponentContext } from "./Vtl";
import { ParameterComponentContext } from "./Vtl";
import { ParameterContext } from "./Vtl";
import { UnaryStringFunctionContext } from "./Vtl";
import { SubstrAtomContext } from "./Vtl";
import { ReplaceAtomContext } from "./Vtl";
import { InstrAtomContext } from "./Vtl";
import { UnaryStringFunctionComponentContext } from "./Vtl";
import { SubstrAtomComponentContext } from "./Vtl";
import { ReplaceAtomComponentContext } from "./Vtl";
import { InstrAtomComponentContext } from "./Vtl";
import { UnaryNumericContext } from "./Vtl";
import { UnaryWithOptionalNumericContext } from "./Vtl";
import { BinaryNumericContext } from "./Vtl";
import { UnaryNumericComponentContext } from "./Vtl";
import { UnaryWithOptionalNumericComponentContext } from "./Vtl";
import { BinaryNumericComponentContext } from "./Vtl";
import { BetweenAtomContext } from "./Vtl";
import { CharsetMatchAtomContext } from "./Vtl";
import { IsNullAtomContext } from "./Vtl";
import { ExistInAtomContext } from "./Vtl";
import { BetweenAtomComponentContext } from "./Vtl";
import { CharsetMatchAtomComponentContext } from "./Vtl";
import { IsNullAtomComponentContext } from "./Vtl";
import { PeriodAtomContext } from "./Vtl";
import { FillTimeAtomContext } from "./Vtl";
import { FlowAtomContext } from "./Vtl";
import { TimeShiftAtomContext } from "./Vtl";
import { TimeAggAtomContext } from "./Vtl";
import { CurrentDateAtomContext } from "./Vtl";
import { PeriodAtomComponentContext } from "./Vtl";
import { FillTimeAtomComponentContext } from "./Vtl";
import { FlowAtomComponentContext } from "./Vtl";
import { TimeShiftAtomComponentContext } from "./Vtl";
import { TimeAggAtomComponentContext } from "./Vtl";
import { CurrentDateAtomComponentContext } from "./Vtl";
import { UnionAtomContext } from "./Vtl";
import { IntersectAtomContext } from "./Vtl";
import { SetOrSYmDiffAtomContext } from "./Vtl";
import { HierarchyOperatorsContext } from "./Vtl";
import { ValidateDPrulesetContext } from "./Vtl";
import { ValidateHRrulesetContext } from "./Vtl";
import { ValidationSimpleContext } from "./Vtl";
import { NvlAtomContext } from "./Vtl";
import { NvlAtomComponentContext } from "./Vtl";
import { AggrCompContext } from "./Vtl";
import { CountAggrCompContext } from "./Vtl";
import { AggrDatasetContext } from "./Vtl";
import { AnSimpleFunctionContext } from "./Vtl";
import { LagOrLeadAnContext } from "./Vtl";
import { RatioToReportAnContext } from "./Vtl";
import { AnSimpleFunctionComponentContext } from "./Vtl";
import { LagOrLeadAnComponentContext } from "./Vtl";
import { RankAnComponentContext } from "./Vtl";
import { RatioToReportAnComponentContext } from "./Vtl";
import { RenameClauseItemContext } from "./Vtl";
import { AggregateClauseContext } from "./Vtl";
import { AggrFunctionClauseContext } from "./Vtl";
import { CalcClauseItemContext } from "./Vtl";
import { SubspaceClauseItemContext } from "./Vtl";
import { JoinClauseWithoutUsingContext } from "./Vtl";
import { JoinClauseContext } from "./Vtl";
import { JoinClauseItemContext } from "./Vtl";
import { JoinBodyContext } from "./Vtl";
import { JoinApplyClauseContext } from "./Vtl";
import { PartitionByClauseContext } from "./Vtl";
import { OrderByClauseContext } from "./Vtl";
import { OrderByItemContext } from "./Vtl";
import { WindowingClauseContext } from "./Vtl";
import { SignedIntegerContext } from "./Vtl";
import { LimitClauseItemContext } from "./Vtl";
import { GroupByOrExceptContext } from "./Vtl";
import { GroupAllContext } from "./Vtl";
import { HavingClauseContext } from "./Vtl";
import { ParameterItemContext } from "./Vtl";
import { OutputParameterTypeContext } from "./Vtl";
import { OutputParameterTypeComponentContext } from "./Vtl";
import { InputParameterTypeContext } from "./Vtl";
import { RulesetTypeContext } from "./Vtl";
import { ScalarTypeContext } from "./Vtl";
import { ComponentTypeContext } from "./Vtl";
import { DatasetTypeContext } from "./Vtl";
import { ScalarSetTypeContext } from "./Vtl";
import { DataPointContext } from "./Vtl";
import { DataPointVdContext } from "./Vtl";
import { DataPointVarContext } from "./Vtl";
import { HrRulesetTypeContext } from "./Vtl";
import { HrRulesetVdTypeContext } from "./Vtl";
import { HrRulesetVarTypeContext } from "./Vtl";
import { ValueDomainNameContext } from "./Vtl";
import { RulesetIDContext } from "./Vtl";
import { RulesetSignatureContext } from "./Vtl";
import { SignatureContext } from "./Vtl";
import { RuleClauseDatapointContext } from "./Vtl";
import { RuleItemDatapointContext } from "./Vtl";
import { RuleClauseHierarchicalContext } from "./Vtl";
import { RuleItemHierarchicalContext } from "./Vtl";
import { HierRuleSignatureContext } from "./Vtl";
import { ValueDomainSignatureContext } from "./Vtl";
import { CodeItemRelationContext } from "./Vtl";
import { CodeItemRelationClauseContext } from "./Vtl";
import { ValueDomainValueContext } from "./Vtl";
import { ConditionConstraintContext } from "./Vtl";
import { RangeConstraintContext } from "./Vtl";
import { CompConstraintContext } from "./Vtl";
import { MultModifierContext } from "./Vtl";
import { ValidationOutputContext } from "./Vtl";
import { ValidationModeContext } from "./Vtl";
import { ConditionClauseContext } from "./Vtl";
import { InputModeContext } from "./Vtl";
import { ImbalanceExprContext } from "./Vtl";
import { InputModeHierarchyContext } from "./Vtl";
import { OutputModeHierarchyContext } from "./Vtl";
import { AliasContext } from "./Vtl";
import { VarIDContext } from "./Vtl";
import { SimpleComponentIdContext } from "./Vtl";
import { ComponentIDContext } from "./Vtl";
import { SetExprContext } from "./Vtl";
import { ValueDomainExprContext } from "./Vtl";
import { ErCodeContext } from "./Vtl";
import { ErLevelContext } from "./Vtl";
import { ComparisonOperandContext } from "./Vtl";
import { OptionalExprContext } from "./Vtl";
import { OptionalExprComponentContext } from "./Vtl";
import { ComponentRoleContext } from "./Vtl";
import { ViralAttributeContext } from "./Vtl";
import { ValueDomainIDContext } from "./Vtl";
import { OperatorIDContext } from "./Vtl";
import { RoutineNameContext } from "./Vtl";
import { ConstantContext } from "./Vtl";
import { BasicScalarTypeContext } from "./Vtl";
import { RetainTypeContext } from "./Vtl";


/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by `Vtl`.
 *
 * @param <Result> The return type of the visit operation. Use `void` for
 * operations with no return type.
 */
export default class VtlVisitor<Result> extends ParseTreeVisitor<Result> {
	/**
	 * Visit a parse tree produced by `Vtl.start`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStart?: (ctx: StartContext) => Result;
	/**
	 * Visit a parse tree produced by the `temporaryAssignment`
	 * labeled alternative in `Vtl.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTemporaryAssignment?: (ctx: TemporaryAssignmentContext) => Result;
	/**
	 * Visit a parse tree produced by the `persistAssignment`
	 * labeled alternative in `Vtl.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPersistAssignment?: (ctx: PersistAssignmentContext) => Result;
	/**
	 * Visit a parse tree produced by the `defineExpression`
	 * labeled alternative in `Vtl.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefineExpression?: (ctx: DefineExpressionContext) => Result;
	/**
	 * Visit a parse tree produced by the `varIdExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVarIdExpr?: (ctx: VarIdExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `membershipExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMembershipExpr?: (ctx: MembershipExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `inNotInExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInNotInExpr?: (ctx: InNotInExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `booleanExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBooleanExpr?: (ctx: BooleanExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonExpr?: (ctx: ComparisonExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryExpr?: (ctx: UnaryExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `functionsExpression`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFunctionsExpression?: (ctx: FunctionsExpressionContext) => Result;
	/**
	 * Visit a parse tree produced by the `ifExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIfExpr?: (ctx: IfExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `clauseExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitClauseExpr?: (ctx: ClauseExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExpr?: (ctx: ArithmeticExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `parenthesisExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParenthesisExpr?: (ctx: ParenthesisExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `constantExpr`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConstantExpr?: (ctx: ConstantExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExprOrConcat`
	 * labeled alternative in `Vtl.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExprOrConcat?: (ctx: ArithmeticExprOrConcatContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExprComp?: (ctx: ArithmeticExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `ifExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIfExprComp?: (ctx: IfExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonExprComp?: (ctx: ComparisonExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `functionsExpressionComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFunctionsExpressionComp?: (ctx: FunctionsExpressionCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `compId`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCompId?: (ctx: CompIdContext) => Result;
	/**
	 * Visit a parse tree produced by the `constantExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConstantExprComp?: (ctx: ConstantExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExprOrConcatComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExprOrConcatComp?: (ctx: ArithmeticExprOrConcatCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `parenthesisExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParenthesisExprComp?: (ctx: ParenthesisExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `inNotInExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInNotInExprComp?: (ctx: InNotInExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryExprComp?: (ctx: UnaryExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `booleanExprComp`
	 * labeled alternative in `Vtl.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBooleanExprComp?: (ctx: BooleanExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `genericFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGenericFunctionsComponents?: (ctx: GenericFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `stringFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStringFunctionsComponents?: (ctx: StringFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `numericFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNumericFunctionsComponents?: (ctx: NumericFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonFunctionsComponents?: (ctx: ComparisonFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeFunctionsComponents?: (ctx: TimeFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `conditionalFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionalFunctionsComponents?: (ctx: ConditionalFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggregateFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggregateFunctionsComponents?: (ctx: AggregateFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `analyticFunctionsComponents`
	 * labeled alternative in `Vtl.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnalyticFunctionsComponents?: (ctx: AnalyticFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `joinFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinFunctions?: (ctx: JoinFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `genericFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGenericFunctions?: (ctx: GenericFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `stringFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStringFunctions?: (ctx: StringFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `numericFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNumericFunctions?: (ctx: NumericFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonFunctions?: (ctx: ComparisonFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeFunctions?: (ctx: TimeFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `setFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSetFunctions?: (ctx: SetFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `hierarchyFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHierarchyFunctions?: (ctx: HierarchyFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `validationFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationFunctions?: (ctx: ValidationFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `conditionalFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionalFunctions?: (ctx: ConditionalFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggregateFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggregateFunctions?: (ctx: AggregateFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `analyticFunctions`
	 * labeled alternative in `Vtl.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnalyticFunctions?: (ctx: AnalyticFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.datasetClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDatasetClause?: (ctx: DatasetClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.renameClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRenameClause?: (ctx: RenameClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.aggrClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrClause?: (ctx: AggrClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.filterClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFilterClause?: (ctx: FilterClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.calcClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCalcClause?: (ctx: CalcClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.keepOrDropClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitKeepOrDropClause?: (ctx: KeepOrDropClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.pivotOrUnpivotClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPivotOrUnpivotClause?: (ctx: PivotOrUnpivotClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.subspaceClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubspaceClause?: (ctx: SubspaceClauseContext) => Result;
	/**
	 * Visit a parse tree produced by the `joinExpr`
	 * labeled alternative in `Vtl.joinOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinExpr?: (ctx: JoinExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `defOperator`
	 * labeled alternative in `Vtl.defOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefOperator?: (ctx: DefOperatorContext) => Result;
	/**
	 * Visit a parse tree produced by the `defDatapointRuleset`
	 * labeled alternative in `Vtl.defOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefDatapointRuleset?: (ctx: DefDatapointRulesetContext) => Result;
	/**
	 * Visit a parse tree produced by the `defHierarchical`
	 * labeled alternative in `Vtl.defOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefHierarchical?: (ctx: DefHierarchicalContext) => Result;
	/**
	 * Visit a parse tree produced by the `callDataset`
	 * labeled alternative in `Vtl.genericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCallDataset?: (ctx: CallDatasetContext) => Result;
	/**
	 * Visit a parse tree produced by the `evalAtom`
	 * labeled alternative in `Vtl.genericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEvalAtom?: (ctx: EvalAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `castExprDataset`
	 * labeled alternative in `Vtl.genericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCastExprDataset?: (ctx: CastExprDatasetContext) => Result;
	/**
	 * Visit a parse tree produced by the `callComponent`
	 * labeled alternative in `Vtl.genericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCallComponent?: (ctx: CallComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `castExprComponent`
	 * labeled alternative in `Vtl.genericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCastExprComponent?: (ctx: CastExprComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `evalAtomComponent`
	 * labeled alternative in `Vtl.genericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEvalAtomComponent?: (ctx: EvalAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.parameterComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParameterComponent?: (ctx: ParameterComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.parameter`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParameter?: (ctx: ParameterContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryStringFunction`
	 * labeled alternative in `Vtl.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryStringFunction?: (ctx: UnaryStringFunctionContext) => Result;
	/**
	 * Visit a parse tree produced by the `substrAtom`
	 * labeled alternative in `Vtl.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubstrAtom?: (ctx: SubstrAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `replaceAtom`
	 * labeled alternative in `Vtl.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitReplaceAtom?: (ctx: ReplaceAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `instrAtom`
	 * labeled alternative in `Vtl.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInstrAtom?: (ctx: InstrAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryStringFunctionComponent`
	 * labeled alternative in `Vtl.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryStringFunctionComponent?: (ctx: UnaryStringFunctionComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `substrAtomComponent`
	 * labeled alternative in `Vtl.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubstrAtomComponent?: (ctx: SubstrAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `replaceAtomComponent`
	 * labeled alternative in `Vtl.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitReplaceAtomComponent?: (ctx: ReplaceAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `instrAtomComponent`
	 * labeled alternative in `Vtl.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInstrAtomComponent?: (ctx: InstrAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryNumeric`
	 * labeled alternative in `Vtl.numericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryNumeric?: (ctx: UnaryNumericContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryWithOptionalNumeric`
	 * labeled alternative in `Vtl.numericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryWithOptionalNumeric?: (ctx: UnaryWithOptionalNumericContext) => Result;
	/**
	 * Visit a parse tree produced by the `binaryNumeric`
	 * labeled alternative in `Vtl.numericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBinaryNumeric?: (ctx: BinaryNumericContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryNumericComponent`
	 * labeled alternative in `Vtl.numericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryNumericComponent?: (ctx: UnaryNumericComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryWithOptionalNumericComponent`
	 * labeled alternative in `Vtl.numericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryWithOptionalNumericComponent?: (ctx: UnaryWithOptionalNumericComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `binaryNumericComponent`
	 * labeled alternative in `Vtl.numericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBinaryNumericComponent?: (ctx: BinaryNumericComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `betweenAtom`
	 * labeled alternative in `Vtl.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBetweenAtom?: (ctx: BetweenAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `charsetMatchAtom`
	 * labeled alternative in `Vtl.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCharsetMatchAtom?: (ctx: CharsetMatchAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `isNullAtom`
	 * labeled alternative in `Vtl.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIsNullAtom?: (ctx: IsNullAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `existInAtom`
	 * labeled alternative in `Vtl.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitExistInAtom?: (ctx: ExistInAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `betweenAtomComponent`
	 * labeled alternative in `Vtl.comparisonOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBetweenAtomComponent?: (ctx: BetweenAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `charsetMatchAtomComponent`
	 * labeled alternative in `Vtl.comparisonOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCharsetMatchAtomComponent?: (ctx: CharsetMatchAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `isNullAtomComponent`
	 * labeled alternative in `Vtl.comparisonOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIsNullAtomComponent?: (ctx: IsNullAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `periodAtom`
	 * labeled alternative in `Vtl.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPeriodAtom?: (ctx: PeriodAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `fillTimeAtom`
	 * labeled alternative in `Vtl.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFillTimeAtom?: (ctx: FillTimeAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `flowAtom`
	 * labeled alternative in `Vtl.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFlowAtom?: (ctx: FlowAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeShiftAtom`
	 * labeled alternative in `Vtl.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeShiftAtom?: (ctx: TimeShiftAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeAggAtom`
	 * labeled alternative in `Vtl.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeAggAtom?: (ctx: TimeAggAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `currentDateAtom`
	 * labeled alternative in `Vtl.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCurrentDateAtom?: (ctx: CurrentDateAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `periodAtomComponent`
	 * labeled alternative in `Vtl.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPeriodAtomComponent?: (ctx: PeriodAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `fillTimeAtomComponent`
	 * labeled alternative in `Vtl.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFillTimeAtomComponent?: (ctx: FillTimeAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `flowAtomComponent`
	 * labeled alternative in `Vtl.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFlowAtomComponent?: (ctx: FlowAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeShiftAtomComponent`
	 * labeled alternative in `Vtl.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeShiftAtomComponent?: (ctx: TimeShiftAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeAggAtomComponent`
	 * labeled alternative in `Vtl.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeAggAtomComponent?: (ctx: TimeAggAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `currentDateAtomComponent`
	 * labeled alternative in `Vtl.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCurrentDateAtomComponent?: (ctx: CurrentDateAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `unionAtom`
	 * labeled alternative in `Vtl.setOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnionAtom?: (ctx: UnionAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `intersectAtom`
	 * labeled alternative in `Vtl.setOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIntersectAtom?: (ctx: IntersectAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `setOrSYmDiffAtom`
	 * labeled alternative in `Vtl.setOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSetOrSYmDiffAtom?: (ctx: SetOrSYmDiffAtomContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.hierarchyOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHierarchyOperators?: (ctx: HierarchyOperatorsContext) => Result;
	/**
	 * Visit a parse tree produced by the `validateDPruleset`
	 * labeled alternative in `Vtl.validationOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidateDPruleset?: (ctx: ValidateDPrulesetContext) => Result;
	/**
	 * Visit a parse tree produced by the `validateHRruleset`
	 * labeled alternative in `Vtl.validationOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidateHRruleset?: (ctx: ValidateHRrulesetContext) => Result;
	/**
	 * Visit a parse tree produced by the `validationSimple`
	 * labeled alternative in `Vtl.validationOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationSimple?: (ctx: ValidationSimpleContext) => Result;
	/**
	 * Visit a parse tree produced by the `nvlAtom`
	 * labeled alternative in `Vtl.conditionalOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNvlAtom?: (ctx: NvlAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `nvlAtomComponent`
	 * labeled alternative in `Vtl.conditionalOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNvlAtomComponent?: (ctx: NvlAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggrComp`
	 * labeled alternative in `Vtl.aggrOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrComp?: (ctx: AggrCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `countAggrComp`
	 * labeled alternative in `Vtl.aggrOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCountAggrComp?: (ctx: CountAggrCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggrDataset`
	 * labeled alternative in `Vtl.aggrOperatorsGrouping`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrDataset?: (ctx: AggrDatasetContext) => Result;
	/**
	 * Visit a parse tree produced by the `anSimpleFunction`
	 * labeled alternative in `Vtl.anFunction`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnSimpleFunction?: (ctx: AnSimpleFunctionContext) => Result;
	/**
	 * Visit a parse tree produced by the `lagOrLeadAn`
	 * labeled alternative in `Vtl.anFunction`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLagOrLeadAn?: (ctx: LagOrLeadAnContext) => Result;
	/**
	 * Visit a parse tree produced by the `ratioToReportAn`
	 * labeled alternative in `Vtl.anFunction`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRatioToReportAn?: (ctx: RatioToReportAnContext) => Result;
	/**
	 * Visit a parse tree produced by the `anSimpleFunctionComponent`
	 * labeled alternative in `Vtl.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnSimpleFunctionComponent?: (ctx: AnSimpleFunctionComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `lagOrLeadAnComponent`
	 * labeled alternative in `Vtl.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLagOrLeadAnComponent?: (ctx: LagOrLeadAnComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `rankAnComponent`
	 * labeled alternative in `Vtl.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRankAnComponent?: (ctx: RankAnComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `ratioToReportAnComponent`
	 * labeled alternative in `Vtl.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRatioToReportAnComponent?: (ctx: RatioToReportAnComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.renameClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRenameClauseItem?: (ctx: RenameClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.aggregateClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggregateClause?: (ctx: AggregateClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.aggrFunctionClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrFunctionClause?: (ctx: AggrFunctionClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.calcClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCalcClauseItem?: (ctx: CalcClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.subspaceClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubspaceClauseItem?: (ctx: SubspaceClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.joinClauseWithoutUsing`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinClauseWithoutUsing?: (ctx: JoinClauseWithoutUsingContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.joinClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinClause?: (ctx: JoinClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.joinClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinClauseItem?: (ctx: JoinClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.joinBody`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinBody?: (ctx: JoinBodyContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.joinApplyClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinApplyClause?: (ctx: JoinApplyClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.partitionByClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPartitionByClause?: (ctx: PartitionByClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.orderByClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOrderByClause?: (ctx: OrderByClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.orderByItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOrderByItem?: (ctx: OrderByItemContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.windowingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitWindowingClause?: (ctx: WindowingClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.signedInteger`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSignedInteger?: (ctx: SignedIntegerContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.limitClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLimitClauseItem?: (ctx: LimitClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by the `groupByOrExcept`
	 * labeled alternative in `Vtl.groupingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGroupByOrExcept?: (ctx: GroupByOrExceptContext) => Result;
	/**
	 * Visit a parse tree produced by the `groupAll`
	 * labeled alternative in `Vtl.groupingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGroupAll?: (ctx: GroupAllContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.havingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHavingClause?: (ctx: HavingClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.parameterItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParameterItem?: (ctx: ParameterItemContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.outputParameterType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOutputParameterType?: (ctx: OutputParameterTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.outputParameterTypeComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOutputParameterTypeComponent?: (ctx: OutputParameterTypeComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.inputParameterType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInputParameterType?: (ctx: InputParameterTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.rulesetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRulesetType?: (ctx: RulesetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.scalarType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitScalarType?: (ctx: ScalarTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.componentType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponentType?: (ctx: ComponentTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.datasetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDatasetType?: (ctx: DatasetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.scalarSetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitScalarSetType?: (ctx: ScalarSetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by the `dataPoint`
	 * labeled alternative in `Vtl.dpRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDataPoint?: (ctx: DataPointContext) => Result;
	/**
	 * Visit a parse tree produced by the `dataPointVd`
	 * labeled alternative in `Vtl.dpRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDataPointVd?: (ctx: DataPointVdContext) => Result;
	/**
	 * Visit a parse tree produced by the `dataPointVar`
	 * labeled alternative in `Vtl.dpRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDataPointVar?: (ctx: DataPointVarContext) => Result;
	/**
	 * Visit a parse tree produced by the `hrRulesetType`
	 * labeled alternative in `Vtl.hrRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHrRulesetType?: (ctx: HrRulesetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by the `hrRulesetVdType`
	 * labeled alternative in `Vtl.hrRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHrRulesetVdType?: (ctx: HrRulesetVdTypeContext) => Result;
	/**
	 * Visit a parse tree produced by the `hrRulesetVarType`
	 * labeled alternative in `Vtl.hrRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHrRulesetVarType?: (ctx: HrRulesetVarTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.valueDomainName`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainName?: (ctx: ValueDomainNameContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.rulesetID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRulesetID?: (ctx: RulesetIDContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.rulesetSignature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRulesetSignature?: (ctx: RulesetSignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.signature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSignature?: (ctx: SignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.ruleClauseDatapoint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleClauseDatapoint?: (ctx: RuleClauseDatapointContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.ruleItemDatapoint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleItemDatapoint?: (ctx: RuleItemDatapointContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.ruleClauseHierarchical`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleClauseHierarchical?: (ctx: RuleClauseHierarchicalContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.ruleItemHierarchical`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleItemHierarchical?: (ctx: RuleItemHierarchicalContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.hierRuleSignature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHierRuleSignature?: (ctx: HierRuleSignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.valueDomainSignature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainSignature?: (ctx: ValueDomainSignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.codeItemRelation`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCodeItemRelation?: (ctx: CodeItemRelationContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.codeItemRelationClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCodeItemRelationClause?: (ctx: CodeItemRelationClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.valueDomainValue`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainValue?: (ctx: ValueDomainValueContext) => Result;
	/**
	 * Visit a parse tree produced by the `conditionConstraint`
	 * labeled alternative in `Vtl.scalarTypeConstraint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionConstraint?: (ctx: ConditionConstraintContext) => Result;
	/**
	 * Visit a parse tree produced by the `rangeConstraint`
	 * labeled alternative in `Vtl.scalarTypeConstraint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRangeConstraint?: (ctx: RangeConstraintContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.compConstraint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCompConstraint?: (ctx: CompConstraintContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.multModifier`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMultModifier?: (ctx: MultModifierContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.validationOutput`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationOutput?: (ctx: ValidationOutputContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.validationMode`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationMode?: (ctx: ValidationModeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.conditionClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionClause?: (ctx: ConditionClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.inputMode`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInputMode?: (ctx: InputModeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.imbalanceExpr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitImbalanceExpr?: (ctx: ImbalanceExprContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.inputModeHierarchy`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInputModeHierarchy?: (ctx: InputModeHierarchyContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.outputModeHierarchy`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOutputModeHierarchy?: (ctx: OutputModeHierarchyContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.alias`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAlias?: (ctx: AliasContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.varID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVarID?: (ctx: VarIDContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.simpleComponentId`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSimpleComponentId?: (ctx: SimpleComponentIdContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.componentID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponentID?: (ctx: ComponentIDContext) => Result;
	/**
	 * Visit a parse tree produced by the `setExpr`
	 * labeled alternative in `Vtl.inexpr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSetExpr?: (ctx: SetExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `valueDomainExpr`
	 * labeled alternative in `Vtl.inexpr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainExpr?: (ctx: ValueDomainExprContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.erCode`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitErCode?: (ctx: ErCodeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.erLevel`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitErLevel?: (ctx: ErLevelContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.comparisonOperand`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonOperand?: (ctx: ComparisonOperandContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.optionalExpr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOptionalExpr?: (ctx: OptionalExprContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.optionalExprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOptionalExprComponent?: (ctx: OptionalExprComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.componentRole`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponentRole?: (ctx: ComponentRoleContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.viralAttribute`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitViralAttribute?: (ctx: ViralAttributeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.valueDomainID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainID?: (ctx: ValueDomainIDContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.operatorID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOperatorID?: (ctx: OperatorIDContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.routineName`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRoutineName?: (ctx: RoutineNameContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.constant`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConstant?: (ctx: ConstantContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.basicScalarType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBasicScalarType?: (ctx: BasicScalarTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `Vtl.retainType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRetainType?: (ctx: RetainTypeContext) => Result;
}

