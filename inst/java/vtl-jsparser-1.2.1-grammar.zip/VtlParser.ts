// Generated from org/sdmx/vtl/VtlParser.g4 by ANTLR 4.13.1
// noinspection ES6UnusedImports,JSUnusedGlobalSymbols,JSUnusedLocalSymbols

import {
	ATN,
	ATNDeserializer, DecisionState, DFA, FailedPredicateException,
	RecognitionException, NoViableAltException, BailErrorStrategy,
	Parser, ParserATNSimulator,
	RuleContext, ParserRuleContext, PredictionMode, PredictionContextCache,
	TerminalNode, RuleNode,
	Token, TokenStream,
	Interval, IntervalSet
} from 'antlr4';
import VtlParserVisitor from "./VtlParserVisitor.js";

// for running tests with parameters, TODO: discuss strategy for typed parameters in CI
// eslint-disable-next-line no-unused-vars
type int = number;

export default class VtlParser extends Parser {
	public static readonly LPAREN = 1;
	public static readonly RPAREN = 2;
	public static readonly QLPAREN = 3;
	public static readonly QRPAREN = 4;
	public static readonly GLPAREN = 5;
	public static readonly GRPAREN = 6;
	public static readonly EQ = 7;
	public static readonly LT = 8;
	public static readonly MT = 9;
	public static readonly ME = 10;
	public static readonly NEQ = 11;
	public static readonly LE = 12;
	public static readonly PLUS = 13;
	public static readonly MINUS = 14;
	public static readonly MUL = 15;
	public static readonly DIV = 16;
	public static readonly COMMA = 17;
	public static readonly POINTER = 18;
	public static readonly COLON = 19;
	public static readonly ASSIGN = 20;
	public static readonly MEMBERSHIP = 21;
	public static readonly EVAL = 22;
	public static readonly IF = 23;
	public static readonly CASE = 24;
	public static readonly THEN = 25;
	public static readonly ELSE = 26;
	public static readonly USING = 27;
	public static readonly WITH = 28;
	public static readonly CURRENT_DATE = 29;
	public static readonly DATEDIFF = 30;
	public static readonly DATEADD = 31;
	public static readonly YEAR_OP = 32;
	public static readonly MONTH_OP = 33;
	public static readonly DAYOFMONTH = 34;
	public static readonly DAYOFYEAR = 35;
	public static readonly DAYTOYEAR = 36;
	public static readonly DAYTOMONTH = 37;
	public static readonly YEARTODAY = 38;
	public static readonly MONTHTODAY = 39;
	public static readonly ON = 40;
	public static readonly DROP = 41;
	public static readonly KEEP = 42;
	public static readonly CALC = 43;
	public static readonly ATTRCALC = 44;
	public static readonly RENAME = 45;
	public static readonly AS = 46;
	public static readonly AND = 47;
	public static readonly OR = 48;
	public static readonly XOR = 49;
	public static readonly NOT = 50;
	public static readonly BETWEEN = 51;
	public static readonly IN = 52;
	public static readonly NOT_IN = 53;
	public static readonly NULL_CONSTANT = 54;
	public static readonly ISNULL = 55;
	public static readonly EX = 56;
	public static readonly UNION = 57;
	public static readonly DIFF = 58;
	public static readonly SYMDIFF = 59;
	public static readonly INTERSECT = 60;
	public static readonly RANDOM = 61;
	public static readonly KEYS = 62;
	public static readonly INTYEAR = 63;
	public static readonly INTMONTH = 64;
	public static readonly INTDAY = 65;
	public static readonly CHECK = 66;
	public static readonly EXISTS_IN = 67;
	public static readonly TO = 68;
	public static readonly RETURN = 69;
	public static readonly IMBALANCE = 70;
	public static readonly ERRORCODE = 71;
	public static readonly ALL = 72;
	public static readonly AGGREGATE = 73;
	public static readonly ERRORLEVEL = 74;
	public static readonly ORDER = 75;
	public static readonly BY = 76;
	public static readonly RANK = 77;
	public static readonly ASC = 78;
	public static readonly DESC = 79;
	public static readonly MIN = 80;
	public static readonly MAX = 81;
	public static readonly FIRST = 82;
	public static readonly LAST = 83;
	public static readonly INDEXOF = 84;
	public static readonly ABS = 85;
	public static readonly KEY = 86;
	public static readonly LN = 87;
	public static readonly LOG = 88;
	public static readonly TRUNC = 89;
	public static readonly ROUND = 90;
	public static readonly POWER = 91;
	public static readonly MOD = 92;
	public static readonly LEN = 93;
	public static readonly CONCAT = 94;
	public static readonly TRIM = 95;
	public static readonly UCASE = 96;
	public static readonly LCASE = 97;
	public static readonly SUBSTR = 98;
	public static readonly SUM = 99;
	public static readonly AVG = 100;
	public static readonly MEDIAN = 101;
	public static readonly COUNT = 102;
	public static readonly DIMENSION = 103;
	public static readonly MEASURE = 104;
	public static readonly ATTRIBUTE = 105;
	public static readonly FILTER = 106;
	public static readonly MERGE = 107;
	public static readonly EXP = 108;
	public static readonly ROLE = 109;
	public static readonly VIRAL = 110;
	public static readonly CHARSET_MATCH = 111;
	public static readonly TYPE = 112;
	public static readonly NVL = 113;
	public static readonly HIERARCHY = 114;
	public static readonly OPTIONAL = 115;
	public static readonly INVALID = 116;
	public static readonly VALUE_DOMAIN = 117;
	public static readonly VARIABLE = 118;
	public static readonly DATA = 119;
	public static readonly STRUCTURE = 120;
	public static readonly DATASET = 121;
	public static readonly OPERATOR = 122;
	public static readonly DEFINE = 123;
	public static readonly PUT_SYMBOL = 124;
	public static readonly DATAPOINT = 125;
	public static readonly HIERARCHICAL = 126;
	public static readonly RULESET = 127;
	public static readonly RULE = 128;
	public static readonly END = 129;
	public static readonly ALTER_DATASET = 130;
	public static readonly LTRIM = 131;
	public static readonly RTRIM = 132;
	public static readonly INSTR = 133;
	public static readonly REPLACE = 134;
	public static readonly CEIL = 135;
	public static readonly FLOOR = 136;
	public static readonly SQRT = 137;
	public static readonly ANY = 138;
	public static readonly SETDIFF = 139;
	public static readonly STDDEV_POP = 140;
	public static readonly STDDEV_SAMP = 141;
	public static readonly VAR_POP = 142;
	public static readonly VAR_SAMP = 143;
	public static readonly GROUP = 144;
	public static readonly EXCEPT = 145;
	public static readonly HAVING = 146;
	public static readonly FIRST_VALUE = 147;
	public static readonly LAST_VALUE = 148;
	public static readonly LAG = 149;
	public static readonly LEAD = 150;
	public static readonly RATIO_TO_REPORT = 151;
	public static readonly OVER = 152;
	public static readonly PRECEDING = 153;
	public static readonly FOLLOWING = 154;
	public static readonly UNBOUNDED = 155;
	public static readonly PARTITION = 156;
	public static readonly ROWS = 157;
	public static readonly RANGE = 158;
	public static readonly CURRENT = 159;
	public static readonly VALID = 160;
	public static readonly FILL_TIME_SERIES = 161;
	public static readonly FLOW_TO_STOCK = 162;
	public static readonly STOCK_TO_FLOW = 163;
	public static readonly TIMESHIFT = 164;
	public static readonly MEASURES = 165;
	public static readonly NO_MEASURES = 166;
	public static readonly CONDITION = 167;
	public static readonly BOOLEAN = 168;
	public static readonly DATE = 169;
	public static readonly TIME_PERIOD = 170;
	public static readonly NUMBER = 171;
	public static readonly STRING = 172;
	public static readonly TIME = 173;
	public static readonly INTEGER = 174;
	public static readonly FLOAT = 175;
	public static readonly LIST = 176;
	public static readonly RECORD = 177;
	public static readonly RESTRICT = 178;
	public static readonly YYYY = 179;
	public static readonly MM = 180;
	public static readonly DD = 181;
	public static readonly MAX_LENGTH = 182;
	public static readonly REGEXP = 183;
	public static readonly IS = 184;
	public static readonly WHEN = 185;
	public static readonly FROM = 186;
	public static readonly AGGREGATES = 187;
	public static readonly POINTS = 188;
	public static readonly POINT = 189;
	public static readonly TOTAL = 190;
	public static readonly PARTIAL = 191;
	public static readonly ALWAYS = 192;
	public static readonly INNER_JOIN = 193;
	public static readonly LEFT_JOIN = 194;
	public static readonly CROSS_JOIN = 195;
	public static readonly FULL_JOIN = 196;
	public static readonly MAPS_FROM = 197;
	public static readonly MAPS_TO = 198;
	public static readonly MAP_TO = 199;
	public static readonly MAP_FROM = 200;
	public static readonly RETURNS = 201;
	public static readonly PIVOT = 202;
	public static readonly CUSTOMPIVOT = 203;
	public static readonly UNPIVOT = 204;
	public static readonly SUBSPACE = 205;
	public static readonly APPLY = 206;
	public static readonly CONDITIONED = 207;
	public static readonly PERIOD_INDICATOR = 208;
	public static readonly SINGLE = 209;
	public static readonly DURATION = 210;
	public static readonly TIME_AGG = 211;
	public static readonly UNIT = 212;
	public static readonly VALUE = 213;
	public static readonly VALUEDOMAINS = 214;
	public static readonly VARIABLES = 215;
	public static readonly INPUT = 216;
	public static readonly OUTPUT = 217;
	public static readonly CAST = 218;
	public static readonly RULE_PRIORITY = 219;
	public static readonly DATASET_PRIORITY = 220;
	public static readonly DEFAULT = 221;
	public static readonly CHECK_DATAPOINT = 222;
	public static readonly CHECK_HIERARCHY = 223;
	public static readonly COMPUTED = 224;
	public static readonly NON_NULL = 225;
	public static readonly NON_ZERO = 226;
	public static readonly PARTIAL_NULL = 227;
	public static readonly PARTIAL_ZERO = 228;
	public static readonly ALWAYS_NULL = 229;
	public static readonly ALWAYS_ZERO = 230;
	public static readonly COMPONENTS = 231;
	public static readonly ALL_MEASURES = 232;
	public static readonly SCALAR = 233;
	public static readonly COMPONENT = 234;
	public static readonly DATAPOINT_ON_VD = 235;
	public static readonly DATAPOINT_ON_VAR = 236;
	public static readonly HIERARCHICAL_ON_VD = 237;
	public static readonly HIERARCHICAL_ON_VAR = 238;
	public static readonly SET = 239;
	public static readonly LANGUAGE = 240;
	public static readonly INTEGER_CONSTANT = 241;
	public static readonly NUMBER_CONSTANT = 242;
	public static readonly BOOLEAN_CONSTANT = 243;
	public static readonly STRING_CONSTANT = 244;
	public static readonly IDENTIFIER = 245;
	public static readonly WS = 246;
	public static readonly EOL = 247;
	public static readonly ML_COMMENT = 248;
	public static readonly SL_COMMENT = 249;
	public static readonly EOF = Token.EOF;
	public static readonly RULE_start = 0;
	public static readonly RULE_statement = 1;
	public static readonly RULE_expr = 2;
	public static readonly RULE_exprComponent = 3;
	public static readonly RULE_functionsComponents = 4;
	public static readonly RULE_functions = 5;
	public static readonly RULE_datasetClause = 6;
	public static readonly RULE_renameClause = 7;
	public static readonly RULE_aggrClause = 8;
	public static readonly RULE_filterClause = 9;
	public static readonly RULE_calcClause = 10;
	public static readonly RULE_keepOrDropClause = 11;
	public static readonly RULE_pivotOrUnpivotClause = 12;
	public static readonly RULE_customPivotClause = 13;
	public static readonly RULE_subspaceClause = 14;
	public static readonly RULE_joinOperators = 15;
	public static readonly RULE_defOperators = 16;
	public static readonly RULE_genericOperators = 17;
	public static readonly RULE_genericOperatorsComponent = 18;
	public static readonly RULE_parameterComponent = 19;
	public static readonly RULE_parameter = 20;
	public static readonly RULE_stringOperators = 21;
	public static readonly RULE_stringOperatorsComponent = 22;
	public static readonly RULE_numericOperators = 23;
	public static readonly RULE_numericOperatorsComponent = 24;
	public static readonly RULE_comparisonOperators = 25;
	public static readonly RULE_comparisonOperatorsComponent = 26;
	public static readonly RULE_timeOperators = 27;
	public static readonly RULE_timeOperatorsComponent = 28;
	public static readonly RULE_setOperators = 29;
	public static readonly RULE_hierarchyOperators = 30;
	public static readonly RULE_validationOperators = 31;
	public static readonly RULE_conditionalOperators = 32;
	public static readonly RULE_conditionalOperatorsComponent = 33;
	public static readonly RULE_aggrOperators = 34;
	public static readonly RULE_aggrOperatorsGrouping = 35;
	public static readonly RULE_anFunction = 36;
	public static readonly RULE_anFunctionComponent = 37;
	public static readonly RULE_renameClauseItem = 38;
	public static readonly RULE_aggregateClause = 39;
	public static readonly RULE_aggrFunctionClause = 40;
	public static readonly RULE_calcClauseItem = 41;
	public static readonly RULE_subspaceClauseItem = 42;
	public static readonly RULE_scalarItem = 43;
	public static readonly RULE_joinClauseWithoutUsing = 44;
	public static readonly RULE_joinClause = 45;
	public static readonly RULE_joinClauseItem = 46;
	public static readonly RULE_joinBody = 47;
	public static readonly RULE_joinApplyClause = 48;
	public static readonly RULE_partitionByClause = 49;
	public static readonly RULE_orderByClause = 50;
	public static readonly RULE_orderByItem = 51;
	public static readonly RULE_windowingClause = 52;
	public static readonly RULE_signedInteger = 53;
	public static readonly RULE_signedNumber = 54;
	public static readonly RULE_limitClauseItem = 55;
	public static readonly RULE_groupingClause = 56;
	public static readonly RULE_havingClause = 57;
	public static readonly RULE_parameterItem = 58;
	public static readonly RULE_outputParameterType = 59;
	public static readonly RULE_outputParameterTypeComponent = 60;
	public static readonly RULE_inputParameterType = 61;
	public static readonly RULE_rulesetType = 62;
	public static readonly RULE_scalarType = 63;
	public static readonly RULE_componentType = 64;
	public static readonly RULE_datasetType = 65;
	public static readonly RULE_evalDatasetType = 66;
	public static readonly RULE_scalarSetType = 67;
	public static readonly RULE_dpRuleset = 68;
	public static readonly RULE_hrRuleset = 69;
	public static readonly RULE_valueDomainName = 70;
	public static readonly RULE_rulesetID = 71;
	public static readonly RULE_rulesetSignature = 72;
	public static readonly RULE_signature = 73;
	public static readonly RULE_ruleClauseDatapoint = 74;
	public static readonly RULE_ruleItemDatapoint = 75;
	public static readonly RULE_ruleClauseHierarchical = 76;
	public static readonly RULE_ruleItemHierarchical = 77;
	public static readonly RULE_hierRuleSignature = 78;
	public static readonly RULE_valueDomainSignature = 79;
	public static readonly RULE_codeItemRelation = 80;
	public static readonly RULE_codeItemRelationClause = 81;
	public static readonly RULE_valueDomainValue = 82;
	public static readonly RULE_scalarTypeConstraint = 83;
	public static readonly RULE_compConstraint = 84;
	public static readonly RULE_multModifier = 85;
	public static readonly RULE_validationOutput = 86;
	public static readonly RULE_validationMode = 87;
	public static readonly RULE_conditionClause = 88;
	public static readonly RULE_inputMode = 89;
	public static readonly RULE_imbalanceExpr = 90;
	public static readonly RULE_inputModeHierarchy = 91;
	public static readonly RULE_outputModeHierarchy = 92;
	public static readonly RULE_alias = 93;
	public static readonly RULE_varID = 94;
	public static readonly RULE_simpleComponentId = 95;
	public static readonly RULE_componentID = 96;
	public static readonly RULE_lists = 97;
	public static readonly RULE_erCode = 98;
	public static readonly RULE_erLevel = 99;
	public static readonly RULE_comparisonOperand = 100;
	public static readonly RULE_optionalExpr = 101;
	public static readonly RULE_optionalExprComponent = 102;
	public static readonly RULE_componentRole = 103;
	public static readonly RULE_viralAttribute = 104;
	public static readonly RULE_valueDomainID = 105;
	public static readonly RULE_operatorID = 106;
	public static readonly RULE_routineName = 107;
	public static readonly RULE_constant = 108;
	public static readonly RULE_basicScalarType = 109;
	public static readonly RULE_retainType = 110;
	public static readonly literalNames: (string | null)[] = [ null, "'('", 
                                                            "')'", "'['", 
                                                            "']'", "'{'", 
                                                            "'}'", "'='", 
                                                            "'<'", "'>'", 
                                                            "'>='", "'<>'", 
                                                            "'<='", "'+'", 
                                                            "'-'", "'*'", 
                                                            "'/'", "','", 
                                                            "'->'", "':'", 
                                                            "':='", "'#'", 
                                                            "'eval'", "'if'", 
                                                            "'case'", "'then'", 
                                                            "'else'", "'using'", 
                                                            "'with'", "'current_date'", 
                                                            "'datediff'", 
                                                            "'dateadd'", 
                                                            "'getyear'", 
                                                            "'getmonth'", 
                                                            "'dayofmonth'", 
                                                            "'dayofyear'", 
                                                            "'daytoyear'", 
                                                            "'daytomonth'", 
                                                            "'yeartoday'", 
                                                            "'monthtoday'", 
                                                            "'on'", "'drop'", 
                                                            "'keep'", "'calc'", 
                                                            "'attrcalc'", 
                                                            "'rename'", 
                                                            "'as'", "'and'", 
                                                            "'or'", "'xor'", 
                                                            "'not'", "'between'", 
                                                            "'in'", "'not_in'", 
                                                            "'null'", "'isnull'", 
                                                            "'ex'", "'union'", 
                                                            "'diff'", "'symdiff'", 
                                                            "'intersect'", 
                                                            "'random'", 
                                                            "'keys'", "'intyear'", 
                                                            "'intmonth'", 
                                                            "'intday'", 
                                                            "'check'", "'exists_in'", 
                                                            "'to'", "'return'", 
                                                            "'imbalance'", 
                                                            "'errorcode'", 
                                                            "'all'", "'aggr'", 
                                                            "'errorlevel'", 
                                                            "'order'", "'by'", 
                                                            "'rank'", "'asc'", 
                                                            "'desc'", "'min'", 
                                                            "'max'", "'first'", 
                                                            "'last'", "'indexof'", 
                                                            "'abs'", "'key'", 
                                                            "'ln'", "'log'", 
                                                            "'trunc'", "'round'", 
                                                            "'power'", "'mod'", 
                                                            "'length'", 
                                                            "'||'", "'trim'", 
                                                            "'upper'", "'lower'", 
                                                            "'substr'", 
                                                            "'sum'", "'avg'", 
                                                            "'median'", 
                                                            "'count'", "'identifier'", 
                                                            "'measure'", 
                                                            "'attribute'", 
                                                            "'filter'", 
                                                            "'merge'", "'exp'", 
                                                            "'componentRole'", 
                                                            "'viral'", "'match_characters'", 
                                                            "'type'", "'nvl'", 
                                                            "'hierarchy'", 
                                                            "'_'", "'invalid'", 
                                                            "'valuedomain'", 
                                                            "'variable'", 
                                                            "'data'", "'structure'", 
                                                            "'dataset'", 
                                                            "'operator'", 
                                                            "'define'", 
                                                            "'<-'", "'datapoint'", 
                                                            "'hierarchical'", 
                                                            "'ruleset'", 
                                                            "'rule'", "'end'", 
                                                            "'alterDataset'", 
                                                            "'ltrim'", "'rtrim'", 
                                                            "'instr'", "'replace'", 
                                                            "'ceil'", "'floor'", 
                                                            "'sqrt'", "'any'", 
                                                            "'setdiff'", 
                                                            "'stddev_pop'", 
                                                            "'stddev_samp'", 
                                                            "'var_pop'", 
                                                            "'var_samp'", 
                                                            "'group'", "'except'", 
                                                            "'having'", 
                                                            "'first_value'", 
                                                            "'last_value'", 
                                                            "'lag'", "'lead'", 
                                                            "'ratio_to_report'", 
                                                            "'over'", "'preceding'", 
                                                            "'following'", 
                                                            "'unbounded'", 
                                                            "'partition'", 
                                                            "'rows'", "'range'", 
                                                            "'current'", 
                                                            "'valid'", "'fill_time_series'", 
                                                            "'flow_to_stock'", 
                                                            "'stock_to_flow'", 
                                                            "'timeshift'", 
                                                            "'measures'", 
                                                            "'no_measures'", 
                                                            "'condition'", 
                                                            "'boolean'", 
                                                            "'date'", "'time_period'", 
                                                            "'number'", 
                                                            "'string'", 
                                                            "'time'", "'integer'", 
                                                            "'float'", "'list'", 
                                                            "'record'", 
                                                            "'restrict'", 
                                                            "'yyyy'", "'mm'", 
                                                            "'dd'", "'maxLength'", 
                                                            "'regexp'", 
                                                            "'is'", "'when'", 
                                                            "'from'", "'aggregates'", 
                                                            "'points'", 
                                                            "'point'", "'total'", 
                                                            "'partial'", 
                                                            "'always'", 
                                                            "'inner_join'", 
                                                            "'left_join'", 
                                                            "'cross_join'", 
                                                            "'full_join'", 
                                                            "'maps_from'", 
                                                            "'maps_to'", 
                                                            "'map_to'", 
                                                            "'map_from'", 
                                                            "'returns'", 
                                                            "'pivot'", "'customPivot'", 
                                                            "'unpivot'", 
                                                            "'sub'", "'apply'", 
                                                            "'conditioned'", 
                                                            "'period_indicator'", 
                                                            "'single'", 
                                                            "'duration'", 
                                                            "'time_agg'", 
                                                            "'unit'", "'Value'", 
                                                            "'valuedomains'", 
                                                            "'variables'", 
                                                            "'input'", "'output'", 
                                                            "'cast'", "'rule_priority'", 
                                                            "'dataset_priority'", 
                                                            "'default'", 
                                                            "'check_datapoint'", 
                                                            "'check_hierarchy'", 
                                                            "'computed'", 
                                                            "'non_null'", 
                                                            "'non_zero'", 
                                                            "'partial_null'", 
                                                            "'partial_zero'", 
                                                            "'always_null'", 
                                                            "'always_zero'", 
                                                            "'components'", 
                                                            "'all_measures'", 
                                                            "'scalar'", 
                                                            "'component'", 
                                                            "'datapoint_on_valuedomains'", 
                                                            "'datapoint_on_variables'", 
                                                            "'hierarchical_on_valuedomains'", 
                                                            "'hierarchical_on_variables'", 
                                                            "'set'", "'language'", 
                                                            null, null, 
                                                            null, null, 
                                                            null, null, 
                                                            "';'" ];
	public static readonly symbolicNames: (string | null)[] = [ null, "LPAREN", 
                                                             "RPAREN", "QLPAREN", 
                                                             "QRPAREN", 
                                                             "GLPAREN", 
                                                             "GRPAREN", 
                                                             "EQ", "LT", 
                                                             "MT", "ME", 
                                                             "NEQ", "LE", 
                                                             "PLUS", "MINUS", 
                                                             "MUL", "DIV", 
                                                             "COMMA", "POINTER", 
                                                             "COLON", "ASSIGN", 
                                                             "MEMBERSHIP", 
                                                             "EVAL", "IF", 
                                                             "CASE", "THEN", 
                                                             "ELSE", "USING", 
                                                             "WITH", "CURRENT_DATE", 
                                                             "DATEDIFF", 
                                                             "DATEADD", 
                                                             "YEAR_OP", 
                                                             "MONTH_OP", 
                                                             "DAYOFMONTH", 
                                                             "DAYOFYEAR", 
                                                             "DAYTOYEAR", 
                                                             "DAYTOMONTH", 
                                                             "YEARTODAY", 
                                                             "MONTHTODAY", 
                                                             "ON", "DROP", 
                                                             "KEEP", "CALC", 
                                                             "ATTRCALC", 
                                                             "RENAME", "AS", 
                                                             "AND", "OR", 
                                                             "XOR", "NOT", 
                                                             "BETWEEN", 
                                                             "IN", "NOT_IN", 
                                                             "NULL_CONSTANT", 
                                                             "ISNULL", "EX", 
                                                             "UNION", "DIFF", 
                                                             "SYMDIFF", 
                                                             "INTERSECT", 
                                                             "RANDOM", "KEYS", 
                                                             "INTYEAR", 
                                                             "INTMONTH", 
                                                             "INTDAY", "CHECK", 
                                                             "EXISTS_IN", 
                                                             "TO", "RETURN", 
                                                             "IMBALANCE", 
                                                             "ERRORCODE", 
                                                             "ALL", "AGGREGATE", 
                                                             "ERRORLEVEL", 
                                                             "ORDER", "BY", 
                                                             "RANK", "ASC", 
                                                             "DESC", "MIN", 
                                                             "MAX", "FIRST", 
                                                             "LAST", "INDEXOF", 
                                                             "ABS", "KEY", 
                                                             "LN", "LOG", 
                                                             "TRUNC", "ROUND", 
                                                             "POWER", "MOD", 
                                                             "LEN", "CONCAT", 
                                                             "TRIM", "UCASE", 
                                                             "LCASE", "SUBSTR", 
                                                             "SUM", "AVG", 
                                                             "MEDIAN", "COUNT", 
                                                             "DIMENSION", 
                                                             "MEASURE", 
                                                             "ATTRIBUTE", 
                                                             "FILTER", "MERGE", 
                                                             "EXP", "ROLE", 
                                                             "VIRAL", "CHARSET_MATCH", 
                                                             "TYPE", "NVL", 
                                                             "HIERARCHY", 
                                                             "OPTIONAL", 
                                                             "INVALID", 
                                                             "VALUE_DOMAIN", 
                                                             "VARIABLE", 
                                                             "DATA", "STRUCTURE", 
                                                             "DATASET", 
                                                             "OPERATOR", 
                                                             "DEFINE", "PUT_SYMBOL", 
                                                             "DATAPOINT", 
                                                             "HIERARCHICAL", 
                                                             "RULESET", 
                                                             "RULE", "END", 
                                                             "ALTER_DATASET", 
                                                             "LTRIM", "RTRIM", 
                                                             "INSTR", "REPLACE", 
                                                             "CEIL", "FLOOR", 
                                                             "SQRT", "ANY", 
                                                             "SETDIFF", 
                                                             "STDDEV_POP", 
                                                             "STDDEV_SAMP", 
                                                             "VAR_POP", 
                                                             "VAR_SAMP", 
                                                             "GROUP", "EXCEPT", 
                                                             "HAVING", "FIRST_VALUE", 
                                                             "LAST_VALUE", 
                                                             "LAG", "LEAD", 
                                                             "RATIO_TO_REPORT", 
                                                             "OVER", "PRECEDING", 
                                                             "FOLLOWING", 
                                                             "UNBOUNDED", 
                                                             "PARTITION", 
                                                             "ROWS", "RANGE", 
                                                             "CURRENT", 
                                                             "VALID", "FILL_TIME_SERIES", 
                                                             "FLOW_TO_STOCK", 
                                                             "STOCK_TO_FLOW", 
                                                             "TIMESHIFT", 
                                                             "MEASURES", 
                                                             "NO_MEASURES", 
                                                             "CONDITION", 
                                                             "BOOLEAN", 
                                                             "DATE", "TIME_PERIOD", 
                                                             "NUMBER", "STRING", 
                                                             "TIME", "INTEGER", 
                                                             "FLOAT", "LIST", 
                                                             "RECORD", "RESTRICT", 
                                                             "YYYY", "MM", 
                                                             "DD", "MAX_LENGTH", 
                                                             "REGEXP", "IS", 
                                                             "WHEN", "FROM", 
                                                             "AGGREGATES", 
                                                             "POINTS", "POINT", 
                                                             "TOTAL", "PARTIAL", 
                                                             "ALWAYS", "INNER_JOIN", 
                                                             "LEFT_JOIN", 
                                                             "CROSS_JOIN", 
                                                             "FULL_JOIN", 
                                                             "MAPS_FROM", 
                                                             "MAPS_TO", 
                                                             "MAP_TO", "MAP_FROM", 
                                                             "RETURNS", 
                                                             "PIVOT", "CUSTOMPIVOT", 
                                                             "UNPIVOT", 
                                                             "SUBSPACE", 
                                                             "APPLY", "CONDITIONED", 
                                                             "PERIOD_INDICATOR", 
                                                             "SINGLE", "DURATION", 
                                                             "TIME_AGG", 
                                                             "UNIT", "VALUE", 
                                                             "VALUEDOMAINS", 
                                                             "VARIABLES", 
                                                             "INPUT", "OUTPUT", 
                                                             "CAST", "RULE_PRIORITY", 
                                                             "DATASET_PRIORITY", 
                                                             "DEFAULT", 
                                                             "CHECK_DATAPOINT", 
                                                             "CHECK_HIERARCHY", 
                                                             "COMPUTED", 
                                                             "NON_NULL", 
                                                             "NON_ZERO", 
                                                             "PARTIAL_NULL", 
                                                             "PARTIAL_ZERO", 
                                                             "ALWAYS_NULL", 
                                                             "ALWAYS_ZERO", 
                                                             "COMPONENTS", 
                                                             "ALL_MEASURES", 
                                                             "SCALAR", "COMPONENT", 
                                                             "DATAPOINT_ON_VD", 
                                                             "DATAPOINT_ON_VAR", 
                                                             "HIERARCHICAL_ON_VD", 
                                                             "HIERARCHICAL_ON_VAR", 
                                                             "SET", "LANGUAGE", 
                                                             "INTEGER_CONSTANT", 
                                                             "NUMBER_CONSTANT", 
                                                             "BOOLEAN_CONSTANT", 
                                                             "STRING_CONSTANT", 
                                                             "IDENTIFIER", 
                                                             "WS", "EOL", 
                                                             "ML_COMMENT", 
                                                             "SL_COMMENT" ];
	// tslint:disable:no-trailing-whitespace
	public static readonly ruleNames: string[] = [
		"start", "statement", "expr", "exprComponent", "functionsComponents", 
		"functions", "datasetClause", "renameClause", "aggrClause", "filterClause", 
		"calcClause", "keepOrDropClause", "pivotOrUnpivotClause", "customPivotClause", 
		"subspaceClause", "joinOperators", "defOperators", "genericOperators", 
		"genericOperatorsComponent", "parameterComponent", "parameter", "stringOperators", 
		"stringOperatorsComponent", "numericOperators", "numericOperatorsComponent", 
		"comparisonOperators", "comparisonOperatorsComponent", "timeOperators", 
		"timeOperatorsComponent", "setOperators", "hierarchyOperators", "validationOperators", 
		"conditionalOperators", "conditionalOperatorsComponent", "aggrOperators", 
		"aggrOperatorsGrouping", "anFunction", "anFunctionComponent", "renameClauseItem", 
		"aggregateClause", "aggrFunctionClause", "calcClauseItem", "subspaceClauseItem", 
		"scalarItem", "joinClauseWithoutUsing", "joinClause", "joinClauseItem", 
		"joinBody", "joinApplyClause", "partitionByClause", "orderByClause", "orderByItem", 
		"windowingClause", "signedInteger", "signedNumber", "limitClauseItem", 
		"groupingClause", "havingClause", "parameterItem", "outputParameterType", 
		"outputParameterTypeComponent", "inputParameterType", "rulesetType", "scalarType", 
		"componentType", "datasetType", "evalDatasetType", "scalarSetType", "dpRuleset", 
		"hrRuleset", "valueDomainName", "rulesetID", "rulesetSignature", "signature", 
		"ruleClauseDatapoint", "ruleItemDatapoint", "ruleClauseHierarchical", 
		"ruleItemHierarchical", "hierRuleSignature", "valueDomainSignature", "codeItemRelation", 
		"codeItemRelationClause", "valueDomainValue", "scalarTypeConstraint", 
		"compConstraint", "multModifier", "validationOutput", "validationMode", 
		"conditionClause", "inputMode", "imbalanceExpr", "inputModeHierarchy", 
		"outputModeHierarchy", "alias", "varID", "simpleComponentId", "componentID", 
		"lists", "erCode", "erLevel", "comparisonOperand", "optionalExpr", "optionalExprComponent", 
		"componentRole", "viralAttribute", "valueDomainID", "operatorID", "routineName", 
		"constant", "basicScalarType", "retainType",
	];
	public get grammarFileName(): string { return "VtlParser.g4"; }
	public get literalNames(): (string | null)[] { return VtlParser.literalNames; }
	public get symbolicNames(): (string | null)[] { return VtlParser.symbolicNames; }
	public get ruleNames(): string[] { return VtlParser.ruleNames; }
	public get serializedATN(): number[] { return VtlParser._serializedATN; }

	protected createFailedPredicateException(predicate?: string, message?: string): FailedPredicateException {
		return new FailedPredicateException(this, predicate, message);
	}

	constructor(input: TokenStream) {
		super(input);
		this._interp = new ParserATNSimulator(this, VtlParser._ATN, VtlParser.DecisionsToDFA, new PredictionContextCache());
	}
	// @RuleVersion(0)
	public start(): StartContext {
		let localctx: StartContext = new StartContext(this, this._ctx, this.state);
		this.enterRule(localctx, 0, VtlParser.RULE_start);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 227;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===123 || _la===245) {
				{
				{
				this.state = 222;
				this.statement();
				this.state = 223;
				this.match(VtlParser.EOL);
				}
				}
				this.state = 229;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 230;
			this.match(VtlParser.EOF);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public statement(): StatementContext {
		let localctx: StatementContext = new StatementContext(this, this._ctx, this.state);
		this.enterRule(localctx, 2, VtlParser.RULE_statement);
		try {
			this.state = 241;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 1, this._ctx) ) {
			case 1:
				localctx = new TemporaryAssignmentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 232;
				this.varID();
				this.state = 233;
				this.match(VtlParser.ASSIGN);
				this.state = 234;
				this.expr(0);
				}
				break;
			case 2:
				localctx = new PersistAssignmentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 236;
				this.varID();
				this.state = 237;
				this.match(VtlParser.PUT_SYMBOL);
				this.state = 238;
				this.expr(0);
				}
				break;
			case 3:
				localctx = new DefineExpressionContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 240;
				this.defOperators();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}

	public expr(): ExprContext;
	public expr(_p: number): ExprContext;
	// @RuleVersion(0)
	public expr(_p?: number): ExprContext {
		if (_p === undefined) {
			_p = 0;
		}

		let _parentctx: ParserRuleContext = this._ctx;
		let _parentState: number = this.state;
		let localctx: ExprContext = new ExprContext(this, this._ctx, _parentState);
		let _prevctx: ExprContext = localctx;
		let _startState: number = 4;
		this.enterRecursionRule(localctx, 4, VtlParser.RULE_expr, _p);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 273;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 3, this._ctx) ) {
			case 1:
				{
				localctx = new ParenthesisExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;

				this.state = 244;
				this.match(VtlParser.LPAREN);
				this.state = 245;
				this.expr(0);
				this.state = 246;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 2:
				{
				localctx = new FunctionsExpressionContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 248;
				this.functions();
				}
				break;
			case 3:
				{
				localctx = new UnaryExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 249;
				(localctx as UnaryExprContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===13 || _la===14 || _la===50)) {
				    (localctx as UnaryExprContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 250;
				(localctx as UnaryExprContext)._right = this.expr(11);
				}
				break;
			case 4:
				{
				localctx = new IfExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 251;
				this.match(VtlParser.IF);
				this.state = 252;
				(localctx as IfExprContext)._conditionalExpr = this.expr(0);
				this.state = 253;
				this.match(VtlParser.THEN);
				this.state = 254;
				(localctx as IfExprContext)._thenExpr = this.expr(0);
				this.state = 255;
				this.match(VtlParser.ELSE);
				this.state = 256;
				(localctx as IfExprContext)._elseExpr = this.expr(4);
				}
				break;
			case 5:
				{
				localctx = new CaseExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 258;
				this.match(VtlParser.CASE);
				this.state = 264;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				do {
					{
					{
					this.state = 259;
					this.match(VtlParser.WHEN);
					this.state = 260;
					(localctx as CaseExprContext)._expr = this.expr(0);
					(localctx as CaseExprContext)._condExpr.push((localctx as CaseExprContext)._expr);
					this.state = 261;
					this.match(VtlParser.THEN);
					this.state = 262;
					(localctx as CaseExprContext)._expr = this.expr(0);
					(localctx as CaseExprContext)._thenExpr.push((localctx as CaseExprContext)._expr);
					}
					}
					this.state = 266;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				} while (_la===185);
				this.state = 268;
				this.match(VtlParser.ELSE);
				this.state = 269;
				(localctx as CaseExprContext)._elseExpr = this.expr(3);
				}
				break;
			case 6:
				{
				localctx = new ConstantExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 271;
				this.constant();
				}
				break;
			case 7:
				{
				localctx = new VarIdExprContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 272;
				this.varID();
				}
				break;
			}
			this._ctx.stop = this._input.LT(-1);
			this.state = 307;
			this._errHandler.sync(this);
			_alt = this._interp.adaptivePredict(this._input, 6, this._ctx);
			while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
				if (_alt === 1) {
					if (this._parseListeners != null) {
						this.triggerExitRuleEvent();
					}
					_prevctx = localctx;
					{
					this.state = 305;
					this._errHandler.sync(this);
					switch ( this._interp.adaptivePredict(this._input, 5, this._ctx) ) {
					case 1:
						{
						localctx = new ArithmeticExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 275;
						if (!(this.precpred(this._ctx, 10))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 10)");
						}
						this.state = 276;
						(localctx as ArithmeticExprContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===15 || _la===16)) {
						    (localctx as ArithmeticExprContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 277;
						(localctx as ArithmeticExprContext)._right = this.expr(11);
						}
						break;
					case 2:
						{
						localctx = new ArithmeticExprOrConcatContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprOrConcatContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 278;
						if (!(this.precpred(this._ctx, 9))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 9)");
						}
						this.state = 279;
						(localctx as ArithmeticExprOrConcatContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===13 || _la===14 || _la===94)) {
						    (localctx as ArithmeticExprOrConcatContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 280;
						(localctx as ArithmeticExprOrConcatContext)._right = this.expr(10);
						}
						break;
					case 3:
						{
						localctx = new ComparisonExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ComparisonExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 281;
						if (!(this.precpred(this._ctx, 8))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 8)");
						}
						this.state = 282;
						(localctx as ComparisonExprContext)._op = this.comparisonOperand();
						this.state = 283;
						(localctx as ComparisonExprContext)._right = this.expr(9);
						}
						break;
					case 4:
						{
						localctx = new BooleanExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as BooleanExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 285;
						if (!(this.precpred(this._ctx, 6))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 6)");
						}
						this.state = 286;
						(localctx as BooleanExprContext)._op = this.match(VtlParser.AND);
						this.state = 287;
						(localctx as BooleanExprContext)._right = this.expr(7);
						}
						break;
					case 5:
						{
						localctx = new BooleanExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as BooleanExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 288;
						if (!(this.precpred(this._ctx, 5))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 5)");
						}
						this.state = 289;
						(localctx as BooleanExprContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===48 || _la===49)) {
						    (localctx as BooleanExprContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 290;
						(localctx as BooleanExprContext)._right = this.expr(6);
						}
						break;
					case 6:
						{
						localctx = new ClauseExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as ClauseExprContext)._dataset = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 291;
						if (!(this.precpred(this._ctx, 13))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 13)");
						}
						this.state = 292;
						this.match(VtlParser.QLPAREN);
						this.state = 293;
						(localctx as ClauseExprContext)._clause = this.datasetClause();
						this.state = 294;
						this.match(VtlParser.QRPAREN);
						}
						break;
					case 7:
						{
						localctx = new MembershipExprContext(this, new ExprContext(this, _parentctx, _parentState));
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 296;
						if (!(this.precpred(this._ctx, 12))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 12)");
						}
						this.state = 297;
						this.match(VtlParser.MEMBERSHIP);
						this.state = 298;
						this.simpleComponentId();
						}
						break;
					case 8:
						{
						localctx = new InNotInExprContext(this, new ExprContext(this, _parentctx, _parentState));
						(localctx as InNotInExprContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_expr);
						this.state = 299;
						if (!(this.precpred(this._ctx, 7))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 7)");
						}
						this.state = 300;
						(localctx as InNotInExprContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===52 || _la===53)) {
						    (localctx as InNotInExprContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 303;
						this._errHandler.sync(this);
						switch (this._input.LA(1)) {
						case 5:
							{
							this.state = 301;
							this.lists();
							}
							break;
						case 245:
							{
							this.state = 302;
							this.valueDomainID();
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						}
						break;
					}
					}
				}
				this.state = 309;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 6, this._ctx);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.unrollRecursionContexts(_parentctx);
		}
		return localctx;
	}

	public exprComponent(): ExprComponentContext;
	public exprComponent(_p: number): ExprComponentContext;
	// @RuleVersion(0)
	public exprComponent(_p?: number): ExprComponentContext {
		if (_p === undefined) {
			_p = 0;
		}

		let _parentctx: ParserRuleContext = this._ctx;
		let _parentState: number = this.state;
		let localctx: ExprComponentContext = new ExprComponentContext(this, this._ctx, _parentState);
		let _prevctx: ExprComponentContext = localctx;
		let _startState: number = 6;
		this.enterRecursionRule(localctx, 6, VtlParser.RULE_exprComponent, _p);
		let _la: number;
		try {
			let _alt: number;
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 340;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 8, this._ctx) ) {
			case 1:
				{
				localctx = new ParenthesisExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;

				this.state = 311;
				this.match(VtlParser.LPAREN);
				this.state = 312;
				this.exprComponent(0);
				this.state = 313;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 2:
				{
				localctx = new FunctionsExpressionCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 315;
				this.functionsComponents();
				}
				break;
			case 3:
				{
				localctx = new UnaryExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 316;
				(localctx as UnaryExprCompContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===13 || _la===14 || _la===50)) {
				    (localctx as UnaryExprCompContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 317;
				(localctx as UnaryExprCompContext)._right = this.exprComponent(11);
				}
				break;
			case 4:
				{
				localctx = new IfExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 318;
				this.match(VtlParser.IF);
				this.state = 319;
				(localctx as IfExprCompContext)._conditionalExpr = this.exprComponent(0);
				this.state = 320;
				this.match(VtlParser.THEN);
				this.state = 321;
				(localctx as IfExprCompContext)._thenExpr = this.exprComponent(0);
				this.state = 322;
				this.match(VtlParser.ELSE);
				this.state = 323;
				(localctx as IfExprCompContext)._elseExpr = this.exprComponent(4);
				}
				break;
			case 5:
				{
				localctx = new CaseExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 325;
				this.match(VtlParser.CASE);
				this.state = 331;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				do {
					{
					{
					this.state = 326;
					this.match(VtlParser.WHEN);
					this.state = 327;
					(localctx as CaseExprCompContext)._exprComponent = this.exprComponent(0);
					(localctx as CaseExprCompContext)._condExpr.push((localctx as CaseExprCompContext)._exprComponent);
					this.state = 328;
					this.match(VtlParser.THEN);
					this.state = 329;
					(localctx as CaseExprCompContext)._exprComponent = this.exprComponent(0);
					(localctx as CaseExprCompContext)._thenExpr.push((localctx as CaseExprCompContext)._exprComponent);
					}
					}
					this.state = 333;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				} while (_la===185);
				this.state = 335;
				this.match(VtlParser.ELSE);
				this.state = 336;
				(localctx as CaseExprCompContext)._elseExpr = this.exprComponent(3);
				}
				break;
			case 6:
				{
				localctx = new ConstantExprCompContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 338;
				this.constant();
				}
				break;
			case 7:
				{
				localctx = new CompIdContext(this, localctx);
				this._ctx = localctx;
				_prevctx = localctx;
				this.state = 339;
				this.componentID();
				}
				break;
			}
			this._ctx.stop = this._input.LT(-1);
			this.state = 366;
			this._errHandler.sync(this);
			_alt = this._interp.adaptivePredict(this._input, 11, this._ctx);
			while (_alt !== 2 && _alt !== ATN.INVALID_ALT_NUMBER) {
				if (_alt === 1) {
					if (this._parseListeners != null) {
						this.triggerExitRuleEvent();
					}
					_prevctx = localctx;
					{
					this.state = 364;
					this._errHandler.sync(this);
					switch ( this._interp.adaptivePredict(this._input, 10, this._ctx) ) {
					case 1:
						{
						localctx = new ArithmeticExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_exprComponent);
						this.state = 342;
						if (!(this.precpred(this._ctx, 10))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 10)");
						}
						this.state = 343;
						(localctx as ArithmeticExprCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===15 || _la===16)) {
						    (localctx as ArithmeticExprCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 344;
						(localctx as ArithmeticExprCompContext)._right = this.exprComponent(11);
						}
						break;
					case 2:
						{
						localctx = new ArithmeticExprOrConcatCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as ArithmeticExprOrConcatCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_exprComponent);
						this.state = 345;
						if (!(this.precpred(this._ctx, 9))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 9)");
						}
						this.state = 346;
						(localctx as ArithmeticExprOrConcatCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===13 || _la===14 || _la===94)) {
						    (localctx as ArithmeticExprOrConcatCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 347;
						(localctx as ArithmeticExprOrConcatCompContext)._right = this.exprComponent(10);
						}
						break;
					case 3:
						{
						localctx = new ComparisonExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as ComparisonExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_exprComponent);
						this.state = 348;
						if (!(this.precpred(this._ctx, 8))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 8)");
						}
						this.state = 349;
						this.comparisonOperand();
						this.state = 350;
						(localctx as ComparisonExprCompContext)._right = this.exprComponent(9);
						}
						break;
					case 4:
						{
						localctx = new BooleanExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as BooleanExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_exprComponent);
						this.state = 352;
						if (!(this.precpred(this._ctx, 6))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 6)");
						}
						this.state = 353;
						(localctx as BooleanExprCompContext)._op = this.match(VtlParser.AND);
						this.state = 354;
						(localctx as BooleanExprCompContext)._right = this.exprComponent(7);
						}
						break;
					case 5:
						{
						localctx = new BooleanExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as BooleanExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_exprComponent);
						this.state = 355;
						if (!(this.precpred(this._ctx, 5))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 5)");
						}
						this.state = 356;
						(localctx as BooleanExprCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===48 || _la===49)) {
						    (localctx as BooleanExprCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 357;
						(localctx as BooleanExprCompContext)._right = this.exprComponent(6);
						}
						break;
					case 6:
						{
						localctx = new InNotInExprCompContext(this, new ExprComponentContext(this, _parentctx, _parentState));
						(localctx as InNotInExprCompContext)._left = _prevctx;
						this.pushNewRecursionContext(localctx, _startState, VtlParser.RULE_exprComponent);
						this.state = 358;
						if (!(this.precpred(this._ctx, 7))) {
							throw this.createFailedPredicateException("this.precpred(this._ctx, 7)");
						}
						this.state = 359;
						(localctx as InNotInExprCompContext)._op = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===52 || _la===53)) {
						    (localctx as InNotInExprCompContext)._op = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						this.state = 362;
						this._errHandler.sync(this);
						switch (this._input.LA(1)) {
						case 5:
							{
							this.state = 360;
							this.lists();
							}
							break;
						case 245:
							{
							this.state = 361;
							this.valueDomainID();
							}
							break;
						default:
							throw new NoViableAltException(this);
						}
						}
						break;
					}
					}
				}
				this.state = 368;
				this._errHandler.sync(this);
				_alt = this._interp.adaptivePredict(this._input, 11, this._ctx);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.unrollRecursionContexts(_parentctx);
		}
		return localctx;
	}
	// @RuleVersion(0)
	public functionsComponents(): FunctionsComponentsContext {
		let localctx: FunctionsComponentsContext = new FunctionsComponentsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 8, VtlParser.RULE_functionsComponents);
		try {
			this.state = 377;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 12, this._ctx) ) {
			case 1:
				localctx = new GenericFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 369;
				this.genericOperatorsComponent();
				}
				break;
			case 2:
				localctx = new StringFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 370;
				this.stringOperatorsComponent();
				}
				break;
			case 3:
				localctx = new NumericFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 371;
				this.numericOperatorsComponent();
				}
				break;
			case 4:
				localctx = new ComparisonFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 372;
				this.comparisonOperatorsComponent();
				}
				break;
			case 5:
				localctx = new TimeFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 373;
				this.timeOperatorsComponent();
				}
				break;
			case 6:
				localctx = new ConditionalFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 374;
				this.conditionalOperatorsComponent();
				}
				break;
			case 7:
				localctx = new AggregateFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 375;
				this.aggrOperators();
				}
				break;
			case 8:
				localctx = new AnalyticFunctionsComponentsContext(this, localctx);
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 376;
				this.anFunctionComponent();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public functions(): FunctionsContext {
		let localctx: FunctionsContext = new FunctionsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 10, VtlParser.RULE_functions);
		try {
			this.state = 391;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 13, this._ctx) ) {
			case 1:
				localctx = new JoinFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 379;
				this.joinOperators();
				}
				break;
			case 2:
				localctx = new GenericFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 380;
				this.genericOperators();
				}
				break;
			case 3:
				localctx = new StringFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 381;
				this.stringOperators();
				}
				break;
			case 4:
				localctx = new NumericFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 382;
				this.numericOperators();
				}
				break;
			case 5:
				localctx = new ComparisonFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 383;
				this.comparisonOperators();
				}
				break;
			case 6:
				localctx = new TimeFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 384;
				this.timeOperators();
				}
				break;
			case 7:
				localctx = new SetFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 385;
				this.setOperators();
				}
				break;
			case 8:
				localctx = new HierarchyFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 386;
				this.hierarchyOperators();
				}
				break;
			case 9:
				localctx = new ValidationFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 9);
				{
				this.state = 387;
				this.validationOperators();
				}
				break;
			case 10:
				localctx = new ConditionalFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 10);
				{
				this.state = 388;
				this.conditionalOperators();
				}
				break;
			case 11:
				localctx = new AggregateFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 11);
				{
				this.state = 389;
				this.aggrOperatorsGrouping();
				}
				break;
			case 12:
				localctx = new AnalyticFunctionsContext(this, localctx);
				this.enterOuterAlt(localctx, 12);
				{
				this.state = 390;
				this.anFunction();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public datasetClause(): DatasetClauseContext {
		let localctx: DatasetClauseContext = new DatasetClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 12, VtlParser.RULE_datasetClause);
		try {
			this.state = 400;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 45:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 393;
				this.renameClause();
				}
				break;
			case 73:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 394;
				this.aggrClause();
				}
				break;
			case 106:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 395;
				this.filterClause();
				}
				break;
			case 43:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 396;
				this.calcClause();
				}
				break;
			case 41:
			case 42:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 397;
				this.keepOrDropClause();
				}
				break;
			case 202:
			case 204:
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 398;
				this.pivotOrUnpivotClause();
				}
				break;
			case 205:
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 399;
				this.subspaceClause();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public renameClause(): RenameClauseContext {
		let localctx: RenameClauseContext = new RenameClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 14, VtlParser.RULE_renameClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 402;
			this.match(VtlParser.RENAME);
			this.state = 403;
			this.renameClauseItem();
			this.state = 408;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 404;
				this.match(VtlParser.COMMA);
				this.state = 405;
				this.renameClauseItem();
				}
				}
				this.state = 410;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrClause(): AggrClauseContext {
		let localctx: AggrClauseContext = new AggrClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 16, VtlParser.RULE_aggrClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 411;
			this.match(VtlParser.AGGREGATE);
			this.state = 412;
			this.aggregateClause();
			this.state = 417;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===144) {
				{
				this.state = 413;
				this.groupingClause();
				this.state = 415;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===146) {
					{
					this.state = 414;
					this.havingClause();
					}
				}

				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public filterClause(): FilterClauseContext {
		let localctx: FilterClauseContext = new FilterClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 18, VtlParser.RULE_filterClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 419;
			this.match(VtlParser.FILTER);
			this.state = 420;
			this.exprComponent(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public calcClause(): CalcClauseContext {
		let localctx: CalcClauseContext = new CalcClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 20, VtlParser.RULE_calcClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 422;
			this.match(VtlParser.CALC);
			this.state = 423;
			this.calcClauseItem();
			this.state = 428;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 424;
				this.match(VtlParser.COMMA);
				this.state = 425;
				this.calcClauseItem();
				}
				}
				this.state = 430;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public keepOrDropClause(): KeepOrDropClauseContext {
		let localctx: KeepOrDropClauseContext = new KeepOrDropClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 22, VtlParser.RULE_keepOrDropClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 431;
			localctx._op = this._input.LT(1);
			_la = this._input.LA(1);
			if(!(_la===41 || _la===42)) {
			    localctx._op = this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 432;
			this.componentID();
			this.state = 437;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 433;
				this.match(VtlParser.COMMA);
				this.state = 434;
				this.componentID();
				}
				}
				this.state = 439;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public pivotOrUnpivotClause(): PivotOrUnpivotClauseContext {
		let localctx: PivotOrUnpivotClauseContext = new PivotOrUnpivotClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 24, VtlParser.RULE_pivotOrUnpivotClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 440;
			localctx._op = this._input.LT(1);
			_la = this._input.LA(1);
			if(!(_la===202 || _la===204)) {
			    localctx._op = this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 441;
			localctx._id_ = this.componentID();
			this.state = 442;
			this.match(VtlParser.COMMA);
			this.state = 443;
			localctx._mea = this.componentID();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public customPivotClause(): CustomPivotClauseContext {
		let localctx: CustomPivotClauseContext = new CustomPivotClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 26, VtlParser.RULE_customPivotClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 445;
			this.match(VtlParser.CUSTOMPIVOT);
			this.state = 446;
			localctx._id_ = this.componentID();
			this.state = 447;
			this.match(VtlParser.COMMA);
			this.state = 448;
			localctx._mea = this.componentID();
			this.state = 449;
			this.match(VtlParser.IN);
			this.state = 450;
			this.constant();
			this.state = 455;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 451;
				this.match(VtlParser.COMMA);
				this.state = 452;
				this.constant();
				}
				}
				this.state = 457;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public subspaceClause(): SubspaceClauseContext {
		let localctx: SubspaceClauseContext = new SubspaceClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 28, VtlParser.RULE_subspaceClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 458;
			this.match(VtlParser.SUBSPACE);
			this.state = 459;
			this.subspaceClauseItem();
			this.state = 464;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 460;
				this.match(VtlParser.COMMA);
				this.state = 461;
				this.subspaceClauseItem();
				}
				}
				this.state = 466;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinOperators(): JoinOperatorsContext {
		let localctx: JoinOperatorsContext = new JoinOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 30, VtlParser.RULE_joinOperators);
		let _la: number;
		try {
			this.state = 479;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 193:
			case 194:
				localctx = new JoinExprContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 467;
				(localctx as JoinExprContext)._joinKeyword = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===193 || _la===194)) {
				    (localctx as JoinExprContext)._joinKeyword = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 468;
				this.match(VtlParser.LPAREN);
				this.state = 469;
				this.joinClause();
				this.state = 470;
				this.joinBody();
				this.state = 471;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 195:
			case 196:
				localctx = new JoinExprContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 473;
				(localctx as JoinExprContext)._joinKeyword = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===195 || _la===196)) {
				    (localctx as JoinExprContext)._joinKeyword = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 474;
				this.match(VtlParser.LPAREN);
				this.state = 475;
				this.joinClauseWithoutUsing();
				this.state = 476;
				this.joinBody();
				this.state = 477;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public defOperators(): DefOperatorsContext {
		let localctx: DefOperatorsContext = new DefOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 32, VtlParser.RULE_defOperators);
		let _la: number;
		try {
			this.state = 531;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 26, this._ctx) ) {
			case 1:
				localctx = new DefOperatorContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 481;
				this.match(VtlParser.DEFINE);
				this.state = 482;
				this.match(VtlParser.OPERATOR);
				this.state = 483;
				this.operatorID();
				this.state = 484;
				this.match(VtlParser.LPAREN);
				this.state = 493;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===245) {
					{
					this.state = 485;
					this.parameterItem();
					this.state = 490;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 486;
						this.match(VtlParser.COMMA);
						this.state = 487;
						this.parameterItem();
						}
						}
						this.state = 492;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 495;
				this.match(VtlParser.RPAREN);
				this.state = 498;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===201) {
					{
					this.state = 496;
					this.match(VtlParser.RETURNS);
					this.state = 497;
					this.outputParameterType();
					}
				}

				this.state = 500;
				this.match(VtlParser.IS);
				{
				this.state = 501;
				this.expr(0);
				}
				this.state = 502;
				this.match(VtlParser.END);
				this.state = 503;
				this.match(VtlParser.OPERATOR);
				}
				break;
			case 2:
				localctx = new DefDatapointRulesetContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 505;
				this.match(VtlParser.DEFINE);
				this.state = 506;
				this.match(VtlParser.DATAPOINT);
				this.state = 507;
				this.match(VtlParser.RULESET);
				this.state = 508;
				this.rulesetID();
				this.state = 509;
				this.match(VtlParser.LPAREN);
				this.state = 510;
				this.rulesetSignature();
				this.state = 511;
				this.match(VtlParser.RPAREN);
				this.state = 512;
				this.match(VtlParser.IS);
				this.state = 513;
				this.ruleClauseDatapoint();
				this.state = 514;
				this.match(VtlParser.END);
				this.state = 515;
				this.match(VtlParser.DATAPOINT);
				this.state = 516;
				this.match(VtlParser.RULESET);
				}
				break;
			case 3:
				localctx = new DefHierarchicalContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 518;
				this.match(VtlParser.DEFINE);
				this.state = 519;
				this.match(VtlParser.HIERARCHICAL);
				this.state = 520;
				this.match(VtlParser.RULESET);
				this.state = 521;
				this.rulesetID();
				this.state = 522;
				this.match(VtlParser.LPAREN);
				this.state = 523;
				this.hierRuleSignature();
				this.state = 524;
				this.match(VtlParser.RPAREN);
				this.state = 525;
				this.match(VtlParser.IS);
				this.state = 526;
				this.ruleClauseHierarchical();
				this.state = 527;
				this.match(VtlParser.END);
				this.state = 528;
				this.match(VtlParser.HIERARCHICAL);
				this.state = 529;
				this.match(VtlParser.RULESET);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public genericOperators(): GenericOperatorsContext {
		let localctx: GenericOperatorsContext = new GenericOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 34, VtlParser.RULE_genericOperators);
		let _la: number;
		try {
			this.state = 590;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 245:
				localctx = new CallDatasetContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 533;
				this.operatorID();
				this.state = 534;
				this.match(VtlParser.LPAREN);
				this.state = 543;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 3787481090) !== 0) || ((((_la - 32)) & ~0x1F) === 0 && ((1 << (_la - 32)) & 986448127) !== 0) || ((((_la - 66)) & ~0x1F) === 0 && ((1 << (_la - 66)) & 4025008131) !== 0) || ((((_la - 98)) & ~0x1F) === 0 && ((1 << (_la - 98)) & 238623) !== 0) || ((((_la - 131)) & ~0x1F) === 0 && ((1 << (_la - 131)) & 3223265151) !== 0) || ((((_la - 163)) & ~0x1F) === 0 && ((1 << (_la - 163)) & 3221225475) !== 0) || ((((_la - 195)) & ~0x1F) === 0 && ((1 << (_la - 195)) & 411115523) !== 0) || ((((_la - 241)) & ~0x1F) === 0 && ((1 << (_la - 241)) & 31) !== 0)) {
					{
					this.state = 535;
					this.parameter();
					this.state = 540;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 536;
						this.match(VtlParser.COMMA);
						this.state = 537;
						this.parameter();
						}
						}
						this.state = 542;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 545;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 22:
				localctx = new EvalAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 547;
				this.match(VtlParser.EVAL);
				this.state = 548;
				this.match(VtlParser.LPAREN);
				this.state = 549;
				this.routineName();
				this.state = 550;
				this.match(VtlParser.LPAREN);
				this.state = 553;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 245:
					{
					this.state = 551;
					this.varID();
					}
					break;
				case 13:
				case 14:
				case 54:
				case 218:
				case 241:
				case 242:
				case 243:
				case 244:
					{
					this.state = 552;
					this.scalarItem();
					}
					break;
				case 2:
				case 17:
					break;
				default:
					break;
				}
				this.state = 562;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 555;
					this.match(VtlParser.COMMA);
					this.state = 558;
					this._errHandler.sync(this);
					switch (this._input.LA(1)) {
					case 245:
						{
						this.state = 556;
						this.varID();
						}
						break;
					case 13:
					case 14:
					case 54:
					case 218:
					case 241:
					case 242:
					case 243:
					case 244:
						{
						this.state = 557;
						this.scalarItem();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					this.state = 564;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 565;
				this.match(VtlParser.RPAREN);
				this.state = 568;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===240) {
					{
					this.state = 566;
					this.match(VtlParser.LANGUAGE);
					this.state = 567;
					this.match(VtlParser.STRING_CONSTANT);
					}
				}

				this.state = 572;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===201) {
					{
					this.state = 570;
					this.match(VtlParser.RETURNS);
					this.state = 571;
					this.evalDatasetType();
					}
				}

				this.state = 574;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 218:
				localctx = new CastExprDatasetContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 576;
				this.match(VtlParser.CAST);
				this.state = 577;
				this.match(VtlParser.LPAREN);
				this.state = 578;
				this.expr(0);
				this.state = 579;
				this.match(VtlParser.COMMA);
				this.state = 582;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 168:
				case 169:
				case 170:
				case 171:
				case 172:
				case 173:
				case 174:
				case 210:
				case 233:
					{
					this.state = 580;
					this.basicScalarType();
					}
					break;
				case 245:
					{
					this.state = 581;
					this.valueDomainName();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				this.state = 586;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 584;
					this.match(VtlParser.COMMA);
					this.state = 585;
					this.match(VtlParser.STRING_CONSTANT);
					}
				}

				this.state = 588;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public genericOperatorsComponent(): GenericOperatorsComponentContext {
		let localctx: GenericOperatorsComponentContext = new GenericOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 36, VtlParser.RULE_genericOperatorsComponent);
		let _la: number;
		try {
			this.state = 649;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 245:
				localctx = new CallComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 592;
				this.operatorID();
				this.state = 593;
				this.match(VtlParser.LPAREN);
				this.state = 602;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 3787481090) !== 0) || ((((_la - 32)) & ~0x1F) === 0 && ((1 << (_la - 32)) & 550240511) !== 0) || ((((_la - 77)) & ~0x1F) === 0 && ((1 << (_la - 77)) & 2214460697) !== 0) || ((((_la - 111)) & ~0x1F) === 0 && ((1 << (_la - 111)) & 3891265557) !== 0) || ((((_la - 143)) & ~0x1F) === 0 && ((1 << (_la - 143)) & 3932657) !== 0) || ((((_la - 208)) & ~0x1F) === 0 && ((1 << (_la - 208)) & 1033) !== 0) || ((((_la - 241)) & ~0x1F) === 0 && ((1 << (_la - 241)) & 31) !== 0)) {
					{
					this.state = 594;
					this.parameterComponent();
					this.state = 599;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 595;
						this.match(VtlParser.COMMA);
						this.state = 596;
						this.parameterComponent();
						}
						}
						this.state = 601;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 604;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 218:
				localctx = new CastExprComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 606;
				this.match(VtlParser.CAST);
				this.state = 607;
				this.match(VtlParser.LPAREN);
				this.state = 608;
				this.exprComponent(0);
				this.state = 609;
				this.match(VtlParser.COMMA);
				this.state = 612;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 168:
				case 169:
				case 170:
				case 171:
				case 172:
				case 173:
				case 174:
				case 210:
				case 233:
					{
					this.state = 610;
					this.basicScalarType();
					}
					break;
				case 245:
					{
					this.state = 611;
					this.valueDomainName();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				this.state = 616;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 614;
					this.match(VtlParser.COMMA);
					this.state = 615;
					this.match(VtlParser.STRING_CONSTANT);
					}
				}

				this.state = 618;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 22:
				localctx = new EvalAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 620;
				this.match(VtlParser.EVAL);
				this.state = 621;
				this.match(VtlParser.LPAREN);
				this.state = 622;
				this.routineName();
				this.state = 623;
				this.match(VtlParser.LPAREN);
				this.state = 626;
				this._errHandler.sync(this);
				switch (this._input.LA(1)) {
				case 245:
					{
					this.state = 624;
					this.componentID();
					}
					break;
				case 13:
				case 14:
				case 54:
				case 218:
				case 241:
				case 242:
				case 243:
				case 244:
					{
					this.state = 625;
					this.scalarItem();
					}
					break;
				case 2:
				case 17:
					break;
				default:
					break;
				}
				this.state = 635;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 628;
					this.match(VtlParser.COMMA);
					this.state = 631;
					this._errHandler.sync(this);
					switch (this._input.LA(1)) {
					case 245:
						{
						this.state = 629;
						this.componentID();
						}
						break;
					case 13:
					case 14:
					case 54:
					case 218:
					case 241:
					case 242:
					case 243:
					case 244:
						{
						this.state = 630;
						this.scalarItem();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					}
					this.state = 637;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 638;
				this.match(VtlParser.RPAREN);
				this.state = 641;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===240) {
					{
					this.state = 639;
					this.match(VtlParser.LANGUAGE);
					this.state = 640;
					this.match(VtlParser.STRING_CONSTANT);
					}
				}

				this.state = 645;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===201) {
					{
					this.state = 643;
					this.match(VtlParser.RETURNS);
					this.state = 644;
					this.outputParameterTypeComponent();
					}
				}

				this.state = 647;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public parameterComponent(): ParameterComponentContext {
		let localctx: ParameterComponentContext = new ParameterComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 38, VtlParser.RULE_parameterComponent);
		try {
			this.state = 653;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 13:
			case 14:
			case 22:
			case 23:
			case 24:
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 50:
			case 51:
			case 54:
			case 55:
			case 61:
			case 77:
			case 80:
			case 81:
			case 85:
			case 87:
			case 88:
			case 89:
			case 90:
			case 91:
			case 92:
			case 93:
			case 95:
			case 96:
			case 97:
			case 98:
			case 99:
			case 100:
			case 101:
			case 102:
			case 108:
			case 111:
			case 113:
			case 131:
			case 132:
			case 133:
			case 134:
			case 135:
			case 136:
			case 137:
			case 140:
			case 141:
			case 142:
			case 143:
			case 147:
			case 148:
			case 149:
			case 150:
			case 151:
			case 161:
			case 162:
			case 163:
			case 164:
			case 208:
			case 211:
			case 218:
			case 241:
			case 242:
			case 243:
			case 244:
			case 245:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 651;
				this.exprComponent(0);
				}
				break;
			case 115:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 652;
				this.match(VtlParser.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public parameter(): ParameterContext {
		let localctx: ParameterContext = new ParameterContext(this, this._ctx, this.state);
		this.enterRule(localctx, 40, VtlParser.RULE_parameter);
		try {
			this.state = 657;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 13:
			case 14:
			case 22:
			case 23:
			case 24:
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 50:
			case 51:
			case 54:
			case 55:
			case 57:
			case 59:
			case 60:
			case 61:
			case 66:
			case 67:
			case 80:
			case 81:
			case 85:
			case 87:
			case 88:
			case 89:
			case 90:
			case 91:
			case 92:
			case 93:
			case 95:
			case 96:
			case 97:
			case 98:
			case 99:
			case 100:
			case 101:
			case 102:
			case 108:
			case 111:
			case 113:
			case 114:
			case 131:
			case 132:
			case 133:
			case 134:
			case 135:
			case 136:
			case 137:
			case 139:
			case 140:
			case 141:
			case 142:
			case 143:
			case 147:
			case 148:
			case 149:
			case 150:
			case 151:
			case 161:
			case 162:
			case 163:
			case 164:
			case 193:
			case 194:
			case 195:
			case 196:
			case 208:
			case 211:
			case 218:
			case 222:
			case 223:
			case 241:
			case 242:
			case 243:
			case 244:
			case 245:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 655;
				this.expr(0);
				}
				break;
			case 115:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 656;
				this.match(VtlParser.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public stringOperators(): StringOperatorsContext {
		let localctx: StringOperatorsContext = new StringOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 42, VtlParser.RULE_stringOperators);
		let _la: number;
		try {
			this.state = 707;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 93:
			case 95:
			case 96:
			case 97:
			case 131:
			case 132:
				localctx = new UnaryStringFunctionContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 659;
				(localctx as UnaryStringFunctionContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 93)) & ~0x1F) === 0 && ((1 << (_la - 93)) & 29) !== 0) || _la===131 || _la===132)) {
				    (localctx as UnaryStringFunctionContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 660;
				this.match(VtlParser.LPAREN);
				this.state = 661;
				this.expr(0);
				this.state = 662;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 98:
				localctx = new SubstrAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 664;
				this.match(VtlParser.SUBSTR);
				this.state = 665;
				this.match(VtlParser.LPAREN);
				this.state = 666;
				this.expr(0);
				this.state = 677;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 50, this._ctx) ) {
				case 1:
					{
					this.state = 673;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						{
						this.state = 667;
						this.match(VtlParser.COMMA);
						this.state = 668;
						(localctx as SubstrAtomContext)._startParameter = this.optionalExpr();
						}
						{
						this.state = 670;
						this.match(VtlParser.COMMA);
						this.state = 671;
						(localctx as SubstrAtomContext)._endParameter = this.optionalExpr();
						}
						}
					}

					}
					break;
				case 2:
					{
					this.state = 675;
					this.match(VtlParser.COMMA);
					this.state = 676;
					(localctx as SubstrAtomContext)._startParameter = this.optionalExpr();
					}
					break;
				}
				this.state = 679;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 134:
				localctx = new ReplaceAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 681;
				this.match(VtlParser.REPLACE);
				this.state = 682;
				this.match(VtlParser.LPAREN);
				this.state = 683;
				this.expr(0);
				this.state = 684;
				this.match(VtlParser.COMMA);
				this.state = 685;
				(localctx as ReplaceAtomContext)._param = this.expr(0);
				this.state = 688;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 686;
					this.match(VtlParser.COMMA);
					this.state = 687;
					this.optionalExpr();
					}
				}

				this.state = 690;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 133:
				localctx = new InstrAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 692;
				this.match(VtlParser.INSTR);
				this.state = 693;
				this.match(VtlParser.LPAREN);
				this.state = 694;
				this.expr(0);
				this.state = 695;
				this.match(VtlParser.COMMA);
				this.state = 696;
				(localctx as InstrAtomContext)._pattern = this.expr(0);
				this.state = 699;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 52, this._ctx) ) {
				case 1:
					{
					this.state = 697;
					this.match(VtlParser.COMMA);
					this.state = 698;
					(localctx as InstrAtomContext)._startParameter = this.optionalExpr();
					}
					break;
				}
				this.state = 703;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 701;
					this.match(VtlParser.COMMA);
					this.state = 702;
					(localctx as InstrAtomContext)._occurrenceParameter = this.optionalExpr();
					}
				}

				this.state = 705;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public stringOperatorsComponent(): StringOperatorsComponentContext {
		let localctx: StringOperatorsComponentContext = new StringOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 44, VtlParser.RULE_stringOperatorsComponent);
		let _la: number;
		try {
			this.state = 757;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 93:
			case 95:
			case 96:
			case 97:
			case 131:
			case 132:
				localctx = new UnaryStringFunctionComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 709;
				(localctx as UnaryStringFunctionComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 93)) & ~0x1F) === 0 && ((1 << (_la - 93)) & 29) !== 0) || _la===131 || _la===132)) {
				    (localctx as UnaryStringFunctionComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 710;
				this.match(VtlParser.LPAREN);
				this.state = 711;
				this.exprComponent(0);
				this.state = 712;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 98:
				localctx = new SubstrAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 714;
				this.match(VtlParser.SUBSTR);
				this.state = 715;
				this.match(VtlParser.LPAREN);
				this.state = 716;
				this.exprComponent(0);
				this.state = 727;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 56, this._ctx) ) {
				case 1:
					{
					this.state = 723;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						{
						this.state = 717;
						this.match(VtlParser.COMMA);
						this.state = 718;
						(localctx as SubstrAtomComponentContext)._startParameter = this.optionalExprComponent();
						}
						{
						this.state = 720;
						this.match(VtlParser.COMMA);
						this.state = 721;
						(localctx as SubstrAtomComponentContext)._endParameter = this.optionalExprComponent();
						}
						}
					}

					}
					break;
				case 2:
					{
					this.state = 725;
					this.match(VtlParser.COMMA);
					this.state = 726;
					(localctx as SubstrAtomComponentContext)._startParameter = this.optionalExprComponent();
					}
					break;
				}
				this.state = 729;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 134:
				localctx = new ReplaceAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 731;
				this.match(VtlParser.REPLACE);
				this.state = 732;
				this.match(VtlParser.LPAREN);
				this.state = 733;
				this.exprComponent(0);
				this.state = 734;
				this.match(VtlParser.COMMA);
				this.state = 735;
				(localctx as ReplaceAtomComponentContext)._param = this.exprComponent(0);
				this.state = 738;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 736;
					this.match(VtlParser.COMMA);
					this.state = 737;
					this.optionalExprComponent();
					}
				}

				this.state = 740;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 133:
				localctx = new InstrAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 742;
				this.match(VtlParser.INSTR);
				this.state = 743;
				this.match(VtlParser.LPAREN);
				this.state = 744;
				this.exprComponent(0);
				this.state = 745;
				this.match(VtlParser.COMMA);
				this.state = 746;
				(localctx as InstrAtomComponentContext)._pattern = this.exprComponent(0);
				this.state = 749;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 58, this._ctx) ) {
				case 1:
					{
					this.state = 747;
					this.match(VtlParser.COMMA);
					this.state = 748;
					(localctx as InstrAtomComponentContext)._startParameter = this.optionalExprComponent();
					}
					break;
				}
				this.state = 753;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 751;
					this.match(VtlParser.COMMA);
					this.state = 752;
					(localctx as InstrAtomComponentContext)._occurrenceParameter = this.optionalExprComponent();
					}
				}

				this.state = 755;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public numericOperators(): NumericOperatorsContext {
		let localctx: NumericOperatorsContext = new NumericOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 46, VtlParser.RULE_numericOperators);
		let _la: number;
		try {
			this.state = 780;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 85:
			case 87:
			case 108:
			case 135:
			case 136:
			case 137:
				localctx = new UnaryNumericContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 759;
				(localctx as UnaryNumericContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 85)) & ~0x1F) === 0 && ((1 << (_la - 85)) & 8388613) !== 0) || ((((_la - 135)) & ~0x1F) === 0 && ((1 << (_la - 135)) & 7) !== 0))) {
				    (localctx as UnaryNumericContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 760;
				this.match(VtlParser.LPAREN);
				this.state = 761;
				this.expr(0);
				this.state = 762;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 89:
			case 90:
				localctx = new UnaryWithOptionalNumericContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 764;
				(localctx as UnaryWithOptionalNumericContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===89 || _la===90)) {
				    (localctx as UnaryWithOptionalNumericContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 765;
				this.match(VtlParser.LPAREN);
				this.state = 766;
				this.expr(0);
				this.state = 769;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 767;
					this.match(VtlParser.COMMA);
					this.state = 768;
					this.optionalExpr();
					}
				}

				this.state = 771;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 61:
			case 88:
			case 91:
			case 92:
				localctx = new BinaryNumericContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 773;
				(localctx as BinaryNumericContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 61)) & ~0x1F) === 0 && ((1 << (_la - 61)) & 3355443201) !== 0))) {
				    (localctx as BinaryNumericContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 774;
				this.match(VtlParser.LPAREN);
				this.state = 775;
				(localctx as BinaryNumericContext)._left = this.expr(0);
				this.state = 776;
				this.match(VtlParser.COMMA);
				this.state = 777;
				(localctx as BinaryNumericContext)._right = this.expr(0);
				this.state = 778;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public numericOperatorsComponent(): NumericOperatorsComponentContext {
		let localctx: NumericOperatorsComponentContext = new NumericOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 48, VtlParser.RULE_numericOperatorsComponent);
		let _la: number;
		try {
			this.state = 803;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 85:
			case 87:
			case 108:
			case 135:
			case 136:
			case 137:
				localctx = new UnaryNumericComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 782;
				(localctx as UnaryNumericComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 85)) & ~0x1F) === 0 && ((1 << (_la - 85)) & 8388613) !== 0) || ((((_la - 135)) & ~0x1F) === 0 && ((1 << (_la - 135)) & 7) !== 0))) {
				    (localctx as UnaryNumericComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 783;
				this.match(VtlParser.LPAREN);
				this.state = 784;
				this.exprComponent(0);
				this.state = 785;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 89:
			case 90:
				localctx = new UnaryWithOptionalNumericComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 787;
				(localctx as UnaryWithOptionalNumericComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===89 || _la===90)) {
				    (localctx as UnaryWithOptionalNumericComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 788;
				this.match(VtlParser.LPAREN);
				this.state = 789;
				this.exprComponent(0);
				this.state = 792;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 790;
					this.match(VtlParser.COMMA);
					this.state = 791;
					this.optionalExprComponent();
					}
				}

				this.state = 794;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 61:
			case 88:
			case 91:
			case 92:
				localctx = new BinaryNumericComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 796;
				(localctx as BinaryNumericComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 61)) & ~0x1F) === 0 && ((1 << (_la - 61)) & 3355443201) !== 0))) {
				    (localctx as BinaryNumericComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 797;
				this.match(VtlParser.LPAREN);
				this.state = 798;
				(localctx as BinaryNumericComponentContext)._left = this.exprComponent(0);
				this.state = 799;
				this.match(VtlParser.COMMA);
				this.state = 800;
				(localctx as BinaryNumericComponentContext)._right = this.exprComponent(0);
				this.state = 801;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public comparisonOperators(): ComparisonOperatorsContext {
		let localctx: ComparisonOperatorsContext = new ComparisonOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 50, VtlParser.RULE_comparisonOperators);
		let _la: number;
		try {
			this.state = 837;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 51:
				localctx = new BetweenAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 805;
				this.match(VtlParser.BETWEEN);
				this.state = 806;
				this.match(VtlParser.LPAREN);
				this.state = 807;
				(localctx as BetweenAtomContext)._op = this.expr(0);
				this.state = 808;
				this.match(VtlParser.COMMA);
				this.state = 809;
				(localctx as BetweenAtomContext)._from_ = this.expr(0);
				this.state = 810;
				this.match(VtlParser.COMMA);
				this.state = 811;
				(localctx as BetweenAtomContext)._to_ = this.expr(0);
				this.state = 812;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 111:
				localctx = new CharsetMatchAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 814;
				this.match(VtlParser.CHARSET_MATCH);
				this.state = 815;
				this.match(VtlParser.LPAREN);
				this.state = 816;
				(localctx as CharsetMatchAtomContext)._op = this.expr(0);
				this.state = 817;
				this.match(VtlParser.COMMA);
				this.state = 818;
				(localctx as CharsetMatchAtomContext)._pattern = this.expr(0);
				this.state = 819;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 55:
				localctx = new IsNullAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 821;
				this.match(VtlParser.ISNULL);
				this.state = 822;
				this.match(VtlParser.LPAREN);
				this.state = 823;
				this.expr(0);
				this.state = 824;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 67:
				localctx = new ExistInAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 826;
				this.match(VtlParser.EXISTS_IN);
				this.state = 827;
				this.match(VtlParser.LPAREN);
				this.state = 828;
				(localctx as ExistInAtomContext)._left = this.expr(0);
				this.state = 829;
				this.match(VtlParser.COMMA);
				this.state = 830;
				(localctx as ExistInAtomContext)._right = this.expr(0);
				this.state = 833;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 831;
					this.match(VtlParser.COMMA);
					this.state = 832;
					this.retainType();
					}
				}

				this.state = 835;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public comparisonOperatorsComponent(): ComparisonOperatorsComponentContext {
		let localctx: ComparisonOperatorsComponentContext = new ComparisonOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 52, VtlParser.RULE_comparisonOperatorsComponent);
		try {
			this.state = 860;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 51:
				localctx = new BetweenAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 839;
				this.match(VtlParser.BETWEEN);
				this.state = 840;
				this.match(VtlParser.LPAREN);
				this.state = 841;
				(localctx as BetweenAtomComponentContext)._op = this.exprComponent(0);
				this.state = 842;
				this.match(VtlParser.COMMA);
				this.state = 843;
				(localctx as BetweenAtomComponentContext)._from_ = this.exprComponent(0);
				this.state = 844;
				this.match(VtlParser.COMMA);
				this.state = 845;
				(localctx as BetweenAtomComponentContext)._to_ = this.exprComponent(0);
				this.state = 846;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 111:
				localctx = new CharsetMatchAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 848;
				this.match(VtlParser.CHARSET_MATCH);
				this.state = 849;
				this.match(VtlParser.LPAREN);
				this.state = 850;
				(localctx as CharsetMatchAtomComponentContext)._op = this.exprComponent(0);
				this.state = 851;
				this.match(VtlParser.COMMA);
				this.state = 852;
				(localctx as CharsetMatchAtomComponentContext)._pattern = this.exprComponent(0);
				this.state = 853;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 55:
				localctx = new IsNullAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 855;
				this.match(VtlParser.ISNULL);
				this.state = 856;
				this.match(VtlParser.LPAREN);
				this.state = 857;
				this.exprComponent(0);
				this.state = 858;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public timeOperators(): TimeOperatorsContext {
		let localctx: TimeOperatorsContext = new TimeOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 54, VtlParser.RULE_timeOperators);
		let _la: number;
		try {
			this.state = 964;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 208:
				localctx = new PeriodAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 862;
				this.match(VtlParser.PERIOD_INDICATOR);
				this.state = 863;
				this.match(VtlParser.LPAREN);
				this.state = 865;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 3787481090) !== 0) || ((((_la - 32)) & ~0x1F) === 0 && ((1 << (_la - 32)) & 986448127) !== 0) || ((((_la - 66)) & ~0x1F) === 0 && ((1 << (_la - 66)) & 4025008131) !== 0) || ((((_la - 98)) & ~0x1F) === 0 && ((1 << (_la - 98)) & 107551) !== 0) || ((((_la - 131)) & ~0x1F) === 0 && ((1 << (_la - 131)) & 3223265151) !== 0) || ((((_la - 163)) & ~0x1F) === 0 && ((1 << (_la - 163)) & 3221225475) !== 0) || ((((_la - 195)) & ~0x1F) === 0 && ((1 << (_la - 195)) & 411115523) !== 0) || ((((_la - 241)) & ~0x1F) === 0 && ((1 << (_la - 241)) & 31) !== 0)) {
					{
					this.state = 864;
					this.expr(0);
					}
				}

				this.state = 867;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 161:
				localctx = new FillTimeAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 868;
				this.match(VtlParser.FILL_TIME_SERIES);
				this.state = 869;
				this.match(VtlParser.LPAREN);
				this.state = 870;
				this.expr(0);
				this.state = 873;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 871;
					this.match(VtlParser.COMMA);
					this.state = 872;
					(localctx as FillTimeAtomContext)._op = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===72 || _la===209)) {
					    (localctx as FillTimeAtomContext)._op = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 875;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 162:
			case 163:
				localctx = new FlowAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 877;
				(localctx as FlowAtomContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===162 || _la===163)) {
				    (localctx as FlowAtomContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 878;
				this.match(VtlParser.LPAREN);
				this.state = 879;
				this.expr(0);
				this.state = 880;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 164:
				localctx = new TimeShiftAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 882;
				this.match(VtlParser.TIMESHIFT);
				this.state = 883;
				this.match(VtlParser.LPAREN);
				this.state = 884;
				this.expr(0);
				this.state = 885;
				this.match(VtlParser.COMMA);
				this.state = 886;
				this.signedInteger();
				this.state = 887;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 211:
				localctx = new TimeAggAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 889;
				this.match(VtlParser.TIME_AGG);
				this.state = 890;
				this.match(VtlParser.LPAREN);
				this.state = 891;
				(localctx as TimeAggAtomContext)._periodIndTo = this.match(VtlParser.STRING_CONSTANT);
				this.state = 894;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 70, this._ctx) ) {
				case 1:
					{
					this.state = 892;
					this.match(VtlParser.COMMA);
					this.state = 893;
					(localctx as TimeAggAtomContext)._periodIndFrom = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===115 || _la===244)) {
					    (localctx as TimeAggAtomContext)._periodIndFrom = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
					break;
				}
				this.state = 898;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 71, this._ctx) ) {
				case 1:
					{
					this.state = 896;
					this.match(VtlParser.COMMA);
					this.state = 897;
					(localctx as TimeAggAtomContext)._op = this.optionalExpr();
					}
					break;
				}
				this.state = 902;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 900;
					this.match(VtlParser.COMMA);
					this.state = 901;
					(localctx as TimeAggAtomContext)._delim = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===82 || _la===83)) {
					    (localctx as TimeAggAtomContext)._delim = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 904;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 29:
				localctx = new CurrentDateAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 905;
				this.match(VtlParser.CURRENT_DATE);
				this.state = 906;
				this.match(VtlParser.LPAREN);
				this.state = 907;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 30:
				localctx = new DateDiffAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 908;
				this.match(VtlParser.DATEDIFF);
				this.state = 909;
				this.match(VtlParser.LPAREN);
				this.state = 910;
				(localctx as DateDiffAtomContext)._dateFrom = this.expr(0);
				this.state = 911;
				this.match(VtlParser.COMMA);
				this.state = 912;
				(localctx as DateDiffAtomContext)._dateTo = this.expr(0);
				this.state = 913;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 31:
				localctx = new DateAddAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 915;
				this.match(VtlParser.DATEADD);
				this.state = 916;
				this.match(VtlParser.LPAREN);
				this.state = 917;
				(localctx as DateAddAtomContext)._op = this.expr(0);
				this.state = 918;
				this.match(VtlParser.COMMA);
				this.state = 919;
				(localctx as DateAddAtomContext)._shiftNumber = this.expr(0);
				this.state = 920;
				this.match(VtlParser.COMMA);
				this.state = 921;
				(localctx as DateAddAtomContext)._periodInd = this.expr(0);
				this.state = 922;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 32:
				localctx = new YearAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 9);
				{
				this.state = 924;
				this.match(VtlParser.YEAR_OP);
				this.state = 925;
				this.match(VtlParser.LPAREN);
				this.state = 926;
				this.expr(0);
				this.state = 927;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 33:
				localctx = new MonthAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 10);
				{
				this.state = 929;
				this.match(VtlParser.MONTH_OP);
				this.state = 930;
				this.match(VtlParser.LPAREN);
				this.state = 931;
				this.expr(0);
				this.state = 932;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 34:
				localctx = new DayOfMonthAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 11);
				{
				this.state = 934;
				this.match(VtlParser.DAYOFMONTH);
				this.state = 935;
				this.match(VtlParser.LPAREN);
				this.state = 936;
				this.expr(0);
				this.state = 937;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 35:
				localctx = new DayOfYearAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 12);
				{
				this.state = 939;
				this.match(VtlParser.DAYOFYEAR);
				this.state = 940;
				this.match(VtlParser.LPAREN);
				this.state = 941;
				this.expr(0);
				this.state = 942;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 36:
				localctx = new DayToYearAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 13);
				{
				this.state = 944;
				this.match(VtlParser.DAYTOYEAR);
				this.state = 945;
				this.match(VtlParser.LPAREN);
				this.state = 946;
				this.expr(0);
				this.state = 947;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 37:
				localctx = new DayToMonthAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 14);
				{
				this.state = 949;
				this.match(VtlParser.DAYTOMONTH);
				this.state = 950;
				this.match(VtlParser.LPAREN);
				this.state = 951;
				this.expr(0);
				this.state = 952;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 38:
				localctx = new YearTodayAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 15);
				{
				this.state = 954;
				this.match(VtlParser.YEARTODAY);
				this.state = 955;
				this.match(VtlParser.LPAREN);
				this.state = 956;
				this.expr(0);
				this.state = 957;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 39:
				localctx = new MonthTodayAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 16);
				{
				this.state = 959;
				this.match(VtlParser.MONTHTODAY);
				this.state = 960;
				this.match(VtlParser.LPAREN);
				this.state = 961;
				this.expr(0);
				this.state = 962;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public timeOperatorsComponent(): TimeOperatorsComponentContext {
		let localctx: TimeOperatorsComponentContext = new TimeOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 56, VtlParser.RULE_timeOperatorsComponent);
		let _la: number;
		try {
			this.state = 1068;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 208:
				localctx = new PeriodAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 966;
				this.match(VtlParser.PERIOD_INDICATOR);
				this.state = 967;
				this.match(VtlParser.LPAREN);
				this.state = 969;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 3787481090) !== 0) || ((((_la - 32)) & ~0x1F) === 0 && ((1 << (_la - 32)) & 550240511) !== 0) || ((((_la - 77)) & ~0x1F) === 0 && ((1 << (_la - 77)) & 2214460697) !== 0) || ((((_la - 111)) & ~0x1F) === 0 && ((1 << (_la - 111)) & 3891265541) !== 0) || ((((_la - 143)) & ~0x1F) === 0 && ((1 << (_la - 143)) & 3932657) !== 0) || ((((_la - 208)) & ~0x1F) === 0 && ((1 << (_la - 208)) & 1033) !== 0) || ((((_la - 241)) & ~0x1F) === 0 && ((1 << (_la - 241)) & 31) !== 0)) {
					{
					this.state = 968;
					this.exprComponent(0);
					}
				}

				this.state = 971;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 161:
				localctx = new FillTimeAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 972;
				this.match(VtlParser.FILL_TIME_SERIES);
				this.state = 973;
				this.match(VtlParser.LPAREN);
				this.state = 974;
				this.exprComponent(0);
				this.state = 977;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 975;
					this.match(VtlParser.COMMA);
					this.state = 976;
					(localctx as FillTimeAtomComponentContext)._op = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===72 || _la===209)) {
					    (localctx as FillTimeAtomComponentContext)._op = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 979;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 162:
			case 163:
				localctx = new FlowAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 981;
				(localctx as FlowAtomComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===162 || _la===163)) {
				    (localctx as FlowAtomComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 982;
				this.match(VtlParser.LPAREN);
				this.state = 983;
				this.exprComponent(0);
				this.state = 984;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 164:
				localctx = new TimeShiftAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 986;
				this.match(VtlParser.TIMESHIFT);
				this.state = 987;
				this.match(VtlParser.LPAREN);
				this.state = 988;
				this.exprComponent(0);
				this.state = 989;
				this.match(VtlParser.COMMA);
				this.state = 990;
				this.signedInteger();
				this.state = 991;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 211:
				localctx = new TimeAggAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 993;
				this.match(VtlParser.TIME_AGG);
				this.state = 994;
				this.match(VtlParser.LPAREN);
				this.state = 995;
				(localctx as TimeAggAtomComponentContext)._periodIndTo = this.match(VtlParser.STRING_CONSTANT);
				this.state = 998;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 76, this._ctx) ) {
				case 1:
					{
					this.state = 996;
					this.match(VtlParser.COMMA);
					this.state = 997;
					(localctx as TimeAggAtomComponentContext)._periodIndFrom = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===115 || _la===244)) {
					    (localctx as TimeAggAtomComponentContext)._periodIndFrom = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
					break;
				}
				this.state = 1002;
				this._errHandler.sync(this);
				switch ( this._interp.adaptivePredict(this._input, 77, this._ctx) ) {
				case 1:
					{
					this.state = 1000;
					this.match(VtlParser.COMMA);
					this.state = 1001;
					(localctx as TimeAggAtomComponentContext)._op = this.optionalExprComponent();
					}
					break;
				}
				this.state = 1006;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 1004;
					this.match(VtlParser.COMMA);
					this.state = 1005;
					(localctx as TimeAggAtomComponentContext)._delim = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===82 || _la===83)) {
					    (localctx as TimeAggAtomComponentContext)._delim = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 1008;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 29:
				localctx = new CurrentDateAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 6);
				{
				this.state = 1009;
				this.match(VtlParser.CURRENT_DATE);
				this.state = 1010;
				this.match(VtlParser.LPAREN);
				this.state = 1011;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 30:
				localctx = new DateDiffAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 7);
				{
				this.state = 1012;
				this.match(VtlParser.DATEDIFF);
				this.state = 1013;
				this.match(VtlParser.LPAREN);
				this.state = 1014;
				(localctx as DateDiffAtomComponentContext)._dateFrom = this.exprComponent(0);
				this.state = 1015;
				this.match(VtlParser.COMMA);
				this.state = 1016;
				(localctx as DateDiffAtomComponentContext)._dateTo = this.expr(0);
				this.state = 1017;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 31:
				localctx = new DateAddAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 8);
				{
				this.state = 1019;
				this.match(VtlParser.DATEADD);
				this.state = 1020;
				this.match(VtlParser.LPAREN);
				this.state = 1021;
				(localctx as DateAddAtomComponentContext)._op = this.exprComponent(0);
				this.state = 1022;
				this.match(VtlParser.COMMA);
				this.state = 1023;
				(localctx as DateAddAtomComponentContext)._shiftNumber = this.exprComponent(0);
				this.state = 1024;
				this.match(VtlParser.COMMA);
				this.state = 1025;
				(localctx as DateAddAtomComponentContext)._periodInd = this.exprComponent(0);
				this.state = 1026;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 32:
				localctx = new YearAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 9);
				{
				this.state = 1028;
				this.match(VtlParser.YEAR_OP);
				this.state = 1029;
				this.match(VtlParser.LPAREN);
				this.state = 1030;
				this.exprComponent(0);
				this.state = 1031;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 33:
				localctx = new MonthAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 10);
				{
				this.state = 1033;
				this.match(VtlParser.MONTH_OP);
				this.state = 1034;
				this.match(VtlParser.LPAREN);
				this.state = 1035;
				this.exprComponent(0);
				this.state = 1036;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 34:
				localctx = new DayOfMonthAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 11);
				{
				this.state = 1038;
				this.match(VtlParser.DAYOFMONTH);
				this.state = 1039;
				this.match(VtlParser.LPAREN);
				this.state = 1040;
				this.exprComponent(0);
				this.state = 1041;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 35:
				localctx = new DatOfYearAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 12);
				{
				this.state = 1043;
				this.match(VtlParser.DAYOFYEAR);
				this.state = 1044;
				this.match(VtlParser.LPAREN);
				this.state = 1045;
				this.exprComponent(0);
				this.state = 1046;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 36:
				localctx = new DayToYearAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 13);
				{
				this.state = 1048;
				this.match(VtlParser.DAYTOYEAR);
				this.state = 1049;
				this.match(VtlParser.LPAREN);
				this.state = 1050;
				this.exprComponent(0);
				this.state = 1051;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 37:
				localctx = new DayToMonthAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 14);
				{
				this.state = 1053;
				this.match(VtlParser.DAYTOMONTH);
				this.state = 1054;
				this.match(VtlParser.LPAREN);
				this.state = 1055;
				this.exprComponent(0);
				this.state = 1056;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 38:
				localctx = new YearTodayAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 15);
				{
				this.state = 1058;
				this.match(VtlParser.YEARTODAY);
				this.state = 1059;
				this.match(VtlParser.LPAREN);
				this.state = 1060;
				this.exprComponent(0);
				this.state = 1061;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 39:
				localctx = new MonthTodayAtomComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 16);
				{
				this.state = 1063;
				this.match(VtlParser.MONTHTODAY);
				this.state = 1064;
				this.match(VtlParser.LPAREN);
				this.state = 1065;
				this.exprComponent(0);
				this.state = 1066;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public setOperators(): SetOperatorsContext {
		let localctx: SetOperatorsContext = new SetOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 58, VtlParser.RULE_setOperators);
		let _la: number;
		try {
			this.state = 1099;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 57:
				localctx = new UnionAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1070;
				this.match(VtlParser.UNION);
				this.state = 1071;
				this.match(VtlParser.LPAREN);
				this.state = 1072;
				(localctx as UnionAtomContext)._left = this.expr(0);
				this.state = 1075;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				do {
					{
					{
					this.state = 1073;
					this.match(VtlParser.COMMA);
					this.state = 1074;
					this.expr(0);
					}
					}
					this.state = 1077;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				} while (_la===17);
				this.state = 1079;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 60:
				localctx = new IntersectAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1081;
				this.match(VtlParser.INTERSECT);
				this.state = 1082;
				this.match(VtlParser.LPAREN);
				this.state = 1083;
				(localctx as IntersectAtomContext)._left = this.expr(0);
				this.state = 1086;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				do {
					{
					{
					this.state = 1084;
					this.match(VtlParser.COMMA);
					this.state = 1085;
					this.expr(0);
					}
					}
					this.state = 1088;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				} while (_la===17);
				this.state = 1090;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 59:
			case 139:
				localctx = new SetOrSYmDiffAtomContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1092;
				(localctx as SetOrSYmDiffAtomContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===59 || _la===139)) {
				    (localctx as SetOrSYmDiffAtomContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1093;
				this.match(VtlParser.LPAREN);
				this.state = 1094;
				(localctx as SetOrSYmDiffAtomContext)._left = this.expr(0);
				this.state = 1095;
				this.match(VtlParser.COMMA);
				this.state = 1096;
				(localctx as SetOrSYmDiffAtomContext)._right = this.expr(0);
				this.state = 1097;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public hierarchyOperators(): HierarchyOperatorsContext {
		let localctx: HierarchyOperatorsContext = new HierarchyOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 60, VtlParser.RULE_hierarchyOperators);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1101;
			this.match(VtlParser.HIERARCHY);
			this.state = 1102;
			this.match(VtlParser.LPAREN);
			this.state = 1103;
			localctx._op = this.expr(0);
			this.state = 1104;
			this.match(VtlParser.COMMA);
			this.state = 1105;
			localctx._hrName = this.match(VtlParser.IDENTIFIER);
			this.state = 1107;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===167) {
				{
				this.state = 1106;
				this.conditionClause();
				}
			}

			this.state = 1111;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 84, this._ctx) ) {
			case 1:
				{
				this.state = 1109;
				this.match(VtlParser.RULE);
				this.state = 1110;
				localctx._ruleComponent = this.componentID();
				}
				break;
			}
			this.state = 1114;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (((((_la - 225)) & ~0x1F) === 0 && ((1 << (_la - 225)) & 63) !== 0)) {
				{
				this.state = 1113;
				this.validationMode();
				}
			}

			this.state = 1117;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===121 || _la===128 || _la===219) {
				{
				this.state = 1116;
				this.inputModeHierarchy();
				}
			}

			this.state = 1120;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===72 || _la===224) {
				{
				this.state = 1119;
				this.outputModeHierarchy();
				}
			}

			this.state = 1122;
			this.match(VtlParser.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public validationOperators(): ValidationOperatorsContext {
		let localctx: ValidationOperatorsContext = new ValidationOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 62, VtlParser.RULE_validationOperators);
		let _la: number;
		try {
			this.state = 1185;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 222:
				localctx = new ValidateDPrulesetContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1124;
				this.match(VtlParser.CHECK_DATAPOINT);
				this.state = 1125;
				this.match(VtlParser.LPAREN);
				this.state = 1126;
				(localctx as ValidateDPrulesetContext)._op = this.expr(0);
				this.state = 1127;
				this.match(VtlParser.COMMA);
				this.state = 1128;
				(localctx as ValidateDPrulesetContext)._dpName = this.match(VtlParser.IDENTIFIER);
				this.state = 1138;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===231) {
					{
					this.state = 1129;
					this.match(VtlParser.COMPONENTS);
					this.state = 1130;
					this.componentID();
					this.state = 1135;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===17) {
						{
						{
						this.state = 1131;
						this.match(VtlParser.COMMA);
						this.state = 1132;
						this.componentID();
						}
						}
						this.state = 1137;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					}
				}

				this.state = 1141;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===72 || _la===116 || _la===232) {
					{
					this.state = 1140;
					this.validationOutput();
					}
				}

				this.state = 1143;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 223:
				localctx = new ValidateHRrulesetContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1145;
				this.match(VtlParser.CHECK_HIERARCHY);
				this.state = 1146;
				this.match(VtlParser.LPAREN);
				this.state = 1147;
				(localctx as ValidateHRrulesetContext)._op = this.expr(0);
				this.state = 1148;
				this.match(VtlParser.COMMA);
				this.state = 1149;
				(localctx as ValidateHRrulesetContext)._hrName = this.match(VtlParser.IDENTIFIER);
				this.state = 1151;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===167) {
					{
					this.state = 1150;
					this.conditionClause();
					}
				}

				this.state = 1155;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===128) {
					{
					this.state = 1153;
					this.match(VtlParser.RULE);
					this.state = 1154;
					this.componentID();
					}
				}

				this.state = 1158;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (((((_la - 225)) & ~0x1F) === 0 && ((1 << (_la - 225)) & 63) !== 0)) {
					{
					this.state = 1157;
					this.validationMode();
					}
				}

				this.state = 1161;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===121 || _la===220) {
					{
					this.state = 1160;
					this.inputMode();
					}
				}

				this.state = 1164;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===72 || _la===116 || _la===232) {
					{
					this.state = 1163;
					this.validationOutput();
					}
				}

				this.state = 1166;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 66:
				localctx = new ValidationSimpleContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1168;
				this.match(VtlParser.CHECK);
				this.state = 1169;
				this.match(VtlParser.LPAREN);
				this.state = 1170;
				(localctx as ValidationSimpleContext)._op = this.expr(0);
				this.state = 1172;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===71) {
					{
					this.state = 1171;
					(localctx as ValidationSimpleContext)._codeErr = this.erCode();
					}
				}

				this.state = 1175;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===74) {
					{
					this.state = 1174;
					(localctx as ValidationSimpleContext)._levelCode = this.erLevel();
					}
				}

				this.state = 1178;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===70) {
					{
					this.state = 1177;
					this.imbalanceExpr();
					}
				}

				this.state = 1181;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===72 || _la===116) {
					{
					this.state = 1180;
					(localctx as ValidationSimpleContext)._output = this._input.LT(1);
					_la = this._input.LA(1);
					if(!(_la===72 || _la===116)) {
					    (localctx as ValidationSimpleContext)._output = this._errHandler.recoverInline(this);
					}
					else {
						this._errHandler.reportMatch(this);
					    this.consume();
					}
					}
				}

				this.state = 1183;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public conditionalOperators(): ConditionalOperatorsContext {
		let localctx: ConditionalOperatorsContext = new ConditionalOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 64, VtlParser.RULE_conditionalOperators);
		try {
			localctx = new NvlAtomContext(this, localctx);
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1187;
			this.match(VtlParser.NVL);
			this.state = 1188;
			this.match(VtlParser.LPAREN);
			this.state = 1189;
			(localctx as NvlAtomContext)._left = this.expr(0);
			this.state = 1190;
			this.match(VtlParser.COMMA);
			this.state = 1191;
			(localctx as NvlAtomContext)._right = this.expr(0);
			this.state = 1192;
			this.match(VtlParser.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public conditionalOperatorsComponent(): ConditionalOperatorsComponentContext {
		let localctx: ConditionalOperatorsComponentContext = new ConditionalOperatorsComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 66, VtlParser.RULE_conditionalOperatorsComponent);
		try {
			localctx = new NvlAtomComponentContext(this, localctx);
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1194;
			this.match(VtlParser.NVL);
			this.state = 1195;
			this.match(VtlParser.LPAREN);
			this.state = 1196;
			(localctx as NvlAtomComponentContext)._left = this.exprComponent(0);
			this.state = 1197;
			this.match(VtlParser.COMMA);
			this.state = 1198;
			(localctx as NvlAtomComponentContext)._right = this.exprComponent(0);
			this.state = 1199;
			this.match(VtlParser.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrOperators(): AggrOperatorsContext {
		let localctx: AggrOperatorsContext = new AggrOperatorsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 68, VtlParser.RULE_aggrOperators);
		let _la: number;
		try {
			this.state = 1209;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 101, this._ctx) ) {
			case 1:
				localctx = new AggrCompContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1201;
				(localctx as AggrCompContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 80)) & ~0x1F) === 0 && ((1 << (_la - 80)) & 7864323) !== 0) || ((((_la - 140)) & ~0x1F) === 0 && ((1 << (_la - 140)) & 15) !== 0))) {
				    (localctx as AggrCompContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1202;
				this.match(VtlParser.LPAREN);
				this.state = 1203;
				this.exprComponent(0);
				this.state = 1204;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 2:
				localctx = new CountAggrCompContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1206;
				this.match(VtlParser.COUNT);
				this.state = 1207;
				this.match(VtlParser.LPAREN);
				this.state = 1208;
				this.match(VtlParser.RPAREN);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrOperatorsGrouping(): AggrOperatorsGroupingContext {
		let localctx: AggrOperatorsGroupingContext = new AggrOperatorsGroupingContext(this, this._ctx, this.state);
		this.enterRule(localctx, 70, VtlParser.RULE_aggrOperatorsGrouping);
		let _la: number;
		try {
			localctx = new AggrDatasetContext(this, localctx);
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1211;
			(localctx as AggrDatasetContext)._op = this._input.LT(1);
			_la = this._input.LA(1);
			if(!(((((_la - 80)) & ~0x1F) === 0 && ((1 << (_la - 80)) & 7864323) !== 0) || ((((_la - 140)) & ~0x1F) === 0 && ((1 << (_la - 140)) & 15) !== 0))) {
			    (localctx as AggrDatasetContext)._op = this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 1212;
			this.match(VtlParser.LPAREN);
			this.state = 1213;
			this.expr(0);
			this.state = 1218;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===144) {
				{
				this.state = 1214;
				this.groupingClause();
				this.state = 1216;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===146) {
					{
					this.state = 1215;
					this.havingClause();
					}
				}

				}
			}

			this.state = 1220;
			this.match(VtlParser.RPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public anFunction(): AnFunctionContext {
		let localctx: AnFunctionContext = new AnFunctionContext(this, this._ctx, this.state);
		this.enterRule(localctx, 72, VtlParser.RULE_anFunction);
		let _la: number;
		try {
			this.state = 1269;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 80:
			case 81:
			case 99:
			case 100:
			case 101:
			case 102:
			case 140:
			case 141:
			case 142:
			case 143:
			case 147:
			case 148:
				localctx = new AnSimpleFunctionContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1222;
				(localctx as AnSimpleFunctionContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 80)) & ~0x1F) === 0 && ((1 << (_la - 80)) & 7864323) !== 0) || ((((_la - 140)) & ~0x1F) === 0 && ((1 << (_la - 140)) & 399) !== 0))) {
				    (localctx as AnSimpleFunctionContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1223;
				this.match(VtlParser.LPAREN);
				this.state = 1224;
				this.expr(0);
				this.state = 1225;
				this.match(VtlParser.OVER);
				this.state = 1226;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1228;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===156) {
					{
					this.state = 1227;
					(localctx as AnSimpleFunctionContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1231;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===75) {
					{
					this.state = 1230;
					(localctx as AnSimpleFunctionContext)._orderBy = this.orderByClause();
					}
				}

				this.state = 1234;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===119 || _la===158) {
					{
					this.state = 1233;
					(localctx as AnSimpleFunctionContext)._windowing = this.windowingClause();
					}
				}

				}
				this.state = 1236;
				this.match(VtlParser.RPAREN);
				this.state = 1237;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 149:
			case 150:
				localctx = new LagOrLeadAnContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1239;
				(localctx as LagOrLeadAnContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===149 || _la===150)) {
				    (localctx as LagOrLeadAnContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1240;
				this.match(VtlParser.LPAREN);
				this.state = 1241;
				this.expr(0);
				this.state = 1248;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 1242;
					this.match(VtlParser.COMMA);
					this.state = 1243;
					(localctx as LagOrLeadAnContext)._offset = this.signedInteger();
					this.state = 1246;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						this.state = 1244;
						this.match(VtlParser.COMMA);
						this.state = 1245;
						(localctx as LagOrLeadAnContext)._defaultValue = this.scalarItem();
						}
					}

					}
				}

				this.state = 1250;
				this.match(VtlParser.OVER);
				this.state = 1251;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1253;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===156) {
					{
					this.state = 1252;
					(localctx as LagOrLeadAnContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1255;
				(localctx as LagOrLeadAnContext)._orderBy = this.orderByClause();
				}
				this.state = 1257;
				this.match(VtlParser.RPAREN);
				this.state = 1258;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 151:
				localctx = new RatioToReportAnContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1260;
				(localctx as RatioToReportAnContext)._op = this.match(VtlParser.RATIO_TO_REPORT);
				this.state = 1261;
				this.match(VtlParser.LPAREN);
				this.state = 1262;
				this.expr(0);
				this.state = 1263;
				this.match(VtlParser.OVER);
				this.state = 1264;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1265;
				(localctx as RatioToReportAnContext)._partition = this.partitionByClause();
				}
				this.state = 1266;
				this.match(VtlParser.RPAREN);
				this.state = 1267;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public anFunctionComponent(): AnFunctionComponentContext {
		let localctx: AnFunctionComponentContext = new AnFunctionComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 74, VtlParser.RULE_anFunctionComponent);
		let _la: number;
		try {
			this.state = 1329;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 80:
			case 81:
			case 99:
			case 100:
			case 101:
			case 102:
			case 140:
			case 141:
			case 142:
			case 143:
			case 147:
			case 148:
				localctx = new AnSimpleFunctionComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1271;
				(localctx as AnSimpleFunctionComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(((((_la - 80)) & ~0x1F) === 0 && ((1 << (_la - 80)) & 7864323) !== 0) || ((((_la - 140)) & ~0x1F) === 0 && ((1 << (_la - 140)) & 399) !== 0))) {
				    (localctx as AnSimpleFunctionComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1272;
				this.match(VtlParser.LPAREN);
				this.state = 1273;
				this.exprComponent(0);
				this.state = 1274;
				this.match(VtlParser.OVER);
				this.state = 1275;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1277;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===156) {
					{
					this.state = 1276;
					(localctx as AnSimpleFunctionComponentContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1280;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===75) {
					{
					this.state = 1279;
					(localctx as AnSimpleFunctionComponentContext)._orderBy = this.orderByClause();
					}
				}

				this.state = 1283;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===119 || _la===158) {
					{
					this.state = 1282;
					(localctx as AnSimpleFunctionComponentContext)._windowing = this.windowingClause();
					}
				}

				}
				this.state = 1285;
				this.match(VtlParser.RPAREN);
				this.state = 1286;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 149:
			case 150:
				localctx = new LagOrLeadAnComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1288;
				(localctx as LagOrLeadAnComponentContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===149 || _la===150)) {
				    (localctx as LagOrLeadAnComponentContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1289;
				this.match(VtlParser.LPAREN);
				this.state = 1290;
				this.exprComponent(0);
				this.state = 1296;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 1291;
					this.match(VtlParser.COMMA);
					this.state = 1292;
					(localctx as LagOrLeadAnComponentContext)._offset = this.signedInteger();
					this.state = 1294;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===13 || _la===14 || _la===54 || ((((_la - 218)) & ~0x1F) === 0 && ((1 << (_la - 218)) & 125829121) !== 0)) {
						{
						this.state = 1293;
						(localctx as LagOrLeadAnComponentContext)._defaultValue = this.scalarItem();
						}
					}

					}
				}

				this.state = 1298;
				this.match(VtlParser.OVER);
				this.state = 1299;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1301;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===156) {
					{
					this.state = 1300;
					(localctx as LagOrLeadAnComponentContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1303;
				(localctx as LagOrLeadAnComponentContext)._orderBy = this.orderByClause();
				}
				this.state = 1305;
				this.match(VtlParser.RPAREN);
				this.state = 1306;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 77:
				localctx = new RankAnComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1308;
				(localctx as RankAnComponentContext)._op = this.match(VtlParser.RANK);
				this.state = 1309;
				this.match(VtlParser.LPAREN);
				this.state = 1310;
				this.match(VtlParser.OVER);
				this.state = 1311;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1313;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===156) {
					{
					this.state = 1312;
					(localctx as RankAnComponentContext)._partition = this.partitionByClause();
					}
				}

				this.state = 1315;
				(localctx as RankAnComponentContext)._orderBy = this.orderByClause();
				}
				this.state = 1317;
				this.match(VtlParser.RPAREN);
				this.state = 1318;
				this.match(VtlParser.RPAREN);
				}
				break;
			case 151:
				localctx = new RatioToReportAnComponentContext(this, localctx);
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1320;
				(localctx as RatioToReportAnComponentContext)._op = this.match(VtlParser.RATIO_TO_REPORT);
				this.state = 1321;
				this.match(VtlParser.LPAREN);
				this.state = 1322;
				this.exprComponent(0);
				this.state = 1323;
				this.match(VtlParser.OVER);
				this.state = 1324;
				this.match(VtlParser.LPAREN);
				{
				this.state = 1325;
				(localctx as RatioToReportAnComponentContext)._partition = this.partitionByClause();
				}
				this.state = 1326;
				this.match(VtlParser.RPAREN);
				this.state = 1327;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public renameClauseItem(): RenameClauseItemContext {
		let localctx: RenameClauseItemContext = new RenameClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 76, VtlParser.RULE_renameClauseItem);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1331;
			localctx._fromName = this.componentID();
			this.state = 1332;
			this.match(VtlParser.TO);
			this.state = 1333;
			localctx._toName = this.componentID();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggregateClause(): AggregateClauseContext {
		let localctx: AggregateClauseContext = new AggregateClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 78, VtlParser.RULE_aggregateClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1335;
			this.aggrFunctionClause();
			this.state = 1340;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1336;
				this.match(VtlParser.COMMA);
				this.state = 1337;
				this.aggrFunctionClause();
				}
				}
				this.state = 1342;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public aggrFunctionClause(): AggrFunctionClauseContext {
		let localctx: AggrFunctionClauseContext = new AggrFunctionClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 80, VtlParser.RULE_aggrFunctionClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1344;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (((((_la - 103)) & ~0x1F) === 0 && ((1 << (_la - 103)) & 135) !== 0) || _la===234) {
				{
				this.state = 1343;
				this.componentRole();
				}
			}

			this.state = 1346;
			this.componentID();
			this.state = 1347;
			this.match(VtlParser.ASSIGN);
			this.state = 1348;
			this.aggrOperators();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public calcClauseItem(): CalcClauseItemContext {
		let localctx: CalcClauseItemContext = new CalcClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 82, VtlParser.RULE_calcClauseItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1351;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (((((_la - 103)) & ~0x1F) === 0 && ((1 << (_la - 103)) & 135) !== 0) || _la===234) {
				{
				this.state = 1350;
				this.componentRole();
				}
			}

			this.state = 1353;
			this.componentID();
			this.state = 1354;
			this.match(VtlParser.ASSIGN);
			this.state = 1355;
			this.exprComponent(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public subspaceClauseItem(): SubspaceClauseItemContext {
		let localctx: SubspaceClauseItemContext = new SubspaceClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 84, VtlParser.RULE_subspaceClauseItem);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1357;
			this.componentID();
			this.state = 1358;
			this.match(VtlParser.EQ);
			this.state = 1359;
			this.scalarItem();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarItem(): ScalarItemContext {
		let localctx: ScalarItemContext = new ScalarItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 86, VtlParser.RULE_scalarItem);
		let _la: number;
		try {
			this.state = 1373;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 13:
			case 14:
			case 54:
			case 241:
			case 242:
			case 243:
			case 244:
				localctx = new SimpleScalarContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1361;
				this.constant();
				}
				break;
			case 218:
				localctx = new ScalarWithCastContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1362;
				this.match(VtlParser.CAST);
				this.state = 1363;
				this.match(VtlParser.LPAREN);
				this.state = 1364;
				this.constant();
				this.state = 1365;
				this.match(VtlParser.COMMA);
				{
				this.state = 1366;
				this.basicScalarType();
				}
				this.state = 1369;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===17) {
					{
					this.state = 1367;
					this.match(VtlParser.COMMA);
					this.state = 1368;
					this.match(VtlParser.STRING_CONSTANT);
					}
				}

				this.state = 1371;
				this.match(VtlParser.RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinClauseWithoutUsing(): JoinClauseWithoutUsingContext {
		let localctx: JoinClauseWithoutUsingContext = new JoinClauseWithoutUsingContext(this, this._ctx, this.state);
		this.enterRule(localctx, 88, VtlParser.RULE_joinClauseWithoutUsing);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1375;
			this.joinClauseItem();
			this.state = 1380;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1376;
				this.match(VtlParser.COMMA);
				this.state = 1377;
				this.joinClauseItem();
				}
				}
				this.state = 1382;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinClause(): JoinClauseContext {
		let localctx: JoinClauseContext = new JoinClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 90, VtlParser.RULE_joinClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1383;
			this.joinClauseItem();
			this.state = 1388;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1384;
				this.match(VtlParser.COMMA);
				this.state = 1385;
				this.joinClauseItem();
				}
				}
				this.state = 1390;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 1400;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===27) {
				{
				this.state = 1391;
				this.match(VtlParser.USING);
				this.state = 1392;
				this.componentID();
				this.state = 1397;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1393;
					this.match(VtlParser.COMMA);
					this.state = 1394;
					this.componentID();
					}
					}
					this.state = 1399;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinClauseItem(): JoinClauseItemContext {
		let localctx: JoinClauseItemContext = new JoinClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 92, VtlParser.RULE_joinClauseItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1402;
			this.expr(0);
			this.state = 1405;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===46) {
				{
				this.state = 1403;
				this.match(VtlParser.AS);
				this.state = 1404;
				this.alias();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinBody(): JoinBodyContext {
		let localctx: JoinBodyContext = new JoinBodyContext(this, this._ctx, this.state);
		this.enterRule(localctx, 94, VtlParser.RULE_joinBody);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1408;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===106) {
				{
				this.state = 1407;
				this.filterClause();
				}
			}

			this.state = 1413;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 43:
				{
				this.state = 1410;
				this.calcClause();
				}
				break;
			case 206:
				{
				this.state = 1411;
				this.joinApplyClause();
				}
				break;
			case 73:
				{
				this.state = 1412;
				this.aggrClause();
				}
				break;
			case 2:
			case 41:
			case 42:
			case 45:
				break;
			default:
				break;
			}
			this.state = 1416;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===41 || _la===42) {
				{
				this.state = 1415;
				this.keepOrDropClause();
				}
			}

			this.state = 1419;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===45) {
				{
				this.state = 1418;
				this.renameClause();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public joinApplyClause(): JoinApplyClauseContext {
		let localctx: JoinApplyClauseContext = new JoinApplyClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 96, VtlParser.RULE_joinApplyClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1421;
			this.match(VtlParser.APPLY);
			this.state = 1422;
			this.expr(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public partitionByClause(): PartitionByClauseContext {
		let localctx: PartitionByClauseContext = new PartitionByClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 98, VtlParser.RULE_partitionByClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1424;
			this.match(VtlParser.PARTITION);
			this.state = 1425;
			this.match(VtlParser.BY);
			this.state = 1426;
			this.componentID();
			this.state = 1431;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1427;
				this.match(VtlParser.COMMA);
				this.state = 1428;
				this.componentID();
				}
				}
				this.state = 1433;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public orderByClause(): OrderByClauseContext {
		let localctx: OrderByClauseContext = new OrderByClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 100, VtlParser.RULE_orderByClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1434;
			this.match(VtlParser.ORDER);
			this.state = 1435;
			this.match(VtlParser.BY);
			this.state = 1436;
			this.orderByItem();
			this.state = 1441;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1437;
				this.match(VtlParser.COMMA);
				this.state = 1438;
				this.orderByItem();
				}
				}
				this.state = 1443;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public orderByItem(): OrderByItemContext {
		let localctx: OrderByItemContext = new OrderByItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 102, VtlParser.RULE_orderByItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1444;
			this.componentID();
			this.state = 1446;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===78 || _la===79) {
				{
				this.state = 1445;
				_la = this._input.LA(1);
				if(!(_la===78 || _la===79)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public windowingClause(): WindowingClauseContext {
		let localctx: WindowingClauseContext = new WindowingClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 104, VtlParser.RULE_windowingClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1451;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 119:
				{
				{
				this.state = 1448;
				this.match(VtlParser.DATA);
				this.state = 1449;
				this.match(VtlParser.POINTS);
				}
				}
				break;
			case 158:
				{
				this.state = 1450;
				this.match(VtlParser.RANGE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			this.state = 1453;
			this.match(VtlParser.BETWEEN);
			this.state = 1454;
			localctx._from_ = this.limitClauseItem();
			this.state = 1455;
			this.match(VtlParser.AND);
			this.state = 1456;
			localctx._to_ = this.limitClauseItem();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public signedInteger(): SignedIntegerContext {
		let localctx: SignedIntegerContext = new SignedIntegerContext(this, this._ctx, this.state);
		this.enterRule(localctx, 106, VtlParser.RULE_signedInteger);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1459;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===13 || _la===14) {
				{
				this.state = 1458;
				_la = this._input.LA(1);
				if(!(_la===13 || _la===14)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			this.state = 1461;
			this.match(VtlParser.INTEGER_CONSTANT);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public signedNumber(): SignedNumberContext {
		let localctx: SignedNumberContext = new SignedNumberContext(this, this._ctx, this.state);
		this.enterRule(localctx, 108, VtlParser.RULE_signedNumber);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1464;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===13 || _la===14) {
				{
				this.state = 1463;
				_la = this._input.LA(1);
				if(!(_la===13 || _la===14)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			this.state = 1466;
			this.match(VtlParser.NUMBER_CONSTANT);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public limitClauseItem(): LimitClauseItemContext {
		let localctx: LimitClauseItemContext = new LimitClauseItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 110, VtlParser.RULE_limitClauseItem);
		try {
			this.state = 1481;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 139, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1468;
				this.signedInteger();
				this.state = 1469;
				localctx._dir = this.match(VtlParser.PRECEDING);
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1471;
				this.signedInteger();
				this.state = 1472;
				localctx._dir = this.match(VtlParser.FOLLOWING);
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1474;
				this.match(VtlParser.CURRENT);
				this.state = 1475;
				this.match(VtlParser.DATA);
				this.state = 1476;
				this.match(VtlParser.POINT);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1477;
				this.match(VtlParser.UNBOUNDED);
				this.state = 1478;
				localctx._dir = this.match(VtlParser.PRECEDING);
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1479;
				this.match(VtlParser.UNBOUNDED);
				this.state = 1480;
				localctx._dir = this.match(VtlParser.FOLLOWING);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public groupingClause(): GroupingClauseContext {
		let localctx: GroupingClauseContext = new GroupingClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 112, VtlParser.RULE_groupingClause);
		let _la: number;
		try {
			this.state = 1511;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 144, this._ctx) ) {
			case 1:
				localctx = new GroupByOrExceptContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1483;
				this.match(VtlParser.GROUP);
				this.state = 1484;
				(localctx as GroupByOrExceptContext)._op = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===76 || _la===145)) {
				    (localctx as GroupByOrExceptContext)._op = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				this.state = 1485;
				this.componentID();
				this.state = 1490;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1486;
					this.match(VtlParser.COMMA);
					this.state = 1487;
					this.componentID();
					}
					}
					this.state = 1492;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1501;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===211) {
					{
					this.state = 1493;
					this.match(VtlParser.TIME_AGG);
					this.state = 1494;
					this.match(VtlParser.LPAREN);
					this.state = 1495;
					this.match(VtlParser.STRING_CONSTANT);
					this.state = 1498;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===17) {
						{
						this.state = 1496;
						this.match(VtlParser.COMMA);
						this.state = 1497;
						(localctx as GroupByOrExceptContext)._delim = this._input.LT(1);
						_la = this._input.LA(1);
						if(!(_la===82 || _la===83)) {
						    (localctx as GroupByOrExceptContext)._delim = this._errHandler.recoverInline(this);
						}
						else {
							this._errHandler.reportMatch(this);
						    this.consume();
						}
						}
					}

					this.state = 1500;
					this.match(VtlParser.RPAREN);
					}
				}

				}
				break;
			case 2:
				localctx = new GroupAllContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1503;
				this.match(VtlParser.GROUP);
				this.state = 1504;
				this.match(VtlParser.ALL);
				this.state = 1509;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===211) {
					{
					this.state = 1505;
					this.match(VtlParser.TIME_AGG);
					this.state = 1506;
					this.match(VtlParser.LPAREN);
					this.state = 1507;
					this.match(VtlParser.STRING_CONSTANT);
					this.state = 1508;
					this.match(VtlParser.RPAREN);
					}
				}

				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public havingClause(): HavingClauseContext {
		let localctx: HavingClauseContext = new HavingClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 114, VtlParser.RULE_havingClause);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1513;
			this.match(VtlParser.HAVING);
			this.state = 1514;
			this.exprComponent(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public parameterItem(): ParameterItemContext {
		let localctx: ParameterItemContext = new ParameterItemContext(this, this._ctx, this.state);
		this.enterRule(localctx, 116, VtlParser.RULE_parameterItem);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1516;
			this.varID();
			this.state = 1517;
			this.inputParameterType();
			this.state = 1520;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===221) {
				{
				this.state = 1518;
				this.match(VtlParser.DEFAULT);
				this.state = 1519;
				this.scalarItem();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public outputParameterType(): OutputParameterTypeContext {
		let localctx: OutputParameterTypeContext = new OutputParameterTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 118, VtlParser.RULE_outputParameterType);
		try {
			this.state = 1525;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 168:
			case 169:
			case 170:
			case 171:
			case 172:
			case 173:
			case 174:
			case 210:
			case 233:
			case 245:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1522;
				this.scalarType();
				}
				break;
			case 121:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1523;
				this.datasetType();
				}
				break;
			case 103:
			case 104:
			case 105:
			case 110:
			case 234:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1524;
				this.componentType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public outputParameterTypeComponent(): OutputParameterTypeComponentContext {
		let localctx: OutputParameterTypeComponentContext = new OutputParameterTypeComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 120, VtlParser.RULE_outputParameterTypeComponent);
		try {
			this.state = 1529;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 103:
			case 104:
			case 105:
			case 110:
			case 234:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1527;
				this.componentType();
				}
				break;
			case 168:
			case 169:
			case 170:
			case 171:
			case 172:
			case 173:
			case 174:
			case 210:
			case 233:
			case 245:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1528;
				this.scalarType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inputParameterType(): InputParameterTypeContext {
		let localctx: InputParameterTypeContext = new InputParameterTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 122, VtlParser.RULE_inputParameterType);
		try {
			this.state = 1536;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 168:
			case 169:
			case 170:
			case 171:
			case 172:
			case 173:
			case 174:
			case 210:
			case 233:
			case 245:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1531;
				this.scalarType();
				}
				break;
			case 121:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1532;
				this.datasetType();
				}
				break;
			case 239:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1533;
				this.scalarSetType();
				}
				break;
			case 125:
			case 126:
			case 127:
			case 235:
			case 236:
			case 237:
			case 238:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1534;
				this.rulesetType();
				}
				break;
			case 103:
			case 104:
			case 105:
			case 110:
			case 234:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1535;
				this.componentType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public rulesetType(): RulesetTypeContext {
		let localctx: RulesetTypeContext = new RulesetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 124, VtlParser.RULE_rulesetType);
		try {
			this.state = 1541;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 127:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1538;
				this.match(VtlParser.RULESET);
				}
				break;
			case 125:
			case 235:
			case 236:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1539;
				this.dpRuleset();
				}
				break;
			case 126:
			case 237:
			case 238:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1540;
				this.hrRuleset();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarType(): ScalarTypeContext {
		let localctx: ScalarTypeContext = new ScalarTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 126, VtlParser.RULE_scalarType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1545;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 168:
			case 169:
			case 170:
			case 171:
			case 172:
			case 173:
			case 174:
			case 210:
			case 233:
				{
				this.state = 1543;
				this.basicScalarType();
				}
				break;
			case 245:
				{
				this.state = 1544;
				this.valueDomainName();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			this.state = 1548;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===3 || _la===5) {
				{
				this.state = 1547;
				this.scalarTypeConstraint();
				}
			}

			this.state = 1554;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===50 || _la===54) {
				{
				this.state = 1551;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===50) {
					{
					this.state = 1550;
					this.match(VtlParser.NOT);
					}
				}

				this.state = 1553;
				this.match(VtlParser.NULL_CONSTANT);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public componentType(): ComponentTypeContext {
		let localctx: ComponentTypeContext = new ComponentTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 128, VtlParser.RULE_componentType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1556;
			this.componentRole();
			this.state = 1561;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===8) {
				{
				this.state = 1557;
				this.match(VtlParser.LT);
				this.state = 1558;
				this.scalarType();
				this.state = 1559;
				this.match(VtlParser.MT);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public datasetType(): DatasetTypeContext {
		let localctx: DatasetTypeContext = new DatasetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 130, VtlParser.RULE_datasetType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1563;
			this.match(VtlParser.DATASET);
			this.state = 1575;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===5) {
				{
				this.state = 1564;
				this.match(VtlParser.GLPAREN);
				this.state = 1565;
				this.compConstraint();
				this.state = 1570;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1566;
					this.match(VtlParser.COMMA);
					this.state = 1567;
					this.compConstraint();
					}
					}
					this.state = 1572;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1573;
				this.match(VtlParser.GRPAREN);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public evalDatasetType(): EvalDatasetTypeContext {
		let localctx: EvalDatasetTypeContext = new EvalDatasetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 132, VtlParser.RULE_evalDatasetType);
		try {
			this.state = 1579;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 121:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1577;
				this.datasetType();
				}
				break;
			case 168:
			case 169:
			case 170:
			case 171:
			case 172:
			case 173:
			case 174:
			case 210:
			case 233:
			case 245:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1578;
				this.scalarType();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarSetType(): ScalarSetTypeContext {
		let localctx: ScalarSetTypeContext = new ScalarSetTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 134, VtlParser.RULE_scalarSetType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1581;
			this.match(VtlParser.SET);
			this.state = 1586;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===8) {
				{
				this.state = 1582;
				this.match(VtlParser.LT);
				this.state = 1583;
				this.scalarType();
				this.state = 1584;
				this.match(VtlParser.MT);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public dpRuleset(): DpRulesetContext {
		let localctx: DpRulesetContext = new DpRulesetContext(this, this._ctx, this.state);
		this.enterRule(localctx, 136, VtlParser.RULE_dpRuleset);
		let _la: number;
		try {
			this.state = 1617;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 125:
				localctx = new DataPointContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1588;
				this.match(VtlParser.DATAPOINT);
				}
				break;
			case 235:
				localctx = new DataPointVdContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1589;
				this.match(VtlParser.DATAPOINT_ON_VD);
				this.state = 1601;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1590;
					this.match(VtlParser.GLPAREN);
					this.state = 1591;
					this.valueDomainName();
					this.state = 1596;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===15) {
						{
						{
						this.state = 1592;
						this.match(VtlParser.MUL);
						this.state = 1593;
						this.valueDomainName();
						}
						}
						this.state = 1598;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 1599;
					this.match(VtlParser.GRPAREN);
					}
				}

				}
				break;
			case 236:
				localctx = new DataPointVarContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1603;
				this.match(VtlParser.DATAPOINT_ON_VAR);
				this.state = 1615;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1604;
					this.match(VtlParser.GLPAREN);
					this.state = 1605;
					this.varID();
					this.state = 1610;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					while (_la===15) {
						{
						{
						this.state = 1606;
						this.match(VtlParser.MUL);
						this.state = 1607;
						this.varID();
						}
						}
						this.state = 1612;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
					}
					this.state = 1613;
					this.match(VtlParser.GRPAREN);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public hrRuleset(): HrRulesetContext {
		let localctx: HrRulesetContext = new HrRulesetContext(this, this._ctx, this.state);
		this.enterRule(localctx, 138, VtlParser.RULE_hrRuleset);
		let _la: number;
		try {
			this.state = 1659;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 126:
				localctx = new HrRulesetTypeContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1619;
				this.match(VtlParser.HIERARCHICAL);
				}
				break;
			case 237:
				localctx = new HrRulesetVdTypeContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1620;
				this.match(VtlParser.HIERARCHICAL_ON_VD);
				this.state = 1637;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1621;
					this.match(VtlParser.GLPAREN);
					this.state = 1622;
					(localctx as HrRulesetVdTypeContext)._vdName = this.match(VtlParser.IDENTIFIER);
					this.state = 1634;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===1) {
						{
						this.state = 1623;
						this.match(VtlParser.LPAREN);
						this.state = 1624;
						this.valueDomainName();
						this.state = 1629;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
						while (_la===15) {
							{
							{
							this.state = 1625;
							this.match(VtlParser.MUL);
							this.state = 1626;
							this.valueDomainName();
							}
							}
							this.state = 1631;
							this._errHandler.sync(this);
							_la = this._input.LA(1);
						}
						this.state = 1632;
						this.match(VtlParser.RPAREN);
						}
					}

					this.state = 1636;
					this.match(VtlParser.GRPAREN);
					}
				}

				}
				break;
			case 238:
				localctx = new HrRulesetVarTypeContext(this, localctx);
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1639;
				this.match(VtlParser.HIERARCHICAL_ON_VAR);
				this.state = 1657;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				if (_la===5) {
					{
					this.state = 1640;
					this.match(VtlParser.GLPAREN);
					this.state = 1641;
					(localctx as HrRulesetVarTypeContext)._varName = this.varID();
					this.state = 1653;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
					if (_la===1) {
						{
						this.state = 1642;
						this.match(VtlParser.LPAREN);
						this.state = 1643;
						this.varID();
						this.state = 1648;
						this._errHandler.sync(this);
						_la = this._input.LA(1);
						while (_la===15) {
							{
							{
							this.state = 1644;
							this.match(VtlParser.MUL);
							this.state = 1645;
							this.varID();
							}
							}
							this.state = 1650;
							this._errHandler.sync(this);
							_la = this._input.LA(1);
						}
						this.state = 1651;
						this.match(VtlParser.RPAREN);
						}
					}

					this.state = 1655;
					this.match(VtlParser.GRPAREN);
					}
				}

				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainName(): ValueDomainNameContext {
		let localctx: ValueDomainNameContext = new ValueDomainNameContext(this, this._ctx, this.state);
		this.enterRule(localctx, 140, VtlParser.RULE_valueDomainName);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1661;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public rulesetID(): RulesetIDContext {
		let localctx: RulesetIDContext = new RulesetIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 142, VtlParser.RULE_rulesetID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1663;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public rulesetSignature(): RulesetSignatureContext {
		let localctx: RulesetSignatureContext = new RulesetSignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 144, VtlParser.RULE_rulesetSignature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1665;
			_la = this._input.LA(1);
			if(!(_la===117 || _la===118)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 1666;
			this.signature();
			this.state = 1671;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1667;
				this.match(VtlParser.COMMA);
				this.state = 1668;
				this.signature();
				}
				}
				this.state = 1673;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public signature(): SignatureContext {
		let localctx: SignatureContext = new SignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 146, VtlParser.RULE_signature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1674;
			this.varID();
			this.state = 1677;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===46) {
				{
				this.state = 1675;
				this.match(VtlParser.AS);
				this.state = 1676;
				this.alias();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleClauseDatapoint(): RuleClauseDatapointContext {
		let localctx: RuleClauseDatapointContext = new RuleClauseDatapointContext(this, this._ctx, this.state);
		this.enterRule(localctx, 148, VtlParser.RULE_ruleClauseDatapoint);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1679;
			this.ruleItemDatapoint();
			this.state = 1684;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===247) {
				{
				{
				this.state = 1680;
				this.match(VtlParser.EOL);
				this.state = 1681;
				this.ruleItemDatapoint();
				}
				}
				this.state = 1686;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleItemDatapoint(): RuleItemDatapointContext {
		let localctx: RuleItemDatapointContext = new RuleItemDatapointContext(this, this._ctx, this.state);
		this.enterRule(localctx, 150, VtlParser.RULE_ruleItemDatapoint);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1689;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 174, this._ctx) ) {
			case 1:
				{
				this.state = 1687;
				localctx._ruleName = this.match(VtlParser.IDENTIFIER);
				this.state = 1688;
				this.match(VtlParser.COLON);
				}
				break;
			}
			this.state = 1695;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===185) {
				{
				this.state = 1691;
				this.match(VtlParser.WHEN);
				this.state = 1692;
				localctx._antecedentContiditon = this.exprComponent(0);
				this.state = 1693;
				this.match(VtlParser.THEN);
				}
			}

			this.state = 1697;
			localctx._consequentCondition = this.exprComponent(0);
			this.state = 1699;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===71) {
				{
				this.state = 1698;
				this.erCode();
				}
			}

			this.state = 1702;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===74) {
				{
				this.state = 1701;
				this.erLevel();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleClauseHierarchical(): RuleClauseHierarchicalContext {
		let localctx: RuleClauseHierarchicalContext = new RuleClauseHierarchicalContext(this, this._ctx, this.state);
		this.enterRule(localctx, 152, VtlParser.RULE_ruleClauseHierarchical);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1704;
			this.ruleItemHierarchical();
			this.state = 1709;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===247) {
				{
				{
				this.state = 1705;
				this.match(VtlParser.EOL);
				this.state = 1706;
				this.ruleItemHierarchical();
				}
				}
				this.state = 1711;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public ruleItemHierarchical(): RuleItemHierarchicalContext {
		let localctx: RuleItemHierarchicalContext = new RuleItemHierarchicalContext(this, this._ctx, this.state);
		this.enterRule(localctx, 154, VtlParser.RULE_ruleItemHierarchical);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1714;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 179, this._ctx) ) {
			case 1:
				{
				this.state = 1712;
				localctx._ruleName = this.match(VtlParser.IDENTIFIER);
				this.state = 1713;
				this.match(VtlParser.COLON);
				}
				break;
			}
			this.state = 1716;
			this.codeItemRelation();
			this.state = 1718;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===71) {
				{
				this.state = 1717;
				this.erCode();
				}
			}

			this.state = 1721;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===74) {
				{
				this.state = 1720;
				this.erLevel();
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public hierRuleSignature(): HierRuleSignatureContext {
		let localctx: HierRuleSignatureContext = new HierRuleSignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 156, VtlParser.RULE_hierRuleSignature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1723;
			_la = this._input.LA(1);
			if(!(_la===117 || _la===118)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			this.state = 1726;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===167) {
				{
				this.state = 1724;
				this.match(VtlParser.CONDITION);
				this.state = 1725;
				this.valueDomainSignature();
				}
			}

			this.state = 1728;
			this.match(VtlParser.RULE);
			this.state = 1729;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainSignature(): ValueDomainSignatureContext {
		let localctx: ValueDomainSignatureContext = new ValueDomainSignatureContext(this, this._ctx, this.state);
		this.enterRule(localctx, 158, VtlParser.RULE_valueDomainSignature);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1731;
			this.signature();
			this.state = 1736;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1732;
				this.match(VtlParser.COMMA);
				this.state = 1733;
				this.signature();
				}
				}
				this.state = 1738;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public codeItemRelation(): CodeItemRelationContext {
		let localctx: CodeItemRelationContext = new CodeItemRelationContext(this, this._ctx, this.state);
		this.enterRule(localctx, 160, VtlParser.RULE_codeItemRelation);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1743;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===185) {
				{
				this.state = 1739;
				this.match(VtlParser.WHEN);
				this.state = 1740;
				this.exprComponent(0);
				this.state = 1741;
				this.match(VtlParser.THEN);
				}
			}

			this.state = 1745;
			localctx._codetemRef = this.valueDomainValue();
			this.state = 1747;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 8064) !== 0)) {
				{
				this.state = 1746;
				this.comparisonOperand();
				}
			}

			this.state = 1749;
			this.codeItemRelationClause();
			this.state = 1753;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===13 || _la===14 || ((((_la - 241)) & ~0x1F) === 0 && ((1 << (_la - 241)) & 19) !== 0)) {
				{
				{
				this.state = 1750;
				this.codeItemRelationClause();
				}
				}
				this.state = 1755;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public codeItemRelationClause(): CodeItemRelationClauseContext {
		let localctx: CodeItemRelationClauseContext = new CodeItemRelationClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 162, VtlParser.RULE_codeItemRelationClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1757;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 187, this._ctx) ) {
			case 1:
				{
				this.state = 1756;
				localctx._opAdd = this._input.LT(1);
				_la = this._input.LA(1);
				if(!(_la===13 || _la===14)) {
				    localctx._opAdd = this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
				break;
			}
			this.state = 1759;
			localctx._rightCodeItem = this.valueDomainValue();
			this.state = 1764;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===3) {
				{
				this.state = 1760;
				this.match(VtlParser.QLPAREN);
				this.state = 1761;
				localctx._rightCondition = this.exprComponent(0);
				this.state = 1762;
				this.match(VtlParser.QRPAREN);
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainValue(): ValueDomainValueContext {
		let localctx: ValueDomainValueContext = new ValueDomainValueContext(this, this._ctx, this.state);
		this.enterRule(localctx, 164, VtlParser.RULE_valueDomainValue);
		try {
			this.state = 1769;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 189, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1766;
				this.match(VtlParser.IDENTIFIER);
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1767;
				this.signedInteger();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1768;
				this.signedNumber();
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public scalarTypeConstraint(): ScalarTypeConstraintContext {
		let localctx: ScalarTypeConstraintContext = new ScalarTypeConstraintContext(this, this._ctx, this.state);
		this.enterRule(localctx, 166, VtlParser.RULE_scalarTypeConstraint);
		let _la: number;
		try {
			this.state = 1786;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 3:
				localctx = new ConditionConstraintContext(this, localctx);
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1771;
				this.match(VtlParser.QLPAREN);
				this.state = 1772;
				this.exprComponent(0);
				this.state = 1773;
				this.match(VtlParser.QRPAREN);
				}
				break;
			case 5:
				localctx = new RangeConstraintContext(this, localctx);
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1775;
				this.match(VtlParser.GLPAREN);
				this.state = 1776;
				this.scalarItem();
				this.state = 1781;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
				while (_la===17) {
					{
					{
					this.state = 1777;
					this.match(VtlParser.COMMA);
					this.state = 1778;
					this.scalarItem();
					}
					}
					this.state = 1783;
					this._errHandler.sync(this);
					_la = this._input.LA(1);
				}
				this.state = 1784;
				this.match(VtlParser.GRPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public compConstraint(): CompConstraintContext {
		let localctx: CompConstraintContext = new CompConstraintContext(this, this._ctx, this.state);
		this.enterRule(localctx, 168, VtlParser.RULE_compConstraint);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1788;
			this.componentType();
			this.state = 1791;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 245:
				{
				this.state = 1789;
				this.componentID();
				}
				break;
			case 115:
				{
				this.state = 1790;
				this.multModifier();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public multModifier(): MultModifierContext {
		let localctx: MultModifierContext = new MultModifierContext(this, this._ctx, this.state);
		this.enterRule(localctx, 170, VtlParser.RULE_multModifier);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1793;
			this.match(VtlParser.OPTIONAL);
			this.state = 1795;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			if (_la===13 || _la===15) {
				{
				this.state = 1794;
				_la = this._input.LA(1);
				if(!(_la===13 || _la===15)) {
				this._errHandler.recoverInline(this);
				}
				else {
					this._errHandler.reportMatch(this);
				    this.consume();
				}
				}
			}

			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public validationOutput(): ValidationOutputContext {
		let localctx: ValidationOutputContext = new ValidationOutputContext(this, this._ctx, this.state);
		this.enterRule(localctx, 172, VtlParser.RULE_validationOutput);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1797;
			_la = this._input.LA(1);
			if(!(_la===72 || _la===116 || _la===232)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public validationMode(): ValidationModeContext {
		let localctx: ValidationModeContext = new ValidationModeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 174, VtlParser.RULE_validationMode);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1799;
			_la = this._input.LA(1);
			if(!(((((_la - 225)) & ~0x1F) === 0 && ((1 << (_la - 225)) & 63) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public conditionClause(): ConditionClauseContext {
		let localctx: ConditionClauseContext = new ConditionClauseContext(this, this._ctx, this.state);
		this.enterRule(localctx, 176, VtlParser.RULE_conditionClause);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1801;
			this.match(VtlParser.CONDITION);
			this.state = 1802;
			this.componentID();
			this.state = 1807;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1803;
				this.match(VtlParser.COMMA);
				this.state = 1804;
				this.componentID();
				}
				}
				this.state = 1809;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inputMode(): InputModeContext {
		let localctx: InputModeContext = new InputModeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 178, VtlParser.RULE_inputMode);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1810;
			_la = this._input.LA(1);
			if(!(_la===121 || _la===220)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public imbalanceExpr(): ImbalanceExprContext {
		let localctx: ImbalanceExprContext = new ImbalanceExprContext(this, this._ctx, this.state);
		this.enterRule(localctx, 180, VtlParser.RULE_imbalanceExpr);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1812;
			this.match(VtlParser.IMBALANCE);
			this.state = 1813;
			this.expr(0);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public inputModeHierarchy(): InputModeHierarchyContext {
		let localctx: InputModeHierarchyContext = new InputModeHierarchyContext(this, this._ctx, this.state);
		this.enterRule(localctx, 182, VtlParser.RULE_inputModeHierarchy);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1815;
			_la = this._input.LA(1);
			if(!(_la===121 || _la===128 || _la===219)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public outputModeHierarchy(): OutputModeHierarchyContext {
		let localctx: OutputModeHierarchyContext = new OutputModeHierarchyContext(this, this._ctx, this.state);
		this.enterRule(localctx, 184, VtlParser.RULE_outputModeHierarchy);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1817;
			_la = this._input.LA(1);
			if(!(_la===72 || _la===224)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public alias(): AliasContext {
		let localctx: AliasContext = new AliasContext(this, this._ctx, this.state);
		this.enterRule(localctx, 186, VtlParser.RULE_alias);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1819;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public varID(): VarIDContext {
		let localctx: VarIDContext = new VarIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 188, VtlParser.RULE_varID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1821;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public simpleComponentId(): SimpleComponentIdContext {
		let localctx: SimpleComponentIdContext = new SimpleComponentIdContext(this, this._ctx, this.state);
		this.enterRule(localctx, 190, VtlParser.RULE_simpleComponentId);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1823;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public componentID(): ComponentIDContext {
		let localctx: ComponentIDContext = new ComponentIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 192, VtlParser.RULE_componentID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1825;
			this.match(VtlParser.IDENTIFIER);
			this.state = 1828;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 195, this._ctx) ) {
			case 1:
				{
				this.state = 1826;
				this.match(VtlParser.MEMBERSHIP);
				this.state = 1827;
				this.match(VtlParser.IDENTIFIER);
				}
				break;
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public lists(): ListsContext {
		let localctx: ListsContext = new ListsContext(this, this._ctx, this.state);
		this.enterRule(localctx, 194, VtlParser.RULE_lists);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1830;
			this.match(VtlParser.GLPAREN);
			this.state = 1831;
			this.scalarItem();
			this.state = 1836;
			this._errHandler.sync(this);
			_la = this._input.LA(1);
			while (_la===17) {
				{
				{
				this.state = 1832;
				this.match(VtlParser.COMMA);
				this.state = 1833;
				this.scalarItem();
				}
				}
				this.state = 1838;
				this._errHandler.sync(this);
				_la = this._input.LA(1);
			}
			this.state = 1839;
			this.match(VtlParser.GRPAREN);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public erCode(): ErCodeContext {
		let localctx: ErCodeContext = new ErCodeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 196, VtlParser.RULE_erCode);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1841;
			this.match(VtlParser.ERRORCODE);
			this.state = 1842;
			this.constant();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public erLevel(): ErLevelContext {
		let localctx: ErLevelContext = new ErLevelContext(this, this._ctx, this.state);
		this.enterRule(localctx, 198, VtlParser.RULE_erLevel);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1844;
			this.match(VtlParser.ERRORLEVEL);
			this.state = 1845;
			this.constant();
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public comparisonOperand(): ComparisonOperandContext {
		let localctx: ComparisonOperandContext = new ComparisonOperandContext(this, this._ctx, this.state);
		this.enterRule(localctx, 200, VtlParser.RULE_comparisonOperand);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1847;
			_la = this._input.LA(1);
			if(!((((_la) & ~0x1F) === 0 && ((1 << _la) & 8064) !== 0))) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public optionalExpr(): OptionalExprContext {
		let localctx: OptionalExprContext = new OptionalExprContext(this, this._ctx, this.state);
		this.enterRule(localctx, 202, VtlParser.RULE_optionalExpr);
		try {
			this.state = 1851;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 13:
			case 14:
			case 22:
			case 23:
			case 24:
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 50:
			case 51:
			case 54:
			case 55:
			case 57:
			case 59:
			case 60:
			case 61:
			case 66:
			case 67:
			case 80:
			case 81:
			case 85:
			case 87:
			case 88:
			case 89:
			case 90:
			case 91:
			case 92:
			case 93:
			case 95:
			case 96:
			case 97:
			case 98:
			case 99:
			case 100:
			case 101:
			case 102:
			case 108:
			case 111:
			case 113:
			case 114:
			case 131:
			case 132:
			case 133:
			case 134:
			case 135:
			case 136:
			case 137:
			case 139:
			case 140:
			case 141:
			case 142:
			case 143:
			case 147:
			case 148:
			case 149:
			case 150:
			case 151:
			case 161:
			case 162:
			case 163:
			case 164:
			case 193:
			case 194:
			case 195:
			case 196:
			case 208:
			case 211:
			case 218:
			case 222:
			case 223:
			case 241:
			case 242:
			case 243:
			case 244:
			case 245:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1849;
				this.expr(0);
				}
				break;
			case 115:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1850;
				this.match(VtlParser.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public optionalExprComponent(): OptionalExprComponentContext {
		let localctx: OptionalExprComponentContext = new OptionalExprComponentContext(this, this._ctx, this.state);
		this.enterRule(localctx, 204, VtlParser.RULE_optionalExprComponent);
		try {
			this.state = 1855;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 1:
			case 13:
			case 14:
			case 22:
			case 23:
			case 24:
			case 29:
			case 30:
			case 31:
			case 32:
			case 33:
			case 34:
			case 35:
			case 36:
			case 37:
			case 38:
			case 39:
			case 50:
			case 51:
			case 54:
			case 55:
			case 61:
			case 77:
			case 80:
			case 81:
			case 85:
			case 87:
			case 88:
			case 89:
			case 90:
			case 91:
			case 92:
			case 93:
			case 95:
			case 96:
			case 97:
			case 98:
			case 99:
			case 100:
			case 101:
			case 102:
			case 108:
			case 111:
			case 113:
			case 131:
			case 132:
			case 133:
			case 134:
			case 135:
			case 136:
			case 137:
			case 140:
			case 141:
			case 142:
			case 143:
			case 147:
			case 148:
			case 149:
			case 150:
			case 151:
			case 161:
			case 162:
			case 163:
			case 164:
			case 208:
			case 211:
			case 218:
			case 241:
			case 242:
			case 243:
			case 244:
			case 245:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1853;
				this.exprComponent(0);
				}
				break;
			case 115:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1854;
				this.match(VtlParser.OPTIONAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public componentRole(): ComponentRoleContext {
		let localctx: ComponentRoleContext = new ComponentRoleContext(this, this._ctx, this.state);
		this.enterRule(localctx, 206, VtlParser.RULE_componentRole);
		try {
			this.state = 1862;
			this._errHandler.sync(this);
			switch (this._input.LA(1)) {
			case 104:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1857;
				this.match(VtlParser.MEASURE);
				}
				break;
			case 234:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1858;
				this.match(VtlParser.COMPONENT);
				}
				break;
			case 103:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1859;
				this.match(VtlParser.DIMENSION);
				}
				break;
			case 105:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1860;
				this.match(VtlParser.ATTRIBUTE);
				}
				break;
			case 110:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1861;
				this.viralAttribute();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public viralAttribute(): ViralAttributeContext {
		let localctx: ViralAttributeContext = new ViralAttributeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 208, VtlParser.RULE_viralAttribute);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1864;
			this.match(VtlParser.VIRAL);
			this.state = 1865;
			this.match(VtlParser.ATTRIBUTE);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public valueDomainID(): ValueDomainIDContext {
		let localctx: ValueDomainIDContext = new ValueDomainIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 210, VtlParser.RULE_valueDomainID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1867;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public operatorID(): OperatorIDContext {
		let localctx: OperatorIDContext = new OperatorIDContext(this, this._ctx, this.state);
		this.enterRule(localctx, 212, VtlParser.RULE_operatorID);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1869;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public routineName(): RoutineNameContext {
		let localctx: RoutineNameContext = new RoutineNameContext(this, this._ctx, this.state);
		this.enterRule(localctx, 214, VtlParser.RULE_routineName);
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1871;
			this.match(VtlParser.IDENTIFIER);
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public constant(): ConstantContext {
		let localctx: ConstantContext = new ConstantContext(this, this._ctx, this.state);
		this.enterRule(localctx, 216, VtlParser.RULE_constant);
		try {
			this.state = 1878;
			this._errHandler.sync(this);
			switch ( this._interp.adaptivePredict(this._input, 200, this._ctx) ) {
			case 1:
				this.enterOuterAlt(localctx, 1);
				{
				this.state = 1873;
				this.signedInteger();
				}
				break;
			case 2:
				this.enterOuterAlt(localctx, 2);
				{
				this.state = 1874;
				this.signedNumber();
				}
				break;
			case 3:
				this.enterOuterAlt(localctx, 3);
				{
				this.state = 1875;
				this.match(VtlParser.BOOLEAN_CONSTANT);
				}
				break;
			case 4:
				this.enterOuterAlt(localctx, 4);
				{
				this.state = 1876;
				this.match(VtlParser.STRING_CONSTANT);
				}
				break;
			case 5:
				this.enterOuterAlt(localctx, 5);
				{
				this.state = 1877;
				this.match(VtlParser.NULL_CONSTANT);
				}
				break;
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public basicScalarType(): BasicScalarTypeContext {
		let localctx: BasicScalarTypeContext = new BasicScalarTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 218, VtlParser.RULE_basicScalarType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1880;
			_la = this._input.LA(1);
			if(!(((((_la - 168)) & ~0x1F) === 0 && ((1 << (_la - 168)) & 127) !== 0) || _la===210 || _la===233)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}
	// @RuleVersion(0)
	public retainType(): RetainTypeContext {
		let localctx: RetainTypeContext = new RetainTypeContext(this, this._ctx, this.state);
		this.enterRule(localctx, 220, VtlParser.RULE_retainType);
		let _la: number;
		try {
			this.enterOuterAlt(localctx, 1);
			{
			this.state = 1882;
			_la = this._input.LA(1);
			if(!(_la===72 || _la===243)) {
			this._errHandler.recoverInline(this);
			}
			else {
				this._errHandler.reportMatch(this);
			    this.consume();
			}
			}
		}
		catch (re) {
			if (re instanceof RecognitionException) {
				localctx.exception = re;
				this._errHandler.reportError(this, re);
				this._errHandler.recover(this, re);
			} else {
				throw re;
			}
		}
		finally {
			this.exitRule();
		}
		return localctx;
	}

	public sempred(localctx: RuleContext, ruleIndex: number, predIndex: number): boolean {
		switch (ruleIndex) {
		case 2:
			return this.expr_sempred(localctx as ExprContext, predIndex);
		case 3:
			return this.exprComponent_sempred(localctx as ExprComponentContext, predIndex);
		}
		return true;
	}
	private expr_sempred(localctx: ExprContext, predIndex: number): boolean {
		switch (predIndex) {
		case 0:
			return this.precpred(this._ctx, 10);
		case 1:
			return this.precpred(this._ctx, 9);
		case 2:
			return this.precpred(this._ctx, 8);
		case 3:
			return this.precpred(this._ctx, 6);
		case 4:
			return this.precpred(this._ctx, 5);
		case 5:
			return this.precpred(this._ctx, 13);
		case 6:
			return this.precpred(this._ctx, 12);
		case 7:
			return this.precpred(this._ctx, 7);
		}
		return true;
	}
	private exprComponent_sempred(localctx: ExprComponentContext, predIndex: number): boolean {
		switch (predIndex) {
		case 8:
			return this.precpred(this._ctx, 10);
		case 9:
			return this.precpred(this._ctx, 9);
		case 10:
			return this.precpred(this._ctx, 8);
		case 11:
			return this.precpred(this._ctx, 6);
		case 12:
			return this.precpred(this._ctx, 5);
		case 13:
			return this.precpred(this._ctx, 7);
		}
		return true;
	}

	public static readonly _serializedATN: number[] = [4,1,249,1885,2,0,7,0,
	2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,
	2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,2,14,7,14,2,15,7,15,2,16,7,16,2,
	17,7,17,2,18,7,18,2,19,7,19,2,20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,
	7,24,2,25,7,25,2,26,7,26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,
	31,2,32,7,32,2,33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,
	2,39,7,39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
	46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,52,2,53,
	7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,59,7,59,2,60,7,
	60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,2,65,7,65,2,66,7,66,2,67,7,67,
	2,68,7,68,2,69,7,69,2,70,7,70,2,71,7,71,2,72,7,72,2,73,7,73,2,74,7,74,2,
	75,7,75,2,76,7,76,2,77,7,77,2,78,7,78,2,79,7,79,2,80,7,80,2,81,7,81,2,82,
	7,82,2,83,7,83,2,84,7,84,2,85,7,85,2,86,7,86,2,87,7,87,2,88,7,88,2,89,7,
	89,2,90,7,90,2,91,7,91,2,92,7,92,2,93,7,93,2,94,7,94,2,95,7,95,2,96,7,96,
	2,97,7,97,2,98,7,98,2,99,7,99,2,100,7,100,2,101,7,101,2,102,7,102,2,103,
	7,103,2,104,7,104,2,105,7,105,2,106,7,106,2,107,7,107,2,108,7,108,2,109,
	7,109,2,110,7,110,1,0,1,0,1,0,5,0,226,8,0,10,0,12,0,229,9,0,1,0,1,0,1,1,
	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,242,8,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
	1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,4,2,265,8,2,11,
	2,12,2,266,1,2,1,2,1,2,1,2,1,2,3,2,274,8,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
	1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
	1,2,1,2,1,2,3,2,304,8,2,5,2,306,8,2,10,2,12,2,309,9,2,1,3,1,3,1,3,1,3,1,
	3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,4,3,332,
	8,3,11,3,12,3,333,1,3,1,3,1,3,1,3,1,3,3,3,341,8,3,1,3,1,3,1,3,1,3,1,3,1,
	3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,363,8,3,5,
	3,365,8,3,10,3,12,3,368,9,3,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,378,8,4,
	1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,1,5,3,5,392,8,5,1,6,1,6,1,6,
	1,6,1,6,1,6,1,6,3,6,401,8,6,1,7,1,7,1,7,1,7,5,7,407,8,7,10,7,12,7,410,9,
	7,1,8,1,8,1,8,1,8,3,8,416,8,8,3,8,418,8,8,1,9,1,9,1,9,1,10,1,10,1,10,1,
	10,5,10,427,8,10,10,10,12,10,430,9,10,1,11,1,11,1,11,1,11,5,11,436,8,11,
	10,11,12,11,439,9,11,1,12,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,
	1,13,1,13,1,13,5,13,454,8,13,10,13,12,13,457,9,13,1,14,1,14,1,14,1,14,5,
	14,463,8,14,10,14,12,14,466,9,14,1,15,1,15,1,15,1,15,1,15,1,15,1,15,1,15,
	1,15,1,15,1,15,1,15,3,15,480,8,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,5,
	16,489,8,16,10,16,12,16,492,9,16,3,16,494,8,16,1,16,1,16,1,16,3,16,499,
	8,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,
	16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,
	1,16,1,16,1,16,3,16,532,8,16,1,17,1,17,1,17,1,17,1,17,5,17,539,8,17,10,
	17,12,17,542,9,17,3,17,544,8,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,
	3,17,554,8,17,1,17,1,17,1,17,3,17,559,8,17,5,17,561,8,17,10,17,12,17,564,
	9,17,1,17,1,17,1,17,3,17,569,8,17,1,17,1,17,3,17,573,8,17,1,17,1,17,1,17,
	1,17,1,17,1,17,1,17,1,17,3,17,583,8,17,1,17,1,17,3,17,587,8,17,1,17,1,17,
	3,17,591,8,17,1,18,1,18,1,18,1,18,1,18,5,18,598,8,18,10,18,12,18,601,9,
	18,3,18,603,8,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,3,18,613,8,18,
	1,18,1,18,3,18,617,8,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,3,18,627,
	8,18,1,18,1,18,1,18,3,18,632,8,18,5,18,634,8,18,10,18,12,18,637,9,18,1,
	18,1,18,1,18,3,18,642,8,18,1,18,1,18,3,18,646,8,18,1,18,1,18,3,18,650,8,
	18,1,19,1,19,3,19,654,8,19,1,20,1,20,3,20,658,8,20,1,21,1,21,1,21,1,21,
	1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,674,8,21,1,21,1,
	21,3,21,678,8,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,689,
	8,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,3,21,700,8,21,1,21,1,
	21,3,21,704,8,21,1,21,1,21,3,21,708,8,21,1,22,1,22,1,22,1,22,1,22,1,22,
	1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,3,22,724,8,22,1,22,1,22,3,22,728,
	8,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,3,22,739,8,22,1,22,1,
	22,1,22,1,22,1,22,1,22,1,22,1,22,1,22,3,22,750,8,22,1,22,1,22,3,22,754,
	8,22,1,22,1,22,3,22,758,8,22,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,
	23,1,23,3,23,770,8,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,3,23,
	781,8,23,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,793,8,24,
	1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,1,24,3,24,804,8,24,1,25,1,25,1,
	25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
	1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,1,25,3,25,834,8,25,1,
	25,1,25,3,25,838,8,25,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,
	1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,1,26,3,26,861,8,26,1,
	27,1,27,1,27,3,27,866,8,27,1,27,1,27,1,27,1,27,1,27,1,27,3,27,874,8,27,
	1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,
	27,1,27,1,27,1,27,1,27,3,27,895,8,27,1,27,1,27,3,27,899,8,27,1,27,1,27,
	3,27,903,8,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,
	27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,
	1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,
	27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,
	1,27,1,27,1,27,1,27,1,27,3,27,965,8,27,1,28,1,28,1,28,3,28,970,8,28,1,28,
	1,28,1,28,1,28,1,28,1,28,3,28,978,8,28,1,28,1,28,1,28,1,28,1,28,1,28,1,
	28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,999,
	8,28,1,28,1,28,3,28,1003,8,28,1,28,1,28,3,28,1007,8,28,1,28,1,28,1,28,1,
	28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,
	1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,
	28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,
	1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,3,28,1069,
	8,28,1,29,1,29,1,29,1,29,1,29,4,29,1076,8,29,11,29,12,29,1077,1,29,1,29,
	1,29,1,29,1,29,1,29,1,29,4,29,1087,8,29,11,29,12,29,1088,1,29,1,29,1,29,
	1,29,1,29,1,29,1,29,1,29,1,29,3,29,1100,8,29,1,30,1,30,1,30,1,30,1,30,1,
	30,3,30,1108,8,30,1,30,1,30,3,30,1112,8,30,1,30,3,30,1115,8,30,1,30,3,30,
	1118,8,30,1,30,3,30,1121,8,30,1,30,1,30,1,31,1,31,1,31,1,31,1,31,1,31,1,
	31,1,31,1,31,5,31,1134,8,31,10,31,12,31,1137,9,31,3,31,1139,8,31,1,31,3,
	31,1142,8,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,1152,8,31,1,31,
	1,31,3,31,1156,8,31,1,31,3,31,1159,8,31,1,31,3,31,1162,8,31,1,31,3,31,1165,
	8,31,1,31,1,31,1,31,1,31,1,31,1,31,3,31,1173,8,31,1,31,3,31,1176,8,31,1,
	31,3,31,1179,8,31,1,31,3,31,1182,8,31,1,31,1,31,3,31,1186,8,31,1,32,1,32,
	1,32,1,32,1,32,1,32,1,32,1,33,1,33,1,33,1,33,1,33,1,33,1,33,1,34,1,34,1,
	34,1,34,1,34,1,34,1,34,1,34,3,34,1210,8,34,1,35,1,35,1,35,1,35,1,35,3,35,
	1217,8,35,3,35,1219,8,35,1,35,1,35,1,36,1,36,1,36,1,36,1,36,1,36,3,36,1229,
	8,36,1,36,3,36,1232,8,36,1,36,3,36,1235,8,36,1,36,1,36,1,36,1,36,1,36,1,
	36,1,36,1,36,1,36,1,36,3,36,1247,8,36,3,36,1249,8,36,1,36,1,36,1,36,3,36,
	1254,8,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,1,
	36,1,36,3,36,1270,8,36,1,37,1,37,1,37,1,37,1,37,1,37,3,37,1278,8,37,1,37,
	3,37,1281,8,37,1,37,3,37,1284,8,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,
	37,1,37,3,37,1295,8,37,3,37,1297,8,37,1,37,1,37,1,37,3,37,1302,8,37,1,37,
	1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,3,37,1314,8,37,1,37,1,37,1,
	37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,1,37,3,37,1330,8,37,
	1,38,1,38,1,38,1,38,1,39,1,39,1,39,5,39,1339,8,39,10,39,12,39,1342,9,39,
	1,40,3,40,1345,8,40,1,40,1,40,1,40,1,40,1,41,3,41,1352,8,41,1,41,1,41,1,
	41,1,41,1,42,1,42,1,42,1,42,1,43,1,43,1,43,1,43,1,43,1,43,1,43,1,43,3,43,
	1370,8,43,1,43,1,43,3,43,1374,8,43,1,44,1,44,1,44,5,44,1379,8,44,10,44,
	12,44,1382,9,44,1,45,1,45,1,45,5,45,1387,8,45,10,45,12,45,1390,9,45,1,45,
	1,45,1,45,1,45,5,45,1396,8,45,10,45,12,45,1399,9,45,3,45,1401,8,45,1,46,
	1,46,1,46,3,46,1406,8,46,1,47,3,47,1409,8,47,1,47,1,47,1,47,3,47,1414,8,
	47,1,47,3,47,1417,8,47,1,47,3,47,1420,8,47,1,48,1,48,1,48,1,49,1,49,1,49,
	1,49,1,49,5,49,1430,8,49,10,49,12,49,1433,9,49,1,50,1,50,1,50,1,50,1,50,
	5,50,1440,8,50,10,50,12,50,1443,9,50,1,51,1,51,3,51,1447,8,51,1,52,1,52,
	1,52,3,52,1452,8,52,1,52,1,52,1,52,1,52,1,52,1,53,3,53,1460,8,53,1,53,1,
	53,1,54,3,54,1465,8,54,1,54,1,54,1,55,1,55,1,55,1,55,1,55,1,55,1,55,1,55,
	1,55,1,55,1,55,1,55,1,55,3,55,1482,8,55,1,56,1,56,1,56,1,56,1,56,5,56,1489,
	8,56,10,56,12,56,1492,9,56,1,56,1,56,1,56,1,56,1,56,3,56,1499,8,56,1,56,
	3,56,1502,8,56,1,56,1,56,1,56,1,56,1,56,1,56,3,56,1510,8,56,3,56,1512,8,
	56,1,57,1,57,1,57,1,58,1,58,1,58,1,58,3,58,1521,8,58,1,59,1,59,1,59,3,59,
	1526,8,59,1,60,1,60,3,60,1530,8,60,1,61,1,61,1,61,1,61,1,61,3,61,1537,8,
	61,1,62,1,62,1,62,3,62,1542,8,62,1,63,1,63,3,63,1546,8,63,1,63,3,63,1549,
	8,63,1,63,3,63,1552,8,63,1,63,3,63,1555,8,63,1,64,1,64,1,64,1,64,1,64,3,
	64,1562,8,64,1,65,1,65,1,65,1,65,1,65,5,65,1569,8,65,10,65,12,65,1572,9,
	65,1,65,1,65,3,65,1576,8,65,1,66,1,66,3,66,1580,8,66,1,67,1,67,1,67,1,67,
	1,67,3,67,1587,8,67,1,68,1,68,1,68,1,68,1,68,1,68,5,68,1595,8,68,10,68,
	12,68,1598,9,68,1,68,1,68,3,68,1602,8,68,1,68,1,68,1,68,1,68,1,68,5,68,
	1609,8,68,10,68,12,68,1612,9,68,1,68,1,68,3,68,1616,8,68,3,68,1618,8,68,
	1,69,1,69,1,69,1,69,1,69,1,69,1,69,1,69,5,69,1628,8,69,10,69,12,69,1631,
	9,69,1,69,1,69,3,69,1635,8,69,1,69,3,69,1638,8,69,1,69,1,69,1,69,1,69,1,
	69,1,69,1,69,5,69,1647,8,69,10,69,12,69,1650,9,69,1,69,1,69,3,69,1654,8,
	69,1,69,1,69,3,69,1658,8,69,3,69,1660,8,69,1,70,1,70,1,71,1,71,1,72,1,72,
	1,72,1,72,5,72,1670,8,72,10,72,12,72,1673,9,72,1,73,1,73,1,73,3,73,1678,
	8,73,1,74,1,74,1,74,5,74,1683,8,74,10,74,12,74,1686,9,74,1,75,1,75,3,75,
	1690,8,75,1,75,1,75,1,75,1,75,3,75,1696,8,75,1,75,1,75,3,75,1700,8,75,1,
	75,3,75,1703,8,75,1,76,1,76,1,76,5,76,1708,8,76,10,76,12,76,1711,9,76,1,
	77,1,77,3,77,1715,8,77,1,77,1,77,3,77,1719,8,77,1,77,3,77,1722,8,77,1,78,
	1,78,1,78,3,78,1727,8,78,1,78,1,78,1,78,1,79,1,79,1,79,5,79,1735,8,79,10,
	79,12,79,1738,9,79,1,80,1,80,1,80,1,80,3,80,1744,8,80,1,80,1,80,3,80,1748,
	8,80,1,80,1,80,5,80,1752,8,80,10,80,12,80,1755,9,80,1,81,3,81,1758,8,81,
	1,81,1,81,1,81,1,81,1,81,3,81,1765,8,81,1,82,1,82,1,82,3,82,1770,8,82,1,
	83,1,83,1,83,1,83,1,83,1,83,1,83,1,83,5,83,1780,8,83,10,83,12,83,1783,9,
	83,1,83,1,83,3,83,1787,8,83,1,84,1,84,1,84,3,84,1792,8,84,1,85,1,85,3,85,
	1796,8,85,1,86,1,86,1,87,1,87,1,88,1,88,1,88,1,88,5,88,1806,8,88,10,88,
	12,88,1809,9,88,1,89,1,89,1,90,1,90,1,90,1,91,1,91,1,92,1,92,1,93,1,93,
	1,94,1,94,1,95,1,95,1,96,1,96,1,96,3,96,1829,8,96,1,97,1,97,1,97,1,97,5,
	97,1835,8,97,10,97,12,97,1838,9,97,1,97,1,97,1,98,1,98,1,98,1,99,1,99,1,
	99,1,100,1,100,1,101,1,101,3,101,1852,8,101,1,102,1,102,3,102,1856,8,102,
	1,103,1,103,1,103,1,103,1,103,3,103,1863,8,103,1,104,1,104,1,104,1,105,
	1,105,1,106,1,106,1,107,1,107,1,108,1,108,1,108,1,108,1,108,3,108,1879,
	8,108,1,109,1,109,1,110,1,110,1,110,0,2,4,6,111,0,2,4,6,8,10,12,14,16,18,
	20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,
	68,70,72,74,76,78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,
	112,114,116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,146,
	148,150,152,154,156,158,160,162,164,166,168,170,172,174,176,178,180,182,
	184,186,188,190,192,194,196,198,200,202,204,206,208,210,212,214,216,218,
	220,0,35,2,0,13,14,50,50,1,0,15,16,2,0,13,14,94,94,1,0,48,49,1,0,52,53,
	1,0,41,42,2,0,202,202,204,204,1,0,193,194,1,0,195,196,3,0,93,93,95,97,131,
	132,4,0,85,85,87,87,108,108,135,137,1,0,89,90,3,0,61,61,88,88,91,92,2,0,
	72,72,209,209,1,0,162,163,2,0,115,115,244,244,1,0,82,83,2,0,59,59,139,139,
	2,0,72,72,116,116,3,0,80,81,99,102,140,143,4,0,80,81,99,102,140,143,147,
	148,1,0,149,150,1,0,78,79,1,0,13,14,2,0,76,76,145,145,1,0,117,118,2,0,13,
	13,15,15,3,0,72,72,116,116,232,232,1,0,225,230,2,0,121,121,220,220,3,0,
	121,121,128,128,219,219,2,0,72,72,224,224,1,0,7,12,3,0,168,174,210,210,
	233,233,2,0,72,72,243,243,2082,0,227,1,0,0,0,2,241,1,0,0,0,4,273,1,0,0,
	0,6,340,1,0,0,0,8,377,1,0,0,0,10,391,1,0,0,0,12,400,1,0,0,0,14,402,1,0,
	0,0,16,411,1,0,0,0,18,419,1,0,0,0,20,422,1,0,0,0,22,431,1,0,0,0,24,440,
	1,0,0,0,26,445,1,0,0,0,28,458,1,0,0,0,30,479,1,0,0,0,32,531,1,0,0,0,34,
	590,1,0,0,0,36,649,1,0,0,0,38,653,1,0,0,0,40,657,1,0,0,0,42,707,1,0,0,0,
	44,757,1,0,0,0,46,780,1,0,0,0,48,803,1,0,0,0,50,837,1,0,0,0,52,860,1,0,
	0,0,54,964,1,0,0,0,56,1068,1,0,0,0,58,1099,1,0,0,0,60,1101,1,0,0,0,62,1185,
	1,0,0,0,64,1187,1,0,0,0,66,1194,1,0,0,0,68,1209,1,0,0,0,70,1211,1,0,0,0,
	72,1269,1,0,0,0,74,1329,1,0,0,0,76,1331,1,0,0,0,78,1335,1,0,0,0,80,1344,
	1,0,0,0,82,1351,1,0,0,0,84,1357,1,0,0,0,86,1373,1,0,0,0,88,1375,1,0,0,0,
	90,1383,1,0,0,0,92,1402,1,0,0,0,94,1408,1,0,0,0,96,1421,1,0,0,0,98,1424,
	1,0,0,0,100,1434,1,0,0,0,102,1444,1,0,0,0,104,1451,1,0,0,0,106,1459,1,0,
	0,0,108,1464,1,0,0,0,110,1481,1,0,0,0,112,1511,1,0,0,0,114,1513,1,0,0,0,
	116,1516,1,0,0,0,118,1525,1,0,0,0,120,1529,1,0,0,0,122,1536,1,0,0,0,124,
	1541,1,0,0,0,126,1545,1,0,0,0,128,1556,1,0,0,0,130,1563,1,0,0,0,132,1579,
	1,0,0,0,134,1581,1,0,0,0,136,1617,1,0,0,0,138,1659,1,0,0,0,140,1661,1,0,
	0,0,142,1663,1,0,0,0,144,1665,1,0,0,0,146,1674,1,0,0,0,148,1679,1,0,0,0,
	150,1689,1,0,0,0,152,1704,1,0,0,0,154,1714,1,0,0,0,156,1723,1,0,0,0,158,
	1731,1,0,0,0,160,1743,1,0,0,0,162,1757,1,0,0,0,164,1769,1,0,0,0,166,1786,
	1,0,0,0,168,1788,1,0,0,0,170,1793,1,0,0,0,172,1797,1,0,0,0,174,1799,1,0,
	0,0,176,1801,1,0,0,0,178,1810,1,0,0,0,180,1812,1,0,0,0,182,1815,1,0,0,0,
	184,1817,1,0,0,0,186,1819,1,0,0,0,188,1821,1,0,0,0,190,1823,1,0,0,0,192,
	1825,1,0,0,0,194,1830,1,0,0,0,196,1841,1,0,0,0,198,1844,1,0,0,0,200,1847,
	1,0,0,0,202,1851,1,0,0,0,204,1855,1,0,0,0,206,1862,1,0,0,0,208,1864,1,0,
	0,0,210,1867,1,0,0,0,212,1869,1,0,0,0,214,1871,1,0,0,0,216,1878,1,0,0,0,
	218,1880,1,0,0,0,220,1882,1,0,0,0,222,223,3,2,1,0,223,224,5,247,0,0,224,
	226,1,0,0,0,225,222,1,0,0,0,226,229,1,0,0,0,227,225,1,0,0,0,227,228,1,0,
	0,0,228,230,1,0,0,0,229,227,1,0,0,0,230,231,5,0,0,1,231,1,1,0,0,0,232,233,
	3,188,94,0,233,234,5,20,0,0,234,235,3,4,2,0,235,242,1,0,0,0,236,237,3,188,
	94,0,237,238,5,124,0,0,238,239,3,4,2,0,239,242,1,0,0,0,240,242,3,32,16,
	0,241,232,1,0,0,0,241,236,1,0,0,0,241,240,1,0,0,0,242,3,1,0,0,0,243,244,
	6,2,-1,0,244,245,5,1,0,0,245,246,3,4,2,0,246,247,5,2,0,0,247,274,1,0,0,
	0,248,274,3,10,5,0,249,250,7,0,0,0,250,274,3,4,2,11,251,252,5,23,0,0,252,
	253,3,4,2,0,253,254,5,25,0,0,254,255,3,4,2,0,255,256,5,26,0,0,256,257,3,
	4,2,4,257,274,1,0,0,0,258,264,5,24,0,0,259,260,5,185,0,0,260,261,3,4,2,
	0,261,262,5,25,0,0,262,263,3,4,2,0,263,265,1,0,0,0,264,259,1,0,0,0,265,
	266,1,0,0,0,266,264,1,0,0,0,266,267,1,0,0,0,267,268,1,0,0,0,268,269,5,26,
	0,0,269,270,3,4,2,3,270,274,1,0,0,0,271,274,3,216,108,0,272,274,3,188,94,
	0,273,243,1,0,0,0,273,248,1,0,0,0,273,249,1,0,0,0,273,251,1,0,0,0,273,258,
	1,0,0,0,273,271,1,0,0,0,273,272,1,0,0,0,274,307,1,0,0,0,275,276,10,10,0,
	0,276,277,7,1,0,0,277,306,3,4,2,11,278,279,10,9,0,0,279,280,7,2,0,0,280,
	306,3,4,2,10,281,282,10,8,0,0,282,283,3,200,100,0,283,284,3,4,2,9,284,306,
	1,0,0,0,285,286,10,6,0,0,286,287,5,47,0,0,287,306,3,4,2,7,288,289,10,5,
	0,0,289,290,7,3,0,0,290,306,3,4,2,6,291,292,10,13,0,0,292,293,5,3,0,0,293,
	294,3,12,6,0,294,295,5,4,0,0,295,306,1,0,0,0,296,297,10,12,0,0,297,298,
	5,21,0,0,298,306,3,190,95,0,299,300,10,7,0,0,300,303,7,4,0,0,301,304,3,
	194,97,0,302,304,3,210,105,0,303,301,1,0,0,0,303,302,1,0,0,0,304,306,1,
	0,0,0,305,275,1,0,0,0,305,278,1,0,0,0,305,281,1,0,0,0,305,285,1,0,0,0,305,
	288,1,0,0,0,305,291,1,0,0,0,305,296,1,0,0,0,305,299,1,0,0,0,306,309,1,0,
	0,0,307,305,1,0,0,0,307,308,1,0,0,0,308,5,1,0,0,0,309,307,1,0,0,0,310,311,
	6,3,-1,0,311,312,5,1,0,0,312,313,3,6,3,0,313,314,5,2,0,0,314,341,1,0,0,
	0,315,341,3,8,4,0,316,317,7,0,0,0,317,341,3,6,3,11,318,319,5,23,0,0,319,
	320,3,6,3,0,320,321,5,25,0,0,321,322,3,6,3,0,322,323,5,26,0,0,323,324,3,
	6,3,4,324,341,1,0,0,0,325,331,5,24,0,0,326,327,5,185,0,0,327,328,3,6,3,
	0,328,329,5,25,0,0,329,330,3,6,3,0,330,332,1,0,0,0,331,326,1,0,0,0,332,
	333,1,0,0,0,333,331,1,0,0,0,333,334,1,0,0,0,334,335,1,0,0,0,335,336,5,26,
	0,0,336,337,3,6,3,3,337,341,1,0,0,0,338,341,3,216,108,0,339,341,3,192,96,
	0,340,310,1,0,0,0,340,315,1,0,0,0,340,316,1,0,0,0,340,318,1,0,0,0,340,325,
	1,0,0,0,340,338,1,0,0,0,340,339,1,0,0,0,341,366,1,0,0,0,342,343,10,10,0,
	0,343,344,7,1,0,0,344,365,3,6,3,11,345,346,10,9,0,0,346,347,7,2,0,0,347,
	365,3,6,3,10,348,349,10,8,0,0,349,350,3,200,100,0,350,351,3,6,3,9,351,365,
	1,0,0,0,352,353,10,6,0,0,353,354,5,47,0,0,354,365,3,6,3,7,355,356,10,5,
	0,0,356,357,7,3,0,0,357,365,3,6,3,6,358,359,10,7,0,0,359,362,7,4,0,0,360,
	363,3,194,97,0,361,363,3,210,105,0,362,360,1,0,0,0,362,361,1,0,0,0,363,
	365,1,0,0,0,364,342,1,0,0,0,364,345,1,0,0,0,364,348,1,0,0,0,364,352,1,0,
	0,0,364,355,1,0,0,0,364,358,1,0,0,0,365,368,1,0,0,0,366,364,1,0,0,0,366,
	367,1,0,0,0,367,7,1,0,0,0,368,366,1,0,0,0,369,378,3,36,18,0,370,378,3,44,
	22,0,371,378,3,48,24,0,372,378,3,52,26,0,373,378,3,56,28,0,374,378,3,66,
	33,0,375,378,3,68,34,0,376,378,3,74,37,0,377,369,1,0,0,0,377,370,1,0,0,
	0,377,371,1,0,0,0,377,372,1,0,0,0,377,373,1,0,0,0,377,374,1,0,0,0,377,375,
	1,0,0,0,377,376,1,0,0,0,378,9,1,0,0,0,379,392,3,30,15,0,380,392,3,34,17,
	0,381,392,3,42,21,0,382,392,3,46,23,0,383,392,3,50,25,0,384,392,3,54,27,
	0,385,392,3,58,29,0,386,392,3,60,30,0,387,392,3,62,31,0,388,392,3,64,32,
	0,389,392,3,70,35,0,390,392,3,72,36,0,391,379,1,0,0,0,391,380,1,0,0,0,391,
	381,1,0,0,0,391,382,1,0,0,0,391,383,1,0,0,0,391,384,1,0,0,0,391,385,1,0,
	0,0,391,386,1,0,0,0,391,387,1,0,0,0,391,388,1,0,0,0,391,389,1,0,0,0,391,
	390,1,0,0,0,392,11,1,0,0,0,393,401,3,14,7,0,394,401,3,16,8,0,395,401,3,
	18,9,0,396,401,3,20,10,0,397,401,3,22,11,0,398,401,3,24,12,0,399,401,3,
	28,14,0,400,393,1,0,0,0,400,394,1,0,0,0,400,395,1,0,0,0,400,396,1,0,0,0,
	400,397,1,0,0,0,400,398,1,0,0,0,400,399,1,0,0,0,401,13,1,0,0,0,402,403,
	5,45,0,0,403,408,3,76,38,0,404,405,5,17,0,0,405,407,3,76,38,0,406,404,1,
	0,0,0,407,410,1,0,0,0,408,406,1,0,0,0,408,409,1,0,0,0,409,15,1,0,0,0,410,
	408,1,0,0,0,411,412,5,73,0,0,412,417,3,78,39,0,413,415,3,112,56,0,414,416,
	3,114,57,0,415,414,1,0,0,0,415,416,1,0,0,0,416,418,1,0,0,0,417,413,1,0,
	0,0,417,418,1,0,0,0,418,17,1,0,0,0,419,420,5,106,0,0,420,421,3,6,3,0,421,
	19,1,0,0,0,422,423,5,43,0,0,423,428,3,82,41,0,424,425,5,17,0,0,425,427,
	3,82,41,0,426,424,1,0,0,0,427,430,1,0,0,0,428,426,1,0,0,0,428,429,1,0,0,
	0,429,21,1,0,0,0,430,428,1,0,0,0,431,432,7,5,0,0,432,437,3,192,96,0,433,
	434,5,17,0,0,434,436,3,192,96,0,435,433,1,0,0,0,436,439,1,0,0,0,437,435,
	1,0,0,0,437,438,1,0,0,0,438,23,1,0,0,0,439,437,1,0,0,0,440,441,7,6,0,0,
	441,442,3,192,96,0,442,443,5,17,0,0,443,444,3,192,96,0,444,25,1,0,0,0,445,
	446,5,203,0,0,446,447,3,192,96,0,447,448,5,17,0,0,448,449,3,192,96,0,449,
	450,5,52,0,0,450,455,3,216,108,0,451,452,5,17,0,0,452,454,3,216,108,0,453,
	451,1,0,0,0,454,457,1,0,0,0,455,453,1,0,0,0,455,456,1,0,0,0,456,27,1,0,
	0,0,457,455,1,0,0,0,458,459,5,205,0,0,459,464,3,84,42,0,460,461,5,17,0,
	0,461,463,3,84,42,0,462,460,1,0,0,0,463,466,1,0,0,0,464,462,1,0,0,0,464,
	465,1,0,0,0,465,29,1,0,0,0,466,464,1,0,0,0,467,468,7,7,0,0,468,469,5,1,
	0,0,469,470,3,90,45,0,470,471,3,94,47,0,471,472,5,2,0,0,472,480,1,0,0,0,
	473,474,7,8,0,0,474,475,5,1,0,0,475,476,3,88,44,0,476,477,3,94,47,0,477,
	478,5,2,0,0,478,480,1,0,0,0,479,467,1,0,0,0,479,473,1,0,0,0,480,31,1,0,
	0,0,481,482,5,123,0,0,482,483,5,122,0,0,483,484,3,212,106,0,484,493,5,1,
	0,0,485,490,3,116,58,0,486,487,5,17,0,0,487,489,3,116,58,0,488,486,1,0,
	0,0,489,492,1,0,0,0,490,488,1,0,0,0,490,491,1,0,0,0,491,494,1,0,0,0,492,
	490,1,0,0,0,493,485,1,0,0,0,493,494,1,0,0,0,494,495,1,0,0,0,495,498,5,2,
	0,0,496,497,5,201,0,0,497,499,3,118,59,0,498,496,1,0,0,0,498,499,1,0,0,
	0,499,500,1,0,0,0,500,501,5,184,0,0,501,502,3,4,2,0,502,503,5,129,0,0,503,
	504,5,122,0,0,504,532,1,0,0,0,505,506,5,123,0,0,506,507,5,125,0,0,507,508,
	5,127,0,0,508,509,3,142,71,0,509,510,5,1,0,0,510,511,3,144,72,0,511,512,
	5,2,0,0,512,513,5,184,0,0,513,514,3,148,74,0,514,515,5,129,0,0,515,516,
	5,125,0,0,516,517,5,127,0,0,517,532,1,0,0,0,518,519,5,123,0,0,519,520,5,
	126,0,0,520,521,5,127,0,0,521,522,3,142,71,0,522,523,5,1,0,0,523,524,3,
	156,78,0,524,525,5,2,0,0,525,526,5,184,0,0,526,527,3,152,76,0,527,528,5,
	129,0,0,528,529,5,126,0,0,529,530,5,127,0,0,530,532,1,0,0,0,531,481,1,0,
	0,0,531,505,1,0,0,0,531,518,1,0,0,0,532,33,1,0,0,0,533,534,3,212,106,0,
	534,543,5,1,0,0,535,540,3,40,20,0,536,537,5,17,0,0,537,539,3,40,20,0,538,
	536,1,0,0,0,539,542,1,0,0,0,540,538,1,0,0,0,540,541,1,0,0,0,541,544,1,0,
	0,0,542,540,1,0,0,0,543,535,1,0,0,0,543,544,1,0,0,0,544,545,1,0,0,0,545,
	546,5,2,0,0,546,591,1,0,0,0,547,548,5,22,0,0,548,549,5,1,0,0,549,550,3,
	214,107,0,550,553,5,1,0,0,551,554,3,188,94,0,552,554,3,86,43,0,553,551,
	1,0,0,0,553,552,1,0,0,0,553,554,1,0,0,0,554,562,1,0,0,0,555,558,5,17,0,
	0,556,559,3,188,94,0,557,559,3,86,43,0,558,556,1,0,0,0,558,557,1,0,0,0,
	559,561,1,0,0,0,560,555,1,0,0,0,561,564,1,0,0,0,562,560,1,0,0,0,562,563,
	1,0,0,0,563,565,1,0,0,0,564,562,1,0,0,0,565,568,5,2,0,0,566,567,5,240,0,
	0,567,569,5,244,0,0,568,566,1,0,0,0,568,569,1,0,0,0,569,572,1,0,0,0,570,
	571,5,201,0,0,571,573,3,132,66,0,572,570,1,0,0,0,572,573,1,0,0,0,573,574,
	1,0,0,0,574,575,5,2,0,0,575,591,1,0,0,0,576,577,5,218,0,0,577,578,5,1,0,
	0,578,579,3,4,2,0,579,582,5,17,0,0,580,583,3,218,109,0,581,583,3,140,70,
	0,582,580,1,0,0,0,582,581,1,0,0,0,583,586,1,0,0,0,584,585,5,17,0,0,585,
	587,5,244,0,0,586,584,1,0,0,0,586,587,1,0,0,0,587,588,1,0,0,0,588,589,5,
	2,0,0,589,591,1,0,0,0,590,533,1,0,0,0,590,547,1,0,0,0,590,576,1,0,0,0,591,
	35,1,0,0,0,592,593,3,212,106,0,593,602,5,1,0,0,594,599,3,38,19,0,595,596,
	5,17,0,0,596,598,3,38,19,0,597,595,1,0,0,0,598,601,1,0,0,0,599,597,1,0,
	0,0,599,600,1,0,0,0,600,603,1,0,0,0,601,599,1,0,0,0,602,594,1,0,0,0,602,
	603,1,0,0,0,603,604,1,0,0,0,604,605,5,2,0,0,605,650,1,0,0,0,606,607,5,218,
	0,0,607,608,5,1,0,0,608,609,3,6,3,0,609,612,5,17,0,0,610,613,3,218,109,
	0,611,613,3,140,70,0,612,610,1,0,0,0,612,611,1,0,0,0,613,616,1,0,0,0,614,
	615,5,17,0,0,615,617,5,244,0,0,616,614,1,0,0,0,616,617,1,0,0,0,617,618,
	1,0,0,0,618,619,5,2,0,0,619,650,1,0,0,0,620,621,5,22,0,0,621,622,5,1,0,
	0,622,623,3,214,107,0,623,626,5,1,0,0,624,627,3,192,96,0,625,627,3,86,43,
	0,626,624,1,0,0,0,626,625,1,0,0,0,626,627,1,0,0,0,627,635,1,0,0,0,628,631,
	5,17,0,0,629,632,3,192,96,0,630,632,3,86,43,0,631,629,1,0,0,0,631,630,1,
	0,0,0,632,634,1,0,0,0,633,628,1,0,0,0,634,637,1,0,0,0,635,633,1,0,0,0,635,
	636,1,0,0,0,636,638,1,0,0,0,637,635,1,0,0,0,638,641,5,2,0,0,639,640,5,240,
	0,0,640,642,5,244,0,0,641,639,1,0,0,0,641,642,1,0,0,0,642,645,1,0,0,0,643,
	644,5,201,0,0,644,646,3,120,60,0,645,643,1,0,0,0,645,646,1,0,0,0,646,647,
	1,0,0,0,647,648,5,2,0,0,648,650,1,0,0,0,649,592,1,0,0,0,649,606,1,0,0,0,
	649,620,1,0,0,0,650,37,1,0,0,0,651,654,3,6,3,0,652,654,5,115,0,0,653,651,
	1,0,0,0,653,652,1,0,0,0,654,39,1,0,0,0,655,658,3,4,2,0,656,658,5,115,0,
	0,657,655,1,0,0,0,657,656,1,0,0,0,658,41,1,0,0,0,659,660,7,9,0,0,660,661,
	5,1,0,0,661,662,3,4,2,0,662,663,5,2,0,0,663,708,1,0,0,0,664,665,5,98,0,
	0,665,666,5,1,0,0,666,677,3,4,2,0,667,668,5,17,0,0,668,669,3,202,101,0,
	669,670,1,0,0,0,670,671,5,17,0,0,671,672,3,202,101,0,672,674,1,0,0,0,673,
	667,1,0,0,0,673,674,1,0,0,0,674,678,1,0,0,0,675,676,5,17,0,0,676,678,3,
	202,101,0,677,673,1,0,0,0,677,675,1,0,0,0,678,679,1,0,0,0,679,680,5,2,0,
	0,680,708,1,0,0,0,681,682,5,134,0,0,682,683,5,1,0,0,683,684,3,4,2,0,684,
	685,5,17,0,0,685,688,3,4,2,0,686,687,5,17,0,0,687,689,3,202,101,0,688,686,
	1,0,0,0,688,689,1,0,0,0,689,690,1,0,0,0,690,691,5,2,0,0,691,708,1,0,0,0,
	692,693,5,133,0,0,693,694,5,1,0,0,694,695,3,4,2,0,695,696,5,17,0,0,696,
	699,3,4,2,0,697,698,5,17,0,0,698,700,3,202,101,0,699,697,1,0,0,0,699,700,
	1,0,0,0,700,703,1,0,0,0,701,702,5,17,0,0,702,704,3,202,101,0,703,701,1,
	0,0,0,703,704,1,0,0,0,704,705,1,0,0,0,705,706,5,2,0,0,706,708,1,0,0,0,707,
	659,1,0,0,0,707,664,1,0,0,0,707,681,1,0,0,0,707,692,1,0,0,0,708,43,1,0,
	0,0,709,710,7,9,0,0,710,711,5,1,0,0,711,712,3,6,3,0,712,713,5,2,0,0,713,
	758,1,0,0,0,714,715,5,98,0,0,715,716,5,1,0,0,716,727,3,6,3,0,717,718,5,
	17,0,0,718,719,3,204,102,0,719,720,1,0,0,0,720,721,5,17,0,0,721,722,3,204,
	102,0,722,724,1,0,0,0,723,717,1,0,0,0,723,724,1,0,0,0,724,728,1,0,0,0,725,
	726,5,17,0,0,726,728,3,204,102,0,727,723,1,0,0,0,727,725,1,0,0,0,728,729,
	1,0,0,0,729,730,5,2,0,0,730,758,1,0,0,0,731,732,5,134,0,0,732,733,5,1,0,
	0,733,734,3,6,3,0,734,735,5,17,0,0,735,738,3,6,3,0,736,737,5,17,0,0,737,
	739,3,204,102,0,738,736,1,0,0,0,738,739,1,0,0,0,739,740,1,0,0,0,740,741,
	5,2,0,0,741,758,1,0,0,0,742,743,5,133,0,0,743,744,5,1,0,0,744,745,3,6,3,
	0,745,746,5,17,0,0,746,749,3,6,3,0,747,748,5,17,0,0,748,750,3,204,102,0,
	749,747,1,0,0,0,749,750,1,0,0,0,750,753,1,0,0,0,751,752,5,17,0,0,752,754,
	3,204,102,0,753,751,1,0,0,0,753,754,1,0,0,0,754,755,1,0,0,0,755,756,5,2,
	0,0,756,758,1,0,0,0,757,709,1,0,0,0,757,714,1,0,0,0,757,731,1,0,0,0,757,
	742,1,0,0,0,758,45,1,0,0,0,759,760,7,10,0,0,760,761,5,1,0,0,761,762,3,4,
	2,0,762,763,5,2,0,0,763,781,1,0,0,0,764,765,7,11,0,0,765,766,5,1,0,0,766,
	769,3,4,2,0,767,768,5,17,0,0,768,770,3,202,101,0,769,767,1,0,0,0,769,770,
	1,0,0,0,770,771,1,0,0,0,771,772,5,2,0,0,772,781,1,0,0,0,773,774,7,12,0,
	0,774,775,5,1,0,0,775,776,3,4,2,0,776,777,5,17,0,0,777,778,3,4,2,0,778,
	779,5,2,0,0,779,781,1,0,0,0,780,759,1,0,0,0,780,764,1,0,0,0,780,773,1,0,
	0,0,781,47,1,0,0,0,782,783,7,10,0,0,783,784,5,1,0,0,784,785,3,6,3,0,785,
	786,5,2,0,0,786,804,1,0,0,0,787,788,7,11,0,0,788,789,5,1,0,0,789,792,3,
	6,3,0,790,791,5,17,0,0,791,793,3,204,102,0,792,790,1,0,0,0,792,793,1,0,
	0,0,793,794,1,0,0,0,794,795,5,2,0,0,795,804,1,0,0,0,796,797,7,12,0,0,797,
	798,5,1,0,0,798,799,3,6,3,0,799,800,5,17,0,0,800,801,3,6,3,0,801,802,5,
	2,0,0,802,804,1,0,0,0,803,782,1,0,0,0,803,787,1,0,0,0,803,796,1,0,0,0,804,
	49,1,0,0,0,805,806,5,51,0,0,806,807,5,1,0,0,807,808,3,4,2,0,808,809,5,17,
	0,0,809,810,3,4,2,0,810,811,5,17,0,0,811,812,3,4,2,0,812,813,5,2,0,0,813,
	838,1,0,0,0,814,815,5,111,0,0,815,816,5,1,0,0,816,817,3,4,2,0,817,818,5,
	17,0,0,818,819,3,4,2,0,819,820,5,2,0,0,820,838,1,0,0,0,821,822,5,55,0,0,
	822,823,5,1,0,0,823,824,3,4,2,0,824,825,5,2,0,0,825,838,1,0,0,0,826,827,
	5,67,0,0,827,828,5,1,0,0,828,829,3,4,2,0,829,830,5,17,0,0,830,833,3,4,2,
	0,831,832,5,17,0,0,832,834,3,220,110,0,833,831,1,0,0,0,833,834,1,0,0,0,
	834,835,1,0,0,0,835,836,5,2,0,0,836,838,1,0,0,0,837,805,1,0,0,0,837,814,
	1,0,0,0,837,821,1,0,0,0,837,826,1,0,0,0,838,51,1,0,0,0,839,840,5,51,0,0,
	840,841,5,1,0,0,841,842,3,6,3,0,842,843,5,17,0,0,843,844,3,6,3,0,844,845,
	5,17,0,0,845,846,3,6,3,0,846,847,5,2,0,0,847,861,1,0,0,0,848,849,5,111,
	0,0,849,850,5,1,0,0,850,851,3,6,3,0,851,852,5,17,0,0,852,853,3,6,3,0,853,
	854,5,2,0,0,854,861,1,0,0,0,855,856,5,55,0,0,856,857,5,1,0,0,857,858,3,
	6,3,0,858,859,5,2,0,0,859,861,1,0,0,0,860,839,1,0,0,0,860,848,1,0,0,0,860,
	855,1,0,0,0,861,53,1,0,0,0,862,863,5,208,0,0,863,865,5,1,0,0,864,866,3,
	4,2,0,865,864,1,0,0,0,865,866,1,0,0,0,866,867,1,0,0,0,867,965,5,2,0,0,868,
	869,5,161,0,0,869,870,5,1,0,0,870,873,3,4,2,0,871,872,5,17,0,0,872,874,
	7,13,0,0,873,871,1,0,0,0,873,874,1,0,0,0,874,875,1,0,0,0,875,876,5,2,0,
	0,876,965,1,0,0,0,877,878,7,14,0,0,878,879,5,1,0,0,879,880,3,4,2,0,880,
	881,5,2,0,0,881,965,1,0,0,0,882,883,5,164,0,0,883,884,5,1,0,0,884,885,3,
	4,2,0,885,886,5,17,0,0,886,887,3,106,53,0,887,888,5,2,0,0,888,965,1,0,0,
	0,889,890,5,211,0,0,890,891,5,1,0,0,891,894,5,244,0,0,892,893,5,17,0,0,
	893,895,7,15,0,0,894,892,1,0,0,0,894,895,1,0,0,0,895,898,1,0,0,0,896,897,
	5,17,0,0,897,899,3,202,101,0,898,896,1,0,0,0,898,899,1,0,0,0,899,902,1,
	0,0,0,900,901,5,17,0,0,901,903,7,16,0,0,902,900,1,0,0,0,902,903,1,0,0,0,
	903,904,1,0,0,0,904,965,5,2,0,0,905,906,5,29,0,0,906,907,5,1,0,0,907,965,
	5,2,0,0,908,909,5,30,0,0,909,910,5,1,0,0,910,911,3,4,2,0,911,912,5,17,0,
	0,912,913,3,4,2,0,913,914,5,2,0,0,914,965,1,0,0,0,915,916,5,31,0,0,916,
	917,5,1,0,0,917,918,3,4,2,0,918,919,5,17,0,0,919,920,3,4,2,0,920,921,5,
	17,0,0,921,922,3,4,2,0,922,923,5,2,0,0,923,965,1,0,0,0,924,925,5,32,0,0,
	925,926,5,1,0,0,926,927,3,4,2,0,927,928,5,2,0,0,928,965,1,0,0,0,929,930,
	5,33,0,0,930,931,5,1,0,0,931,932,3,4,2,0,932,933,5,2,0,0,933,965,1,0,0,
	0,934,935,5,34,0,0,935,936,5,1,0,0,936,937,3,4,2,0,937,938,5,2,0,0,938,
	965,1,0,0,0,939,940,5,35,0,0,940,941,5,1,0,0,941,942,3,4,2,0,942,943,5,
	2,0,0,943,965,1,0,0,0,944,945,5,36,0,0,945,946,5,1,0,0,946,947,3,4,2,0,
	947,948,5,2,0,0,948,965,1,0,0,0,949,950,5,37,0,0,950,951,5,1,0,0,951,952,
	3,4,2,0,952,953,5,2,0,0,953,965,1,0,0,0,954,955,5,38,0,0,955,956,5,1,0,
	0,956,957,3,4,2,0,957,958,5,2,0,0,958,965,1,0,0,0,959,960,5,39,0,0,960,
	961,5,1,0,0,961,962,3,4,2,0,962,963,5,2,0,0,963,965,1,0,0,0,964,862,1,0,
	0,0,964,868,1,0,0,0,964,877,1,0,0,0,964,882,1,0,0,0,964,889,1,0,0,0,964,
	905,1,0,0,0,964,908,1,0,0,0,964,915,1,0,0,0,964,924,1,0,0,0,964,929,1,0,
	0,0,964,934,1,0,0,0,964,939,1,0,0,0,964,944,1,0,0,0,964,949,1,0,0,0,964,
	954,1,0,0,0,964,959,1,0,0,0,965,55,1,0,0,0,966,967,5,208,0,0,967,969,5,
	1,0,0,968,970,3,6,3,0,969,968,1,0,0,0,969,970,1,0,0,0,970,971,1,0,0,0,971,
	1069,5,2,0,0,972,973,5,161,0,0,973,974,5,1,0,0,974,977,3,6,3,0,975,976,
	5,17,0,0,976,978,7,13,0,0,977,975,1,0,0,0,977,978,1,0,0,0,978,979,1,0,0,
	0,979,980,5,2,0,0,980,1069,1,0,0,0,981,982,7,14,0,0,982,983,5,1,0,0,983,
	984,3,6,3,0,984,985,5,2,0,0,985,1069,1,0,0,0,986,987,5,164,0,0,987,988,
	5,1,0,0,988,989,3,6,3,0,989,990,5,17,0,0,990,991,3,106,53,0,991,992,5,2,
	0,0,992,1069,1,0,0,0,993,994,5,211,0,0,994,995,5,1,0,0,995,998,5,244,0,
	0,996,997,5,17,0,0,997,999,7,15,0,0,998,996,1,0,0,0,998,999,1,0,0,0,999,
	1002,1,0,0,0,1000,1001,5,17,0,0,1001,1003,3,204,102,0,1002,1000,1,0,0,0,
	1002,1003,1,0,0,0,1003,1006,1,0,0,0,1004,1005,5,17,0,0,1005,1007,7,16,0,
	0,1006,1004,1,0,0,0,1006,1007,1,0,0,0,1007,1008,1,0,0,0,1008,1069,5,2,0,
	0,1009,1010,5,29,0,0,1010,1011,5,1,0,0,1011,1069,5,2,0,0,1012,1013,5,30,
	0,0,1013,1014,5,1,0,0,1014,1015,3,6,3,0,1015,1016,5,17,0,0,1016,1017,3,
	4,2,0,1017,1018,5,2,0,0,1018,1069,1,0,0,0,1019,1020,5,31,0,0,1020,1021,
	5,1,0,0,1021,1022,3,6,3,0,1022,1023,5,17,0,0,1023,1024,3,6,3,0,1024,1025,
	5,17,0,0,1025,1026,3,6,3,0,1026,1027,5,2,0,0,1027,1069,1,0,0,0,1028,1029,
	5,32,0,0,1029,1030,5,1,0,0,1030,1031,3,6,3,0,1031,1032,5,2,0,0,1032,1069,
	1,0,0,0,1033,1034,5,33,0,0,1034,1035,5,1,0,0,1035,1036,3,6,3,0,1036,1037,
	5,2,0,0,1037,1069,1,0,0,0,1038,1039,5,34,0,0,1039,1040,5,1,0,0,1040,1041,
	3,6,3,0,1041,1042,5,2,0,0,1042,1069,1,0,0,0,1043,1044,5,35,0,0,1044,1045,
	5,1,0,0,1045,1046,3,6,3,0,1046,1047,5,2,0,0,1047,1069,1,0,0,0,1048,1049,
	5,36,0,0,1049,1050,5,1,0,0,1050,1051,3,6,3,0,1051,1052,5,2,0,0,1052,1069,
	1,0,0,0,1053,1054,5,37,0,0,1054,1055,5,1,0,0,1055,1056,3,6,3,0,1056,1057,
	5,2,0,0,1057,1069,1,0,0,0,1058,1059,5,38,0,0,1059,1060,5,1,0,0,1060,1061,
	3,6,3,0,1061,1062,5,2,0,0,1062,1069,1,0,0,0,1063,1064,5,39,0,0,1064,1065,
	5,1,0,0,1065,1066,3,6,3,0,1066,1067,5,2,0,0,1067,1069,1,0,0,0,1068,966,
	1,0,0,0,1068,972,1,0,0,0,1068,981,1,0,0,0,1068,986,1,0,0,0,1068,993,1,0,
	0,0,1068,1009,1,0,0,0,1068,1012,1,0,0,0,1068,1019,1,0,0,0,1068,1028,1,0,
	0,0,1068,1033,1,0,0,0,1068,1038,1,0,0,0,1068,1043,1,0,0,0,1068,1048,1,0,
	0,0,1068,1053,1,0,0,0,1068,1058,1,0,0,0,1068,1063,1,0,0,0,1069,57,1,0,0,
	0,1070,1071,5,57,0,0,1071,1072,5,1,0,0,1072,1075,3,4,2,0,1073,1074,5,17,
	0,0,1074,1076,3,4,2,0,1075,1073,1,0,0,0,1076,1077,1,0,0,0,1077,1075,1,0,
	0,0,1077,1078,1,0,0,0,1078,1079,1,0,0,0,1079,1080,5,2,0,0,1080,1100,1,0,
	0,0,1081,1082,5,60,0,0,1082,1083,5,1,0,0,1083,1086,3,4,2,0,1084,1085,5,
	17,0,0,1085,1087,3,4,2,0,1086,1084,1,0,0,0,1087,1088,1,0,0,0,1088,1086,
	1,0,0,0,1088,1089,1,0,0,0,1089,1090,1,0,0,0,1090,1091,5,2,0,0,1091,1100,
	1,0,0,0,1092,1093,7,17,0,0,1093,1094,5,1,0,0,1094,1095,3,4,2,0,1095,1096,
	5,17,0,0,1096,1097,3,4,2,0,1097,1098,5,2,0,0,1098,1100,1,0,0,0,1099,1070,
	1,0,0,0,1099,1081,1,0,0,0,1099,1092,1,0,0,0,1100,59,1,0,0,0,1101,1102,5,
	114,0,0,1102,1103,5,1,0,0,1103,1104,3,4,2,0,1104,1105,5,17,0,0,1105,1107,
	5,245,0,0,1106,1108,3,176,88,0,1107,1106,1,0,0,0,1107,1108,1,0,0,0,1108,
	1111,1,0,0,0,1109,1110,5,128,0,0,1110,1112,3,192,96,0,1111,1109,1,0,0,0,
	1111,1112,1,0,0,0,1112,1114,1,0,0,0,1113,1115,3,174,87,0,1114,1113,1,0,
	0,0,1114,1115,1,0,0,0,1115,1117,1,0,0,0,1116,1118,3,182,91,0,1117,1116,
	1,0,0,0,1117,1118,1,0,0,0,1118,1120,1,0,0,0,1119,1121,3,184,92,0,1120,1119,
	1,0,0,0,1120,1121,1,0,0,0,1121,1122,1,0,0,0,1122,1123,5,2,0,0,1123,61,1,
	0,0,0,1124,1125,5,222,0,0,1125,1126,5,1,0,0,1126,1127,3,4,2,0,1127,1128,
	5,17,0,0,1128,1138,5,245,0,0,1129,1130,5,231,0,0,1130,1135,3,192,96,0,1131,
	1132,5,17,0,0,1132,1134,3,192,96,0,1133,1131,1,0,0,0,1134,1137,1,0,0,0,
	1135,1133,1,0,0,0,1135,1136,1,0,0,0,1136,1139,1,0,0,0,1137,1135,1,0,0,0,
	1138,1129,1,0,0,0,1138,1139,1,0,0,0,1139,1141,1,0,0,0,1140,1142,3,172,86,
	0,1141,1140,1,0,0,0,1141,1142,1,0,0,0,1142,1143,1,0,0,0,1143,1144,5,2,0,
	0,1144,1186,1,0,0,0,1145,1146,5,223,0,0,1146,1147,5,1,0,0,1147,1148,3,4,
	2,0,1148,1149,5,17,0,0,1149,1151,5,245,0,0,1150,1152,3,176,88,0,1151,1150,
	1,0,0,0,1151,1152,1,0,0,0,1152,1155,1,0,0,0,1153,1154,5,128,0,0,1154,1156,
	3,192,96,0,1155,1153,1,0,0,0,1155,1156,1,0,0,0,1156,1158,1,0,0,0,1157,1159,
	3,174,87,0,1158,1157,1,0,0,0,1158,1159,1,0,0,0,1159,1161,1,0,0,0,1160,1162,
	3,178,89,0,1161,1160,1,0,0,0,1161,1162,1,0,0,0,1162,1164,1,0,0,0,1163,1165,
	3,172,86,0,1164,1163,1,0,0,0,1164,1165,1,0,0,0,1165,1166,1,0,0,0,1166,1167,
	5,2,0,0,1167,1186,1,0,0,0,1168,1169,5,66,0,0,1169,1170,5,1,0,0,1170,1172,
	3,4,2,0,1171,1173,3,196,98,0,1172,1171,1,0,0,0,1172,1173,1,0,0,0,1173,1175,
	1,0,0,0,1174,1176,3,198,99,0,1175,1174,1,0,0,0,1175,1176,1,0,0,0,1176,1178,
	1,0,0,0,1177,1179,3,180,90,0,1178,1177,1,0,0,0,1178,1179,1,0,0,0,1179,1181,
	1,0,0,0,1180,1182,7,18,0,0,1181,1180,1,0,0,0,1181,1182,1,0,0,0,1182,1183,
	1,0,0,0,1183,1184,5,2,0,0,1184,1186,1,0,0,0,1185,1124,1,0,0,0,1185,1145,
	1,0,0,0,1185,1168,1,0,0,0,1186,63,1,0,0,0,1187,1188,5,113,0,0,1188,1189,
	5,1,0,0,1189,1190,3,4,2,0,1190,1191,5,17,0,0,1191,1192,3,4,2,0,1192,1193,
	5,2,0,0,1193,65,1,0,0,0,1194,1195,5,113,0,0,1195,1196,5,1,0,0,1196,1197,
	3,6,3,0,1197,1198,5,17,0,0,1198,1199,3,6,3,0,1199,1200,5,2,0,0,1200,67,
	1,0,0,0,1201,1202,7,19,0,0,1202,1203,5,1,0,0,1203,1204,3,6,3,0,1204,1205,
	5,2,0,0,1205,1210,1,0,0,0,1206,1207,5,102,0,0,1207,1208,5,1,0,0,1208,1210,
	5,2,0,0,1209,1201,1,0,0,0,1209,1206,1,0,0,0,1210,69,1,0,0,0,1211,1212,7,
	19,0,0,1212,1213,5,1,0,0,1213,1218,3,4,2,0,1214,1216,3,112,56,0,1215,1217,
	3,114,57,0,1216,1215,1,0,0,0,1216,1217,1,0,0,0,1217,1219,1,0,0,0,1218,1214,
	1,0,0,0,1218,1219,1,0,0,0,1219,1220,1,0,0,0,1220,1221,5,2,0,0,1221,71,1,
	0,0,0,1222,1223,7,20,0,0,1223,1224,5,1,0,0,1224,1225,3,4,2,0,1225,1226,
	5,152,0,0,1226,1228,5,1,0,0,1227,1229,3,98,49,0,1228,1227,1,0,0,0,1228,
	1229,1,0,0,0,1229,1231,1,0,0,0,1230,1232,3,100,50,0,1231,1230,1,0,0,0,1231,
	1232,1,0,0,0,1232,1234,1,0,0,0,1233,1235,3,104,52,0,1234,1233,1,0,0,0,1234,
	1235,1,0,0,0,1235,1236,1,0,0,0,1236,1237,5,2,0,0,1237,1238,5,2,0,0,1238,
	1270,1,0,0,0,1239,1240,7,21,0,0,1240,1241,5,1,0,0,1241,1248,3,4,2,0,1242,
	1243,5,17,0,0,1243,1246,3,106,53,0,1244,1245,5,17,0,0,1245,1247,3,86,43,
	0,1246,1244,1,0,0,0,1246,1247,1,0,0,0,1247,1249,1,0,0,0,1248,1242,1,0,0,
	0,1248,1249,1,0,0,0,1249,1250,1,0,0,0,1250,1251,5,152,0,0,1251,1253,5,1,
	0,0,1252,1254,3,98,49,0,1253,1252,1,0,0,0,1253,1254,1,0,0,0,1254,1255,1,
	0,0,0,1255,1256,3,100,50,0,1256,1257,1,0,0,0,1257,1258,5,2,0,0,1258,1259,
	5,2,0,0,1259,1270,1,0,0,0,1260,1261,5,151,0,0,1261,1262,5,1,0,0,1262,1263,
	3,4,2,0,1263,1264,5,152,0,0,1264,1265,5,1,0,0,1265,1266,3,98,49,0,1266,
	1267,5,2,0,0,1267,1268,5,2,0,0,1268,1270,1,0,0,0,1269,1222,1,0,0,0,1269,
	1239,1,0,0,0,1269,1260,1,0,0,0,1270,73,1,0,0,0,1271,1272,7,20,0,0,1272,
	1273,5,1,0,0,1273,1274,3,6,3,0,1274,1275,5,152,0,0,1275,1277,5,1,0,0,1276,
	1278,3,98,49,0,1277,1276,1,0,0,0,1277,1278,1,0,0,0,1278,1280,1,0,0,0,1279,
	1281,3,100,50,0,1280,1279,1,0,0,0,1280,1281,1,0,0,0,1281,1283,1,0,0,0,1282,
	1284,3,104,52,0,1283,1282,1,0,0,0,1283,1284,1,0,0,0,1284,1285,1,0,0,0,1285,
	1286,5,2,0,0,1286,1287,5,2,0,0,1287,1330,1,0,0,0,1288,1289,7,21,0,0,1289,
	1290,5,1,0,0,1290,1296,3,6,3,0,1291,1292,5,17,0,0,1292,1294,3,106,53,0,
	1293,1295,3,86,43,0,1294,1293,1,0,0,0,1294,1295,1,0,0,0,1295,1297,1,0,0,
	0,1296,1291,1,0,0,0,1296,1297,1,0,0,0,1297,1298,1,0,0,0,1298,1299,5,152,
	0,0,1299,1301,5,1,0,0,1300,1302,3,98,49,0,1301,1300,1,0,0,0,1301,1302,1,
	0,0,0,1302,1303,1,0,0,0,1303,1304,3,100,50,0,1304,1305,1,0,0,0,1305,1306,
	5,2,0,0,1306,1307,5,2,0,0,1307,1330,1,0,0,0,1308,1309,5,77,0,0,1309,1310,
	5,1,0,0,1310,1311,5,152,0,0,1311,1313,5,1,0,0,1312,1314,3,98,49,0,1313,
	1312,1,0,0,0,1313,1314,1,0,0,0,1314,1315,1,0,0,0,1315,1316,3,100,50,0,1316,
	1317,1,0,0,0,1317,1318,5,2,0,0,1318,1319,5,2,0,0,1319,1330,1,0,0,0,1320,
	1321,5,151,0,0,1321,1322,5,1,0,0,1322,1323,3,6,3,0,1323,1324,5,152,0,0,
	1324,1325,5,1,0,0,1325,1326,3,98,49,0,1326,1327,5,2,0,0,1327,1328,5,2,0,
	0,1328,1330,1,0,0,0,1329,1271,1,0,0,0,1329,1288,1,0,0,0,1329,1308,1,0,0,
	0,1329,1320,1,0,0,0,1330,75,1,0,0,0,1331,1332,3,192,96,0,1332,1333,5,68,
	0,0,1333,1334,3,192,96,0,1334,77,1,0,0,0,1335,1340,3,80,40,0,1336,1337,
	5,17,0,0,1337,1339,3,80,40,0,1338,1336,1,0,0,0,1339,1342,1,0,0,0,1340,1338,
	1,0,0,0,1340,1341,1,0,0,0,1341,79,1,0,0,0,1342,1340,1,0,0,0,1343,1345,3,
	206,103,0,1344,1343,1,0,0,0,1344,1345,1,0,0,0,1345,1346,1,0,0,0,1346,1347,
	3,192,96,0,1347,1348,5,20,0,0,1348,1349,3,68,34,0,1349,81,1,0,0,0,1350,
	1352,3,206,103,0,1351,1350,1,0,0,0,1351,1352,1,0,0,0,1352,1353,1,0,0,0,
	1353,1354,3,192,96,0,1354,1355,5,20,0,0,1355,1356,3,6,3,0,1356,83,1,0,0,
	0,1357,1358,3,192,96,0,1358,1359,5,7,0,0,1359,1360,3,86,43,0,1360,85,1,
	0,0,0,1361,1374,3,216,108,0,1362,1363,5,218,0,0,1363,1364,5,1,0,0,1364,
	1365,3,216,108,0,1365,1366,5,17,0,0,1366,1369,3,218,109,0,1367,1368,5,17,
	0,0,1368,1370,5,244,0,0,1369,1367,1,0,0,0,1369,1370,1,0,0,0,1370,1371,1,
	0,0,0,1371,1372,5,2,0,0,1372,1374,1,0,0,0,1373,1361,1,0,0,0,1373,1362,1,
	0,0,0,1374,87,1,0,0,0,1375,1380,3,92,46,0,1376,1377,5,17,0,0,1377,1379,
	3,92,46,0,1378,1376,1,0,0,0,1379,1382,1,0,0,0,1380,1378,1,0,0,0,1380,1381,
	1,0,0,0,1381,89,1,0,0,0,1382,1380,1,0,0,0,1383,1388,3,92,46,0,1384,1385,
	5,17,0,0,1385,1387,3,92,46,0,1386,1384,1,0,0,0,1387,1390,1,0,0,0,1388,1386,
	1,0,0,0,1388,1389,1,0,0,0,1389,1400,1,0,0,0,1390,1388,1,0,0,0,1391,1392,
	5,27,0,0,1392,1397,3,192,96,0,1393,1394,5,17,0,0,1394,1396,3,192,96,0,1395,
	1393,1,0,0,0,1396,1399,1,0,0,0,1397,1395,1,0,0,0,1397,1398,1,0,0,0,1398,
	1401,1,0,0,0,1399,1397,1,0,0,0,1400,1391,1,0,0,0,1400,1401,1,0,0,0,1401,
	91,1,0,0,0,1402,1405,3,4,2,0,1403,1404,5,46,0,0,1404,1406,3,186,93,0,1405,
	1403,1,0,0,0,1405,1406,1,0,0,0,1406,93,1,0,0,0,1407,1409,3,18,9,0,1408,
	1407,1,0,0,0,1408,1409,1,0,0,0,1409,1413,1,0,0,0,1410,1414,3,20,10,0,1411,
	1414,3,96,48,0,1412,1414,3,16,8,0,1413,1410,1,0,0,0,1413,1411,1,0,0,0,1413,
	1412,1,0,0,0,1413,1414,1,0,0,0,1414,1416,1,0,0,0,1415,1417,3,22,11,0,1416,
	1415,1,0,0,0,1416,1417,1,0,0,0,1417,1419,1,0,0,0,1418,1420,3,14,7,0,1419,
	1418,1,0,0,0,1419,1420,1,0,0,0,1420,95,1,0,0,0,1421,1422,5,206,0,0,1422,
	1423,3,4,2,0,1423,97,1,0,0,0,1424,1425,5,156,0,0,1425,1426,5,76,0,0,1426,
	1431,3,192,96,0,1427,1428,5,17,0,0,1428,1430,3,192,96,0,1429,1427,1,0,0,
	0,1430,1433,1,0,0,0,1431,1429,1,0,0,0,1431,1432,1,0,0,0,1432,99,1,0,0,0,
	1433,1431,1,0,0,0,1434,1435,5,75,0,0,1435,1436,5,76,0,0,1436,1441,3,102,
	51,0,1437,1438,5,17,0,0,1438,1440,3,102,51,0,1439,1437,1,0,0,0,1440,1443,
	1,0,0,0,1441,1439,1,0,0,0,1441,1442,1,0,0,0,1442,101,1,0,0,0,1443,1441,
	1,0,0,0,1444,1446,3,192,96,0,1445,1447,7,22,0,0,1446,1445,1,0,0,0,1446,
	1447,1,0,0,0,1447,103,1,0,0,0,1448,1449,5,119,0,0,1449,1452,5,188,0,0,1450,
	1452,5,158,0,0,1451,1448,1,0,0,0,1451,1450,1,0,0,0,1452,1453,1,0,0,0,1453,
	1454,5,51,0,0,1454,1455,3,110,55,0,1455,1456,5,47,0,0,1456,1457,3,110,55,
	0,1457,105,1,0,0,0,1458,1460,7,23,0,0,1459,1458,1,0,0,0,1459,1460,1,0,0,
	0,1460,1461,1,0,0,0,1461,1462,5,241,0,0,1462,107,1,0,0,0,1463,1465,7,23,
	0,0,1464,1463,1,0,0,0,1464,1465,1,0,0,0,1465,1466,1,0,0,0,1466,1467,5,242,
	0,0,1467,109,1,0,0,0,1468,1469,3,106,53,0,1469,1470,5,153,0,0,1470,1482,
	1,0,0,0,1471,1472,3,106,53,0,1472,1473,5,154,0,0,1473,1482,1,0,0,0,1474,
	1475,5,159,0,0,1475,1476,5,119,0,0,1476,1482,5,189,0,0,1477,1478,5,155,
	0,0,1478,1482,5,153,0,0,1479,1480,5,155,0,0,1480,1482,5,154,0,0,1481,1468,
	1,0,0,0,1481,1471,1,0,0,0,1481,1474,1,0,0,0,1481,1477,1,0,0,0,1481,1479,
	1,0,0,0,1482,111,1,0,0,0,1483,1484,5,144,0,0,1484,1485,7,24,0,0,1485,1490,
	3,192,96,0,1486,1487,5,17,0,0,1487,1489,3,192,96,0,1488,1486,1,0,0,0,1489,
	1492,1,0,0,0,1490,1488,1,0,0,0,1490,1491,1,0,0,0,1491,1501,1,0,0,0,1492,
	1490,1,0,0,0,1493,1494,5,211,0,0,1494,1495,5,1,0,0,1495,1498,5,244,0,0,
	1496,1497,5,17,0,0,1497,1499,7,16,0,0,1498,1496,1,0,0,0,1498,1499,1,0,0,
	0,1499,1500,1,0,0,0,1500,1502,5,2,0,0,1501,1493,1,0,0,0,1501,1502,1,0,0,
	0,1502,1512,1,0,0,0,1503,1504,5,144,0,0,1504,1509,5,72,0,0,1505,1506,5,
	211,0,0,1506,1507,5,1,0,0,1507,1508,5,244,0,0,1508,1510,5,2,0,0,1509,1505,
	1,0,0,0,1509,1510,1,0,0,0,1510,1512,1,0,0,0,1511,1483,1,0,0,0,1511,1503,
	1,0,0,0,1512,113,1,0,0,0,1513,1514,5,146,0,0,1514,1515,3,6,3,0,1515,115,
	1,0,0,0,1516,1517,3,188,94,0,1517,1520,3,122,61,0,1518,1519,5,221,0,0,1519,
	1521,3,86,43,0,1520,1518,1,0,0,0,1520,1521,1,0,0,0,1521,117,1,0,0,0,1522,
	1526,3,126,63,0,1523,1526,3,130,65,0,1524,1526,3,128,64,0,1525,1522,1,0,
	0,0,1525,1523,1,0,0,0,1525,1524,1,0,0,0,1526,119,1,0,0,0,1527,1530,3,128,
	64,0,1528,1530,3,126,63,0,1529,1527,1,0,0,0,1529,1528,1,0,0,0,1530,121,
	1,0,0,0,1531,1537,3,126,63,0,1532,1537,3,130,65,0,1533,1537,3,134,67,0,
	1534,1537,3,124,62,0,1535,1537,3,128,64,0,1536,1531,1,0,0,0,1536,1532,1,
	0,0,0,1536,1533,1,0,0,0,1536,1534,1,0,0,0,1536,1535,1,0,0,0,1537,123,1,
	0,0,0,1538,1542,5,127,0,0,1539,1542,3,136,68,0,1540,1542,3,138,69,0,1541,
	1538,1,0,0,0,1541,1539,1,0,0,0,1541,1540,1,0,0,0,1542,125,1,0,0,0,1543,
	1546,3,218,109,0,1544,1546,3,140,70,0,1545,1543,1,0,0,0,1545,1544,1,0,0,
	0,1546,1548,1,0,0,0,1547,1549,3,166,83,0,1548,1547,1,0,0,0,1548,1549,1,
	0,0,0,1549,1554,1,0,0,0,1550,1552,5,50,0,0,1551,1550,1,0,0,0,1551,1552,
	1,0,0,0,1552,1553,1,0,0,0,1553,1555,5,54,0,0,1554,1551,1,0,0,0,1554,1555,
	1,0,0,0,1555,127,1,0,0,0,1556,1561,3,206,103,0,1557,1558,5,8,0,0,1558,1559,
	3,126,63,0,1559,1560,5,9,0,0,1560,1562,1,0,0,0,1561,1557,1,0,0,0,1561,1562,
	1,0,0,0,1562,129,1,0,0,0,1563,1575,5,121,0,0,1564,1565,5,5,0,0,1565,1570,
	3,168,84,0,1566,1567,5,17,0,0,1567,1569,3,168,84,0,1568,1566,1,0,0,0,1569,
	1572,1,0,0,0,1570,1568,1,0,0,0,1570,1571,1,0,0,0,1571,1573,1,0,0,0,1572,
	1570,1,0,0,0,1573,1574,5,6,0,0,1574,1576,1,0,0,0,1575,1564,1,0,0,0,1575,
	1576,1,0,0,0,1576,131,1,0,0,0,1577,1580,3,130,65,0,1578,1580,3,126,63,0,
	1579,1577,1,0,0,0,1579,1578,1,0,0,0,1580,133,1,0,0,0,1581,1586,5,239,0,
	0,1582,1583,5,8,0,0,1583,1584,3,126,63,0,1584,1585,5,9,0,0,1585,1587,1,
	0,0,0,1586,1582,1,0,0,0,1586,1587,1,0,0,0,1587,135,1,0,0,0,1588,1618,5,
	125,0,0,1589,1601,5,235,0,0,1590,1591,5,5,0,0,1591,1596,3,140,70,0,1592,
	1593,5,15,0,0,1593,1595,3,140,70,0,1594,1592,1,0,0,0,1595,1598,1,0,0,0,
	1596,1594,1,0,0,0,1596,1597,1,0,0,0,1597,1599,1,0,0,0,1598,1596,1,0,0,0,
	1599,1600,5,6,0,0,1600,1602,1,0,0,0,1601,1590,1,0,0,0,1601,1602,1,0,0,0,
	1602,1618,1,0,0,0,1603,1615,5,236,0,0,1604,1605,5,5,0,0,1605,1610,3,188,
	94,0,1606,1607,5,15,0,0,1607,1609,3,188,94,0,1608,1606,1,0,0,0,1609,1612,
	1,0,0,0,1610,1608,1,0,0,0,1610,1611,1,0,0,0,1611,1613,1,0,0,0,1612,1610,
	1,0,0,0,1613,1614,5,6,0,0,1614,1616,1,0,0,0,1615,1604,1,0,0,0,1615,1616,
	1,0,0,0,1616,1618,1,0,0,0,1617,1588,1,0,0,0,1617,1589,1,0,0,0,1617,1603,
	1,0,0,0,1618,137,1,0,0,0,1619,1660,5,126,0,0,1620,1637,5,237,0,0,1621,1622,
	5,5,0,0,1622,1634,5,245,0,0,1623,1624,5,1,0,0,1624,1629,3,140,70,0,1625,
	1626,5,15,0,0,1626,1628,3,140,70,0,1627,1625,1,0,0,0,1628,1631,1,0,0,0,
	1629,1627,1,0,0,0,1629,1630,1,0,0,0,1630,1632,1,0,0,0,1631,1629,1,0,0,0,
	1632,1633,5,2,0,0,1633,1635,1,0,0,0,1634,1623,1,0,0,0,1634,1635,1,0,0,0,
	1635,1636,1,0,0,0,1636,1638,5,6,0,0,1637,1621,1,0,0,0,1637,1638,1,0,0,0,
	1638,1660,1,0,0,0,1639,1657,5,238,0,0,1640,1641,5,5,0,0,1641,1653,3,188,
	94,0,1642,1643,5,1,0,0,1643,1648,3,188,94,0,1644,1645,5,15,0,0,1645,1647,
	3,188,94,0,1646,1644,1,0,0,0,1647,1650,1,0,0,0,1648,1646,1,0,0,0,1648,1649,
	1,0,0,0,1649,1651,1,0,0,0,1650,1648,1,0,0,0,1651,1652,5,2,0,0,1652,1654,
	1,0,0,0,1653,1642,1,0,0,0,1653,1654,1,0,0,0,1654,1655,1,0,0,0,1655,1656,
	5,6,0,0,1656,1658,1,0,0,0,1657,1640,1,0,0,0,1657,1658,1,0,0,0,1658,1660,
	1,0,0,0,1659,1619,1,0,0,0,1659,1620,1,0,0,0,1659,1639,1,0,0,0,1660,139,
	1,0,0,0,1661,1662,5,245,0,0,1662,141,1,0,0,0,1663,1664,5,245,0,0,1664,143,
	1,0,0,0,1665,1666,7,25,0,0,1666,1671,3,146,73,0,1667,1668,5,17,0,0,1668,
	1670,3,146,73,0,1669,1667,1,0,0,0,1670,1673,1,0,0,0,1671,1669,1,0,0,0,1671,
	1672,1,0,0,0,1672,145,1,0,0,0,1673,1671,1,0,0,0,1674,1677,3,188,94,0,1675,
	1676,5,46,0,0,1676,1678,3,186,93,0,1677,1675,1,0,0,0,1677,1678,1,0,0,0,
	1678,147,1,0,0,0,1679,1684,3,150,75,0,1680,1681,5,247,0,0,1681,1683,3,150,
	75,0,1682,1680,1,0,0,0,1683,1686,1,0,0,0,1684,1682,1,0,0,0,1684,1685,1,
	0,0,0,1685,149,1,0,0,0,1686,1684,1,0,0,0,1687,1688,5,245,0,0,1688,1690,
	5,19,0,0,1689,1687,1,0,0,0,1689,1690,1,0,0,0,1690,1695,1,0,0,0,1691,1692,
	5,185,0,0,1692,1693,3,6,3,0,1693,1694,5,25,0,0,1694,1696,1,0,0,0,1695,1691,
	1,0,0,0,1695,1696,1,0,0,0,1696,1697,1,0,0,0,1697,1699,3,6,3,0,1698,1700,
	3,196,98,0,1699,1698,1,0,0,0,1699,1700,1,0,0,0,1700,1702,1,0,0,0,1701,1703,
	3,198,99,0,1702,1701,1,0,0,0,1702,1703,1,0,0,0,1703,151,1,0,0,0,1704,1709,
	3,154,77,0,1705,1706,5,247,0,0,1706,1708,3,154,77,0,1707,1705,1,0,0,0,1708,
	1711,1,0,0,0,1709,1707,1,0,0,0,1709,1710,1,0,0,0,1710,153,1,0,0,0,1711,
	1709,1,0,0,0,1712,1713,5,245,0,0,1713,1715,5,19,0,0,1714,1712,1,0,0,0,1714,
	1715,1,0,0,0,1715,1716,1,0,0,0,1716,1718,3,160,80,0,1717,1719,3,196,98,
	0,1718,1717,1,0,0,0,1718,1719,1,0,0,0,1719,1721,1,0,0,0,1720,1722,3,198,
	99,0,1721,1720,1,0,0,0,1721,1722,1,0,0,0,1722,155,1,0,0,0,1723,1726,7,25,
	0,0,1724,1725,5,167,0,0,1725,1727,3,158,79,0,1726,1724,1,0,0,0,1726,1727,
	1,0,0,0,1727,1728,1,0,0,0,1728,1729,5,128,0,0,1729,1730,5,245,0,0,1730,
	157,1,0,0,0,1731,1736,3,146,73,0,1732,1733,5,17,0,0,1733,1735,3,146,73,
	0,1734,1732,1,0,0,0,1735,1738,1,0,0,0,1736,1734,1,0,0,0,1736,1737,1,0,0,
	0,1737,159,1,0,0,0,1738,1736,1,0,0,0,1739,1740,5,185,0,0,1740,1741,3,6,
	3,0,1741,1742,5,25,0,0,1742,1744,1,0,0,0,1743,1739,1,0,0,0,1743,1744,1,
	0,0,0,1744,1745,1,0,0,0,1745,1747,3,164,82,0,1746,1748,3,200,100,0,1747,
	1746,1,0,0,0,1747,1748,1,0,0,0,1748,1749,1,0,0,0,1749,1753,3,162,81,0,1750,
	1752,3,162,81,0,1751,1750,1,0,0,0,1752,1755,1,0,0,0,1753,1751,1,0,0,0,1753,
	1754,1,0,0,0,1754,161,1,0,0,0,1755,1753,1,0,0,0,1756,1758,7,23,0,0,1757,
	1756,1,0,0,0,1757,1758,1,0,0,0,1758,1759,1,0,0,0,1759,1764,3,164,82,0,1760,
	1761,5,3,0,0,1761,1762,3,6,3,0,1762,1763,5,4,0,0,1763,1765,1,0,0,0,1764,
	1760,1,0,0,0,1764,1765,1,0,0,0,1765,163,1,0,0,0,1766,1770,5,245,0,0,1767,
	1770,3,106,53,0,1768,1770,3,108,54,0,1769,1766,1,0,0,0,1769,1767,1,0,0,
	0,1769,1768,1,0,0,0,1770,165,1,0,0,0,1771,1772,5,3,0,0,1772,1773,3,6,3,
	0,1773,1774,5,4,0,0,1774,1787,1,0,0,0,1775,1776,5,5,0,0,1776,1781,3,86,
	43,0,1777,1778,5,17,0,0,1778,1780,3,86,43,0,1779,1777,1,0,0,0,1780,1783,
	1,0,0,0,1781,1779,1,0,0,0,1781,1782,1,0,0,0,1782,1784,1,0,0,0,1783,1781,
	1,0,0,0,1784,1785,5,6,0,0,1785,1787,1,0,0,0,1786,1771,1,0,0,0,1786,1775,
	1,0,0,0,1787,167,1,0,0,0,1788,1791,3,128,64,0,1789,1792,3,192,96,0,1790,
	1792,3,170,85,0,1791,1789,1,0,0,0,1791,1790,1,0,0,0,1792,169,1,0,0,0,1793,
	1795,5,115,0,0,1794,1796,7,26,0,0,1795,1794,1,0,0,0,1795,1796,1,0,0,0,1796,
	171,1,0,0,0,1797,1798,7,27,0,0,1798,173,1,0,0,0,1799,1800,7,28,0,0,1800,
	175,1,0,0,0,1801,1802,5,167,0,0,1802,1807,3,192,96,0,1803,1804,5,17,0,0,
	1804,1806,3,192,96,0,1805,1803,1,0,0,0,1806,1809,1,0,0,0,1807,1805,1,0,
	0,0,1807,1808,1,0,0,0,1808,177,1,0,0,0,1809,1807,1,0,0,0,1810,1811,7,29,
	0,0,1811,179,1,0,0,0,1812,1813,5,70,0,0,1813,1814,3,4,2,0,1814,181,1,0,
	0,0,1815,1816,7,30,0,0,1816,183,1,0,0,0,1817,1818,7,31,0,0,1818,185,1,0,
	0,0,1819,1820,5,245,0,0,1820,187,1,0,0,0,1821,1822,5,245,0,0,1822,189,1,
	0,0,0,1823,1824,5,245,0,0,1824,191,1,0,0,0,1825,1828,5,245,0,0,1826,1827,
	5,21,0,0,1827,1829,5,245,0,0,1828,1826,1,0,0,0,1828,1829,1,0,0,0,1829,193,
	1,0,0,0,1830,1831,5,5,0,0,1831,1836,3,86,43,0,1832,1833,5,17,0,0,1833,1835,
	3,86,43,0,1834,1832,1,0,0,0,1835,1838,1,0,0,0,1836,1834,1,0,0,0,1836,1837,
	1,0,0,0,1837,1839,1,0,0,0,1838,1836,1,0,0,0,1839,1840,5,6,0,0,1840,195,
	1,0,0,0,1841,1842,5,71,0,0,1842,1843,3,216,108,0,1843,197,1,0,0,0,1844,
	1845,5,74,0,0,1845,1846,3,216,108,0,1846,199,1,0,0,0,1847,1848,7,32,0,0,
	1848,201,1,0,0,0,1849,1852,3,4,2,0,1850,1852,5,115,0,0,1851,1849,1,0,0,
	0,1851,1850,1,0,0,0,1852,203,1,0,0,0,1853,1856,3,6,3,0,1854,1856,5,115,
	0,0,1855,1853,1,0,0,0,1855,1854,1,0,0,0,1856,205,1,0,0,0,1857,1863,5,104,
	0,0,1858,1863,5,234,0,0,1859,1863,5,103,0,0,1860,1863,5,105,0,0,1861,1863,
	3,208,104,0,1862,1857,1,0,0,0,1862,1858,1,0,0,0,1862,1859,1,0,0,0,1862,
	1860,1,0,0,0,1862,1861,1,0,0,0,1863,207,1,0,0,0,1864,1865,5,110,0,0,1865,
	1866,5,105,0,0,1866,209,1,0,0,0,1867,1868,5,245,0,0,1868,211,1,0,0,0,1869,
	1870,5,245,0,0,1870,213,1,0,0,0,1871,1872,5,245,0,0,1872,215,1,0,0,0,1873,
	1879,3,106,53,0,1874,1879,3,108,54,0,1875,1879,5,243,0,0,1876,1879,5,244,
	0,0,1877,1879,5,54,0,0,1878,1873,1,0,0,0,1878,1874,1,0,0,0,1878,1875,1,
	0,0,0,1878,1876,1,0,0,0,1878,1877,1,0,0,0,1879,217,1,0,0,0,1880,1881,7,
	33,0,0,1881,219,1,0,0,0,1882,1883,7,34,0,0,1883,221,1,0,0,0,201,227,241,
	266,273,303,305,307,333,340,362,364,366,377,391,400,408,415,417,428,437,
	455,464,479,490,493,498,531,540,543,553,558,562,568,572,582,586,590,599,
	602,612,616,626,631,635,641,645,649,653,657,673,677,688,699,703,707,723,
	727,738,749,753,757,769,780,792,803,833,837,860,865,873,894,898,902,964,
	969,977,998,1002,1006,1068,1077,1088,1099,1107,1111,1114,1117,1120,1135,
	1138,1141,1151,1155,1158,1161,1164,1172,1175,1178,1181,1185,1209,1216,1218,
	1228,1231,1234,1246,1248,1253,1269,1277,1280,1283,1294,1296,1301,1313,1329,
	1340,1344,1351,1369,1373,1380,1388,1397,1400,1405,1408,1413,1416,1419,1431,
	1441,1446,1451,1459,1464,1481,1490,1498,1501,1509,1511,1520,1525,1529,1536,
	1541,1545,1548,1551,1554,1561,1570,1575,1579,1586,1596,1601,1610,1615,1617,
	1629,1634,1637,1648,1653,1657,1659,1671,1677,1684,1689,1695,1699,1702,1709,
	1714,1718,1721,1726,1736,1743,1747,1753,1757,1764,1769,1781,1786,1791,1795,
	1807,1828,1836,1851,1855,1862,1878];

	private static __ATN: ATN;
	public static get _ATN(): ATN {
		if (!VtlParser.__ATN) {
			VtlParser.__ATN = new ATNDeserializer().deserialize(VtlParser._serializedATN);
		}

		return VtlParser.__ATN;
	}


	static DecisionsToDFA = VtlParser._ATN.decisionToState.map( (ds: DecisionState, index: number) => new DFA(ds, index) );

}

export class StartContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public EOF(): TerminalNode {
		return this.getToken(VtlParser.EOF, 0);
	}
	public statement_list(): StatementContext[] {
		return this.getTypedRuleContexts(StatementContext) as StatementContext[];
	}
	public statement(i: number): StatementContext {
		return this.getTypedRuleContext(StatementContext, i) as StatementContext;
	}
	public EOL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.EOL);
	}
	public EOL(i: number): TerminalNode {
		return this.getToken(VtlParser.EOL, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_start;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitStart) {
			return visitor.visitStart(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StatementContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_statement;
	}
	public copyFrom(ctx: StatementContext): void {
		super.copyFrom(ctx);
	}
}
export class DefineExpressionContext extends StatementContext {
	constructor(parser: VtlParser, ctx: StatementContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public defOperators(): DefOperatorsContext {
		return this.getTypedRuleContext(DefOperatorsContext, 0) as DefOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDefineExpression) {
			return visitor.visitDefineExpression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TemporaryAssignmentContext extends StatementContext {
	constructor(parser: VtlParser, ctx: StatementContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public ASSIGN(): TerminalNode {
		return this.getToken(VtlParser.ASSIGN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTemporaryAssignment) {
			return visitor.visitTemporaryAssignment(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class PersistAssignmentContext extends StatementContext {
	constructor(parser: VtlParser, ctx: StatementContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public PUT_SYMBOL(): TerminalNode {
		return this.getToken(VtlParser.PUT_SYMBOL, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitPersistAssignment) {
			return visitor.visitPersistAssignment(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ExprContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_expr;
	}
	public copyFrom(ctx: ExprContext): void {
		super.copyFrom(ctx);
	}
}
export class VarIdExprContext extends ExprContext {
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitVarIdExpr) {
			return visitor.visitVarIdExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class MembershipExprContext extends ExprContext {
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public MEMBERSHIP(): TerminalNode {
		return this.getToken(VtlParser.MEMBERSHIP, 0);
	}
	public simpleComponentId(): SimpleComponentIdContext {
		return this.getTypedRuleContext(SimpleComponentIdContext, 0) as SimpleComponentIdContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitMembershipExpr) {
			return visitor.visitMembershipExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class InNotInExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IN(): TerminalNode {
		return this.getToken(VtlParser.IN, 0);
	}
	public NOT_IN(): TerminalNode {
		return this.getToken(VtlParser.NOT_IN, 0);
	}
	public lists(): ListsContext {
		return this.getTypedRuleContext(ListsContext, 0) as ListsContext;
	}
	public valueDomainID(): ValueDomainIDContext {
		return this.getTypedRuleContext(ValueDomainIDContext, 0) as ValueDomainIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInNotInExpr) {
			return visitor.visitInNotInExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BooleanExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public AND(): TerminalNode {
		return this.getToken(VtlParser.AND, 0);
	}
	public OR(): TerminalNode {
		return this.getToken(VtlParser.OR, 0);
	}
	public XOR(): TerminalNode {
		return this.getToken(VtlParser.XOR, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBooleanExpr) {
			return visitor.visitBooleanExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: ComparisonOperandContext;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public comparisonOperand(): ComparisonOperandContext {
		return this.getTypedRuleContext(ComparisonOperandContext, 0) as ComparisonOperandContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComparisonExpr) {
			return visitor.visitComparisonExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryExprContext extends ExprContext {
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
	public NOT(): TerminalNode {
		return this.getToken(VtlParser.NOT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryExpr) {
			return visitor.visitUnaryExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FunctionsExpressionContext extends ExprContext {
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public functions(): FunctionsContext {
		return this.getTypedRuleContext(FunctionsContext, 0) as FunctionsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFunctionsExpression) {
			return visitor.visitFunctionsExpression(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IfExprContext extends ExprContext {
	public _conditionalExpr!: ExprContext;
	public _thenExpr!: ExprContext;
	public _elseExpr!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public IF(): TerminalNode {
		return this.getToken(VtlParser.IF, 0);
	}
	public THEN(): TerminalNode {
		return this.getToken(VtlParser.THEN, 0);
	}
	public ELSE(): TerminalNode {
		return this.getToken(VtlParser.ELSE, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitIfExpr) {
			return visitor.visitIfExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ClauseExprContext extends ExprContext {
	public _dataset!: ExprContext;
	public _clause!: DatasetClauseContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public QLPAREN(): TerminalNode {
		return this.getToken(VtlParser.QLPAREN, 0);
	}
	public QRPAREN(): TerminalNode {
		return this.getToken(VtlParser.QRPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public datasetClause(): DatasetClauseContext {
		return this.getTypedRuleContext(DatasetClauseContext, 0) as DatasetClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitClauseExpr) {
			return visitor.visitClauseExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CaseExprContext extends ExprContext {
	public _expr!: ExprContext;
	public _condExpr: ExprContext[] = [];
	public _thenExpr: ExprContext[] = [];
	public _elseExpr!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CASE(): TerminalNode {
		return this.getToken(VtlParser.CASE, 0);
	}
	public ELSE(): TerminalNode {
		return this.getToken(VtlParser.ELSE, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public WHEN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.WHEN);
	}
	public WHEN(i: number): TerminalNode {
		return this.getToken(VtlParser.WHEN, i);
	}
	public THEN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.THEN);
	}
	public THEN(i: number): TerminalNode {
		return this.getToken(VtlParser.THEN, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCaseExpr) {
			return visitor.visitCaseExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ArithmeticExprContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public MUL(): TerminalNode {
		return this.getToken(VtlParser.MUL, 0);
	}
	public DIV(): TerminalNode {
		return this.getToken(VtlParser.DIV, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitArithmeticExpr) {
			return visitor.visitArithmeticExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ParenthesisExprContext extends ExprContext {
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitParenthesisExpr) {
			return visitor.visitParenthesisExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConstantExprContext extends ExprContext {
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConstantExpr) {
			return visitor.visitConstantExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ArithmeticExprOrConcatContext extends ExprContext {
	public _left!: ExprContext;
	public _op!: Token;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ExprContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
	public CONCAT(): TerminalNode {
		return this.getToken(VtlParser.CONCAT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitArithmeticExprOrConcat) {
			return visitor.visitArithmeticExprOrConcat(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ExprComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_exprComponent;
	}
	public copyFrom(ctx: ExprComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class ArithmeticExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public MUL(): TerminalNode {
		return this.getToken(VtlParser.MUL, 0);
	}
	public DIV(): TerminalNode {
		return this.getToken(VtlParser.DIV, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitArithmeticExprComp) {
			return visitor.visitArithmeticExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IfExprCompContext extends ExprComponentContext {
	public _conditionalExpr!: ExprComponentContext;
	public _thenExpr!: ExprComponentContext;
	public _elseExpr!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public IF(): TerminalNode {
		return this.getToken(VtlParser.IF, 0);
	}
	public THEN(): TerminalNode {
		return this.getToken(VtlParser.THEN, 0);
	}
	public ELSE(): TerminalNode {
		return this.getToken(VtlParser.ELSE, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitIfExprComp) {
			return visitor.visitIfExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public comparisonOperand(): ComparisonOperandContext {
		return this.getTypedRuleContext(ComparisonOperandContext, 0) as ComparisonOperandContext;
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComparisonExprComp) {
			return visitor.visitComparisonExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FunctionsExpressionCompContext extends ExprComponentContext {
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public functionsComponents(): FunctionsComponentsContext {
		return this.getTypedRuleContext(FunctionsComponentsContext, 0) as FunctionsComponentsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFunctionsExpressionComp) {
			return visitor.visitFunctionsExpressionComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CompIdContext extends ExprComponentContext {
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCompId) {
			return visitor.visitCompId(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConstantExprCompContext extends ExprComponentContext {
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConstantExprComp) {
			return visitor.visitConstantExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ArithmeticExprOrConcatCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
	public CONCAT(): TerminalNode {
		return this.getToken(VtlParser.CONCAT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitArithmeticExprOrConcatComp) {
			return visitor.visitArithmeticExprOrConcatComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ParenthesisExprCompContext extends ExprComponentContext {
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitParenthesisExprComp) {
			return visitor.visitParenthesisExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class InNotInExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public IN(): TerminalNode {
		return this.getToken(VtlParser.IN, 0);
	}
	public NOT_IN(): TerminalNode {
		return this.getToken(VtlParser.NOT_IN, 0);
	}
	public lists(): ListsContext {
		return this.getTypedRuleContext(ListsContext, 0) as ListsContext;
	}
	public valueDomainID(): ValueDomainIDContext {
		return this.getTypedRuleContext(ValueDomainIDContext, 0) as ValueDomainIDContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInNotInExprComp) {
			return visitor.visitInNotInExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryExprCompContext extends ExprComponentContext {
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
	public NOT(): TerminalNode {
		return this.getToken(VtlParser.NOT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryExprComp) {
			return visitor.visitUnaryExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CaseExprCompContext extends ExprComponentContext {
	public _exprComponent!: ExprComponentContext;
	public _condExpr: ExprComponentContext[] = [];
	public _thenExpr: ExprComponentContext[] = [];
	public _elseExpr!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CASE(): TerminalNode {
		return this.getToken(VtlParser.CASE, 0);
	}
	public ELSE(): TerminalNode {
		return this.getToken(VtlParser.ELSE, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public WHEN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.WHEN);
	}
	public WHEN(i: number): TerminalNode {
		return this.getToken(VtlParser.WHEN, i);
	}
	public THEN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.THEN);
	}
	public THEN(i: number): TerminalNode {
		return this.getToken(VtlParser.THEN, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCaseExprComp) {
			return visitor.visitCaseExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BooleanExprCompContext extends ExprComponentContext {
	public _left!: ExprComponentContext;
	public _op!: Token;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ExprComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public AND(): TerminalNode {
		return this.getToken(VtlParser.AND, 0);
	}
	public OR(): TerminalNode {
		return this.getToken(VtlParser.OR, 0);
	}
	public XOR(): TerminalNode {
		return this.getToken(VtlParser.XOR, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBooleanExprComp) {
			return visitor.visitBooleanExprComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class FunctionsComponentsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_functionsComponents;
	}
	public copyFrom(ctx: FunctionsComponentsContext): void {
		super.copyFrom(ctx);
	}
}
export class NumericFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public numericOperatorsComponent(): NumericOperatorsComponentContext {
		return this.getTypedRuleContext(NumericOperatorsComponentContext, 0) as NumericOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitNumericFunctionsComponents) {
			return visitor.visitNumericFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class StringFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public stringOperatorsComponent(): StringOperatorsComponentContext {
		return this.getTypedRuleContext(StringOperatorsComponentContext, 0) as StringOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitStringFunctionsComponents) {
			return visitor.visitStringFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public comparisonOperatorsComponent(): ComparisonOperatorsComponentContext {
		return this.getTypedRuleContext(ComparisonOperatorsComponentContext, 0) as ComparisonOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComparisonFunctionsComponents) {
			return visitor.visitComparisonFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public timeOperatorsComponent(): TimeOperatorsComponentContext {
		return this.getTypedRuleContext(TimeOperatorsComponentContext, 0) as TimeOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTimeFunctionsComponents) {
			return visitor.visitTimeFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class GenericFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public genericOperatorsComponent(): GenericOperatorsComponentContext {
		return this.getTypedRuleContext(GenericOperatorsComponentContext, 0) as GenericOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitGenericFunctionsComponents) {
			return visitor.visitGenericFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AnalyticFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public anFunctionComponent(): AnFunctionComponentContext {
		return this.getTypedRuleContext(AnFunctionComponentContext, 0) as AnFunctionComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAnalyticFunctionsComponents) {
			return visitor.visitAnalyticFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConditionalFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public conditionalOperatorsComponent(): ConditionalOperatorsComponentContext {
		return this.getTypedRuleContext(ConditionalOperatorsComponentContext, 0) as ConditionalOperatorsComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConditionalFunctionsComponents) {
			return visitor.visitConditionalFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AggregateFunctionsComponentsContext extends FunctionsComponentsContext {
	constructor(parser: VtlParser, ctx: FunctionsComponentsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public aggrOperators(): AggrOperatorsContext {
		return this.getTypedRuleContext(AggrOperatorsContext, 0) as AggrOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggregateFunctionsComponents) {
			return visitor.visitAggregateFunctionsComponents(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class FunctionsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_functions;
	}
	public copyFrom(ctx: FunctionsContext): void {
		super.copyFrom(ctx);
	}
}
export class HierarchyFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public hierarchyOperators(): HierarchyOperatorsContext {
		return this.getTypedRuleContext(HierarchyOperatorsContext, 0) as HierarchyOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHierarchyFunctions) {
			return visitor.visitHierarchyFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class StringFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public stringOperators(): StringOperatorsContext {
		return this.getTypedRuleContext(StringOperatorsContext, 0) as StringOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitStringFunctions) {
			return visitor.visitStringFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValidationFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public validationOperators(): ValidationOperatorsContext {
		return this.getTypedRuleContext(ValidationOperatorsContext, 0) as ValidationOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValidationFunctions) {
			return visitor.visitValidationFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class GenericFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public genericOperators(): GenericOperatorsContext {
		return this.getTypedRuleContext(GenericOperatorsContext, 0) as GenericOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitGenericFunctions) {
			return visitor.visitGenericFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConditionalFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public conditionalOperators(): ConditionalOperatorsContext {
		return this.getTypedRuleContext(ConditionalOperatorsContext, 0) as ConditionalOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConditionalFunctions) {
			return visitor.visitConditionalFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AggregateFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public aggrOperatorsGrouping(): AggrOperatorsGroupingContext {
		return this.getTypedRuleContext(AggrOperatorsGroupingContext, 0) as AggrOperatorsGroupingContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggregateFunctions) {
			return visitor.visitAggregateFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class JoinFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public joinOperators(): JoinOperatorsContext {
		return this.getTypedRuleContext(JoinOperatorsContext, 0) as JoinOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinFunctions) {
			return visitor.visitJoinFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ComparisonFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public comparisonOperators(): ComparisonOperatorsContext {
		return this.getTypedRuleContext(ComparisonOperatorsContext, 0) as ComparisonOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComparisonFunctions) {
			return visitor.visitComparisonFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class NumericFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public numericOperators(): NumericOperatorsContext {
		return this.getTypedRuleContext(NumericOperatorsContext, 0) as NumericOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitNumericFunctions) {
			return visitor.visitNumericFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public timeOperators(): TimeOperatorsContext {
		return this.getTypedRuleContext(TimeOperatorsContext, 0) as TimeOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTimeFunctions) {
			return visitor.visitTimeFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SetFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public setOperators(): SetOperatorsContext {
		return this.getTypedRuleContext(SetOperatorsContext, 0) as SetOperatorsContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSetFunctions) {
			return visitor.visitSetFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AnalyticFunctionsContext extends FunctionsContext {
	constructor(parser: VtlParser, ctx: FunctionsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public anFunction(): AnFunctionContext {
		return this.getTypedRuleContext(AnFunctionContext, 0) as AnFunctionContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAnalyticFunctions) {
			return visitor.visitAnalyticFunctions(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DatasetClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public renameClause(): RenameClauseContext {
		return this.getTypedRuleContext(RenameClauseContext, 0) as RenameClauseContext;
	}
	public aggrClause(): AggrClauseContext {
		return this.getTypedRuleContext(AggrClauseContext, 0) as AggrClauseContext;
	}
	public filterClause(): FilterClauseContext {
		return this.getTypedRuleContext(FilterClauseContext, 0) as FilterClauseContext;
	}
	public calcClause(): CalcClauseContext {
		return this.getTypedRuleContext(CalcClauseContext, 0) as CalcClauseContext;
	}
	public keepOrDropClause(): KeepOrDropClauseContext {
		return this.getTypedRuleContext(KeepOrDropClauseContext, 0) as KeepOrDropClauseContext;
	}
	public pivotOrUnpivotClause(): PivotOrUnpivotClauseContext {
		return this.getTypedRuleContext(PivotOrUnpivotClauseContext, 0) as PivotOrUnpivotClauseContext;
	}
	public subspaceClause(): SubspaceClauseContext {
		return this.getTypedRuleContext(SubspaceClauseContext, 0) as SubspaceClauseContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_datasetClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDatasetClause) {
			return visitor.visitDatasetClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RenameClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RENAME(): TerminalNode {
		return this.getToken(VtlParser.RENAME, 0);
	}
	public renameClauseItem_list(): RenameClauseItemContext[] {
		return this.getTypedRuleContexts(RenameClauseItemContext) as RenameClauseItemContext[];
	}
	public renameClauseItem(i: number): RenameClauseItemContext {
		return this.getTypedRuleContext(RenameClauseItemContext, i) as RenameClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_renameClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRenameClause) {
			return visitor.visitRenameClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public AGGREGATE(): TerminalNode {
		return this.getToken(VtlParser.AGGREGATE, 0);
	}
	public aggregateClause(): AggregateClauseContext {
		return this.getTypedRuleContext(AggregateClauseContext, 0) as AggregateClauseContext;
	}
	public groupingClause(): GroupingClauseContext {
		return this.getTypedRuleContext(GroupingClauseContext, 0) as GroupingClauseContext;
	}
	public havingClause(): HavingClauseContext {
		return this.getTypedRuleContext(HavingClauseContext, 0) as HavingClauseContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_aggrClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggrClause) {
			return visitor.visitAggrClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class FilterClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public FILTER(): TerminalNode {
		return this.getToken(VtlParser.FILTER, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_filterClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFilterClause) {
			return visitor.visitFilterClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CalcClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public CALC(): TerminalNode {
		return this.getToken(VtlParser.CALC, 0);
	}
	public calcClauseItem_list(): CalcClauseItemContext[] {
		return this.getTypedRuleContexts(CalcClauseItemContext) as CalcClauseItemContext[];
	}
	public calcClauseItem(i: number): CalcClauseItemContext {
		return this.getTypedRuleContext(CalcClauseItemContext, i) as CalcClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_calcClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCalcClause) {
			return visitor.visitCalcClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class KeepOrDropClauseContext extends ParserRuleContext {
	public _op!: Token;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public KEEP(): TerminalNode {
		return this.getToken(VtlParser.KEEP, 0);
	}
	public DROP(): TerminalNode {
		return this.getToken(VtlParser.DROP, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_keepOrDropClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitKeepOrDropClause) {
			return visitor.visitKeepOrDropClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class PivotOrUnpivotClauseContext extends ParserRuleContext {
	public _op!: Token;
	public _id_!: ComponentIDContext;
	public _mea!: ComponentIDContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public PIVOT(): TerminalNode {
		return this.getToken(VtlParser.PIVOT, 0);
	}
	public UNPIVOT(): TerminalNode {
		return this.getToken(VtlParser.UNPIVOT, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_pivotOrUnpivotClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitPivotOrUnpivotClause) {
			return visitor.visitPivotOrUnpivotClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CustomPivotClauseContext extends ParserRuleContext {
	public _id_!: ComponentIDContext;
	public _mea!: ComponentIDContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public CUSTOMPIVOT(): TerminalNode {
		return this.getToken(VtlParser.CUSTOMPIVOT, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public IN(): TerminalNode {
		return this.getToken(VtlParser.IN, 0);
	}
	public constant_list(): ConstantContext[] {
		return this.getTypedRuleContexts(ConstantContext) as ConstantContext[];
	}
	public constant(i: number): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, i) as ConstantContext;
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_customPivotClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCustomPivotClause) {
			return visitor.visitCustomPivotClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SubspaceClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public SUBSPACE(): TerminalNode {
		return this.getToken(VtlParser.SUBSPACE, 0);
	}
	public subspaceClauseItem_list(): SubspaceClauseItemContext[] {
		return this.getTypedRuleContexts(SubspaceClauseItemContext) as SubspaceClauseItemContext[];
	}
	public subspaceClauseItem(i: number): SubspaceClauseItemContext {
		return this.getTypedRuleContext(SubspaceClauseItemContext, i) as SubspaceClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_subspaceClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSubspaceClause) {
			return visitor.visitSubspaceClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_joinOperators;
	}
	public copyFrom(ctx: JoinOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class JoinExprContext extends JoinOperatorsContext {
	public _joinKeyword!: Token;
	constructor(parser: VtlParser, ctx: JoinOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public joinClause(): JoinClauseContext {
		return this.getTypedRuleContext(JoinClauseContext, 0) as JoinClauseContext;
	}
	public joinBody(): JoinBodyContext {
		return this.getTypedRuleContext(JoinBodyContext, 0) as JoinBodyContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public INNER_JOIN(): TerminalNode {
		return this.getToken(VtlParser.INNER_JOIN, 0);
	}
	public LEFT_JOIN(): TerminalNode {
		return this.getToken(VtlParser.LEFT_JOIN, 0);
	}
	public joinClauseWithoutUsing(): JoinClauseWithoutUsingContext {
		return this.getTypedRuleContext(JoinClauseWithoutUsingContext, 0) as JoinClauseWithoutUsingContext;
	}
	public FULL_JOIN(): TerminalNode {
		return this.getToken(VtlParser.FULL_JOIN, 0);
	}
	public CROSS_JOIN(): TerminalNode {
		return this.getToken(VtlParser.CROSS_JOIN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinExpr) {
			return visitor.visitJoinExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DefOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_defOperators;
	}
	public copyFrom(ctx: DefOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class DefOperatorContext extends DefOperatorsContext {
	constructor(parser: VtlParser, ctx: DefOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DEFINE(): TerminalNode {
		return this.getToken(VtlParser.DEFINE, 0);
	}
	public OPERATOR_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.OPERATOR);
	}
	public OPERATOR(i: number): TerminalNode {
		return this.getToken(VtlParser.OPERATOR, i);
	}
	public operatorID(): OperatorIDContext {
		return this.getTypedRuleContext(OperatorIDContext, 0) as OperatorIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public IS(): TerminalNode {
		return this.getToken(VtlParser.IS, 0);
	}
	public END(): TerminalNode {
		return this.getToken(VtlParser.END, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public parameterItem_list(): ParameterItemContext[] {
		return this.getTypedRuleContexts(ParameterItemContext) as ParameterItemContext[];
	}
	public parameterItem(i: number): ParameterItemContext {
		return this.getTypedRuleContext(ParameterItemContext, i) as ParameterItemContext;
	}
	public RETURNS(): TerminalNode {
		return this.getToken(VtlParser.RETURNS, 0);
	}
	public outputParameterType(): OutputParameterTypeContext {
		return this.getTypedRuleContext(OutputParameterTypeContext, 0) as OutputParameterTypeContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDefOperator) {
			return visitor.visitDefOperator(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DefHierarchicalContext extends DefOperatorsContext {
	constructor(parser: VtlParser, ctx: DefOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DEFINE(): TerminalNode {
		return this.getToken(VtlParser.DEFINE, 0);
	}
	public HIERARCHICAL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.HIERARCHICAL);
	}
	public HIERARCHICAL(i: number): TerminalNode {
		return this.getToken(VtlParser.HIERARCHICAL, i);
	}
	public RULESET_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RULESET);
	}
	public RULESET(i: number): TerminalNode {
		return this.getToken(VtlParser.RULESET, i);
	}
	public rulesetID(): RulesetIDContext {
		return this.getTypedRuleContext(RulesetIDContext, 0) as RulesetIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public hierRuleSignature(): HierRuleSignatureContext {
		return this.getTypedRuleContext(HierRuleSignatureContext, 0) as HierRuleSignatureContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public IS(): TerminalNode {
		return this.getToken(VtlParser.IS, 0);
	}
	public ruleClauseHierarchical(): RuleClauseHierarchicalContext {
		return this.getTypedRuleContext(RuleClauseHierarchicalContext, 0) as RuleClauseHierarchicalContext;
	}
	public END(): TerminalNode {
		return this.getToken(VtlParser.END, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDefHierarchical) {
			return visitor.visitDefHierarchical(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DefDatapointRulesetContext extends DefOperatorsContext {
	constructor(parser: VtlParser, ctx: DefOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DEFINE(): TerminalNode {
		return this.getToken(VtlParser.DEFINE, 0);
	}
	public DATAPOINT_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.DATAPOINT);
	}
	public DATAPOINT(i: number): TerminalNode {
		return this.getToken(VtlParser.DATAPOINT, i);
	}
	public RULESET_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RULESET);
	}
	public RULESET(i: number): TerminalNode {
		return this.getToken(VtlParser.RULESET, i);
	}
	public rulesetID(): RulesetIDContext {
		return this.getTypedRuleContext(RulesetIDContext, 0) as RulesetIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public rulesetSignature(): RulesetSignatureContext {
		return this.getTypedRuleContext(RulesetSignatureContext, 0) as RulesetSignatureContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public IS(): TerminalNode {
		return this.getToken(VtlParser.IS, 0);
	}
	public ruleClauseDatapoint(): RuleClauseDatapointContext {
		return this.getTypedRuleContext(RuleClauseDatapointContext, 0) as RuleClauseDatapointContext;
	}
	public END(): TerminalNode {
		return this.getToken(VtlParser.END, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDefDatapointRuleset) {
			return visitor.visitDefDatapointRuleset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GenericOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_genericOperators;
	}
	public copyFrom(ctx: GenericOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class EvalAtomContext extends GenericOperatorsContext {
	constructor(parser: VtlParser, ctx: GenericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public EVAL(): TerminalNode {
		return this.getToken(VtlParser.EVAL, 0);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public routineName(): RoutineNameContext {
		return this.getTypedRuleContext(RoutineNameContext, 0) as RoutineNameContext;
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public varID_list(): VarIDContext[] {
		return this.getTypedRuleContexts(VarIDContext) as VarIDContext[];
	}
	public varID(i: number): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, i) as VarIDContext;
	}
	public scalarItem_list(): ScalarItemContext[] {
		return this.getTypedRuleContexts(ScalarItemContext) as ScalarItemContext[];
	}
	public scalarItem(i: number): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, i) as ScalarItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public LANGUAGE(): TerminalNode {
		return this.getToken(VtlParser.LANGUAGE, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	public RETURNS(): TerminalNode {
		return this.getToken(VtlParser.RETURNS, 0);
	}
	public evalDatasetType(): EvalDatasetTypeContext {
		return this.getTypedRuleContext(EvalDatasetTypeContext, 0) as EvalDatasetTypeContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitEvalAtom) {
			return visitor.visitEvalAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CastExprDatasetContext extends GenericOperatorsContext {
	constructor(parser: VtlParser, ctx: GenericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CAST(): TerminalNode {
		return this.getToken(VtlParser.CAST, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public valueDomainName(): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, 0) as ValueDomainNameContext;
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCastExprDataset) {
			return visitor.visitCastExprDataset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CallDatasetContext extends GenericOperatorsContext {
	constructor(parser: VtlParser, ctx: GenericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public operatorID(): OperatorIDContext {
		return this.getTypedRuleContext(OperatorIDContext, 0) as OperatorIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public parameter_list(): ParameterContext[] {
		return this.getTypedRuleContexts(ParameterContext) as ParameterContext[];
	}
	public parameter(i: number): ParameterContext {
		return this.getTypedRuleContext(ParameterContext, i) as ParameterContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCallDataset) {
			return visitor.visitCallDataset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GenericOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_genericOperatorsComponent;
	}
	public copyFrom(ctx: GenericOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class EvalAtomComponentContext extends GenericOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: GenericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public EVAL(): TerminalNode {
		return this.getToken(VtlParser.EVAL, 0);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public routineName(): RoutineNameContext {
		return this.getTypedRuleContext(RoutineNameContext, 0) as RoutineNameContext;
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public scalarItem_list(): ScalarItemContext[] {
		return this.getTypedRuleContexts(ScalarItemContext) as ScalarItemContext[];
	}
	public scalarItem(i: number): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, i) as ScalarItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public LANGUAGE(): TerminalNode {
		return this.getToken(VtlParser.LANGUAGE, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	public RETURNS(): TerminalNode {
		return this.getToken(VtlParser.RETURNS, 0);
	}
	public outputParameterTypeComponent(): OutputParameterTypeComponentContext {
		return this.getTypedRuleContext(OutputParameterTypeComponentContext, 0) as OutputParameterTypeComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitEvalAtomComponent) {
			return visitor.visitEvalAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CastExprComponentContext extends GenericOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: GenericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CAST(): TerminalNode {
		return this.getToken(VtlParser.CAST, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public valueDomainName(): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, 0) as ValueDomainNameContext;
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCastExprComponent) {
			return visitor.visitCastExprComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CallComponentContext extends GenericOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: GenericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public operatorID(): OperatorIDContext {
		return this.getTypedRuleContext(OperatorIDContext, 0) as OperatorIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public parameterComponent_list(): ParameterComponentContext[] {
		return this.getTypedRuleContexts(ParameterComponentContext) as ParameterComponentContext[];
	}
	public parameterComponent(i: number): ParameterComponentContext {
		return this.getTypedRuleContext(ParameterComponentContext, i) as ParameterComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCallComponent) {
			return visitor.visitCallComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParameterComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_parameterComponent;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitParameterComponent) {
			return visitor.visitParameterComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParameterContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_parameter;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitParameter) {
			return visitor.visitParameter(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StringOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_stringOperators;
	}
	public copyFrom(ctx: StringOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class InstrAtomContext extends StringOperatorsContext {
	public _pattern!: ExprContext;
	public _startParameter!: OptionalExprContext;
	public _occurrenceParameter!: OptionalExprContext;
	constructor(parser: VtlParser, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public INSTR(): TerminalNode {
		return this.getToken(VtlParser.INSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public optionalExpr_list(): OptionalExprContext[] {
		return this.getTypedRuleContexts(OptionalExprContext) as OptionalExprContext[];
	}
	public optionalExpr(i: number): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, i) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInstrAtom) {
			return visitor.visitInstrAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryStringFunctionContext extends StringOperatorsContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public TRIM(): TerminalNode {
		return this.getToken(VtlParser.TRIM, 0);
	}
	public LTRIM(): TerminalNode {
		return this.getToken(VtlParser.LTRIM, 0);
	}
	public RTRIM(): TerminalNode {
		return this.getToken(VtlParser.RTRIM, 0);
	}
	public UCASE(): TerminalNode {
		return this.getToken(VtlParser.UCASE, 0);
	}
	public LCASE(): TerminalNode {
		return this.getToken(VtlParser.LCASE, 0);
	}
	public LEN(): TerminalNode {
		return this.getToken(VtlParser.LEN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryStringFunction) {
			return visitor.visitUnaryStringFunction(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SubstrAtomContext extends StringOperatorsContext {
	public _startParameter!: OptionalExprContext;
	public _endParameter!: OptionalExprContext;
	constructor(parser: VtlParser, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public SUBSTR(): TerminalNode {
		return this.getToken(VtlParser.SUBSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public optionalExpr_list(): OptionalExprContext[] {
		return this.getTypedRuleContexts(OptionalExprContext) as OptionalExprContext[];
	}
	public optionalExpr(i: number): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, i) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSubstrAtom) {
			return visitor.visitSubstrAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ReplaceAtomContext extends StringOperatorsContext {
	public _param!: ExprContext;
	constructor(parser: VtlParser, ctx: StringOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public REPLACE(): TerminalNode {
		return this.getToken(VtlParser.REPLACE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public optionalExpr(): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, 0) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitReplaceAtom) {
			return visitor.visitReplaceAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class StringOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_stringOperatorsComponent;
	}
	public copyFrom(ctx: StringOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class ReplaceAtomComponentContext extends StringOperatorsComponentContext {
	public _param!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public REPLACE(): TerminalNode {
		return this.getToken(VtlParser.REPLACE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public optionalExprComponent(): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, 0) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitReplaceAtomComponent) {
			return visitor.visitReplaceAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryStringFunctionComponentContext extends StringOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public TRIM(): TerminalNode {
		return this.getToken(VtlParser.TRIM, 0);
	}
	public LTRIM(): TerminalNode {
		return this.getToken(VtlParser.LTRIM, 0);
	}
	public RTRIM(): TerminalNode {
		return this.getToken(VtlParser.RTRIM, 0);
	}
	public UCASE(): TerminalNode {
		return this.getToken(VtlParser.UCASE, 0);
	}
	public LCASE(): TerminalNode {
		return this.getToken(VtlParser.LCASE, 0);
	}
	public LEN(): TerminalNode {
		return this.getToken(VtlParser.LEN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryStringFunctionComponent) {
			return visitor.visitUnaryStringFunctionComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SubstrAtomComponentContext extends StringOperatorsComponentContext {
	public _startParameter!: OptionalExprComponentContext;
	public _endParameter!: OptionalExprComponentContext;
	constructor(parser: VtlParser, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public SUBSTR(): TerminalNode {
		return this.getToken(VtlParser.SUBSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public optionalExprComponent_list(): OptionalExprComponentContext[] {
		return this.getTypedRuleContexts(OptionalExprComponentContext) as OptionalExprComponentContext[];
	}
	public optionalExprComponent(i: number): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, i) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSubstrAtomComponent) {
			return visitor.visitSubstrAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class InstrAtomComponentContext extends StringOperatorsComponentContext {
	public _pattern!: ExprComponentContext;
	public _startParameter!: OptionalExprComponentContext;
	public _occurrenceParameter!: OptionalExprComponentContext;
	constructor(parser: VtlParser, ctx: StringOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public INSTR(): TerminalNode {
		return this.getToken(VtlParser.INSTR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public optionalExprComponent_list(): OptionalExprComponentContext[] {
		return this.getTypedRuleContexts(OptionalExprComponentContext) as OptionalExprComponentContext[];
	}
	public optionalExprComponent(i: number): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, i) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInstrAtomComponent) {
			return visitor.visitInstrAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class NumericOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_numericOperators;
	}
	public copyFrom(ctx: NumericOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class UnaryNumericContext extends NumericOperatorsContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: NumericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public CEIL(): TerminalNode {
		return this.getToken(VtlParser.CEIL, 0);
	}
	public FLOOR(): TerminalNode {
		return this.getToken(VtlParser.FLOOR, 0);
	}
	public ABS(): TerminalNode {
		return this.getToken(VtlParser.ABS, 0);
	}
	public EXP(): TerminalNode {
		return this.getToken(VtlParser.EXP, 0);
	}
	public LN(): TerminalNode {
		return this.getToken(VtlParser.LN, 0);
	}
	public SQRT(): TerminalNode {
		return this.getToken(VtlParser.SQRT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryNumeric) {
			return visitor.visitUnaryNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryWithOptionalNumericContext extends NumericOperatorsContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: NumericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public ROUND(): TerminalNode {
		return this.getToken(VtlParser.ROUND, 0);
	}
	public TRUNC(): TerminalNode {
		return this.getToken(VtlParser.TRUNC, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public optionalExpr(): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, 0) as OptionalExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryWithOptionalNumeric) {
			return visitor.visitUnaryWithOptionalNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BinaryNumericContext extends NumericOperatorsContext {
	public _op!: Token;
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: NumericOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public MOD(): TerminalNode {
		return this.getToken(VtlParser.MOD, 0);
	}
	public POWER(): TerminalNode {
		return this.getToken(VtlParser.POWER, 0);
	}
	public LOG(): TerminalNode {
		return this.getToken(VtlParser.LOG, 0);
	}
	public RANDOM(): TerminalNode {
		return this.getToken(VtlParser.RANDOM, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBinaryNumeric) {
			return visitor.visitBinaryNumeric(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class NumericOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_numericOperatorsComponent;
	}
	public copyFrom(ctx: NumericOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class UnaryNumericComponentContext extends NumericOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: NumericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public CEIL(): TerminalNode {
		return this.getToken(VtlParser.CEIL, 0);
	}
	public FLOOR(): TerminalNode {
		return this.getToken(VtlParser.FLOOR, 0);
	}
	public ABS(): TerminalNode {
		return this.getToken(VtlParser.ABS, 0);
	}
	public EXP(): TerminalNode {
		return this.getToken(VtlParser.EXP, 0);
	}
	public LN(): TerminalNode {
		return this.getToken(VtlParser.LN, 0);
	}
	public SQRT(): TerminalNode {
		return this.getToken(VtlParser.SQRT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryNumericComponent) {
			return visitor.visitUnaryNumericComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BinaryNumericComponentContext extends NumericOperatorsComponentContext {
	public _op!: Token;
	public _left!: ExprComponentContext;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: NumericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public MOD(): TerminalNode {
		return this.getToken(VtlParser.MOD, 0);
	}
	public POWER(): TerminalNode {
		return this.getToken(VtlParser.POWER, 0);
	}
	public LOG(): TerminalNode {
		return this.getToken(VtlParser.LOG, 0);
	}
	public RANDOM(): TerminalNode {
		return this.getToken(VtlParser.RANDOM, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBinaryNumericComponent) {
			return visitor.visitBinaryNumericComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnaryWithOptionalNumericComponentContext extends NumericOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: NumericOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public ROUND(): TerminalNode {
		return this.getToken(VtlParser.ROUND, 0);
	}
	public TRUNC(): TerminalNode {
		return this.getToken(VtlParser.TRUNC, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public optionalExprComponent(): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, 0) as OptionalExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnaryWithOptionalNumericComponent) {
			return visitor.visitUnaryWithOptionalNumericComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComparisonOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_comparisonOperators;
	}
	public copyFrom(ctx: ComparisonOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class BetweenAtomContext extends ComparisonOperatorsContext {
	public _op!: ExprContext;
	public _from_!: ExprContext;
	public _to_!: ExprContext;
	constructor(parser: VtlParser, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public BETWEEN(): TerminalNode {
		return this.getToken(VtlParser.BETWEEN, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBetweenAtom) {
			return visitor.visitBetweenAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CharsetMatchAtomContext extends ComparisonOperatorsContext {
	public _op!: ExprContext;
	public _pattern!: ExprContext;
	constructor(parser: VtlParser, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHARSET_MATCH(): TerminalNode {
		return this.getToken(VtlParser.CHARSET_MATCH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCharsetMatchAtom) {
			return visitor.visitCharsetMatchAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IsNullAtomContext extends ComparisonOperatorsContext {
	constructor(parser: VtlParser, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public ISNULL(): TerminalNode {
		return this.getToken(VtlParser.ISNULL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitIsNullAtom) {
			return visitor.visitIsNullAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ExistInAtomContext extends ComparisonOperatorsContext {
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ComparisonOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public EXISTS_IN(): TerminalNode {
		return this.getToken(VtlParser.EXISTS_IN, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public retainType(): RetainTypeContext {
		return this.getTypedRuleContext(RetainTypeContext, 0) as RetainTypeContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitExistInAtom) {
			return visitor.visitExistInAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComparisonOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_comparisonOperatorsComponent;
	}
	public copyFrom(ctx: ComparisonOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class IsNullAtomComponentContext extends ComparisonOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: ComparisonOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public ISNULL(): TerminalNode {
		return this.getToken(VtlParser.ISNULL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitIsNullAtomComponent) {
			return visitor.visitIsNullAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CharsetMatchAtomComponentContext extends ComparisonOperatorsComponentContext {
	public _op!: ExprComponentContext;
	public _pattern!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ComparisonOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHARSET_MATCH(): TerminalNode {
		return this.getToken(VtlParser.CHARSET_MATCH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCharsetMatchAtomComponent) {
			return visitor.visitCharsetMatchAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class BetweenAtomComponentContext extends ComparisonOperatorsComponentContext {
	public _op!: ExprComponentContext;
	public _from_!: ExprComponentContext;
	public _to_!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ComparisonOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public BETWEEN(): TerminalNode {
		return this.getToken(VtlParser.BETWEEN, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBetweenAtomComponent) {
			return visitor.visitBetweenAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_timeOperators;
	}
	public copyFrom(ctx: TimeOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class DayToYearAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYTOYEAR(): TerminalNode {
		return this.getToken(VtlParser.DAYTOYEAR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayToYearAtom) {
			return visitor.visitDayToYearAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class YearAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public YEAR_OP(): TerminalNode {
		return this.getToken(VtlParser.YEAR_OP, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitYearAtom) {
			return visitor.visitYearAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class YearTodayAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public YEARTODAY(): TerminalNode {
		return this.getToken(VtlParser.YEARTODAY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitYearTodayAtom) {
			return visitor.visitYearTodayAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DayToMonthAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYTOMONTH(): TerminalNode {
		return this.getToken(VtlParser.DAYTOMONTH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayToMonthAtom) {
			return visitor.visitDayToMonthAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class PeriodAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public PERIOD_INDICATOR(): TerminalNode {
		return this.getToken(VtlParser.PERIOD_INDICATOR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitPeriodAtom) {
			return visitor.visitPeriodAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class MonthTodayAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public MONTHTODAY(): TerminalNode {
		return this.getToken(VtlParser.MONTHTODAY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitMonthTodayAtom) {
			return visitor.visitMonthTodayAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FillTimeAtomContext extends TimeOperatorsContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public FILL_TIME_SERIES(): TerminalNode {
		return this.getToken(VtlParser.FILL_TIME_SERIES, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public SINGLE(): TerminalNode {
		return this.getToken(VtlParser.SINGLE, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFillTimeAtom) {
			return visitor.visitFillTimeAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class MonthAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public MONTH_OP(): TerminalNode {
		return this.getToken(VtlParser.MONTH_OP, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitMonthAtom) {
			return visitor.visitMonthAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DayOfYearAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYOFYEAR(): TerminalNode {
		return this.getToken(VtlParser.DAYOFYEAR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayOfYearAtom) {
			return visitor.visitDayOfYearAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FlowAtomContext extends TimeOperatorsContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public FLOW_TO_STOCK(): TerminalNode {
		return this.getToken(VtlParser.FLOW_TO_STOCK, 0);
	}
	public STOCK_TO_FLOW(): TerminalNode {
		return this.getToken(VtlParser.STOCK_TO_FLOW, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFlowAtom) {
			return visitor.visitFlowAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeShiftAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIMESHIFT(): TerminalNode {
		return this.getToken(VtlParser.TIMESHIFT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTimeShiftAtom) {
			return visitor.visitTimeShiftAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeAggAtomContext extends TimeOperatorsContext {
	public _periodIndTo!: Token;
	public _periodIndFrom!: Token;
	public _op!: OptionalExprContext;
	public _delim!: Token;
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(VtlParser.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public STRING_CONSTANT_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.STRING_CONSTANT);
	}
	public STRING_CONSTANT(i: number): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, i);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public optionalExpr(): OptionalExprContext {
		return this.getTypedRuleContext(OptionalExprContext, 0) as OptionalExprContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
	public FIRST(): TerminalNode {
		return this.getToken(VtlParser.FIRST, 0);
	}
	public LAST(): TerminalNode {
		return this.getToken(VtlParser.LAST, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTimeAggAtom) {
			return visitor.visitTimeAggAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DateDiffAtomContext extends TimeOperatorsContext {
	public _dateFrom!: ExprContext;
	public _dateTo!: ExprContext;
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATEDIFF(): TerminalNode {
		return this.getToken(VtlParser.DATEDIFF, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDateDiffAtom) {
			return visitor.visitDateDiffAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DateAddAtomContext extends TimeOperatorsContext {
	public _op!: ExprContext;
	public _shiftNumber!: ExprContext;
	public _periodInd!: ExprContext;
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATEADD(): TerminalNode {
		return this.getToken(VtlParser.DATEADD, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDateAddAtom) {
			return visitor.visitDateAddAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DayOfMonthAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYOFMONTH(): TerminalNode {
		return this.getToken(VtlParser.DAYOFMONTH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayOfMonthAtom) {
			return visitor.visitDayOfMonthAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CurrentDateAtomContext extends TimeOperatorsContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CURRENT_DATE(): TerminalNode {
		return this.getToken(VtlParser.CURRENT_DATE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCurrentDateAtom) {
			return visitor.visitCurrentDateAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class TimeOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_timeOperatorsComponent;
	}
	public copyFrom(ctx: TimeOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class PeriodAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public PERIOD_INDICATOR(): TerminalNode {
		return this.getToken(VtlParser.PERIOD_INDICATOR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitPeriodAtomComponent) {
			return visitor.visitPeriodAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeShiftAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIMESHIFT(): TerminalNode {
		return this.getToken(VtlParser.TIMESHIFT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTimeShiftAtomComponent) {
			return visitor.visitTimeShiftAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class MonthTodayAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public MONTHTODAY(): TerminalNode {
		return this.getToken(VtlParser.MONTHTODAY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitMonthTodayAtomComponent) {
			return visitor.visitMonthTodayAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class TimeAggAtomComponentContext extends TimeOperatorsComponentContext {
	public _periodIndTo!: Token;
	public _periodIndFrom!: Token;
	public _op!: OptionalExprComponentContext;
	public _delim!: Token;
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(VtlParser.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public STRING_CONSTANT_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.STRING_CONSTANT);
	}
	public STRING_CONSTANT(i: number): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, i);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public optionalExprComponent(): OptionalExprComponentContext {
		return this.getTypedRuleContext(OptionalExprComponentContext, 0) as OptionalExprComponentContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
	public FIRST(): TerminalNode {
		return this.getToken(VtlParser.FIRST, 0);
	}
	public LAST(): TerminalNode {
		return this.getToken(VtlParser.LAST, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitTimeAggAtomComponent) {
			return visitor.visitTimeAggAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DayToMonthAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYTOMONTH(): TerminalNode {
		return this.getToken(VtlParser.DAYTOMONTH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayToMonthAtomComponent) {
			return visitor.visitDayToMonthAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DateAddAtomComponentContext extends TimeOperatorsComponentContext {
	public _op!: ExprComponentContext;
	public _shiftNumber!: ExprComponentContext;
	public _periodInd!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATEADD(): TerminalNode {
		return this.getToken(VtlParser.DATEADD, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDateAddAtomComponent) {
			return visitor.visitDateAddAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class YearTodayAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public YEARTODAY(): TerminalNode {
		return this.getToken(VtlParser.YEARTODAY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitYearTodayAtomComponent) {
			return visitor.visitYearTodayAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DayOfMonthAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYOFMONTH(): TerminalNode {
		return this.getToken(VtlParser.DAYOFMONTH, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayOfMonthAtomComponent) {
			return visitor.visitDayOfMonthAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class MonthAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public MONTH_OP(): TerminalNode {
		return this.getToken(VtlParser.MONTH_OP, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitMonthAtomComponent) {
			return visitor.visitMonthAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FillTimeAtomComponentContext extends TimeOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public FILL_TIME_SERIES(): TerminalNode {
		return this.getToken(VtlParser.FILL_TIME_SERIES, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public SINGLE(): TerminalNode {
		return this.getToken(VtlParser.SINGLE, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFillTimeAtomComponent) {
			return visitor.visitFillTimeAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DatOfYearAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYOFYEAR(): TerminalNode {
		return this.getToken(VtlParser.DAYOFYEAR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDatOfYearAtomComponent) {
			return visitor.visitDatOfYearAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DayToYearAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DAYTOYEAR(): TerminalNode {
		return this.getToken(VtlParser.DAYTOYEAR, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDayToYearAtomComponent) {
			return visitor.visitDayToYearAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CurrentDateAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CURRENT_DATE(): TerminalNode {
		return this.getToken(VtlParser.CURRENT_DATE, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCurrentDateAtomComponent) {
			return visitor.visitCurrentDateAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class FlowAtomComponentContext extends TimeOperatorsComponentContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public FLOW_TO_STOCK(): TerminalNode {
		return this.getToken(VtlParser.FLOW_TO_STOCK, 0);
	}
	public STOCK_TO_FLOW(): TerminalNode {
		return this.getToken(VtlParser.STOCK_TO_FLOW, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitFlowAtomComponent) {
			return visitor.visitFlowAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DateDiffAtomComponentContext extends TimeOperatorsComponentContext {
	public _dateFrom!: ExprComponentContext;
	public _dateTo!: ExprContext;
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATEDIFF(): TerminalNode {
		return this.getToken(VtlParser.DATEDIFF, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDateDiffAtomComponent) {
			return visitor.visitDateDiffAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class YearAtomComponentContext extends TimeOperatorsComponentContext {
	constructor(parser: VtlParser, ctx: TimeOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public YEAR_OP(): TerminalNode {
		return this.getToken(VtlParser.YEAR_OP, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitYearAtomComponent) {
			return visitor.visitYearAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SetOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_setOperators;
	}
	public copyFrom(ctx: SetOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class SetOrSYmDiffAtomContext extends SetOperatorsContext {
	public _op!: Token;
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: SetOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public SETDIFF(): TerminalNode {
		return this.getToken(VtlParser.SETDIFF, 0);
	}
	public SYMDIFF(): TerminalNode {
		return this.getToken(VtlParser.SYMDIFF, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSetOrSYmDiffAtom) {
			return visitor.visitSetOrSYmDiffAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class IntersectAtomContext extends SetOperatorsContext {
	public _left!: ExprContext;
	constructor(parser: VtlParser, ctx: SetOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public INTERSECT(): TerminalNode {
		return this.getToken(VtlParser.INTERSECT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitIntersectAtom) {
			return visitor.visitIntersectAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class UnionAtomContext extends SetOperatorsContext {
	public _left!: ExprContext;
	constructor(parser: VtlParser, ctx: SetOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public UNION(): TerminalNode {
		return this.getToken(VtlParser.UNION, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitUnionAtom) {
			return visitor.visitUnionAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HierarchyOperatorsContext extends ParserRuleContext {
	public _op!: ExprContext;
	public _hrName!: Token;
	public _ruleComponent!: ComponentIDContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public HIERARCHY(): TerminalNode {
		return this.getToken(VtlParser.HIERARCHY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
	public conditionClause(): ConditionClauseContext {
		return this.getTypedRuleContext(ConditionClauseContext, 0) as ConditionClauseContext;
	}
	public RULE(): TerminalNode {
		return this.getToken(VtlParser.RULE, 0);
	}
	public validationMode(): ValidationModeContext {
		return this.getTypedRuleContext(ValidationModeContext, 0) as ValidationModeContext;
	}
	public inputModeHierarchy(): InputModeHierarchyContext {
		return this.getTypedRuleContext(InputModeHierarchyContext, 0) as InputModeHierarchyContext;
	}
	public outputModeHierarchy(): OutputModeHierarchyContext {
		return this.getTypedRuleContext(OutputModeHierarchyContext, 0) as OutputModeHierarchyContext;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_hierarchyOperators;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHierarchyOperators) {
			return visitor.visitHierarchyOperators(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValidationOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_validationOperators;
	}
	public copyFrom(ctx: ValidationOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class ValidateHRrulesetContext extends ValidationOperatorsContext {
	public _op!: ExprContext;
	public _hrName!: Token;
	constructor(parser: VtlParser, ctx: ValidationOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHECK_HIERARCHY(): TerminalNode {
		return this.getToken(VtlParser.CHECK_HIERARCHY, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
	public conditionClause(): ConditionClauseContext {
		return this.getTypedRuleContext(ConditionClauseContext, 0) as ConditionClauseContext;
	}
	public RULE(): TerminalNode {
		return this.getToken(VtlParser.RULE, 0);
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public validationMode(): ValidationModeContext {
		return this.getTypedRuleContext(ValidationModeContext, 0) as ValidationModeContext;
	}
	public inputMode(): InputModeContext {
		return this.getTypedRuleContext(InputModeContext, 0) as InputModeContext;
	}
	public validationOutput(): ValidationOutputContext {
		return this.getTypedRuleContext(ValidationOutputContext, 0) as ValidationOutputContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValidateHRruleset) {
			return visitor.visitValidateHRruleset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValidateDPrulesetContext extends ValidationOperatorsContext {
	public _op!: ExprContext;
	public _dpName!: Token;
	constructor(parser: VtlParser, ctx: ValidationOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHECK_DATAPOINT(): TerminalNode {
		return this.getToken(VtlParser.CHECK_DATAPOINT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
	public COMPONENTS(): TerminalNode {
		return this.getToken(VtlParser.COMPONENTS, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public validationOutput(): ValidationOutputContext {
		return this.getTypedRuleContext(ValidationOutputContext, 0) as ValidationOutputContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValidateDPruleset) {
			return visitor.visitValidateDPruleset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ValidationSimpleContext extends ValidationOperatorsContext {
	public _op!: ExprContext;
	public _codeErr!: ErCodeContext;
	public _levelCode!: ErLevelContext;
	public _output!: Token;
	constructor(parser: VtlParser, ctx: ValidationOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CHECK(): TerminalNode {
		return this.getToken(VtlParser.CHECK, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public imbalanceExpr(): ImbalanceExprContext {
		return this.getTypedRuleContext(ImbalanceExprContext, 0) as ImbalanceExprContext;
	}
	public erCode(): ErCodeContext {
		return this.getTypedRuleContext(ErCodeContext, 0) as ErCodeContext;
	}
	public erLevel(): ErLevelContext {
		return this.getTypedRuleContext(ErLevelContext, 0) as ErLevelContext;
	}
	public INVALID(): TerminalNode {
		return this.getToken(VtlParser.INVALID, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValidationSimple) {
			return visitor.visitValidationSimple(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConditionalOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_conditionalOperators;
	}
	public copyFrom(ctx: ConditionalOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class NvlAtomContext extends ConditionalOperatorsContext {
	public _left!: ExprContext;
	public _right!: ExprContext;
	constructor(parser: VtlParser, ctx: ConditionalOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public NVL(): TerminalNode {
		return this.getToken(VtlParser.NVL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public expr_list(): ExprContext[] {
		return this.getTypedRuleContexts(ExprContext) as ExprContext[];
	}
	public expr(i: number): ExprContext {
		return this.getTypedRuleContext(ExprContext, i) as ExprContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitNvlAtom) {
			return visitor.visitNvlAtom(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConditionalOperatorsComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_conditionalOperatorsComponent;
	}
	public copyFrom(ctx: ConditionalOperatorsComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class NvlAtomComponentContext extends ConditionalOperatorsComponentContext {
	public _left!: ExprComponentContext;
	public _right!: ExprComponentContext;
	constructor(parser: VtlParser, ctx: ConditionalOperatorsComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public NVL(): TerminalNode {
		return this.getToken(VtlParser.NVL, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitNvlAtomComponent) {
			return visitor.visitNvlAtomComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrOperatorsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_aggrOperators;
	}
	public copyFrom(ctx: AggrOperatorsContext): void {
		super.copyFrom(ctx);
	}
}
export class AggrCompContext extends AggrOperatorsContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: AggrOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public SUM(): TerminalNode {
		return this.getToken(VtlParser.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(VtlParser.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(VtlParser.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(VtlParser.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(VtlParser.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(VtlParser.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(VtlParser.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(VtlParser.VAR_SAMP, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggrComp) {
			return visitor.visitAggrComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class CountAggrCompContext extends AggrOperatorsContext {
	constructor(parser: VtlParser, ctx: AggrOperatorsContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public COUNT(): TerminalNode {
		return this.getToken(VtlParser.COUNT, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCountAggrComp) {
			return visitor.visitCountAggrComp(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrOperatorsGroupingContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_aggrOperatorsGrouping;
	}
	public copyFrom(ctx: AggrOperatorsGroupingContext): void {
		super.copyFrom(ctx);
	}
}
export class AggrDatasetContext extends AggrOperatorsGroupingContext {
	public _op!: Token;
	constructor(parser: VtlParser, ctx: AggrOperatorsGroupingContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public SUM(): TerminalNode {
		return this.getToken(VtlParser.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(VtlParser.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(VtlParser.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(VtlParser.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(VtlParser.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(VtlParser.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(VtlParser.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(VtlParser.VAR_SAMP, 0);
	}
	public groupingClause(): GroupingClauseContext {
		return this.getTypedRuleContext(GroupingClauseContext, 0) as GroupingClauseContext;
	}
	public havingClause(): HavingClauseContext {
		return this.getTypedRuleContext(HavingClauseContext, 0) as HavingClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggrDataset) {
			return visitor.visitAggrDataset(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AnFunctionContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_anFunction;
	}
	public copyFrom(ctx: AnFunctionContext): void {
		super.copyFrom(ctx);
	}
}
export class LagOrLeadAnContext extends AnFunctionContext {
	public _op!: Token;
	public _offset!: SignedIntegerContext;
	public _defaultValue!: ScalarItemContext;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public LAG(): TerminalNode {
		return this.getToken(VtlParser.LAG, 0);
	}
	public LEAD(): TerminalNode {
		return this.getToken(VtlParser.LEAD, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public scalarItem(): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, 0) as ScalarItemContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitLagOrLeadAn) {
			return visitor.visitLagOrLeadAn(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class RatioToReportAnContext extends AnFunctionContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public RATIO_TO_REPORT(): TerminalNode {
		return this.getToken(VtlParser.RATIO_TO_REPORT, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRatioToReportAn) {
			return visitor.visitRatioToReportAn(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class AnSimpleFunctionContext extends AnFunctionContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	public _windowing!: WindowingClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public SUM(): TerminalNode {
		return this.getToken(VtlParser.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(VtlParser.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(VtlParser.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(VtlParser.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(VtlParser.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(VtlParser.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(VtlParser.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(VtlParser.VAR_SAMP, 0);
	}
	public FIRST_VALUE(): TerminalNode {
		return this.getToken(VtlParser.FIRST_VALUE, 0);
	}
	public LAST_VALUE(): TerminalNode {
		return this.getToken(VtlParser.LAST_VALUE, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public windowingClause(): WindowingClauseContext {
		return this.getTypedRuleContext(WindowingClauseContext, 0) as WindowingClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAnSimpleFunction) {
			return visitor.visitAnSimpleFunction(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AnFunctionComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_anFunctionComponent;
	}
	public copyFrom(ctx: AnFunctionComponentContext): void {
		super.copyFrom(ctx);
	}
}
export class AnSimpleFunctionComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	public _windowing!: WindowingClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public SUM(): TerminalNode {
		return this.getToken(VtlParser.SUM, 0);
	}
	public AVG(): TerminalNode {
		return this.getToken(VtlParser.AVG, 0);
	}
	public COUNT(): TerminalNode {
		return this.getToken(VtlParser.COUNT, 0);
	}
	public MEDIAN(): TerminalNode {
		return this.getToken(VtlParser.MEDIAN, 0);
	}
	public MIN(): TerminalNode {
		return this.getToken(VtlParser.MIN, 0);
	}
	public MAX(): TerminalNode {
		return this.getToken(VtlParser.MAX, 0);
	}
	public STDDEV_POP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_POP, 0);
	}
	public STDDEV_SAMP(): TerminalNode {
		return this.getToken(VtlParser.STDDEV_SAMP, 0);
	}
	public VAR_POP(): TerminalNode {
		return this.getToken(VtlParser.VAR_POP, 0);
	}
	public VAR_SAMP(): TerminalNode {
		return this.getToken(VtlParser.VAR_SAMP, 0);
	}
	public FIRST_VALUE(): TerminalNode {
		return this.getToken(VtlParser.FIRST_VALUE, 0);
	}
	public LAST_VALUE(): TerminalNode {
		return this.getToken(VtlParser.LAST_VALUE, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public windowingClause(): WindowingClauseContext {
		return this.getTypedRuleContext(WindowingClauseContext, 0) as WindowingClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAnSimpleFunctionComponent) {
			return visitor.visitAnSimpleFunctionComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class LagOrLeadAnComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _offset!: SignedIntegerContext;
	public _defaultValue!: ScalarItemContext;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public LAG(): TerminalNode {
		return this.getToken(VtlParser.LAG, 0);
	}
	public LEAD(): TerminalNode {
		return this.getToken(VtlParser.LEAD, 0);
	}
	public COMMA(): TerminalNode {
		return this.getToken(VtlParser.COMMA, 0);
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	public scalarItem(): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, 0) as ScalarItemContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitLagOrLeadAnComponent) {
			return visitor.visitLagOrLeadAnComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class RankAnComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	public _orderBy!: OrderByClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public RANK(): TerminalNode {
		return this.getToken(VtlParser.RANK, 0);
	}
	public orderByClause(): OrderByClauseContext {
		return this.getTypedRuleContext(OrderByClauseContext, 0) as OrderByClauseContext;
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRankAnComponent) {
			return visitor.visitRankAnComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class RatioToReportAnComponentContext extends AnFunctionComponentContext {
	public _op!: Token;
	public _partition!: PartitionByClauseContext;
	constructor(parser: VtlParser, ctx: AnFunctionComponentContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public LPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.LPAREN);
	}
	public LPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.LPAREN, i);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OVER(): TerminalNode {
		return this.getToken(VtlParser.OVER, 0);
	}
	public RPAREN_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.RPAREN);
	}
	public RPAREN(i: number): TerminalNode {
		return this.getToken(VtlParser.RPAREN, i);
	}
	public RATIO_TO_REPORT(): TerminalNode {
		return this.getToken(VtlParser.RATIO_TO_REPORT, 0);
	}
	public partitionByClause(): PartitionByClauseContext {
		return this.getTypedRuleContext(PartitionByClauseContext, 0) as PartitionByClauseContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRatioToReportAnComponent) {
			return visitor.visitRatioToReportAnComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RenameClauseItemContext extends ParserRuleContext {
	public _fromName!: ComponentIDContext;
	public _toName!: ComponentIDContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public TO(): TerminalNode {
		return this.getToken(VtlParser.TO, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_renameClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRenameClauseItem) {
			return visitor.visitRenameClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggregateClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public aggrFunctionClause_list(): AggrFunctionClauseContext[] {
		return this.getTypedRuleContexts(AggrFunctionClauseContext) as AggrFunctionClauseContext[];
	}
	public aggrFunctionClause(i: number): AggrFunctionClauseContext {
		return this.getTypedRuleContext(AggrFunctionClauseContext, i) as AggrFunctionClauseContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_aggregateClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggregateClause) {
			return visitor.visitAggregateClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AggrFunctionClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public ASSIGN(): TerminalNode {
		return this.getToken(VtlParser.ASSIGN, 0);
	}
	public aggrOperators(): AggrOperatorsContext {
		return this.getTypedRuleContext(AggrOperatorsContext, 0) as AggrOperatorsContext;
	}
	public componentRole(): ComponentRoleContext {
		return this.getTypedRuleContext(ComponentRoleContext, 0) as ComponentRoleContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_aggrFunctionClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAggrFunctionClause) {
			return visitor.visitAggrFunctionClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CalcClauseItemContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public ASSIGN(): TerminalNode {
		return this.getToken(VtlParser.ASSIGN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public componentRole(): ComponentRoleContext {
		return this.getTypedRuleContext(ComponentRoleContext, 0) as ComponentRoleContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_calcClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCalcClauseItem) {
			return visitor.visitCalcClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SubspaceClauseItemContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public EQ(): TerminalNode {
		return this.getToken(VtlParser.EQ, 0);
	}
	public scalarItem(): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, 0) as ScalarItemContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_subspaceClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSubspaceClauseItem) {
			return visitor.visitSubspaceClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarItemContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_scalarItem;
	}
	public copyFrom(ctx: ScalarItemContext): void {
		super.copyFrom(ctx);
	}
}
export class ScalarWithCastContext extends ScalarItemContext {
	constructor(parser: VtlParser, ctx: ScalarItemContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public CAST(): TerminalNode {
		return this.getToken(VtlParser.CAST, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitScalarWithCast) {
			return visitor.visitScalarWithCast(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class SimpleScalarContext extends ScalarItemContext {
	constructor(parser: VtlParser, ctx: ScalarItemContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSimpleScalar) {
			return visitor.visitSimpleScalar(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinClauseWithoutUsingContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public joinClauseItem_list(): JoinClauseItemContext[] {
		return this.getTypedRuleContexts(JoinClauseItemContext) as JoinClauseItemContext[];
	}
	public joinClauseItem(i: number): JoinClauseItemContext {
		return this.getTypedRuleContext(JoinClauseItemContext, i) as JoinClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_joinClauseWithoutUsing;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinClauseWithoutUsing) {
			return visitor.visitJoinClauseWithoutUsing(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public joinClauseItem_list(): JoinClauseItemContext[] {
		return this.getTypedRuleContexts(JoinClauseItemContext) as JoinClauseItemContext[];
	}
	public joinClauseItem(i: number): JoinClauseItemContext {
		return this.getTypedRuleContext(JoinClauseItemContext, i) as JoinClauseItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public USING(): TerminalNode {
		return this.getToken(VtlParser.USING, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_joinClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinClause) {
			return visitor.visitJoinClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinClauseItemContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public AS(): TerminalNode {
		return this.getToken(VtlParser.AS, 0);
	}
	public alias(): AliasContext {
		return this.getTypedRuleContext(AliasContext, 0) as AliasContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_joinClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinClauseItem) {
			return visitor.visitJoinClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinBodyContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public filterClause(): FilterClauseContext {
		return this.getTypedRuleContext(FilterClauseContext, 0) as FilterClauseContext;
	}
	public calcClause(): CalcClauseContext {
		return this.getTypedRuleContext(CalcClauseContext, 0) as CalcClauseContext;
	}
	public joinApplyClause(): JoinApplyClauseContext {
		return this.getTypedRuleContext(JoinApplyClauseContext, 0) as JoinApplyClauseContext;
	}
	public aggrClause(): AggrClauseContext {
		return this.getTypedRuleContext(AggrClauseContext, 0) as AggrClauseContext;
	}
	public keepOrDropClause(): KeepOrDropClauseContext {
		return this.getTypedRuleContext(KeepOrDropClauseContext, 0) as KeepOrDropClauseContext;
	}
	public renameClause(): RenameClauseContext {
		return this.getTypedRuleContext(RenameClauseContext, 0) as RenameClauseContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_joinBody;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinBody) {
			return visitor.visitJoinBody(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class JoinApplyClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public APPLY(): TerminalNode {
		return this.getToken(VtlParser.APPLY, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_joinApplyClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitJoinApplyClause) {
			return visitor.visitJoinApplyClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class PartitionByClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public PARTITION(): TerminalNode {
		return this.getToken(VtlParser.PARTITION, 0);
	}
	public BY(): TerminalNode {
		return this.getToken(VtlParser.BY, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_partitionByClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitPartitionByClause) {
			return visitor.visitPartitionByClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OrderByClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ORDER(): TerminalNode {
		return this.getToken(VtlParser.ORDER, 0);
	}
	public BY(): TerminalNode {
		return this.getToken(VtlParser.BY, 0);
	}
	public orderByItem_list(): OrderByItemContext[] {
		return this.getTypedRuleContexts(OrderByItemContext) as OrderByItemContext[];
	}
	public orderByItem(i: number): OrderByItemContext {
		return this.getTypedRuleContext(OrderByItemContext, i) as OrderByItemContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_orderByClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOrderByClause) {
			return visitor.visitOrderByClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OrderByItemContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public ASC(): TerminalNode {
		return this.getToken(VtlParser.ASC, 0);
	}
	public DESC(): TerminalNode {
		return this.getToken(VtlParser.DESC, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_orderByItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOrderByItem) {
			return visitor.visitOrderByItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class WindowingClauseContext extends ParserRuleContext {
	public _from_!: LimitClauseItemContext;
	public _to_!: LimitClauseItemContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public BETWEEN(): TerminalNode {
		return this.getToken(VtlParser.BETWEEN, 0);
	}
	public AND(): TerminalNode {
		return this.getToken(VtlParser.AND, 0);
	}
	public limitClauseItem_list(): LimitClauseItemContext[] {
		return this.getTypedRuleContexts(LimitClauseItemContext) as LimitClauseItemContext[];
	}
	public limitClauseItem(i: number): LimitClauseItemContext {
		return this.getTypedRuleContext(LimitClauseItemContext, i) as LimitClauseItemContext;
	}
	public RANGE(): TerminalNode {
		return this.getToken(VtlParser.RANGE, 0);
	}
	public DATA(): TerminalNode {
		return this.getToken(VtlParser.DATA, 0);
	}
	public POINTS(): TerminalNode {
		return this.getToken(VtlParser.POINTS, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_windowingClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitWindowingClause) {
			return visitor.visitWindowingClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SignedIntegerContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public INTEGER_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.INTEGER_CONSTANT, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_signedInteger;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSignedInteger) {
			return visitor.visitSignedInteger(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SignedNumberContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public NUMBER_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.NUMBER_CONSTANT, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_signedNumber;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSignedNumber) {
			return visitor.visitSignedNumber(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class LimitClauseItemContext extends ParserRuleContext {
	public _dir!: Token;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public PRECEDING(): TerminalNode {
		return this.getToken(VtlParser.PRECEDING, 0);
	}
	public FOLLOWING(): TerminalNode {
		return this.getToken(VtlParser.FOLLOWING, 0);
	}
	public CURRENT(): TerminalNode {
		return this.getToken(VtlParser.CURRENT, 0);
	}
	public DATA(): TerminalNode {
		return this.getToken(VtlParser.DATA, 0);
	}
	public POINT(): TerminalNode {
		return this.getToken(VtlParser.POINT, 0);
	}
	public UNBOUNDED(): TerminalNode {
		return this.getToken(VtlParser.UNBOUNDED, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_limitClauseItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitLimitClauseItem) {
			return visitor.visitLimitClauseItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class GroupingClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_groupingClause;
	}
	public copyFrom(ctx: GroupingClauseContext): void {
		super.copyFrom(ctx);
	}
}
export class GroupAllContext extends GroupingClauseContext {
	constructor(parser: VtlParser, ctx: GroupingClauseContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GROUP(): TerminalNode {
		return this.getToken(VtlParser.GROUP, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(VtlParser.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitGroupAll) {
			return visitor.visitGroupAll(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class GroupByOrExceptContext extends GroupingClauseContext {
	public _op!: Token;
	public _delim!: Token;
	constructor(parser: VtlParser, ctx: GroupingClauseContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GROUP(): TerminalNode {
		return this.getToken(VtlParser.GROUP, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public BY(): TerminalNode {
		return this.getToken(VtlParser.BY, 0);
	}
	public EXCEPT(): TerminalNode {
		return this.getToken(VtlParser.EXCEPT, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	public TIME_AGG(): TerminalNode {
		return this.getToken(VtlParser.TIME_AGG, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public FIRST(): TerminalNode {
		return this.getToken(VtlParser.FIRST, 0);
	}
	public LAST(): TerminalNode {
		return this.getToken(VtlParser.LAST, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitGroupByOrExcept) {
			return visitor.visitGroupByOrExcept(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HavingClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public HAVING(): TerminalNode {
		return this.getToken(VtlParser.HAVING, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_havingClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHavingClause) {
			return visitor.visitHavingClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ParameterItemContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public inputParameterType(): InputParameterTypeContext {
		return this.getTypedRuleContext(InputParameterTypeContext, 0) as InputParameterTypeContext;
	}
	public DEFAULT(): TerminalNode {
		return this.getToken(VtlParser.DEFAULT, 0);
	}
	public scalarItem(): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, 0) as ScalarItemContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_parameterItem;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitParameterItem) {
			return visitor.visitParameterItem(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OutputParameterTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public datasetType(): DatasetTypeContext {
		return this.getTypedRuleContext(DatasetTypeContext, 0) as DatasetTypeContext;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_outputParameterType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOutputParameterType) {
			return visitor.visitOutputParameterType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OutputParameterTypeComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_outputParameterTypeComponent;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOutputParameterTypeComponent) {
			return visitor.visitOutputParameterTypeComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InputParameterTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public datasetType(): DatasetTypeContext {
		return this.getTypedRuleContext(DatasetTypeContext, 0) as DatasetTypeContext;
	}
	public scalarSetType(): ScalarSetTypeContext {
		return this.getTypedRuleContext(ScalarSetTypeContext, 0) as ScalarSetTypeContext;
	}
	public rulesetType(): RulesetTypeContext {
		return this.getTypedRuleContext(RulesetTypeContext, 0) as RulesetTypeContext;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_inputParameterType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInputParameterType) {
			return visitor.visitInputParameterType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RulesetTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RULESET(): TerminalNode {
		return this.getToken(VtlParser.RULESET, 0);
	}
	public dpRuleset(): DpRulesetContext {
		return this.getTypedRuleContext(DpRulesetContext, 0) as DpRulesetContext;
	}
	public hrRuleset(): HrRulesetContext {
		return this.getTypedRuleContext(HrRulesetContext, 0) as HrRulesetContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_rulesetType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRulesetType) {
			return visitor.visitRulesetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public basicScalarType(): BasicScalarTypeContext {
		return this.getTypedRuleContext(BasicScalarTypeContext, 0) as BasicScalarTypeContext;
	}
	public valueDomainName(): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, 0) as ValueDomainNameContext;
	}
	public scalarTypeConstraint(): ScalarTypeConstraintContext {
		return this.getTypedRuleContext(ScalarTypeConstraintContext, 0) as ScalarTypeConstraintContext;
	}
	public NULL_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.NULL_CONSTANT, 0);
	}
	public NOT(): TerminalNode {
		return this.getToken(VtlParser.NOT, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_scalarType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitScalarType) {
			return visitor.visitScalarType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComponentTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentRole(): ComponentRoleContext {
		return this.getTypedRuleContext(ComponentRoleContext, 0) as ComponentRoleContext;
	}
	public LT(): TerminalNode {
		return this.getToken(VtlParser.LT, 0);
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public MT(): TerminalNode {
		return this.getToken(VtlParser.MT, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_componentType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComponentType) {
			return visitor.visitComponentType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DatasetTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public DATASET(): TerminalNode {
		return this.getToken(VtlParser.DATASET, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public compConstraint_list(): CompConstraintContext[] {
		return this.getTypedRuleContexts(CompConstraintContext) as CompConstraintContext[];
	}
	public compConstraint(i: number): CompConstraintContext {
		return this.getTypedRuleContext(CompConstraintContext, i) as CompConstraintContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_datasetType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDatasetType) {
			return visitor.visitDatasetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class EvalDatasetTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public datasetType(): DatasetTypeContext {
		return this.getTypedRuleContext(DatasetTypeContext, 0) as DatasetTypeContext;
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_evalDatasetType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitEvalDatasetType) {
			return visitor.visitEvalDatasetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarSetTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public SET(): TerminalNode {
		return this.getToken(VtlParser.SET, 0);
	}
	public LT(): TerminalNode {
		return this.getToken(VtlParser.LT, 0);
	}
	public scalarType(): ScalarTypeContext {
		return this.getTypedRuleContext(ScalarTypeContext, 0) as ScalarTypeContext;
	}
	public MT(): TerminalNode {
		return this.getToken(VtlParser.MT, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_scalarSetType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitScalarSetType) {
			return visitor.visitScalarSetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class DpRulesetContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_dpRuleset;
	}
	public copyFrom(ctx: DpRulesetContext): void {
		super.copyFrom(ctx);
	}
}
export class DataPointVdContext extends DpRulesetContext {
	constructor(parser: VtlParser, ctx: DpRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATAPOINT_ON_VD(): TerminalNode {
		return this.getToken(VtlParser.DATAPOINT_ON_VD, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public valueDomainName_list(): ValueDomainNameContext[] {
		return this.getTypedRuleContexts(ValueDomainNameContext) as ValueDomainNameContext[];
	}
	public valueDomainName(i: number): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, i) as ValueDomainNameContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(VtlParser.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDataPointVd) {
			return visitor.visitDataPointVd(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DataPointVarContext extends DpRulesetContext {
	constructor(parser: VtlParser, ctx: DpRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATAPOINT_ON_VAR(): TerminalNode {
		return this.getToken(VtlParser.DATAPOINT_ON_VAR, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public varID_list(): VarIDContext[] {
		return this.getTypedRuleContexts(VarIDContext) as VarIDContext[];
	}
	public varID(i: number): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, i) as VarIDContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(VtlParser.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDataPointVar) {
			return visitor.visitDataPointVar(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class DataPointContext extends DpRulesetContext {
	constructor(parser: VtlParser, ctx: DpRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public DATAPOINT(): TerminalNode {
		return this.getToken(VtlParser.DATAPOINT, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitDataPoint) {
			return visitor.visitDataPoint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HrRulesetContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_hrRuleset;
	}
	public copyFrom(ctx: HrRulesetContext): void {
		super.copyFrom(ctx);
	}
}
export class HrRulesetVdTypeContext extends HrRulesetContext {
	public _vdName!: Token;
	constructor(parser: VtlParser, ctx: HrRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public HIERARCHICAL_ON_VD(): TerminalNode {
		return this.getToken(VtlParser.HIERARCHICAL_ON_VD, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public valueDomainName_list(): ValueDomainNameContext[] {
		return this.getTypedRuleContexts(ValueDomainNameContext) as ValueDomainNameContext[];
	}
	public valueDomainName(i: number): ValueDomainNameContext {
		return this.getTypedRuleContext(ValueDomainNameContext, i) as ValueDomainNameContext;
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(VtlParser.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHrRulesetVdType) {
			return visitor.visitHrRulesetVdType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class HrRulesetVarTypeContext extends HrRulesetContext {
	public _varName!: VarIDContext;
	constructor(parser: VtlParser, ctx: HrRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public HIERARCHICAL_ON_VAR(): TerminalNode {
		return this.getToken(VtlParser.HIERARCHICAL_ON_VAR, 0);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public varID_list(): VarIDContext[] {
		return this.getTypedRuleContexts(VarIDContext) as VarIDContext[];
	}
	public varID(i: number): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, i) as VarIDContext;
	}
	public LPAREN(): TerminalNode {
		return this.getToken(VtlParser.LPAREN, 0);
	}
	public RPAREN(): TerminalNode {
		return this.getToken(VtlParser.RPAREN, 0);
	}
	public MUL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.MUL);
	}
	public MUL(i: number): TerminalNode {
		return this.getToken(VtlParser.MUL, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHrRulesetVarType) {
			return visitor.visitHrRulesetVarType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class HrRulesetTypeContext extends HrRulesetContext {
	constructor(parser: VtlParser, ctx: HrRulesetContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public HIERARCHICAL(): TerminalNode {
		return this.getToken(VtlParser.HIERARCHICAL, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHrRulesetType) {
			return visitor.visitHrRulesetType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainNameContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_valueDomainName;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValueDomainName) {
			return visitor.visitValueDomainName(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RulesetIDContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_rulesetID;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRulesetID) {
			return visitor.visitRulesetID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RulesetSignatureContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public signature_list(): SignatureContext[] {
		return this.getTypedRuleContexts(SignatureContext) as SignatureContext[];
	}
	public signature(i: number): SignatureContext {
		return this.getTypedRuleContext(SignatureContext, i) as SignatureContext;
	}
	public VALUE_DOMAIN(): TerminalNode {
		return this.getToken(VtlParser.VALUE_DOMAIN, 0);
	}
	public VARIABLE(): TerminalNode {
		return this.getToken(VtlParser.VARIABLE, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_rulesetSignature;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRulesetSignature) {
			return visitor.visitRulesetSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SignatureContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public varID(): VarIDContext {
		return this.getTypedRuleContext(VarIDContext, 0) as VarIDContext;
	}
	public AS(): TerminalNode {
		return this.getToken(VtlParser.AS, 0);
	}
	public alias(): AliasContext {
		return this.getTypedRuleContext(AliasContext, 0) as AliasContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_signature;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSignature) {
			return visitor.visitSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleClauseDatapointContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ruleItemDatapoint_list(): RuleItemDatapointContext[] {
		return this.getTypedRuleContexts(RuleItemDatapointContext) as RuleItemDatapointContext[];
	}
	public ruleItemDatapoint(i: number): RuleItemDatapointContext {
		return this.getTypedRuleContext(RuleItemDatapointContext, i) as RuleItemDatapointContext;
	}
	public EOL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.EOL);
	}
	public EOL(i: number): TerminalNode {
		return this.getToken(VtlParser.EOL, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_ruleClauseDatapoint;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRuleClauseDatapoint) {
			return visitor.visitRuleClauseDatapoint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleItemDatapointContext extends ParserRuleContext {
	public _ruleName!: Token;
	public _antecedentContiditon!: ExprComponentContext;
	public _consequentCondition!: ExprComponentContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public exprComponent_list(): ExprComponentContext[] {
		return this.getTypedRuleContexts(ExprComponentContext) as ExprComponentContext[];
	}
	public exprComponent(i: number): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, i) as ExprComponentContext;
	}
	public COLON(): TerminalNode {
		return this.getToken(VtlParser.COLON, 0);
	}
	public WHEN(): TerminalNode {
		return this.getToken(VtlParser.WHEN, 0);
	}
	public THEN(): TerminalNode {
		return this.getToken(VtlParser.THEN, 0);
	}
	public erCode(): ErCodeContext {
		return this.getTypedRuleContext(ErCodeContext, 0) as ErCodeContext;
	}
	public erLevel(): ErLevelContext {
		return this.getTypedRuleContext(ErLevelContext, 0) as ErLevelContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_ruleItemDatapoint;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRuleItemDatapoint) {
			return visitor.visitRuleItemDatapoint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleClauseHierarchicalContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ruleItemHierarchical_list(): RuleItemHierarchicalContext[] {
		return this.getTypedRuleContexts(RuleItemHierarchicalContext) as RuleItemHierarchicalContext[];
	}
	public ruleItemHierarchical(i: number): RuleItemHierarchicalContext {
		return this.getTypedRuleContext(RuleItemHierarchicalContext, i) as RuleItemHierarchicalContext;
	}
	public EOL_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.EOL);
	}
	public EOL(i: number): TerminalNode {
		return this.getToken(VtlParser.EOL, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_ruleClauseHierarchical;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRuleClauseHierarchical) {
			return visitor.visitRuleClauseHierarchical(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RuleItemHierarchicalContext extends ParserRuleContext {
	public _ruleName!: Token;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public codeItemRelation(): CodeItemRelationContext {
		return this.getTypedRuleContext(CodeItemRelationContext, 0) as CodeItemRelationContext;
	}
	public COLON(): TerminalNode {
		return this.getToken(VtlParser.COLON, 0);
	}
	public erCode(): ErCodeContext {
		return this.getTypedRuleContext(ErCodeContext, 0) as ErCodeContext;
	}
	public erLevel(): ErLevelContext {
		return this.getTypedRuleContext(ErLevelContext, 0) as ErLevelContext;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_ruleItemHierarchical;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRuleItemHierarchical) {
			return visitor.visitRuleItemHierarchical(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class HierRuleSignatureContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RULE(): TerminalNode {
		return this.getToken(VtlParser.RULE, 0);
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
	public VALUE_DOMAIN(): TerminalNode {
		return this.getToken(VtlParser.VALUE_DOMAIN, 0);
	}
	public VARIABLE(): TerminalNode {
		return this.getToken(VtlParser.VARIABLE, 0);
	}
	public CONDITION(): TerminalNode {
		return this.getToken(VtlParser.CONDITION, 0);
	}
	public valueDomainSignature(): ValueDomainSignatureContext {
		return this.getTypedRuleContext(ValueDomainSignatureContext, 0) as ValueDomainSignatureContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_hierRuleSignature;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitHierRuleSignature) {
			return visitor.visitHierRuleSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainSignatureContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public signature_list(): SignatureContext[] {
		return this.getTypedRuleContexts(SignatureContext) as SignatureContext[];
	}
	public signature(i: number): SignatureContext {
		return this.getTypedRuleContext(SignatureContext, i) as SignatureContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_valueDomainSignature;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValueDomainSignature) {
			return visitor.visitValueDomainSignature(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CodeItemRelationContext extends ParserRuleContext {
	public _codetemRef!: ValueDomainValueContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public codeItemRelationClause_list(): CodeItemRelationClauseContext[] {
		return this.getTypedRuleContexts(CodeItemRelationClauseContext) as CodeItemRelationClauseContext[];
	}
	public codeItemRelationClause(i: number): CodeItemRelationClauseContext {
		return this.getTypedRuleContext(CodeItemRelationClauseContext, i) as CodeItemRelationClauseContext;
	}
	public valueDomainValue(): ValueDomainValueContext {
		return this.getTypedRuleContext(ValueDomainValueContext, 0) as ValueDomainValueContext;
	}
	public WHEN(): TerminalNode {
		return this.getToken(VtlParser.WHEN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public THEN(): TerminalNode {
		return this.getToken(VtlParser.THEN, 0);
	}
	public comparisonOperand(): ComparisonOperandContext {
		return this.getTypedRuleContext(ComparisonOperandContext, 0) as ComparisonOperandContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_codeItemRelation;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCodeItemRelation) {
			return visitor.visitCodeItemRelation(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CodeItemRelationClauseContext extends ParserRuleContext {
	public _opAdd!: Token;
	public _rightCodeItem!: ValueDomainValueContext;
	public _rightCondition!: ExprComponentContext;
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public valueDomainValue(): ValueDomainValueContext {
		return this.getTypedRuleContext(ValueDomainValueContext, 0) as ValueDomainValueContext;
	}
	public QLPAREN(): TerminalNode {
		return this.getToken(VtlParser.QLPAREN, 0);
	}
	public QRPAREN(): TerminalNode {
		return this.getToken(VtlParser.QRPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
	public MINUS(): TerminalNode {
		return this.getToken(VtlParser.MINUS, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_codeItemRelationClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCodeItemRelationClause) {
			return visitor.visitCodeItemRelationClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainValueContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public signedNumber(): SignedNumberContext {
		return this.getTypedRuleContext(SignedNumberContext, 0) as SignedNumberContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_valueDomainValue;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValueDomainValue) {
			return visitor.visitValueDomainValue(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ScalarTypeConstraintContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_scalarTypeConstraint;
	}
	public copyFrom(ctx: ScalarTypeConstraintContext): void {
		super.copyFrom(ctx);
	}
}
export class RangeConstraintContext extends ScalarTypeConstraintContext {
	constructor(parser: VtlParser, ctx: ScalarTypeConstraintContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public scalarItem_list(): ScalarItemContext[] {
		return this.getTypedRuleContexts(ScalarItemContext) as ScalarItemContext[];
	}
	public scalarItem(i: number): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, i) as ScalarItemContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRangeConstraint) {
			return visitor.visitRangeConstraint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
export class ConditionConstraintContext extends ScalarTypeConstraintContext {
	constructor(parser: VtlParser, ctx: ScalarTypeConstraintContext) {
		super(parser, ctx.parentCtx, ctx.invokingState);
		super.copyFrom(ctx);
	}
	public QLPAREN(): TerminalNode {
		return this.getToken(VtlParser.QLPAREN, 0);
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public QRPAREN(): TerminalNode {
		return this.getToken(VtlParser.QRPAREN, 0);
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConditionConstraint) {
			return visitor.visitConditionConstraint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class CompConstraintContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public componentType(): ComponentTypeContext {
		return this.getTypedRuleContext(ComponentTypeContext, 0) as ComponentTypeContext;
	}
	public componentID(): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, 0) as ComponentIDContext;
	}
	public multModifier(): MultModifierContext {
		return this.getTypedRuleContext(MultModifierContext, 0) as MultModifierContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_compConstraint;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitCompConstraint) {
			return visitor.visitCompConstraint(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class MultModifierContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
	public PLUS(): TerminalNode {
		return this.getToken(VtlParser.PLUS, 0);
	}
	public MUL(): TerminalNode {
		return this.getToken(VtlParser.MUL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_multModifier;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitMultModifier) {
			return visitor.visitMultModifier(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValidationOutputContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public INVALID(): TerminalNode {
		return this.getToken(VtlParser.INVALID, 0);
	}
	public ALL_MEASURES(): TerminalNode {
		return this.getToken(VtlParser.ALL_MEASURES, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_validationOutput;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValidationOutput) {
			return visitor.visitValidationOutput(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValidationModeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public NON_NULL(): TerminalNode {
		return this.getToken(VtlParser.NON_NULL, 0);
	}
	public NON_ZERO(): TerminalNode {
		return this.getToken(VtlParser.NON_ZERO, 0);
	}
	public PARTIAL_NULL(): TerminalNode {
		return this.getToken(VtlParser.PARTIAL_NULL, 0);
	}
	public PARTIAL_ZERO(): TerminalNode {
		return this.getToken(VtlParser.PARTIAL_ZERO, 0);
	}
	public ALWAYS_NULL(): TerminalNode {
		return this.getToken(VtlParser.ALWAYS_NULL, 0);
	}
	public ALWAYS_ZERO(): TerminalNode {
		return this.getToken(VtlParser.ALWAYS_ZERO, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_validationMode;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValidationMode) {
			return visitor.visitValidationMode(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConditionClauseContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public CONDITION(): TerminalNode {
		return this.getToken(VtlParser.CONDITION, 0);
	}
	public componentID_list(): ComponentIDContext[] {
		return this.getTypedRuleContexts(ComponentIDContext) as ComponentIDContext[];
	}
	public componentID(i: number): ComponentIDContext {
		return this.getTypedRuleContext(ComponentIDContext, i) as ComponentIDContext;
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_conditionClause;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConditionClause) {
			return visitor.visitConditionClause(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InputModeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public DATASET(): TerminalNode {
		return this.getToken(VtlParser.DATASET, 0);
	}
	public DATASET_PRIORITY(): TerminalNode {
		return this.getToken(VtlParser.DATASET_PRIORITY, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_inputMode;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInputMode) {
			return visitor.visitInputMode(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ImbalanceExprContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IMBALANCE(): TerminalNode {
		return this.getToken(VtlParser.IMBALANCE, 0);
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_imbalanceExpr;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitImbalanceExpr) {
			return visitor.visitImbalanceExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class InputModeHierarchyContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public RULE(): TerminalNode {
		return this.getToken(VtlParser.RULE, 0);
	}
	public DATASET(): TerminalNode {
		return this.getToken(VtlParser.DATASET, 0);
	}
	public RULE_PRIORITY(): TerminalNode {
		return this.getToken(VtlParser.RULE_PRIORITY, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_inputModeHierarchy;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitInputModeHierarchy) {
			return visitor.visitInputModeHierarchy(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OutputModeHierarchyContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public COMPUTED(): TerminalNode {
		return this.getToken(VtlParser.COMPUTED, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_outputModeHierarchy;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOutputModeHierarchy) {
			return visitor.visitOutputModeHierarchy(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class AliasContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_alias;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitAlias) {
			return visitor.visitAlias(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class VarIDContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_varID;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitVarID) {
			return visitor.visitVarID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class SimpleComponentIdContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_simpleComponentId;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitSimpleComponentId) {
			return visitor.visitSimpleComponentId(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComponentIDContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.IDENTIFIER);
	}
	public IDENTIFIER(i: number): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, i);
	}
	public MEMBERSHIP(): TerminalNode {
		return this.getToken(VtlParser.MEMBERSHIP, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_componentID;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComponentID) {
			return visitor.visitComponentID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ListsContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public GLPAREN(): TerminalNode {
		return this.getToken(VtlParser.GLPAREN, 0);
	}
	public scalarItem_list(): ScalarItemContext[] {
		return this.getTypedRuleContexts(ScalarItemContext) as ScalarItemContext[];
	}
	public scalarItem(i: number): ScalarItemContext {
		return this.getTypedRuleContext(ScalarItemContext, i) as ScalarItemContext;
	}
	public GRPAREN(): TerminalNode {
		return this.getToken(VtlParser.GRPAREN, 0);
	}
	public COMMA_list(): TerminalNode[] {
	    	return this.getTokens(VtlParser.COMMA);
	}
	public COMMA(i: number): TerminalNode {
		return this.getToken(VtlParser.COMMA, i);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_lists;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitLists) {
			return visitor.visitLists(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ErCodeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ERRORCODE(): TerminalNode {
		return this.getToken(VtlParser.ERRORCODE, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_erCode;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitErCode) {
			return visitor.visitErCode(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ErLevelContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public ERRORLEVEL(): TerminalNode {
		return this.getToken(VtlParser.ERRORLEVEL, 0);
	}
	public constant(): ConstantContext {
		return this.getTypedRuleContext(ConstantContext, 0) as ConstantContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_erLevel;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitErLevel) {
			return visitor.visitErLevel(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComparisonOperandContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public MT(): TerminalNode {
		return this.getToken(VtlParser.MT, 0);
	}
	public ME(): TerminalNode {
		return this.getToken(VtlParser.ME, 0);
	}
	public LE(): TerminalNode {
		return this.getToken(VtlParser.LE, 0);
	}
	public LT(): TerminalNode {
		return this.getToken(VtlParser.LT, 0);
	}
	public EQ(): TerminalNode {
		return this.getToken(VtlParser.EQ, 0);
	}
	public NEQ(): TerminalNode {
		return this.getToken(VtlParser.NEQ, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_comparisonOperand;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComparisonOperand) {
			return visitor.visitComparisonOperand(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OptionalExprContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public expr(): ExprContext {
		return this.getTypedRuleContext(ExprContext, 0) as ExprContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_optionalExpr;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOptionalExpr) {
			return visitor.visitOptionalExpr(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OptionalExprComponentContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public exprComponent(): ExprComponentContext {
		return this.getTypedRuleContext(ExprComponentContext, 0) as ExprComponentContext;
	}
	public OPTIONAL(): TerminalNode {
		return this.getToken(VtlParser.OPTIONAL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_optionalExprComponent;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOptionalExprComponent) {
			return visitor.visitOptionalExprComponent(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ComponentRoleContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public MEASURE(): TerminalNode {
		return this.getToken(VtlParser.MEASURE, 0);
	}
	public COMPONENT(): TerminalNode {
		return this.getToken(VtlParser.COMPONENT, 0);
	}
	public DIMENSION(): TerminalNode {
		return this.getToken(VtlParser.DIMENSION, 0);
	}
	public ATTRIBUTE(): TerminalNode {
		return this.getToken(VtlParser.ATTRIBUTE, 0);
	}
	public viralAttribute(): ViralAttributeContext {
		return this.getTypedRuleContext(ViralAttributeContext, 0) as ViralAttributeContext;
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_componentRole;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitComponentRole) {
			return visitor.visitComponentRole(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ViralAttributeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public VIRAL(): TerminalNode {
		return this.getToken(VtlParser.VIRAL, 0);
	}
	public ATTRIBUTE(): TerminalNode {
		return this.getToken(VtlParser.ATTRIBUTE, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_viralAttribute;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitViralAttribute) {
			return visitor.visitViralAttribute(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ValueDomainIDContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_valueDomainID;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitValueDomainID) {
			return visitor.visitValueDomainID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class OperatorIDContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_operatorID;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitOperatorID) {
			return visitor.visitOperatorID(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RoutineNameContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public IDENTIFIER(): TerminalNode {
		return this.getToken(VtlParser.IDENTIFIER, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_routineName;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRoutineName) {
			return visitor.visitRoutineName(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class ConstantContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public signedInteger(): SignedIntegerContext {
		return this.getTypedRuleContext(SignedIntegerContext, 0) as SignedIntegerContext;
	}
	public signedNumber(): SignedNumberContext {
		return this.getTypedRuleContext(SignedNumberContext, 0) as SignedNumberContext;
	}
	public BOOLEAN_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.BOOLEAN_CONSTANT, 0);
	}
	public STRING_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.STRING_CONSTANT, 0);
	}
	public NULL_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.NULL_CONSTANT, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_constant;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitConstant) {
			return visitor.visitConstant(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class BasicScalarTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public STRING(): TerminalNode {
		return this.getToken(VtlParser.STRING, 0);
	}
	public INTEGER(): TerminalNode {
		return this.getToken(VtlParser.INTEGER, 0);
	}
	public NUMBER(): TerminalNode {
		return this.getToken(VtlParser.NUMBER, 0);
	}
	public BOOLEAN(): TerminalNode {
		return this.getToken(VtlParser.BOOLEAN, 0);
	}
	public DATE(): TerminalNode {
		return this.getToken(VtlParser.DATE, 0);
	}
	public TIME(): TerminalNode {
		return this.getToken(VtlParser.TIME, 0);
	}
	public TIME_PERIOD(): TerminalNode {
		return this.getToken(VtlParser.TIME_PERIOD, 0);
	}
	public DURATION(): TerminalNode {
		return this.getToken(VtlParser.DURATION, 0);
	}
	public SCALAR(): TerminalNode {
		return this.getToken(VtlParser.SCALAR, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_basicScalarType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitBasicScalarType) {
			return visitor.visitBasicScalarType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}


export class RetainTypeContext extends ParserRuleContext {
	constructor(parser?: VtlParser, parent?: ParserRuleContext, invokingState?: number) {
		super(parent, invokingState);
    	this.parser = parser;
	}
	public BOOLEAN_CONSTANT(): TerminalNode {
		return this.getToken(VtlParser.BOOLEAN_CONSTANT, 0);
	}
	public ALL(): TerminalNode {
		return this.getToken(VtlParser.ALL, 0);
	}
    public get ruleIndex(): number {
    	return VtlParser.RULE_retainType;
	}
	// @Override
	public accept<Result>(visitor: VtlParserVisitor<Result>): Result {
		if (visitor.visitRetainType) {
			return visitor.visitRetainType(this);
		} else {
			return visitor.visitChildren(this);
		}
	}
}
