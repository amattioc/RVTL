// Generated from org/sdmx/vtl/VtlParser.g4 by ANTLR 4.13.1

import {ParseTreeVisitor} from 'antlr4';


import { StartContext } from "./VtlParser";
import { TemporaryAssignmentContext } from "./VtlParser";
import { PersistAssignmentContext } from "./VtlParser";
import { DefineExpressionContext } from "./VtlParser";
import { VarIdExprContext } from "./VtlParser";
import { MembershipExprContext } from "./VtlParser";
import { InNotInExprContext } from "./VtlParser";
import { BooleanExprContext } from "./VtlParser";
import { ComparisonExprContext } from "./VtlParser";
import { UnaryExprContext } from "./VtlParser";
import { FunctionsExpressionContext } from "./VtlParser";
import { IfExprContext } from "./VtlParser";
import { ClauseExprContext } from "./VtlParser";
import { CaseExprContext } from "./VtlParser";
import { ArithmeticExprContext } from "./VtlParser";
import { ParenthesisExprContext } from "./VtlParser";
import { ConstantExprContext } from "./VtlParser";
import { ArithmeticExprOrConcatContext } from "./VtlParser";
import { ArithmeticExprCompContext } from "./VtlParser";
import { IfExprCompContext } from "./VtlParser";
import { ComparisonExprCompContext } from "./VtlParser";
import { FunctionsExpressionCompContext } from "./VtlParser";
import { CompIdContext } from "./VtlParser";
import { ConstantExprCompContext } from "./VtlParser";
import { ArithmeticExprOrConcatCompContext } from "./VtlParser";
import { ParenthesisExprCompContext } from "./VtlParser";
import { InNotInExprCompContext } from "./VtlParser";
import { UnaryExprCompContext } from "./VtlParser";
import { CaseExprCompContext } from "./VtlParser";
import { BooleanExprCompContext } from "./VtlParser";
import { GenericFunctionsComponentsContext } from "./VtlParser";
import { StringFunctionsComponentsContext } from "./VtlParser";
import { NumericFunctionsComponentsContext } from "./VtlParser";
import { ComparisonFunctionsComponentsContext } from "./VtlParser";
import { TimeFunctionsComponentsContext } from "./VtlParser";
import { ConditionalFunctionsComponentsContext } from "./VtlParser";
import { AggregateFunctionsComponentsContext } from "./VtlParser";
import { AnalyticFunctionsComponentsContext } from "./VtlParser";
import { JoinFunctionsContext } from "./VtlParser";
import { GenericFunctionsContext } from "./VtlParser";
import { StringFunctionsContext } from "./VtlParser";
import { NumericFunctionsContext } from "./VtlParser";
import { ComparisonFunctionsContext } from "./VtlParser";
import { TimeFunctionsContext } from "./VtlParser";
import { SetFunctionsContext } from "./VtlParser";
import { HierarchyFunctionsContext } from "./VtlParser";
import { ValidationFunctionsContext } from "./VtlParser";
import { ConditionalFunctionsContext } from "./VtlParser";
import { AggregateFunctionsContext } from "./VtlParser";
import { AnalyticFunctionsContext } from "./VtlParser";
import { DatasetClauseContext } from "./VtlParser";
import { RenameClauseContext } from "./VtlParser";
import { AggrClauseContext } from "./VtlParser";
import { FilterClauseContext } from "./VtlParser";
import { CalcClauseContext } from "./VtlParser";
import { KeepOrDropClauseContext } from "./VtlParser";
import { PivotOrUnpivotClauseContext } from "./VtlParser";
import { CustomPivotClauseContext } from "./VtlParser";
import { SubspaceClauseContext } from "./VtlParser";
import { JoinExprContext } from "./VtlParser";
import { DefOperatorContext } from "./VtlParser";
import { DefDatapointRulesetContext } from "./VtlParser";
import { DefHierarchicalContext } from "./VtlParser";
import { CallDatasetContext } from "./VtlParser";
import { EvalAtomContext } from "./VtlParser";
import { CastExprDatasetContext } from "./VtlParser";
import { CallComponentContext } from "./VtlParser";
import { CastExprComponentContext } from "./VtlParser";
import { EvalAtomComponentContext } from "./VtlParser";
import { ParameterComponentContext } from "./VtlParser";
import { ParameterContext } from "./VtlParser";
import { UnaryStringFunctionContext } from "./VtlParser";
import { SubstrAtomContext } from "./VtlParser";
import { ReplaceAtomContext } from "./VtlParser";
import { InstrAtomContext } from "./VtlParser";
import { UnaryStringFunctionComponentContext } from "./VtlParser";
import { SubstrAtomComponentContext } from "./VtlParser";
import { ReplaceAtomComponentContext } from "./VtlParser";
import { InstrAtomComponentContext } from "./VtlParser";
import { UnaryNumericContext } from "./VtlParser";
import { UnaryWithOptionalNumericContext } from "./VtlParser";
import { BinaryNumericContext } from "./VtlParser";
import { UnaryNumericComponentContext } from "./VtlParser";
import { UnaryWithOptionalNumericComponentContext } from "./VtlParser";
import { BinaryNumericComponentContext } from "./VtlParser";
import { BetweenAtomContext } from "./VtlParser";
import { CharsetMatchAtomContext } from "./VtlParser";
import { IsNullAtomContext } from "./VtlParser";
import { ExistInAtomContext } from "./VtlParser";
import { BetweenAtomComponentContext } from "./VtlParser";
import { CharsetMatchAtomComponentContext } from "./VtlParser";
import { IsNullAtomComponentContext } from "./VtlParser";
import { PeriodAtomContext } from "./VtlParser";
import { FillTimeAtomContext } from "./VtlParser";
import { FlowAtomContext } from "./VtlParser";
import { TimeShiftAtomContext } from "./VtlParser";
import { TimeAggAtomContext } from "./VtlParser";
import { CurrentDateAtomContext } from "./VtlParser";
import { DateDiffAtomContext } from "./VtlParser";
import { DateAddAtomContext } from "./VtlParser";
import { YearAtomContext } from "./VtlParser";
import { MonthAtomContext } from "./VtlParser";
import { DayOfMonthAtomContext } from "./VtlParser";
import { DayOfYearAtomContext } from "./VtlParser";
import { DayToYearAtomContext } from "./VtlParser";
import { DayToMonthAtomContext } from "./VtlParser";
import { YearTodayAtomContext } from "./VtlParser";
import { MonthTodayAtomContext } from "./VtlParser";
import { PeriodAtomComponentContext } from "./VtlParser";
import { FillTimeAtomComponentContext } from "./VtlParser";
import { FlowAtomComponentContext } from "./VtlParser";
import { TimeShiftAtomComponentContext } from "./VtlParser";
import { TimeAggAtomComponentContext } from "./VtlParser";
import { CurrentDateAtomComponentContext } from "./VtlParser";
import { DateDiffAtomComponentContext } from "./VtlParser";
import { DateAddAtomComponentContext } from "./VtlParser";
import { YearAtomComponentContext } from "./VtlParser";
import { MonthAtomComponentContext } from "./VtlParser";
import { DayOfMonthAtomComponentContext } from "./VtlParser";
import { DatOfYearAtomComponentContext } from "./VtlParser";
import { DayToYearAtomComponentContext } from "./VtlParser";
import { DayToMonthAtomComponentContext } from "./VtlParser";
import { YearTodayAtomComponentContext } from "./VtlParser";
import { MonthTodayAtomComponentContext } from "./VtlParser";
import { UnionAtomContext } from "./VtlParser";
import { IntersectAtomContext } from "./VtlParser";
import { SetOrSYmDiffAtomContext } from "./VtlParser";
import { HierarchyOperatorsContext } from "./VtlParser";
import { ValidateDPrulesetContext } from "./VtlParser";
import { ValidateHRrulesetContext } from "./VtlParser";
import { ValidationSimpleContext } from "./VtlParser";
import { NvlAtomContext } from "./VtlParser";
import { NvlAtomComponentContext } from "./VtlParser";
import { AggrCompContext } from "./VtlParser";
import { CountAggrCompContext } from "./VtlParser";
import { AggrDatasetContext } from "./VtlParser";
import { AnSimpleFunctionContext } from "./VtlParser";
import { LagOrLeadAnContext } from "./VtlParser";
import { RatioToReportAnContext } from "./VtlParser";
import { AnSimpleFunctionComponentContext } from "./VtlParser";
import { LagOrLeadAnComponentContext } from "./VtlParser";
import { RankAnComponentContext } from "./VtlParser";
import { RatioToReportAnComponentContext } from "./VtlParser";
import { RenameClauseItemContext } from "./VtlParser";
import { AggregateClauseContext } from "./VtlParser";
import { AggrFunctionClauseContext } from "./VtlParser";
import { CalcClauseItemContext } from "./VtlParser";
import { SubspaceClauseItemContext } from "./VtlParser";
import { SimpleScalarContext } from "./VtlParser";
import { ScalarWithCastContext } from "./VtlParser";
import { JoinClauseWithoutUsingContext } from "./VtlParser";
import { JoinClauseContext } from "./VtlParser";
import { JoinClauseItemContext } from "./VtlParser";
import { JoinBodyContext } from "./VtlParser";
import { JoinApplyClauseContext } from "./VtlParser";
import { PartitionByClauseContext } from "./VtlParser";
import { OrderByClauseContext } from "./VtlParser";
import { OrderByItemContext } from "./VtlParser";
import { WindowingClauseContext } from "./VtlParser";
import { SignedIntegerContext } from "./VtlParser";
import { SignedNumberContext } from "./VtlParser";
import { LimitClauseItemContext } from "./VtlParser";
import { GroupByOrExceptContext } from "./VtlParser";
import { GroupAllContext } from "./VtlParser";
import { HavingClauseContext } from "./VtlParser";
import { ParameterItemContext } from "./VtlParser";
import { OutputParameterTypeContext } from "./VtlParser";
import { OutputParameterTypeComponentContext } from "./VtlParser";
import { InputParameterTypeContext } from "./VtlParser";
import { RulesetTypeContext } from "./VtlParser";
import { ScalarTypeContext } from "./VtlParser";
import { ComponentTypeContext } from "./VtlParser";
import { DatasetTypeContext } from "./VtlParser";
import { EvalDatasetTypeContext } from "./VtlParser";
import { ScalarSetTypeContext } from "./VtlParser";
import { DataPointContext } from "./VtlParser";
import { DataPointVdContext } from "./VtlParser";
import { DataPointVarContext } from "./VtlParser";
import { HrRulesetTypeContext } from "./VtlParser";
import { HrRulesetVdTypeContext } from "./VtlParser";
import { HrRulesetVarTypeContext } from "./VtlParser";
import { ValueDomainNameContext } from "./VtlParser";
import { RulesetIDContext } from "./VtlParser";
import { RulesetSignatureContext } from "./VtlParser";
import { SignatureContext } from "./VtlParser";
import { RuleClauseDatapointContext } from "./VtlParser";
import { RuleItemDatapointContext } from "./VtlParser";
import { RuleClauseHierarchicalContext } from "./VtlParser";
import { RuleItemHierarchicalContext } from "./VtlParser";
import { HierRuleSignatureContext } from "./VtlParser";
import { ValueDomainSignatureContext } from "./VtlParser";
import { CodeItemRelationContext } from "./VtlParser";
import { CodeItemRelationClauseContext } from "./VtlParser";
import { ValueDomainValueContext } from "./VtlParser";
import { ConditionConstraintContext } from "./VtlParser";
import { RangeConstraintContext } from "./VtlParser";
import { CompConstraintContext } from "./VtlParser";
import { MultModifierContext } from "./VtlParser";
import { ValidationOutputContext } from "./VtlParser";
import { ValidationModeContext } from "./VtlParser";
import { ConditionClauseContext } from "./VtlParser";
import { InputModeContext } from "./VtlParser";
import { ImbalanceExprContext } from "./VtlParser";
import { InputModeHierarchyContext } from "./VtlParser";
import { OutputModeHierarchyContext } from "./VtlParser";
import { AliasContext } from "./VtlParser";
import { VarIDContext } from "./VtlParser";
import { SimpleComponentIdContext } from "./VtlParser";
import { ComponentIDContext } from "./VtlParser";
import { ListsContext } from "./VtlParser";
import { ErCodeContext } from "./VtlParser";
import { ErLevelContext } from "./VtlParser";
import { ComparisonOperandContext } from "./VtlParser";
import { OptionalExprContext } from "./VtlParser";
import { OptionalExprComponentContext } from "./VtlParser";
import { ComponentRoleContext } from "./VtlParser";
import { ViralAttributeContext } from "./VtlParser";
import { ValueDomainIDContext } from "./VtlParser";
import { OperatorIDContext } from "./VtlParser";
import { RoutineNameContext } from "./VtlParser";
import { ConstantContext } from "./VtlParser";
import { BasicScalarTypeContext } from "./VtlParser";
import { RetainTypeContext } from "./VtlParser";


/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by `VtlParser`.
 *
 * @param <Result> The return type of the visit operation. Use `void` for
 * operations with no return type.
 */
export default class VtlParserVisitor<Result> extends ParseTreeVisitor<Result> {
	/**
	 * Visit a parse tree produced by `VtlParser.start`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStart?: (ctx: StartContext) => Result;
	/**
	 * Visit a parse tree produced by the `temporaryAssignment`
	 * labeled alternative in `VtlParser.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTemporaryAssignment?: (ctx: TemporaryAssignmentContext) => Result;
	/**
	 * Visit a parse tree produced by the `persistAssignment`
	 * labeled alternative in `VtlParser.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPersistAssignment?: (ctx: PersistAssignmentContext) => Result;
	/**
	 * Visit a parse tree produced by the `defineExpression`
	 * labeled alternative in `VtlParser.statement`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefineExpression?: (ctx: DefineExpressionContext) => Result;
	/**
	 * Visit a parse tree produced by the `varIdExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVarIdExpr?: (ctx: VarIdExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `membershipExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMembershipExpr?: (ctx: MembershipExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `inNotInExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInNotInExpr?: (ctx: InNotInExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `booleanExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBooleanExpr?: (ctx: BooleanExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonExpr?: (ctx: ComparisonExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryExpr?: (ctx: UnaryExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `functionsExpression`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFunctionsExpression?: (ctx: FunctionsExpressionContext) => Result;
	/**
	 * Visit a parse tree produced by the `ifExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIfExpr?: (ctx: IfExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `clauseExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitClauseExpr?: (ctx: ClauseExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `caseExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCaseExpr?: (ctx: CaseExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExpr?: (ctx: ArithmeticExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `parenthesisExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParenthesisExpr?: (ctx: ParenthesisExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `constantExpr`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConstantExpr?: (ctx: ConstantExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExprOrConcat`
	 * labeled alternative in `VtlParser.expr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExprOrConcat?: (ctx: ArithmeticExprOrConcatContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExprComp?: (ctx: ArithmeticExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `ifExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIfExprComp?: (ctx: IfExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonExprComp?: (ctx: ComparisonExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `functionsExpressionComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFunctionsExpressionComp?: (ctx: FunctionsExpressionCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `compId`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCompId?: (ctx: CompIdContext) => Result;
	/**
	 * Visit a parse tree produced by the `constantExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConstantExprComp?: (ctx: ConstantExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `arithmeticExprOrConcatComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitArithmeticExprOrConcatComp?: (ctx: ArithmeticExprOrConcatCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `parenthesisExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParenthesisExprComp?: (ctx: ParenthesisExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `inNotInExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInNotInExprComp?: (ctx: InNotInExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryExprComp?: (ctx: UnaryExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `caseExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCaseExprComp?: (ctx: CaseExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `booleanExprComp`
	 * labeled alternative in `VtlParser.exprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBooleanExprComp?: (ctx: BooleanExprCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `genericFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGenericFunctionsComponents?: (ctx: GenericFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `stringFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStringFunctionsComponents?: (ctx: StringFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `numericFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNumericFunctionsComponents?: (ctx: NumericFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonFunctionsComponents?: (ctx: ComparisonFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeFunctionsComponents?: (ctx: TimeFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `conditionalFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionalFunctionsComponents?: (ctx: ConditionalFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggregateFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggregateFunctionsComponents?: (ctx: AggregateFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `analyticFunctionsComponents`
	 * labeled alternative in `VtlParser.functionsComponents`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnalyticFunctionsComponents?: (ctx: AnalyticFunctionsComponentsContext) => Result;
	/**
	 * Visit a parse tree produced by the `joinFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinFunctions?: (ctx: JoinFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `genericFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGenericFunctions?: (ctx: GenericFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `stringFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitStringFunctions?: (ctx: StringFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `numericFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNumericFunctions?: (ctx: NumericFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `comparisonFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonFunctions?: (ctx: ComparisonFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeFunctions?: (ctx: TimeFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `setFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSetFunctions?: (ctx: SetFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `hierarchyFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHierarchyFunctions?: (ctx: HierarchyFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `validationFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationFunctions?: (ctx: ValidationFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `conditionalFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionalFunctions?: (ctx: ConditionalFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggregateFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggregateFunctions?: (ctx: AggregateFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by the `analyticFunctions`
	 * labeled alternative in `VtlParser.functions`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnalyticFunctions?: (ctx: AnalyticFunctionsContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.datasetClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDatasetClause?: (ctx: DatasetClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.renameClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRenameClause?: (ctx: RenameClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.aggrClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrClause?: (ctx: AggrClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.filterClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFilterClause?: (ctx: FilterClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.calcClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCalcClause?: (ctx: CalcClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.keepOrDropClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitKeepOrDropClause?: (ctx: KeepOrDropClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.pivotOrUnpivotClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPivotOrUnpivotClause?: (ctx: PivotOrUnpivotClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.customPivotClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCustomPivotClause?: (ctx: CustomPivotClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.subspaceClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubspaceClause?: (ctx: SubspaceClauseContext) => Result;
	/**
	 * Visit a parse tree produced by the `joinExpr`
	 * labeled alternative in `VtlParser.joinOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinExpr?: (ctx: JoinExprContext) => Result;
	/**
	 * Visit a parse tree produced by the `defOperator`
	 * labeled alternative in `VtlParser.defOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefOperator?: (ctx: DefOperatorContext) => Result;
	/**
	 * Visit a parse tree produced by the `defDatapointRuleset`
	 * labeled alternative in `VtlParser.defOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefDatapointRuleset?: (ctx: DefDatapointRulesetContext) => Result;
	/**
	 * Visit a parse tree produced by the `defHierarchical`
	 * labeled alternative in `VtlParser.defOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDefHierarchical?: (ctx: DefHierarchicalContext) => Result;
	/**
	 * Visit a parse tree produced by the `callDataset`
	 * labeled alternative in `VtlParser.genericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCallDataset?: (ctx: CallDatasetContext) => Result;
	/**
	 * Visit a parse tree produced by the `evalAtom`
	 * labeled alternative in `VtlParser.genericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEvalAtom?: (ctx: EvalAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `castExprDataset`
	 * labeled alternative in `VtlParser.genericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCastExprDataset?: (ctx: CastExprDatasetContext) => Result;
	/**
	 * Visit a parse tree produced by the `callComponent`
	 * labeled alternative in `VtlParser.genericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCallComponent?: (ctx: CallComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `castExprComponent`
	 * labeled alternative in `VtlParser.genericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCastExprComponent?: (ctx: CastExprComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `evalAtomComponent`
	 * labeled alternative in `VtlParser.genericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEvalAtomComponent?: (ctx: EvalAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.parameterComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParameterComponent?: (ctx: ParameterComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.parameter`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParameter?: (ctx: ParameterContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryStringFunction`
	 * labeled alternative in `VtlParser.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryStringFunction?: (ctx: UnaryStringFunctionContext) => Result;
	/**
	 * Visit a parse tree produced by the `substrAtom`
	 * labeled alternative in `VtlParser.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubstrAtom?: (ctx: SubstrAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `replaceAtom`
	 * labeled alternative in `VtlParser.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitReplaceAtom?: (ctx: ReplaceAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `instrAtom`
	 * labeled alternative in `VtlParser.stringOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInstrAtom?: (ctx: InstrAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryStringFunctionComponent`
	 * labeled alternative in `VtlParser.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryStringFunctionComponent?: (ctx: UnaryStringFunctionComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `substrAtomComponent`
	 * labeled alternative in `VtlParser.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubstrAtomComponent?: (ctx: SubstrAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `replaceAtomComponent`
	 * labeled alternative in `VtlParser.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitReplaceAtomComponent?: (ctx: ReplaceAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `instrAtomComponent`
	 * labeled alternative in `VtlParser.stringOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInstrAtomComponent?: (ctx: InstrAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryNumeric`
	 * labeled alternative in `VtlParser.numericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryNumeric?: (ctx: UnaryNumericContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryWithOptionalNumeric`
	 * labeled alternative in `VtlParser.numericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryWithOptionalNumeric?: (ctx: UnaryWithOptionalNumericContext) => Result;
	/**
	 * Visit a parse tree produced by the `binaryNumeric`
	 * labeled alternative in `VtlParser.numericOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBinaryNumeric?: (ctx: BinaryNumericContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryNumericComponent`
	 * labeled alternative in `VtlParser.numericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryNumericComponent?: (ctx: UnaryNumericComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `unaryWithOptionalNumericComponent`
	 * labeled alternative in `VtlParser.numericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnaryWithOptionalNumericComponent?: (ctx: UnaryWithOptionalNumericComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `binaryNumericComponent`
	 * labeled alternative in `VtlParser.numericOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBinaryNumericComponent?: (ctx: BinaryNumericComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `betweenAtom`
	 * labeled alternative in `VtlParser.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBetweenAtom?: (ctx: BetweenAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `charsetMatchAtom`
	 * labeled alternative in `VtlParser.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCharsetMatchAtom?: (ctx: CharsetMatchAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `isNullAtom`
	 * labeled alternative in `VtlParser.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIsNullAtom?: (ctx: IsNullAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `existInAtom`
	 * labeled alternative in `VtlParser.comparisonOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitExistInAtom?: (ctx: ExistInAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `betweenAtomComponent`
	 * labeled alternative in `VtlParser.comparisonOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBetweenAtomComponent?: (ctx: BetweenAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `charsetMatchAtomComponent`
	 * labeled alternative in `VtlParser.comparisonOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCharsetMatchAtomComponent?: (ctx: CharsetMatchAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `isNullAtomComponent`
	 * labeled alternative in `VtlParser.comparisonOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIsNullAtomComponent?: (ctx: IsNullAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `periodAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPeriodAtom?: (ctx: PeriodAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `fillTimeAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFillTimeAtom?: (ctx: FillTimeAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `flowAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFlowAtom?: (ctx: FlowAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeShiftAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeShiftAtom?: (ctx: TimeShiftAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeAggAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeAggAtom?: (ctx: TimeAggAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `currentDateAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCurrentDateAtom?: (ctx: CurrentDateAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `dateDiffAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDateDiffAtom?: (ctx: DateDiffAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `dateAddAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDateAddAtom?: (ctx: DateAddAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `yearAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitYearAtom?: (ctx: YearAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `monthAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMonthAtom?: (ctx: MonthAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayOfMonthAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayOfMonthAtom?: (ctx: DayOfMonthAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayOfYearAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayOfYearAtom?: (ctx: DayOfYearAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayToYearAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayToYearAtom?: (ctx: DayToYearAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayToMonthAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayToMonthAtom?: (ctx: DayToMonthAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `yearTodayAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitYearTodayAtom?: (ctx: YearTodayAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `monthTodayAtom`
	 * labeled alternative in `VtlParser.timeOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMonthTodayAtom?: (ctx: MonthTodayAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `periodAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPeriodAtomComponent?: (ctx: PeriodAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `fillTimeAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFillTimeAtomComponent?: (ctx: FillTimeAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `flowAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitFlowAtomComponent?: (ctx: FlowAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeShiftAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeShiftAtomComponent?: (ctx: TimeShiftAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `timeAggAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitTimeAggAtomComponent?: (ctx: TimeAggAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `currentDateAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCurrentDateAtomComponent?: (ctx: CurrentDateAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `dateDiffAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDateDiffAtomComponent?: (ctx: DateDiffAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `dateAddAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDateAddAtomComponent?: (ctx: DateAddAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `yearAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitYearAtomComponent?: (ctx: YearAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `monthAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMonthAtomComponent?: (ctx: MonthAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayOfMonthAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayOfMonthAtomComponent?: (ctx: DayOfMonthAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `datOfYearAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDatOfYearAtomComponent?: (ctx: DatOfYearAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayToYearAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayToYearAtomComponent?: (ctx: DayToYearAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `dayToMonthAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDayToMonthAtomComponent?: (ctx: DayToMonthAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `yearTodayAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitYearTodayAtomComponent?: (ctx: YearTodayAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `monthTodayAtomComponent`
	 * labeled alternative in `VtlParser.timeOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMonthTodayAtomComponent?: (ctx: MonthTodayAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `unionAtom`
	 * labeled alternative in `VtlParser.setOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitUnionAtom?: (ctx: UnionAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `intersectAtom`
	 * labeled alternative in `VtlParser.setOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitIntersectAtom?: (ctx: IntersectAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `setOrSYmDiffAtom`
	 * labeled alternative in `VtlParser.setOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSetOrSYmDiffAtom?: (ctx: SetOrSYmDiffAtomContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.hierarchyOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHierarchyOperators?: (ctx: HierarchyOperatorsContext) => Result;
	/**
	 * Visit a parse tree produced by the `validateDPruleset`
	 * labeled alternative in `VtlParser.validationOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidateDPruleset?: (ctx: ValidateDPrulesetContext) => Result;
	/**
	 * Visit a parse tree produced by the `validateHRruleset`
	 * labeled alternative in `VtlParser.validationOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidateHRruleset?: (ctx: ValidateHRrulesetContext) => Result;
	/**
	 * Visit a parse tree produced by the `validationSimple`
	 * labeled alternative in `VtlParser.validationOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationSimple?: (ctx: ValidationSimpleContext) => Result;
	/**
	 * Visit a parse tree produced by the `nvlAtom`
	 * labeled alternative in `VtlParser.conditionalOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNvlAtom?: (ctx: NvlAtomContext) => Result;
	/**
	 * Visit a parse tree produced by the `nvlAtomComponent`
	 * labeled alternative in `VtlParser.conditionalOperatorsComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitNvlAtomComponent?: (ctx: NvlAtomComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggrComp`
	 * labeled alternative in `VtlParser.aggrOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrComp?: (ctx: AggrCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `countAggrComp`
	 * labeled alternative in `VtlParser.aggrOperators`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCountAggrComp?: (ctx: CountAggrCompContext) => Result;
	/**
	 * Visit a parse tree produced by the `aggrDataset`
	 * labeled alternative in `VtlParser.aggrOperatorsGrouping`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrDataset?: (ctx: AggrDatasetContext) => Result;
	/**
	 * Visit a parse tree produced by the `anSimpleFunction`
	 * labeled alternative in `VtlParser.anFunction`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnSimpleFunction?: (ctx: AnSimpleFunctionContext) => Result;
	/**
	 * Visit a parse tree produced by the `lagOrLeadAn`
	 * labeled alternative in `VtlParser.anFunction`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLagOrLeadAn?: (ctx: LagOrLeadAnContext) => Result;
	/**
	 * Visit a parse tree produced by the `ratioToReportAn`
	 * labeled alternative in `VtlParser.anFunction`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRatioToReportAn?: (ctx: RatioToReportAnContext) => Result;
	/**
	 * Visit a parse tree produced by the `anSimpleFunctionComponent`
	 * labeled alternative in `VtlParser.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAnSimpleFunctionComponent?: (ctx: AnSimpleFunctionComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `lagOrLeadAnComponent`
	 * labeled alternative in `VtlParser.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLagOrLeadAnComponent?: (ctx: LagOrLeadAnComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `rankAnComponent`
	 * labeled alternative in `VtlParser.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRankAnComponent?: (ctx: RankAnComponentContext) => Result;
	/**
	 * Visit a parse tree produced by the `ratioToReportAnComponent`
	 * labeled alternative in `VtlParser.anFunctionComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRatioToReportAnComponent?: (ctx: RatioToReportAnComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.renameClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRenameClauseItem?: (ctx: RenameClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.aggregateClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggregateClause?: (ctx: AggregateClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.aggrFunctionClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAggrFunctionClause?: (ctx: AggrFunctionClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.calcClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCalcClauseItem?: (ctx: CalcClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.subspaceClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSubspaceClauseItem?: (ctx: SubspaceClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by the `simpleScalar`
	 * labeled alternative in `VtlParser.scalarItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSimpleScalar?: (ctx: SimpleScalarContext) => Result;
	/**
	 * Visit a parse tree produced by the `scalarWithCast`
	 * labeled alternative in `VtlParser.scalarItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitScalarWithCast?: (ctx: ScalarWithCastContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.joinClauseWithoutUsing`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinClauseWithoutUsing?: (ctx: JoinClauseWithoutUsingContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.joinClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinClause?: (ctx: JoinClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.joinClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinClauseItem?: (ctx: JoinClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.joinBody`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinBody?: (ctx: JoinBodyContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.joinApplyClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitJoinApplyClause?: (ctx: JoinApplyClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.partitionByClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitPartitionByClause?: (ctx: PartitionByClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.orderByClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOrderByClause?: (ctx: OrderByClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.orderByItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOrderByItem?: (ctx: OrderByItemContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.windowingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitWindowingClause?: (ctx: WindowingClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.signedInteger`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSignedInteger?: (ctx: SignedIntegerContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.signedNumber`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSignedNumber?: (ctx: SignedNumberContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.limitClauseItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLimitClauseItem?: (ctx: LimitClauseItemContext) => Result;
	/**
	 * Visit a parse tree produced by the `groupByOrExcept`
	 * labeled alternative in `VtlParser.groupingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGroupByOrExcept?: (ctx: GroupByOrExceptContext) => Result;
	/**
	 * Visit a parse tree produced by the `groupAll`
	 * labeled alternative in `VtlParser.groupingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitGroupAll?: (ctx: GroupAllContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.havingClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHavingClause?: (ctx: HavingClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.parameterItem`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitParameterItem?: (ctx: ParameterItemContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.outputParameterType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOutputParameterType?: (ctx: OutputParameterTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.outputParameterTypeComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOutputParameterTypeComponent?: (ctx: OutputParameterTypeComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.inputParameterType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInputParameterType?: (ctx: InputParameterTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.rulesetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRulesetType?: (ctx: RulesetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.scalarType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitScalarType?: (ctx: ScalarTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.componentType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponentType?: (ctx: ComponentTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.datasetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDatasetType?: (ctx: DatasetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.evalDatasetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitEvalDatasetType?: (ctx: EvalDatasetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.scalarSetType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitScalarSetType?: (ctx: ScalarSetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by the `dataPoint`
	 * labeled alternative in `VtlParser.dpRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDataPoint?: (ctx: DataPointContext) => Result;
	/**
	 * Visit a parse tree produced by the `dataPointVd`
	 * labeled alternative in `VtlParser.dpRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDataPointVd?: (ctx: DataPointVdContext) => Result;
	/**
	 * Visit a parse tree produced by the `dataPointVar`
	 * labeled alternative in `VtlParser.dpRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitDataPointVar?: (ctx: DataPointVarContext) => Result;
	/**
	 * Visit a parse tree produced by the `hrRulesetType`
	 * labeled alternative in `VtlParser.hrRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHrRulesetType?: (ctx: HrRulesetTypeContext) => Result;
	/**
	 * Visit a parse tree produced by the `hrRulesetVdType`
	 * labeled alternative in `VtlParser.hrRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHrRulesetVdType?: (ctx: HrRulesetVdTypeContext) => Result;
	/**
	 * Visit a parse tree produced by the `hrRulesetVarType`
	 * labeled alternative in `VtlParser.hrRuleset`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHrRulesetVarType?: (ctx: HrRulesetVarTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.valueDomainName`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainName?: (ctx: ValueDomainNameContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.rulesetID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRulesetID?: (ctx: RulesetIDContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.rulesetSignature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRulesetSignature?: (ctx: RulesetSignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.signature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSignature?: (ctx: SignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.ruleClauseDatapoint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleClauseDatapoint?: (ctx: RuleClauseDatapointContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.ruleItemDatapoint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleItemDatapoint?: (ctx: RuleItemDatapointContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.ruleClauseHierarchical`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleClauseHierarchical?: (ctx: RuleClauseHierarchicalContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.ruleItemHierarchical`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRuleItemHierarchical?: (ctx: RuleItemHierarchicalContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.hierRuleSignature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitHierRuleSignature?: (ctx: HierRuleSignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.valueDomainSignature`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainSignature?: (ctx: ValueDomainSignatureContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.codeItemRelation`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCodeItemRelation?: (ctx: CodeItemRelationContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.codeItemRelationClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCodeItemRelationClause?: (ctx: CodeItemRelationClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.valueDomainValue`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainValue?: (ctx: ValueDomainValueContext) => Result;
	/**
	 * Visit a parse tree produced by the `conditionConstraint`
	 * labeled alternative in `VtlParser.scalarTypeConstraint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionConstraint?: (ctx: ConditionConstraintContext) => Result;
	/**
	 * Visit a parse tree produced by the `rangeConstraint`
	 * labeled alternative in `VtlParser.scalarTypeConstraint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRangeConstraint?: (ctx: RangeConstraintContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.compConstraint`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitCompConstraint?: (ctx: CompConstraintContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.multModifier`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitMultModifier?: (ctx: MultModifierContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.validationOutput`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationOutput?: (ctx: ValidationOutputContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.validationMode`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValidationMode?: (ctx: ValidationModeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.conditionClause`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConditionClause?: (ctx: ConditionClauseContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.inputMode`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInputMode?: (ctx: InputModeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.imbalanceExpr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitImbalanceExpr?: (ctx: ImbalanceExprContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.inputModeHierarchy`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitInputModeHierarchy?: (ctx: InputModeHierarchyContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.outputModeHierarchy`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOutputModeHierarchy?: (ctx: OutputModeHierarchyContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.alias`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitAlias?: (ctx: AliasContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.varID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitVarID?: (ctx: VarIDContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.simpleComponentId`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitSimpleComponentId?: (ctx: SimpleComponentIdContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.componentID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponentID?: (ctx: ComponentIDContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.lists`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitLists?: (ctx: ListsContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.erCode`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitErCode?: (ctx: ErCodeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.erLevel`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitErLevel?: (ctx: ErLevelContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.comparisonOperand`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComparisonOperand?: (ctx: ComparisonOperandContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.optionalExpr`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOptionalExpr?: (ctx: OptionalExprContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.optionalExprComponent`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOptionalExprComponent?: (ctx: OptionalExprComponentContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.componentRole`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitComponentRole?: (ctx: ComponentRoleContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.viralAttribute`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitViralAttribute?: (ctx: ViralAttributeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.valueDomainID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitValueDomainID?: (ctx: ValueDomainIDContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.operatorID`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitOperatorID?: (ctx: OperatorIDContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.routineName`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRoutineName?: (ctx: RoutineNameContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.constant`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitConstant?: (ctx: ConstantContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.basicScalarType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitBasicScalarType?: (ctx: BasicScalarTypeContext) => Result;
	/**
	 * Visit a parse tree produced by `VtlParser.retainType`.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	visitRetainType?: (ctx: RetainTypeContext) => Result;
}

